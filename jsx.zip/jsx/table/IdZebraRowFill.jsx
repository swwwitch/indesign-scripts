#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdZebraRowFill
Name=表の行に交互の塗り（縞模様）を適用
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.4.6
Release-Date=2026-04-17
Description-BEGIN
選択した表セルに、選択範囲内の行の並びを基準に交互の塗り（縞模様）をプレビュー付きで適用します。
上から／左から指定した数の行・列は、塗りの対象外にできます。

Applies alternating fills (zebra striping) to the selected table cells, based on the row order within the selection, with a live preview.
A given number of rows from the top, and columns from the left, can be left out of the fill.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択した表セルに、選択範囲内の行の並びを基準に交互の塗り（縞模様）をプレビュー付きで適用します。
上から／左から指定した数の行・列は、塗りの対象外にできます。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdZebraRowFill.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n20ff60f6b508

### Overview

Applies alternating fills (zebra striping) to the selected table cells, based on the row order within the selection, with a live preview.
A given number of rows from the top, and columns from the left, can be left out of the fill.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdZebraRowFill.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdZebraRowFill";               /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.4.6";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-04-17";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "表の行に交互の塗り（縞模様）を適用"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdZebraRowFill.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdZebraRowFill.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n20ff60f6b508"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/table/IdZebraRowFill.jsx"; /* 最新版のソース / latest source */

// Original idea
// KK sawa

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

// =========================================
// ユーザー設定 / User settings
// =========================================

/* 濃淡（Tint）の初期値と範囲 / Initial value and range of the tint control */
var TINT_DEFAULT = 100;
var TINT_MIN     = 0;
var TINT_MAX     = 100;

/* 濃淡スライダーの刻み幅（通常 / Shift / Option）/ Tint slider steps (normal, Shift, Option) */
var TINT_STEP_NORMAL = 1;
var TINT_STEP_SHIFT  = 10;
var TINT_STEP_OPTION = 5;

/* ［行のスキップ］［列のスキップ］の初期値 / Initial number of rows and columns to skip */
var SKIP_COUNT_DEFAULT = 1;

// =========================================
// レイアウト設定 / Layout settings
// =========================================

// UIレイアウト（再利用パーツ） / UI layout (reusable)

/* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

/**
 * ウィンドウの共通設定
 * @param {Window} targetWindow - 対象のウィンドウ
 * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
 * @returns {void}
 */
function setupWindow(targetWindow, spacing) {
    targetWindow.orientation = "column";
    targetWindow.alignChildren = "fill";
    targetWindow.margins = WINDOW_MARGINS;
    targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
}

/**
 * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
 * @param {Panel} targetPanel - 対象のパネル
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupPanel(targetPanel, spacing) {
    targetPanel.orientation = "column";
    targetPanel.alignChildren = ["fill", "top"];
    targetPanel.alignment = "fill";
    targetPanel.margins = PANEL_MARGINS;
    targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * タブの共通設定
 * @param {Tab} targetTab - 対象のタブ
 * @param {number} [spacing] - 要素間隔（省略時は変えない）
 * @returns {void}
 */
function setupTab(targetTab, spacing) {
    targetTab.orientation = "column";
    targetTab.alignChildren = "fill";
    targetTab.margins = TAB_MARGINS;
    if (typeof spacing === "number") targetTab.spacing = spacing;
}

/**
 * 横並びの行グループの共通設定（ボタン列など）。
 * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
 * @param {Group} rowGroup - 対象のグループ
 * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupRow(rowGroup, rowAlignment, spacing) {
    rowGroup.orientation = "row";
    rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
    rowGroup.alignChildren = ["left", "center"];
    rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
 * @param {Button} targetButton - 対象のボタン
 * @param {number} trimPixels - 詰める量（px）
 * @returns {void}
 */
function trimButtonHeight(targetButton, trimPixels) {
    /* レイアウト前は size が無い / size is not set until the layout runs */
    if (!targetButton.size) return;
    targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
}

// UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

/* 行パネル内の間隔と、濃淡グループの余白 [左,上,右,下] / Spacing inside a row panel and margins of its tint group */
var ROW_PANEL_SPACING  = 6;
var TINT_GROUP_MARGINS = [0, 20, 0, 10];

/* 入力欄の行・ボタン同士の間隔と、項目名と色見本の間隔 / Spacing inside control rows and next to the swatch chip */
var CONTROL_SPACING    = 8;
var SWATCH_ROW_SPACING = 6;

/* カラードロップダウン・濃淡入力欄・スライダー・スキップ入力欄の幅（px）
   / Widths of the color dropdown, tint field, slider and skip fields (px) */
var COLOR_DROPDOWN_WIDTH = 140;
var TINT_INPUT_WIDTH     = 50;
var TINT_SLIDER_WIDTH    = 150;
var SKIP_INPUT_WIDTH     = 30;

/* スキップのチェックボックスの幅。行と列で入力欄の位置をそろえる（px）
   / Width of the skip checkboxes so both fields line up (px) */
var SKIP_CHECKBOX_WIDTH = 80;

/* 色見本の一辺（px）/ Size of the swatch chip (px) */
var SWATCH_CHIP_SIZE = 18;

/* ダイアログの不透明度 / Dialog opacity */
var DIALOG_OPACITY = 0.98;

/**
 * 行に「∧∨＋入力欄」を隙間0で突き合わせる group を足し、∧∨を置く。入力欄は戻り値の .parent に続けて追加する
 * @param {Group} parentRow 追加先の行
 * @param {function} getNumberInput 対象の入力欄を返す関数
 * @param {object} stepOptions addStepper() に渡す増減の設定
 * @returns {Group} ∧∨をまとめた group
 */
function addStepperInputPair(parentRow, getNumberInput, stepOptions) {
    var pairGroup = parentRow.add("group");
    pairGroup.orientation = "row";
    pairGroup.alignChildren = ["left", "center"];
    pairGroup.spacing = 0; /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
    pairGroup.margins = 0;
    return addStepper(pairGroup, getNumberInput, stepOptions);
}

/**
 * ∧∨で増減したあと、手入力と同じ onChange を通す
 * @param {EditText} numberInput 増減した入力欄
 * @returns {void}
 */
function runInputOnChange(numberInput) {
    if (numberInput.onChange) numberInput.onChange();
}

/**
 * 入力欄と∧∨の有効／無効をまとめて切り替え、∧∨を描き直す
 * @param {EditText} numberInput 対象の入力欄（.stepperGroup に∧∨を控えておく）
 * @param {boolean} isEnabled 有効にするなら true
 * @returns {void}
 */
function setStepperInputEnabled(numberInput, isEnabled) {
    numberInput.enabled = isEnabled;
    numberInput.stepperGroup.enabled = isEnabled;
    /* 自作描画なのでディム表示を描き直す。表示前は最初の描画で反映されるので描き直さない
       redraw the custom-drawn dimming; before the window is shown the first draw picks it up */
    if (numberInput.window && numberInput.window.visible) redrawSteppersIn(numberInput.stepperGroup);
}

// UI の明暗（再利用パーツ） / UI theme (reusable)

/**
 * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
 * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
 */
function isDarkUI() {
    try {
        if (app.preferences && app.preferences.getRealPreference) {
            return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
        }
        return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
    } catch (e) {
        return false;
    }
}

// UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

// ステップボタン（再利用パーツ） / Stepper buttons (reusable)

// -----------------------------------------
// ステップボタンの寸法・増減量 / Stepper metrics and steps
// -----------------------------------------
var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

/* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
   UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
   「p」は「1p6」（1パイカ6ポイント）の形にも使う
   Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
var STEPPER_UNIT_ALIASES = {
    "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
    "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
    "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
};

// -----------------------------------------
// ステップボタンの配色 / Stepper colors
// -----------------------------------------
var STEPPER_UI_DARK           = isDarkUI();
/* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
   ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
   UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
   dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

// -----------------------------------------
// 数値欄を作る（外から呼ぶ関数） / Public API
// -----------------------------------------
/**
 * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
 * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
 * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
 * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と異なる単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
 * @param {Group|Panel} parent - 追加先
 * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
 *     step / min / max / integer（true で整数のみ）/ unit / onStep
 * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
 */
function addSteppedField(parent, fieldOptions) {
    var fieldRowGroup = parent.add("group");
    fieldRowGroup.orientation = "row";
    fieldRowGroup.alignChildren = ["left", "center"];
    fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

    var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
    if (fieldOptions.labelWidth) {
        fieldLabel.preferredSize.width = fieldOptions.labelWidth;
        fieldLabel.justify = "right";
    }

    /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
    var stepperInputGroup = fieldRowGroup.add("group");
    stepperInputGroup.orientation = "row";
    stepperInputGroup.alignChildren = ["left", "center"];
    stepperInputGroup.spacing = 0;
    stepperInputGroup.margins = 0;

    var numberInput;
    var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
    numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
    numberInput.characters = fieldOptions.characters || 6;
    numberInput.fieldLabel = fieldLabel;
    numberInput.stepperGroup = stepperGroup;

    /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
    bindSteppedArrowKeys(numberInput, stepperGroup);

    /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
    numberInput.lastValidText = numberInput.text;
    numberInput.onChange = function () {
        var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
        if (isNaN(value)) {
            numberInput.text = numberInput.lastValidText;
            return;
        }
        writeSteppedValue(numberInput, value, fieldOptions);
    };
    return numberInput;
}

/**
 * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
 * @param {EditText} numberInput - addSteppedField() で作った入力欄
 * @param {boolean} isEnabled - 有効にするなら true
 * @returns {void}
 */
function setSteppedFieldEnabled(numberInput, isEnabled) {
    numberInput.enabled = isEnabled;
    numberInput.fieldLabel.enabled = isEnabled;
    numberInput.stepperGroup.enabled = isEnabled;
    /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
    for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
        redrawStepperGroup(numberInput.stepperGroup.children[i]);
    }
}

/**
 * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
 * @param {Group|Panel} parent - 追加先
 * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
 * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
 * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
 */
function addStepper(parent, getNumberInput, stepOptions) {
    var stepperGroup = parent.add("group");
    stepperGroup.orientation = "column";
    stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
    stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
    stepperGroup.alignment = ["left", "center"];

    /**
     * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @returns {void}
     */
    function stepBy(direction) {
        var numberInput = getNumberInput();
        if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
        var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
        if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
        if (isNaN(value)) value = 0;
        writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
        if (stepOptions.onStep) stepOptions.onStep(numberInput);
    }

    /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
    var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
    var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
    makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); }).helpTip = getLabel(upTooltip);
    makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); }).helpTip = getLabel(downTooltip);
    stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
    stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
    return stepperGroup;
}

/**
 * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
 * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
 * @param {EditText} numberInput - 対象の入力欄
 * @param {Group} stepperGroup - addStepper() で作った∧∨
 * @returns {void}
 */
function bindSteppedArrowKeys(numberInput, stepperGroup) {
    numberInput.addEventListener("keydown", function (event) {
        if (event.keyName !== "Up" && event.keyName !== "Down") return;
        stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
        event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
    });
    numberInput.addEventListener("change", function () {
        var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
        var value = evaluateArithmetic(numberInput.text, fieldUnit);
        if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
        /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
        var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
        if (!hasOperator && value === parseFloat(numberInput.text)) return;
        numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
    });
}

// -----------------------------------------
// 値の計算 / Value helpers
// -----------------------------------------
/**
 * 押された修飾キーに応じて、1回分増減した値を返す
 * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
 * 整数の欄では option を無視して step の倍数へ）
 * @param {number} value - 元の値
 * @param {number} direction - 増やすなら 1、減らすなら -1
 * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
 * @returns {number} 増減した値（下限・上限は未適用）
 */
function computeSteppedValue(value, direction, stepOptions) {
    var keyState = ScriptUI.environment.keyboardState;
    if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
    if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
    return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
}

/**
 * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
 * @param {number} value - 元の値
 * @param {number} multiple - 倍数の単位（例 10）
 * @param {number} direction - 上げるなら 1、下げるなら -1
 * @returns {number} 移した値
 */
function snapStepperToNextMultiple(value, multiple, direction) {
    /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
       round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
    var quotient = Math.round(value / multiple * 1e6) / 1e6;
    if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
    return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
}

/**
 * 値を下限・上限の範囲に収める
 * @param {number} value - 数値
 * @param {Object} rangeOptions - min / max（どちらも省略可）
 * @returns {number} 範囲に収めた値
 */
function clampSteppedValue(value, rangeOptions) {
    if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
    if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
    return value;
}

/**
 * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
 * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
 * 全角の数字・記号と × ÷ は半角に直す
 * @param {string} text - 入力欄の文字列
 * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
 * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
 */
function evaluateArithmetic(text, fieldUnit) {
    var source = String(text)
        .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
        .replace(/×/g, "*")
        .replace(/÷/g, "/")
        .replace(/[−–—]/g, "-")
        .replace(/\s/g, "");
    if (source === "") return NaN;
    var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
    var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
    var position = 0;

    /**
     * 加減算の並び（項 ± 項 …）を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readSum() {
        var total = readProduct();
        while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
            var operator = source.charAt(position++);
            var operand = readProduct();
            total = (operator === "+") ? total + operand : total - operand;
        }
        return total;
    }

    /**
     * 乗除算の並び（因子 × 因子 …）を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readProduct() {
        var total = readFactor();
        while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
            var operator = source.charAt(position++);
            var operand = readFactor();
            if (operator === "/" && operand === 0) return NaN;
            total = (operator === "*") ? total * operand : total / operand;
        }
        return total;
    }

    /**
     * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readFactor() {
        var ch = source.charAt(position);
        if (ch === "+" || ch === "-") {
            position++;
            var signedValue = readFactor();
            return (ch === "-") ? -signedValue : signedValue;
        }
        if (ch === "(") {
            position++;
            var innerValue = readSum();
            if (source.charAt(position) !== ")") return NaN;
            position++;
            return innerValue;
        }
        var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
        if (!numberMatch) return NaN;
        position += numberMatch[0].length;
        return readUnitSuffix(parseFloat(numberMatch[0]));
    }

    /**
     * 数値の直後の単位を読み、欄の単位へ換算する
     * @param {number} value - 単位の前の数値
     * @returns {number} 欄の単位での値（換算できない単位なら NaN）
     */
    function readUnitSuffix(value) {
        var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
        if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
        position += unitMatch[0].length;
        var unitKey = unitMatch[0].toLowerCase();
        if (unitKey === fieldUnitKey) return value;
        var typedValue = createStepperUnitValue(value, unitKey);
        if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
        var points = typedValue.as("pt");
        /* 「1p6」＝1パイカ6ポイント / pica-point notation */
        if (unitKey === "p") {
            var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (pointMatch) {
                position += pointMatch[0].length;
                points += parseFloat(pointMatch[0]);
            }
        }
        return points / fieldUnitValue.as("pt");
    }

    var result = readSum();
    if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
    return result;
}

/**
 * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
 * %（percent）は基準の長さが無いと換算できないので扱わない
 * @param {number} value - 数値
 * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
 * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
 */
function createStepperUnitValue(value, unitKey) {
    if (unitKey === "" || unitKey === "%") return null;
    var alias = STEPPER_UNIT_ALIASES[unitKey];
    var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
    if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
    return unitValue;
}

/**
 * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
 * @param {EditText} numberInput - 書き込む入力欄
 * @param {number} value - 数値
 * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
 * @returns {void}
 */
function writeSteppedValue(numberInput, value, valueOptions) {
    numberInput.text = formatSteppedValue(value, valueOptions);
    numberInput.lastValidText = numberInput.text;
}

/**
 * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
 * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
 * @param {number} value - 数値
 * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
 * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
 */
function formatSteppedValue(value, valueOptions) {
    if (valueOptions.integer) value = Math.round(value);
    return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
}

/**
 * 小数第2位で丸めた数値を文字列で返す
 * @param {number} value - 数値
 * @returns {string} 表示用の数値文字列
 */
function formatStepperNumber(value) {
    return String(Math.round(value * 100) / 100);
}

// -----------------------------------------
// ∧∨ボタンの描画 / Drawing
// -----------------------------------------
/**
 * 山形（∧／∨）の極小ボタンを作成する。
 * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
 * 継ぎ目に線は引かない
 * @param {Group|Panel} parent - 追加先
 * @param {string} direction - "up" または "down"
 * @param {Function} onClickFn - クリック時の処理
 * @returns {Group} ボタンとして使う group
 */
function makeStepperChevronButton(parent, direction, onClickFn) {
    var buttonWidth = STEPPER_BUTTON_WIDTH;
    var buttonHeight = STEPPER_BUTTON_HEIGHT;
    var isUp = (direction === "up");
    var chevronBox = parent.add("group");
    chevronBox.margins = 0;
    chevronBox.spacing = 0;
    chevronBox.preferredSize = [buttonWidth, buttonHeight];
    chevronBox.minimumSize = [buttonWidth, buttonHeight];
    chevronBox.maximumSize = [buttonWidth, buttonHeight];
    chevronBox.isPressed = false;
    chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

    chevronBox.onDraw = function () {
        var boxGraphics = chevronBox.graphics;
        /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
           Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
        var isDimmed = !isStepperEnabledInTree(chevronBox);

        /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
        var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
        boxGraphics.newPath();
        boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
        boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

        drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
        drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
    };

    /**
     * 押下状態を変えて描き直す
     * @param {boolean} isPressed - 押下中なら true
     * @returns {void}
     */
    function repaint(isPressed) {
        if (chevronBox.isPressed === isPressed) return;
        chevronBox.isPressed = isPressed;
        redrawStepperGroup(chevronBox);
    }
    chevronBox.addEventListener("mousedown", function () {
        if (!isStepperEnabledInTree(chevronBox)) return;
        repaint(true);
        if (onClickFn) onClickFn();
    });
    chevronBox.addEventListener("mouseup", function () { repaint(false); });
    /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
    chevronBox.addEventListener("mouseout", function () { repaint(false); });
    return chevronBox;
}

/**
 * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
 * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
 * @param {ScriptUIGraphics} boxGraphics - 描画先
 * @param {number} boxWidth - ボタンの幅
 * @param {number} boxHeight - ボタンの高さ
 * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
 * @param {number[]} frameColor - [r, g, b, a]
 * @returns {void}
 */
function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
    var frameLeft = 0.5;
    var frameRight = boxWidth - 0.5;
    var outerY = isUp ? 0.5 : boxHeight - 0.5;
    var seamY = isUp ? boxHeight : 0;
    var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
    var radius = STEPPER_CORNER_RADIUS;
    var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
    var angle, k;

    boxGraphics.newPath();
    boxGraphics.moveTo(frameLeft, seamY);
    /* 左の角丸 / left corner */
    for (k = 0; k <= arcSteps; k++) {
        angle = (Math.PI / 2) * k / arcSteps;
        boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
    }
    /* 右の角丸 / right corner */
    for (k = 0; k <= arcSteps; k++) {
        angle = (Math.PI / 2) * k / arcSteps;
        boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
    }
    boxGraphics.lineTo(frameRight, seamY);
    boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
}

/**
 * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
 * @param {ScriptUIGraphics} boxGraphics - 描画先
 * @param {number} boxWidth - ボタンの幅
 * @param {number} boxHeight - ボタンの高さ
 * @param {boolean} isUp - ∧なら true、∨なら false
 * @param {number[]} chevronColor - [r, g, b, a]
 * @returns {void}
 */
function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
    var centerX = boxWidth / 2;
    var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
    var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
    var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
    boxGraphics.newPath();
    boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
    boxGraphics.lineTo(centerX, centerY + tipOffsetY);
    boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
    boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
}

/**
 * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
 * @param {Object} control - 対象のコントロール
 * @returns {boolean} すべて有効なら true
 */
function isStepperEnabledInTree(control) {
    for (var node = control; node; node = node.parent) {
        if (!node.enabled) return false;
    }
    return true;
}

/**
 * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
 * @param {Object} container - 行・グループ・パネルなど
 * @returns {void}
 */
function redrawSteppersIn(container) {
    if (!container.children) return;
    for (var i = 0; i < container.children.length; i++) {
        var child = container.children[i];
        if (child.isStepperButton) redrawStepperGroup(child);
        else redrawSteppersIn(child);
    }
}

/**
 * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
 * @param {Group} targetGroup - 描き直す group
 * @returns {void}
 */
function redrawStepperGroup(targetGroup) {
    targetGroup.hide();
    targetGroup.show();
}

// ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

// =========================================
// ラベル定義 / Labels
// =========================================

// ローカライズ（再利用パーツ） / Localization (reusable)

/**
 * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
 * @returns {string} "ja" または "en"
 */
function getCurrentLang() {
    return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
}

var uiLang = getCurrentLang();

/**
 * LABELS から今の UI 言語の文言を取り出す。
 * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
 * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
 * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
 */
function getLabel(labelRef, placeholderValues) {
    var labelEntry = labelRef;
    if (typeof labelRef === "string") {
        var labelPathKeys = labelRef.split(".");
        labelEntry = LABELS;
        for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
            labelEntry = labelEntry[labelPathKeys[i]];
        }
    }
    var labelString;
    if (typeof labelEntry === "string") labelString = labelEntry;
    else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
    else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
    else return (typeof labelRef === "string") ? labelRef : "";
    return fillLabelPlaceholders(String(labelString), placeholderValues);
}

/**
 * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {Object|Array} [placeholderValues] - getLabel と同じ
 * @returns {string} コロン付きの文言
 */
function labelText(labelRef, placeholderValues) {
    return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
}

/**
 * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {string|number} value - コロンのあとに続ける値
 * @returns {string} 項目名と値をつないだ文字列
 */
function labelValueText(labelRef, value) {
    return labelText(labelRef) + " " + value;
}

/**
 * 文言の {name} や %1 に値を差し込む
 * @param {string} labelString - 文言
 * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
 * @returns {string} 差し込んだ文言
 */
function fillLabelPlaceholders(labelString, placeholderValues) {
    if (placeholderValues == null) return labelString;
    if (placeholderValues instanceof Array) {
        /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
        for (var i = placeholderValues.length; i >= 1; i--) {
            labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
        }
        return labelString;
    }
    for (var placeholderKey in placeholderValues) {
        if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
        labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
    }
    return labelString;
}

// ローカライズ（再利用パーツ）ここまで / End of the reusable localization

// ボタン行（再利用パーツ） / Button row (reusable)

var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

/**
 * ダイアログ下部のボタン行を作る。
 * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
 * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
 * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
 * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
 */
function addButtonRow(parent, rowOptions) {
    var isCentered = !!(rowOptions && rowOptions.centered);
    var btnRowGroup = parent.add("group");
    btnRowGroup.orientation = "row";
    btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
    btnRowGroup.spacing = BUTTON_ROW_SPACING;

    if (isCentered) {
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
    }

    btnRowGroup.alignment = ["fill", "bottom"];

    var btnLeftGroup = btnRowGroup.add("group");
    btnLeftGroup.alignChildren = ["left", "center"];
    btnLeftGroup.spacing = BUTTON_ROW_SPACING;

    /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
    var spacer = btnRowGroup.add("group");
    spacer.alignment = ["fill", "fill"];
    spacer.minimumSize.width = 0;

    var btnRightGroup = btnRowGroup.add("group");
    btnRightGroup.alignChildren = ["right", "center"];
    btnRightGroup.spacing = BUTTON_ROW_SPACING;

    return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
}

/**
 * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
 * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
 * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
 * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
 * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
 * @returns {void}
 */
function alignRightOnlyButtonRow(buttonRow) {
    if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
    var dialogWindow = buttonRow.rowGroup.window;
    dialogWindow.addEventListener("show", function () {
        if (!buttonRow.leftGroup) return;
        var btnRowGroup = buttonRow.rowGroup;
        /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
        if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
        /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
        btnRowGroup.remove(buttonRow.leftGroup);
        btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        buttonRow.leftGroup = null;
        dialogWindow.layout.layout(true);
    });
}

// ボタン行（再利用パーツ）ここまで / End of the reusable button row

// バージョン表示（再利用パーツ） / Version footer (reusable)

var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

/* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
   9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
   / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
     nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
var VERSION_FOOTER_GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
    "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
    "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
    "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
    "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
    "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
    "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
    "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
    "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
    "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
    "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
    "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
    "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
    "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
    "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
    "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
    "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
    "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
    "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
    "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
    "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
    "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
    "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
    "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
    "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
    "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
    "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
    "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
    "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
    "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
    "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
    "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
    "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
    "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
    "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
    "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
    "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
    "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
    ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
    "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
    "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
    "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
    " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
};

/**
 * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
 * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
 * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
 * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
 * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
 */
function addVersionFooter(targetWindow) {
    if (targetWindow.versionFooter) return null;

    /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
    var lastChild = targetWindow.children[targetWindow.children.length - 1];
    if (lastChild && lastChild.type === "group") {
        var rowMargins = lastChild.margins;
        lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
    }
    var windowMargins = targetWindow.margins;
    targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

    var footerGroup = targetWindow.add("group");
    footerGroup.orientation = "row";
    footerGroup.alignment = ["fill", "bottom"];
    footerGroup.alignChildren = ["left", "center"];
    footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

    /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
       左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
       / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
         or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
    var versionText = String(SCRIPT_VERSION);
    var leftCandidates = [versionText];
    if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
    var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
    versionCanvas.alignment = ["fill", "center"];
    bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
    var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
    brandCanvas.alignment = ["right", "center"];
    brandCanvas.maximumSize = brandCanvas.preferredSize;
    targetWindow.versionFooter = footerGroup;
    return versionCanvas;
}

/**
 * 文字列のすべての文字に字形があるかを返す
 * @param {string} dotText - 文字列
 * @returns {boolean} すべてあれば true
 */
function hasVersionFooterGlyphs(dotText) {
    for (var i = 0; i < dotText.length; i++) {
        if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
    }
    return dotText.length > 0;
}

/**
 * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
 * @param {Group} parentGroup - 足す先
 * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
 * @returns {Group} 描くグループ
 */
function addVersionFooterCanvas(parentGroup, dotTexts) {
    var dotCanvas = parentGroup.add("group");
    var shortestText = dotTexts[dotTexts.length - 1];
    dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
    dotCanvas.helpTip = dotTexts[0];
    dotCanvas.onDraw = function () {
        var availableWidth = this.size ? this.size.width : 0;
        var drawText = shortestText;
        for (var i = 0; i < dotTexts.length; i++) {
            if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                drawText = dotTexts[i];
                break;
            }
        }
        drawVersionFooterDots(this.graphics, drawText);
    };
    return dotCanvas;
}

/**
 * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
 * @param {string} versionText - 文字列
 * @returns {number} 幅（ドット）
 */
function measureVersionFooterDots(versionText) {
    var dotCount = 0;
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
        dotCount += glyphRows[0].length;
    }
    return dotCount;
}

/**
 * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
 * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
 * @param {string} versionText - 文字列
 * @returns {void}
 */
function drawVersionFooterDots(canvasGraphics, versionText) {
    var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
    var dotSize = VERSION_FOOTER_PIXEL_SIZE;
    var cursorDots = 0;
    canvasGraphics.newPath();
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
        for (var row = 0; row < glyphRows.length; row++) {
            var rowText = glyphRows[row];
            var runStart = -1;
            for (var col = 0; col <= rowText.length; col++) {
                var isDot = col < rowText.length && rowText.charAt(col) === "#";
                if (isDot && runStart < 0) runStart = col;
                if (!isDot && runStart >= 0) {
                    canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                    runStart = -1;
                }
            }
        }
        cursorDots += glyphRows[0].length;
    }
    canvasGraphics.fillPath(footerBrush);
}

// -----------------------------------------
// このスクリプトについて / About this script
// -----------------------------------------
/* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
   この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
   Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
   and keeps its own labels and layout values so the part works on its own */

var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
/* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
   The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
/* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

var VERSION_INFO_LABELS = {
    dialog: {
        title: { ja: "このスクリプトについて", en: "About This Script" }
    },
    panel: {
        generalInfo: { ja: "基本情報", en: "General" },
        links: { ja: "リンク", en: "Links" }
    },
    fieldLabel: {
        scriptName: { ja: "スクリプト名", en: "Script Name" },
        scriptFeature: { ja: "機能", en: "Feature" },
        scriptVersion: { ja: "バージョン", en: "Version" }
    },
    button: {
        openReadme: { ja: "README", en: "README" },
        openSourceCode: { ja: "ソースコード", en: "Source Code" },
        openArticle: { ja: "記事（note）", en: "Article (note)" },
        revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
        revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
        close: { ja: "閉じる", en: "Close" }
    },
    tooltip: {
        versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
        copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
    },
    alert: {
        copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
    }
};

/**
 * VERSION_INFO_LABELS の文言を今の言語で返す
 * @param {Object} labelEntry - { ja, en }
 * @returns {string} 文言
 */
function getVersionInfoLabel(labelEntry) {
    return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
}

/**
 * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
 * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
 * @returns {string} 値
 */
function getVersionInfoValue(variableKey) {
    var infoValue;
    if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
    else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
    else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
    else if (variableKey === "readme") {
        if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
        else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
    }
    else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
    else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
    return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
}

/**
 * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
 * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
 * @returns {void}
 */
function bindVersionInfoClick(versionCanvas) {
    versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
    /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
       Open on mouseup so the release does not land on the footer after the dialog closes */
    versionCanvas.addEventListener("mouseup", function () {
        showVersionInfoDialog(versionCanvas.window.type === "palette");
    });
}

/**
 * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
 * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
 * @returns {void}
 */
function showVersionInfoDialog(isFromPalette) {
    var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
    infoDialog.orientation = "column";
    infoDialog.alignChildren = "fill";
    infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
    infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

    var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
    /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
    /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
    if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
    }
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
    alignVersionInfoLabels(infoPanel);

    /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
    var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
    var linkButtonRow = linksPanel.add("group");
    linkButtonRow.orientation = "row";
    linkButtonRow.alignment = ["left", "center"];
    linkButtonRow.alignChildren = ["left", "center"];
    linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

    /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
    var buttonRow = infoDialog.add("group");
    buttonRow.orientation = "row";
    buttonRow.alignment = ["fill", "bottom"];
    buttonRow.alignChildren = ["left", "center"];
    buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
    buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
    var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
    if (VERSION_INFO_SCRIPT_FILE.exists) {
        revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
        revealButton.onClick = function () {
            revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
            infoDialog.close();
        };
    } else {
        revealButton.enabled = false;
    }
    /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
    var buttonSpacer = buttonRow.add("group");
    buttonSpacer.alignment = ["fill", "fill"];
    buttonSpacer.minimumSize.width = 0;
    var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
    closeButton.alignment = ["right", "center"];
    /* return でも esc でも閉じる / Close with both Return and Esc */
    infoDialog.defaultElement = closeButton;
    infoDialog.cancelElement = closeButton;
    infoDialog.onShow = function () {
        pinVersionInfoCopyButton(infoPanel);
    };
    infoDialog.show();
}

/**
 * 「このスクリプトについて」のダイアログにパネルを足す
 * @param {Window} infoDialog - 足す先のダイアログ
 * @param {Object} titleEntry - パネル名の文言 { ja, en }
 * @returns {Panel} パネル
 */
function addVersionInfoPanel(infoDialog, titleEntry) {
    var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
    infoPanel.orientation = "column";
    infoPanel.alignChildren = ["fill", "top"];
    infoPanel.alignment = "fill";
    infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
    infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
    return infoPanel;
}

/**
 * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
 * @param {Panel} infoPanel - 足す先のパネル
 * @param {Object} labelEntry - 項目名の文言 { ja, en }
 * @param {string} valueText - 表示する値
 * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
 * @returns {StaticText} 値の statictext
 */
function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
    var infoRow = infoPanel.add("group");
    infoRow.orientation = "row";
    infoRow.alignment = ["fill", "center"];
    infoRow.alignChildren = ["left", "center"];
    infoRow.spacing = VERSION_INFO_ROW_SPACING;
    /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
    var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
    rowLabel.justify = "right";
    var valueLabel = infoRow.add("statictext", undefined, valueText);
    if (copyFromPalette === null) return valueLabel;
    /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
       A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
    var copySpacer = infoRow.add("group");
    copySpacer.alignment = ["fill", "fill"];
    copySpacer.minimumSize.width = 0;
    infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
    return valueLabel;
}

/**
 * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
 * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
 * @param {Panel} infoPanel - ［基本情報］パネル
 * @returns {void}
 */
function pinVersionInfoCopyButton(infoPanel) {
    var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
    for (var i = 0; i < infoPanel.children.length; i++) {
        var infoRow = infoPanel.children[i];
        if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
        infoRow.size = [innerWidth, infoRow.size.height];
        infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
    }
}

/**
 * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
 * @param {Panel} infoPanel - 対象のパネル
 * @returns {void}
 */
function alignVersionInfoLabels(infoPanel) {
    var rowLabels = [];
    var labelWidth = 0;
    for (var i = 0; i < infoPanel.children.length; i++) {
        var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
        rowLabels.push(rowLabel);
        labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
    }
    for (var j = 0; j < rowLabels.length; j++) {
        rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
    }
}

/**
 * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
 * @param {Window} infoDialog - ボタンを置くダイアログ
 * @param {Group} buttonGroup - 足す先のグループ
 * @param {Object} labelEntry - ボタンの文言 { ja, en }
 * @param {string} targetUrl - 開く URL（空ならディム表示）
 * @returns {void}
 */
function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
    var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
    if (!targetUrl) {
        linkButton.enabled = false;
        return;
    }
    linkButton.helpTip = targetUrl;
    linkButton.onClick = function () {
        openVersionInfoUrl(targetUrl);
        infoDialog.close();
    };
}

/**
 * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
 * @param {Group} infoRow - 足す先の行
 * @param {StaticText} valueLabel - コピーする値の statictext
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {Group} ボタンとして使う group
 */
function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
    var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
    var copyButton = infoRow.add("group");
    copyButton.preferredSize = [buttonSize, buttonSize];
    copyButton.minimumSize = [buttonSize, buttonSize];
    copyButton.maximumSize = [buttonSize, buttonSize];
    copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
    copyButton.isPressed = false;
    copyButton.isCopied = false;

    copyButton.onDraw = function () {
        var buttonGraphics = copyButton.graphics;
        var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
        buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
        if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
        else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
    };

    /**
     * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
     * @param {boolean} isPressed - 押下中なら true
     * @param {boolean} isCopied - コピー済みなら true
     * @returns {void}
     */
    function repaint(isPressed, isCopied) {
        if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
        copyButton.isPressed = isPressed;
        copyButton.isCopied = isCopied;
        copyButton.hide();
        copyButton.show();
    }
    copyButton.addEventListener("mousedown", function () { repaint(true, false); });
    copyButton.addEventListener("mouseup", function () {
        if (!copyButton.isPressed) return;
        var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
        repaint(false, hasCopied);
        if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
    });
    /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
    copyButton.addEventListener("mouseout", function () { repaint(false, false); });
    return copyButton;
}

/**
 * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
    var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
    var sheetSize = 9;
    var offset = 3;
    var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var backLeft = frontLeft - offset;
    var backTop = frontTop - offset;
    /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
    buttonGraphics.newPath();
    buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
    buttonGraphics.strokePath(iconPen);
    buttonGraphics.newPath();
    buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
    buttonGraphics.strokePath(iconPen);
}

/**
 * コピーしたあとのチェックマークを描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
    var center = buttonSize / 2;
    buttonGraphics.newPath();
    buttonGraphics.moveTo(center - 4.5, center);
    buttonGraphics.lineTo(center - 1.5, center + 3);
    buttonGraphics.lineTo(center + 4.5, center - 3.5);
    buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
}

/**
 * 文字列をクリップボードにコピーする。
 * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
 * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
 * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
 * @param {string} copyText - コピーする文字列
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {boolean} コピーの操作まで進めたら true
 */
function copyVersionInfoText(copyText, isFromPalette) {
    try {
        if (VERSION_INFO_IS_INDESIGN) {
            if (File.fs === "Windows") {
                app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
            } else {
                app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
            }
            return true;
        }
        var copyScript = buildVersionInfoCopyScript(copyText);
        if (!isFromPalette) return eval(copyScript) === true;
        var copyMessage = new BridgeTalk();
        copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
        copyMessage.body = copyScript;
        copyMessage.send();
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
 * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
 * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
 * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
 * @param {string} copyText - コピーする文字列
 * @returns {string} 実行すると true / false を返すスクリプト
 */
function buildVersionInfoCopyScript(copyText) {
    return [
        "(function (copyText) {",
        "    var usingTempDoc = (app.documents.length === 0);",
        "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
        "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
        "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
        "    var tempLayer = null;",
        "    var hasCopied = false;",
        "    try {",
        "        tempLayer = targetDoc.layers.add();",
        "        var tempFrame = tempLayer.textFrames.add();",
        "        tempFrame.contents = copyText;",
        "        app.redraw();",
        "        app.executeMenuCommand('deselectall');",
        "        tempFrame.selected = true;",
        "        app.redraw();",
        "        app.executeMenuCommand('copy');",
        "        app.redraw();",
        "        hasCopied = true;",
        "    } catch (e) { }",
        "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
        "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
        "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
        "    targetDoc.selection = null;",
        "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
        "    app.redraw();",
        "    return hasCopied;",
        "})(" + quoteVersionInfoString(copyText) + ");"
    ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
}

/**
 * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
 * @param {string} sourceText - 文字列
 * @returns {string} "…" の形のリテラル
 */
function quoteVersionInfoString(sourceText) {
    return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

/**
 * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
 * @param {File} scriptFile - 表示するファイル
 * @returns {void}
 */
function revealVersionInfoScriptFile(scriptFile) {
    /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
    var hasRevealApp = (File.fs === "Macintosh")
        && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
    /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
    if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
    /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
    scriptFile.parent.execute();
}

/**
 * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
 * @param {string} targetPath - 絶対パス
 * @returns {boolean} 書き出せたら true
 */
function writeVersionInfoRevealPath(targetPath) {
    var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
    pathFile.encoding = "UTF-8";
    pathFile.lineFeed = "Unix";
    if (!pathFile.open("w")) return false;
    var hasWritten = pathFile.write(targetPath);
    pathFile.close();
    return hasWritten;
}

/**
 * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
 * @param {string} targetUrl - 開く URL
 * @returns {void}
 */
function openVersionInfoUrl(targetUrl) {
    var isMac = (File.fs === "Macintosh");
    var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
    shortcutFile.encoding = "UTF-8";
    shortcutFile.open("w");
    if (isMac) {
        var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
        shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
            + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
    } else {
        shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
    }
    shortcutFile.close();
    shortcutFile.execute();
}

// バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

// プレビュー画面モード（再利用パーツ） / Preview screen mode (reusable)

/**
 * 作業中のウィンドウがプレビュー画面モードかどうかを返す
 * @returns {boolean} プレビューなら true。ストーリーエディターなど screenMode の無いウィンドウでは false
 */
function isPreviewScreenMode() {
    try {
        var docWindow = app.activeWindow;
        return !!(docWindow && docWindow.screenMode === ScreenModeOptions.PREVIEW_TO_PAGE);
    } catch (e) {
        /* ストーリーエディターのウィンドウには screenMode が無い / Story editor windows have no screenMode */
        return false;
    }
}

/**
 * 作業中のウィンドウの画面モードを、標準モードとプレビューで切り替える
 * @returns {void}
 */
function togglePreviewScreenMode() {
    try {
        var docWindow = app.activeWindow;
        if (!docWindow) return;
        docWindow.screenMode = isPreviewScreenMode() ? ScreenModeOptions.PREVIEW_OFF : ScreenModeOptions.PREVIEW_TO_PAGE;
    } catch (e) {
        /* screenMode の無いウィンドウでは何もしない / Nothing to do for windows without a screenMode */
    }
}

/**
 * 画面モードの切り替えボタンの文字（押すと切り替わる先）を返す
 * @returns {string} プレビュー中は「標準モード」、それ以外は「プレビュー」
 */
function getScreenModeButtonLabel() {
    return getLabel(isPreviewScreenMode() ? LABELS.button.screenModeNormal : LABELS.button.screenModePreview);
}

/**
 * 画面モードの切り替えボタンを足す
 * @param {Group} parent - ボタンを足す先（ふつうはボタン行の左のグループ）
 * @param {Function} [onToggle] - 切り替えたあとに呼ぶ関数
 * @returns {Button} 足したボタン
 */
function addScreenModeButton(parent, onToggle) {
    var btnScreenMode = parent.add("button", undefined, getScreenModeButtonLabel());
    btnScreenMode.helpTip = getLabel(LABELS.tooltip.screenMode);
    btnScreenMode.onClick = function () {
        togglePreviewScreenMode();
        btnScreenMode.text = getScreenModeButtonLabel();
        if (onToggle) onToggle();
    };
    return btnScreenMode;
}

// プレビュー画面モード（再利用パーツ）ここまで / End of the reusable preview screen mode

// 表の選択（再利用パーツ） / Table selection (reusable)

var TABLE_PARENT_LOOKUP_LIMIT = 20; /* 親をたどる上限（無限ループよけ） / max parent hops (guards against loops) */

/**
 * 親をたどって、いちばん近い表を返す（セル・行・列・セル内のテキストや挿入点に対応）
 * @param {Object} startItem - たどり始めるオブジェクト
 * @returns {Table|null} 見つかった表。表の中でなければ null
 */
function findParentTable(startItem) {
    var node = startItem;
    for (var i = 0; i < TABLE_PARENT_LOOKUP_LIMIT && node; i++) {
        try {
            var typeName = node.constructor.name;
            if (typeName === "Table") return node;
            if (typeName === "Document" || typeName === "Application") return null;
            node = node.parent;
        } catch (e) {
            return null;
        }
    }
    return null;
}

/**
 * 選択から対象の表を返す。表の中の選択ならその表、表を含むテキストフレームやテキストなら最初の表
 * @param {Object} selectionItem - app.selection[0] など
 * @returns {Table|null} 対象の表。見つからなければ null
 */
function getTableFromSelection(selectionItem) {
    if (!selectionItem) return null;
    var parentTable = findParentTable(selectionItem);
    if (parentTable) return parentTable;
    try {
        if (selectionItem.tables && selectionItem.tables.length > 0) return selectionItem.tables[0];
    } catch (e) {
        /* tables を持たない選択（画像など） / Selections without tables (images, etc.) */
    }
    return null;
}

/**
 * 選択からセルを1つずつの配列にして返す。セル選択・表の選択はその全セル、セル内のテキストや挿入点はそのセル
 * @param {Object} selectionItem - app.selection[0] など
 * @returns {Cell[]} セルの配列。表の外なら空配列
 */
function getSelectedCells(selectionItem) {
    var selectedCells = [];
    if (!selectionItem) return selectedCells;
    try {
        var typeName = selectionItem.constructor.name;
        if (typeName === "Cell" || typeName === "Table") {
            /* 複数セルの選択も1つの Cell で返るので .cells で展開する / A multi-cell selection is one Cell; expand it via .cells */
            var cellCollection = selectionItem.cells;
            for (var i = 0; i < cellCollection.length; i++) selectedCells.push(cellCollection[i]);
            return selectedCells;
        }
        var node = selectionItem;
        for (var j = 0; j < TABLE_PARENT_LOOKUP_LIMIT && node; j++) {
            var nodeType = node.constructor.name;
            if (nodeType === "Cell") {
                selectedCells.push(node);
                break;
            }
            if (nodeType === "Table" || nodeType === "Document" || nodeType === "Application") break;
            node = node.parent;
        }
    } catch (e) {
        /* 親をたどれない選択は空のまま / Leave empty when the parent chain cannot be followed */
    }
    return selectedCells;
}

/**
 * 2つの表が同じ表かどうかを返す
 * @param {Table} tableA - 表
 * @param {Table} tableB - 表
 * @returns {boolean} 同じ表なら true
 */
function isSameTable(tableA, tableB) {
    if (!tableA || !tableB) return false;
    try {
        return tableA.id === tableB.id && tableA.parent.id === tableB.parent.id;
    } catch (e) {
        return false;
    }
}

// 表の選択（再利用パーツ）ここまで / End of the reusable table selection


var LABELS = {
    dialog: {
        title: { ja: "行の塗りを交互に設定", en: "Alternating Row Fill" }
    },
    panel: {
        oddRows:  { ja: "奇数番目の行", en: "Odd-numbered Rows" },
        evenRows: { ja: "偶数番目の行", en: "Even-numbered Rows" },
        options:  { ja: "オプション", en: "Options" },
        skip:     { ja: "スキップ", en: "Skip" }
    },
    fieldLabel: {
        color: { ja: "カラー", en: "Color" },
        tint:  { ja: "濃淡", en: "Tint" }
    },
    checkbox: {
        swapRows:    { ja: "奇数行と偶数行を入れ替え", en: "Swap odd and even" },
        skipRows:    { ja: "行", en: "Rows" },
        skipColumns: { ja: "列", en: "Columns" }
    },
    swatch: {
        black: { ja: "黒", en: "Black" },
        paper: { ja: "紙色", en: "Paper" },
        none:  { ja: "なし", en: "None" }
    },
    button: {
        ok:                { ja: "OK", en: "OK" },
        cancel:            { ja: "キャンセル", en: "Cancel" },
        screenModePreview: { ja: "プレビュー", en: "Preview" },
        screenModeNormal:  { ja: "標準モード", en: "Normal Mode" }
    },
    tooltip: {
        oddRows: {
            ja: "選択範囲の上から数えて1・3・5…番目の行です。除外した行は数に入りません。",
            en: "The 1st, 3rd, 5th and so on row counted from the top of the selection. Skipped rows are not counted."
        },
        evenRows: {
            ja: "選択範囲の上から数えて2・4・6…番目の行です。除外した行は数に入りません。",
            en: "The 2nd, 4th, 6th and so on row counted from the top of the selection. Skipped rows are not counted."
        },
        colorDropdown: {
            ja: "「なし」と「紙色」では濃淡を指定できません。",
            en: "Tint is not available for None or Paper."
        },
        tintInput: {
            ja: "↑↓キーで1ずつ、Shift+↑↓キーで10ずつ増減します。",
            en: "Up/Down arrow keys change the value by 1, or by 10 with Shift."
        },
        tintSlider: {
            ja: "Shift+ドラッグで10%刻み、Option（Alt）+ドラッグで5%刻みになります。",
            en: "Shift-drag snaps to 10% steps, Option (Alt)-drag to 5% steps."
        },
        /* ステップボタン用 / for the stepper */
        stepUp: {
            ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
            en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
        },
        stepDown: {
            ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
            en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
        },
        stepUpInteger:   { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
        stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" },
        swapRows: {
            ja: "奇数行と偶数行のカラー・濃淡を入れ替えます。",
            en: "Exchanges the color and tint between the odd and even rows."
        },
        skipRows: {
            ja: "選択範囲の上から指定した行数を塗りの対象から外し、実行前のカラーに戻します。",
            en: "Leaves the given number of rows at the top of the selection out of the fill, restoring the color they had before the script ran."
        },
        skipColumns: {
            ja: "選択範囲の左から指定した列数を塗りの対象から外し、実行前のカラーに戻します。",
            en: "Leaves the given number of columns at the left of the selection out of the fill, restoring the color they had before the script ran."
        },
        screenMode: {
            ja: "ドキュメントウィンドウの画面モードを、標準モードとプレビューで切り替えます。",
            en: "Switches the document window between the Normal and Preview screen modes."
        }
    },
    alert: {
        noDocument:      { ja: "ドキュメントを開いてください。", en: "Please open a document." },
        noCellSelection: { ja: "セルを選択してください。", en: "Please select table cells." },
        noUsableSwatch:  { ja: "使用可能なカラーがありません。", en: "No usable colors are available." }
    },
    undo: {
        previewFills: { ja: "塗りプレビュー", en: "Fill Preview" },
        applyFills:   { ja: "セルの塗りを交互に設定", en: "Apply Alternating Fills" }
    }
};

// =========================================
// スウォッチ / Swatches
// =========================================

/* 特別扱いするスウォッチ名（角括弧・大文字小文字は無視して照合）/ Special swatch names (brackets and case are ignored) */
var SPECIAL_SWATCH_NAMES = {
    none:         ["None", "なし"],
    black:        ["Black", "ブラック", "黒"],
    paper:        ["Paper", "紙色", "紙"],
    registration: ["Registration", "レジストレーション", "トンボ用"]
};

/* 色見本に使う RGB（0〜1）/ RGB values (0-1) used for the swatch chip */
var CHIP_RGB_BLACK    = [0, 0, 0];
var CHIP_RGB_WHITE    = [1, 1, 1];
var CHIP_RGB_FALLBACK = [0.5, 0.5, 0.5];

/**
 * @typedef {object} SwatchChoice
 * @property {string} swatchName ドキュメント上のスウォッチ名
 * @property {string} displayName ドロップダウンに表示する名前
 * @property {string} swatchKind 特別なスウォッチの種別。通常のカラーは空文字
 */

/**
 * 比較しやすいようにスウォッチ名を正規化する（角括弧・前後の空白・大文字小文字を落とす）
 * @param {string} swatchName スウォッチ名
 * @returns {string} 正規化した名前
 */
function normalizeSwatchName(swatchName) {
    if (swatchName == null) return "";
    return String(swatchName).replace(/^\[|\]$/g, "").replace(/^\s+|\s+$/g, "").toLowerCase();
}

/**
 * スウォッチ名が特別なスウォッチのどれに当たるかを調べる
 * @param {string} swatchName スウォッチ名
 * @returns {string} "none" / "black" / "paper" / "registration"。どれでもなければ空文字
 */
function getSpecialSwatchKind(swatchName) {
    var normalizedName = normalizeSwatchName(swatchName);
    var swatchKind, names, i;
    for (swatchKind in SPECIAL_SWATCH_NAMES) {
        if (!SPECIAL_SWATCH_NAMES.hasOwnProperty(swatchKind)) continue;
        names = SPECIAL_SWATCH_NAMES[swatchKind];
        for (i = 0; i < names.length; i++) {
            if (normalizeSwatchName(names[i]) === normalizedName) return swatchKind;
        }
    }
    return "";
}

/**
 * 濃淡を指定できないスウォッチかどうかを判定する
 * @param {string} swatchKind getSpecialSwatchKind() が返した種別
 * @returns {boolean} 濃淡を指定できないなら true
 */
function isTintDisabledKind(swatchKind) {
    return swatchKind === "none" || swatchKind === "paper";
}

/**
 * カラー候補として表示するスウォッチ一覧を作る（レジストレーションは除く）
 * @returns {Array<SwatchChoice>} スウォッチ一覧
 */
function getSwatchChoices() {
    var swatches = app.activeDocument.swatches;
    var swatchChoices = [];
    var i, swatchName, swatchKind;

    for (i = 0; i < swatches.length; i++) {
        swatchName = String(swatches[i].name);
        swatchKind = getSpecialSwatchKind(swatchName);
        if (swatchKind === "registration") continue;
        swatchChoices.push({
            swatchName: swatchName,
            displayName: swatchKind ? getLabel("swatch." + swatchKind) : swatchName,
            swatchKind: swatchKind
        });
    }
    return swatchChoices;
}

/**
 * 名前からスウォッチを取得する
 * @param {string} swatchName スウォッチ名
 * @returns {Swatch|null} 見つかったスウォッチ。無ければ null
 */
function findSwatch(swatchName) {
    var swatch = app.activeDocument.swatches.itemByName(String(swatchName));
    return (swatch && swatch.isValid) ? swatch : null;
}

/**
 * 一覧の中からスウォッチ名に一致する位置を求める
 * @param {Array<SwatchChoice>} swatchChoices スウォッチ一覧
 * @param {string} swatchName 探すスウォッチ名
 * @returns {number} 見つかった位置。無ければ 0
 */
function findSwatchChoiceIndex(swatchChoices, swatchName) {
    for (var i = 0; i < swatchChoices.length; i++) {
        if (swatchChoices[i].swatchName === swatchName) return i;
    }
    return 0;
}

/**
 * スウォッチのカラー値を色見本用の RGB に変換する
 * @param {Swatch|null} swatch 対象のスウォッチ
 * @returns {Array<number>} 0〜1 の RGB 値
 */
function getSwatchChipRGB(swatch) {
    if (!swatch || !swatch.isValid) return CHIP_RGB_FALLBACK;

    var swatchKind = getSpecialSwatchKind(String(swatch.name));
    if (swatchKind === "paper" || swatchKind === "none") return CHIP_RGB_WHITE;
    if (swatchKind === "black" || swatchKind === "registration") return CHIP_RGB_BLACK;

    /* グラデーションや混合インキは色値を読めない / Gradients and mixed inks have no readable color value */
    try {
        var colorValues = swatch.colorValue;
        if (swatch.space === ColorSpace.RGB) {
            return [colorValues[0] / 255, colorValues[1] / 255, colorValues[2] / 255];
        }
        if (swatch.space === ColorSpace.CMYK) {
            var cyanValue    = colorValues[0] / 100;
            var magentaValue = colorValues[1] / 100;
            var yellowValue  = colorValues[2] / 100;
            var blackValue   = colorValues[3] / 100;
            return [
                (1 - cyanValue) * (1 - blackValue),
                (1 - magentaValue) * (1 - blackValue),
                (1 - yellowValue) * (1 - blackValue)
            ];
        }
    } catch (e) { }
    return CHIP_RGB_FALLBACK;
}

/**
 * 色見本をスウォッチのカラーで塗り直す
 * @param {Group} swatchChip 色見本のグループ
 * @param {Swatch|null} swatch 表示するスウォッチ
 * @returns {void}
 */
function paintSwatchChip(swatchChip, swatch) {
    var rgb = getSwatchChipRGB(swatch);
    swatchChip.graphics.backgroundColor = swatchChip.graphics.newBrush(
        swatchChip.graphics.BrushType.SOLID_COLOR,
        [rgb[0], rgb[1], rgb[2], 1]
    );
    if (swatchChip.window) swatchChip.window.update();
}

// =========================================
// 数値の正規化とキー操作 / Value handling
// =========================================

/**
 * 修飾キーに応じた濃淡スライダーの刻み幅を返す
 * @returns {number} 刻み幅
 */
function getTintSliderStep() {
    var keyboard = ScriptUI.environment.keyboardState;
    if (keyboard.shiftKey) return TINT_STEP_SHIFT;
    if (keyboard.altKey) return TINT_STEP_OPTION;
    return TINT_STEP_NORMAL;
}

/**
 * 濃淡を有効範囲の整数に収める
 * @param {number} value 入力された値
 * @returns {number} 整えた値
 */
function normalizeTint(value) {
    if (isNaN(value)) value = TINT_DEFAULT;
    if (value < TINT_MIN) value = TINT_MIN;
    if (value > TINT_MAX) value = TINT_MAX;
    return Math.round(value);
}

/**
 * 濃淡スライダーの値を、修飾キーに応じた刻み幅に合わせる
 * @param {number} value スライダーの値
 * @returns {number} 整えた値
 */
function snapTintToSliderStep(value) {
    var step = getTintSliderStep();
    return normalizeTint(Math.round(normalizeTint(value) / step) * step);
}

/**
 * スキップ数を 0 以上の整数に整える
 * @param {number} value 入力された値
 * @returns {number} 整えた値
 */
function normalizeSkipCount(value) {
    if (isNaN(value) || value < 0) return 0;
    return Math.round(value);
}

// =========================================
// 選択セルと初期値 / Selected cells & defaults
// =========================================

/**
 * @typedef {object} CellFill
 * @property {Swatch|null} color 塗りのカラー
 * @property {number|null} tint 濃淡。指定しない場合は null
 */

/**
 * セルの現在の塗りを控える（スキップ時に戻すため）
 * @param {Cell} cell 対象のセル
 * @returns {CellFill} 控えた塗り
 */
function captureCellFill(cell) {
    var fillColor = cell.fillColor;
    var fillTint = cell.fillTint;
    var swatchKind = (fillColor && fillColor.name) ? getSpecialSwatchKind(String(fillColor.name)) : "";
    var hasTint = !isTintDisabledKind(swatchKind) && !isNaN(fillTint) &&
        fillTint >= TINT_MIN && fillTint <= TINT_MAX;

    return { color: fillColor, tint: hasTint ? fillTint : null };
}

/**
 * 選択セルすべての塗りを控える
 * @param {Array<Cell>} cells 対象のセル
 * @returns {Array<CellFill>} セルと同じ並びの塗り
 */
function captureCellFills(cells) {
    var fills = [];
    for (var i = 0; i < cells.length; i++) {
        fills.push(captureCellFill(cells[i]));
    }
    return fills;
}

/**
 * 選択セルの塗り（カラー＋濃淡）を、使われている数の多い順に並べる
 * @param {Array<Cell>} cells 対象のセル
 * @param {{colorName: string, tint: number}} fallbackFill 塗りを読めなかったときに使う値
 * @returns {Array<{colorName: string, tint: number, count: number}>} 多い順の組み合わせ
 */
function countFillUsages(cells, fallbackFill) {
    var usageByKey = {};
    var usages = [];
    var i, fillColor, fillTint, colorName, tint, usageKey;

    for (i = 0; i < cells.length; i++) {
        fillColor = cells[i].fillColor;
        fillTint = cells[i].fillTint;
        colorName = (fillColor && fillColor.name) ? String(fillColor.name) : fallbackFill.colorName;
        tint = (!isNaN(fillTint) && fillTint >= TINT_MIN && fillTint <= TINT_MAX) ? fillTint : fallbackFill.tint;

        usageKey = colorName + "||" + tint;
        if (!usageByKey[usageKey]) {
            usageByKey[usageKey] = { colorName: colorName, tint: tint, count: 0 };
            usages.push(usageByKey[usageKey]);
        }
        usageByKey[usageKey].count++;
    }

    usages.sort(function (a, b) { return b.count - a.count; });
    return usages;
}

/**
 * 選択セルでよく使われている塗りから、奇数行・偶数行の初期値を決める
 * @param {Array<Cell>} cells 対象のセル
 * @param {string} fallbackColorName 塗りを読めなかったときに使うスウォッチ名
 * @returns {{odd: {colorName: string, tint: number}, even: {colorName: string, tint: number}}} 初期値
 */
function detectDefaultFills(cells, fallbackColorName) {
    var fallbackFill = { colorName: fallbackColorName, tint: TINT_DEFAULT };
    var usages = countFillUsages(cells, fallbackFill);
    var mostUsed = (usages.length > 0) ? usages[0] : fallbackFill;

    return {
        odd: mostUsed,
        even: (usages.length > 1) ? usages[1] : mostUsed
    };
}

// =========================================
// ダイアログの組み立て / Dialog
// =========================================

/**
 * @typedef {object} RowFillControls
 * @property {Panel} panel パネル本体
 * @property {DropDownList} colorDropdown カラーのドロップダウン
 * @property {Group} swatchChip 選択中のカラーを示す色見本
 * @property {EditText} tintInput 濃淡の入力欄
 * @property {Slider} tintSlider 濃淡のスライダー
 * @property {Array<SwatchChoice>} swatchChoices ドロップダウンと同じ並びのスウォッチ一覧
 */

/**
 * 行のカラーと濃淡を設定するパネルを作る（奇数行・偶数行で共通）
 * @param {Group} parent 追加先のグループ
 * @param {string} titleKey パネル名のラベルキー
 * @param {string} tooltipKey パネルに付けるツールチップのキー
 * @param {Array<SwatchChoice>} swatchChoices スウォッチ一覧
 * @param {{colorName: string, tint: number}} defaultFill カラーと濃淡の初期値
 * @param {function} onChange 値が変わったときに呼ぶ処理
 * @returns {RowFillControls} 作成したコントロール一式
 */
function createRowFillPanel(parent, titleKey, tooltipKey, swatchChoices, defaultFill, onChange) {
    var rowFillPanel = parent.add("panel", undefined, getLabel(titleKey));
    setupPanel(rowFillPanel, ROW_PANEL_SPACING);
    rowFillPanel.alignChildren = ["left", "top"];
    rowFillPanel.helpTip = getLabel(tooltipKey);

    var colorGroup = rowFillPanel.add("group");
    colorGroup.orientation = "column";
    colorGroup.alignChildren = ["left", "top"];

    var colorLabelRow = colorGroup.add("group");
    setupRow(colorLabelRow, "left", SWATCH_ROW_SPACING);
    colorLabelRow.add("statictext", undefined, labelText("fieldLabel.color"));

    var swatchChip = colorLabelRow.add("group");
    swatchChip.preferredSize = [SWATCH_CHIP_SIZE, SWATCH_CHIP_SIZE];
    swatchChip.minimumSize   = [SWATCH_CHIP_SIZE, SWATCH_CHIP_SIZE];
    swatchChip.maximumSize   = [SWATCH_CHIP_SIZE, SWATCH_CHIP_SIZE];

    var displayNames = [];
    for (var i = 0; i < swatchChoices.length; i++) {
        displayNames.push(swatchChoices[i].displayName);
    }
    var colorDropdown = colorGroup.add("dropdownlist", undefined, displayNames);
    colorDropdown.preferredSize.width = COLOR_DROPDOWN_WIDTH;
    colorDropdown.helpTip = getLabel("tooltip.colorDropdown");
    colorDropdown.selection = findSwatchChoiceIndex(swatchChoices, defaultFill.colorName);

    var tintGroup = rowFillPanel.add("group");
    tintGroup.orientation = "column";
    tintGroup.alignChildren = ["left", "top"];
    tintGroup.margins = TINT_GROUP_MARGINS;

    var tintInputRow = tintGroup.add("group");
    setupRow(tintInputRow, "left", CONTROL_SPACING);
    tintInputRow.add("statictext", undefined, labelText("fieldLabel.tint"));

    /* 増減後は手入力と同じ onChange（スライダーの同期とプレビュー）を通す / after stepping, run the same onChange as typing */
    var tintInput;
    var tintStepperGroup = addStepperInputPair(tintInputRow, function () { return tintInput; }, {
        step: 1,
        min: TINT_MIN,
        max: TINT_MAX,
        integer: true,
        onStep: runInputOnChange
    });
    tintInput = tintStepperGroup.parent.add("edittext", undefined, String(defaultFill.tint));
    tintInput.preferredSize.width = TINT_INPUT_WIDTH;
    tintInput.helpTip = getLabel("tooltip.tintInput");
    tintInput.stepperGroup = tintStepperGroup;
    bindSteppedArrowKeys(tintInput, tintStepperGroup);

    var tintSlider = tintGroup.add("slider", undefined, defaultFill.tint, TINT_MIN, TINT_MAX);
    tintSlider.preferredSize.width = TINT_SLIDER_WIDTH;
    tintSlider.helpTip = getLabel("tooltip.tintSlider");

    var rowFill = {
        panel: rowFillPanel,
        colorDropdown: colorDropdown,
        swatchChip: swatchChip,
        tintInput: tintInput,
        tintSlider: tintSlider,
        swatchChoices: swatchChoices
    };

    /* ハンドラーは初期値を入れ終えてから付ける（selection への代入で発火するため）
       / Attach the handlers after the initial values are in place */
    colorDropdown.onChange = function () {
        refreshRowFill(rowFill);
        onChange();
    };
    tintSlider.onChanging = function () {
        var tint = snapTintToSliderStep(this.value);
        this.value = tint;
        tintInput.text = String(tint);
        onChange();
    };
    tintInput.onChange = function () {
        setRowFillTint(rowFill, normalizeTint(parseFloat(this.text)));
        onChange();
    };

    return rowFill;
}

/**
 * パネルで選択中のスウォッチを取得する
 * @param {RowFillControls} rowFill 対象のパネル
 * @returns {SwatchChoice} 選択中のスウォッチ
 */
function getRowFillChoice(rowFill) {
    var selectedIndex = rowFill.colorDropdown.selection ? rowFill.colorDropdown.selection.index : 0;
    return rowFill.swatchChoices[selectedIndex];
}

/**
 * パネルの濃淡を入力欄とスライダーの両方に反映する
 * @param {RowFillControls} rowFill 対象のパネル
 * @param {number} tint 設定する濃淡
 * @returns {void}
 */
function setRowFillTint(rowFill, tint) {
    rowFill.tintInput.text = String(tint);
    rowFill.tintSlider.value = tint;
}

/**
 * 選択中のカラーに合わせて、色見本と濃淡コントロールの状態を更新する
 * @param {RowFillControls} rowFill 対象のパネル
 * @returns {void}
 */
function refreshRowFill(rowFill) {
    var swatchChoice = getRowFillChoice(rowFill);
    var tintEnabled = !isTintDisabledKind(swatchChoice.swatchKind);

    setStepperInputEnabled(rowFill.tintInput, tintEnabled);
    rowFill.tintSlider.enabled = tintEnabled;
    paintSwatchChip(rowFill.swatchChip, findSwatch(swatchChoice.swatchName));
}

/**
 * オプションのパネルとスキップのパネルを追加する
 * @param {Window} dialog 対象のダイアログ
 * @param {object} ui UI オブジェクト
 * @param {function} onChange 値が変わったときに呼ぶ処理
 * @returns {void}
 */
function addOptions(dialog, ui, onChange) {
    /* 左にオプション、右にスキップの2カラム / Two columns: options on the left, skip on the right */
    var optionPanelsGroup = dialog.add("group");
    setupRow(optionPanelsGroup, "fill", COLUMN_SPACING);
    optionPanelsGroup.alignChildren = ["left", "top"];

    var optionsPanel = optionPanelsGroup.add("panel", undefined, getLabel("panel.options"));
    setupPanel(optionsPanel, ROW_PANEL_SPACING);
    optionsPanel.alignChildren = ["left", "top"];

    ui.swapCheckbox = optionsPanel.add("checkbox", undefined, getLabel("checkbox.swapRows"));
    ui.swapCheckbox.helpTip = getLabel("tooltip.swapRows");
    ui.swapCheckbox.value = false;
    ui.swapCheckbox.onClick = onChange;

    /* 選択範囲の上から／左から、指定数を塗りの対象外にする / Leave the given rows and columns out of the fill */
    var skipPanel = optionPanelsGroup.add("panel", undefined, getLabel("panel.skip"));
    setupPanel(skipPanel, ROW_PANEL_SPACING);
    skipPanel.alignChildren = ["left", "top"];

    var skipRowControls = addSkipRow(skipPanel, "checkbox.skipRows", "tooltip.skipRows", onChange);
    ui.skipRowCheckbox = skipRowControls.checkbox;
    ui.skipRowInput = skipRowControls.input;

    var skipColumnControls = addSkipRow(skipPanel, "checkbox.skipColumns", "tooltip.skipColumns", onChange);
    ui.skipColumnCheckbox = skipColumnControls.checkbox;
    ui.skipColumnInput = skipColumnControls.input;
}

/**
 * スキップ数の1行（チェックボックス＋入力欄）を追加する
 * @param {Panel} parent 追加先のパネル
 * @param {string} labelKey チェックボックスのラベルキー
 * @param {string} tooltipKey ツールチップのキー
 * @param {function} onChange 値が変わったときに呼ぶ処理
 * @returns {{checkbox: Checkbox, input: EditText}} 作成したコントロール
 */
function addSkipRow(parent, labelKey, tooltipKey, onChange) {
    var skipGroup = parent.add("group");
    setupRow(skipGroup, "left", CONTROL_SPACING);

    var skipCheckbox = skipGroup.add("checkbox", undefined, labelText(labelKey));
    skipCheckbox.preferredSize.width = SKIP_CHECKBOX_WIDTH;
    /* 増減後は手入力と同じ onChange（整数化とプレビュー）を通す / after stepping, run the same onChange as typing */
    var skipInput;
    var skipStepperGroup = addStepperInputPair(skipGroup, function () { return skipInput; }, {
        step: 1,
        min: 0,
        integer: true,
        onStep: runInputOnChange
    });
    skipInput = skipStepperGroup.parent.add("edittext", undefined, String(SKIP_COUNT_DEFAULT));
    skipInput.preferredSize.width = SKIP_INPUT_WIDTH;
    skipInput.stepperGroup = skipStepperGroup;
    bindSteppedArrowKeys(skipInput, skipStepperGroup);

    skipCheckbox.helpTip = getLabel(tooltipKey);
    skipInput.helpTip = getLabel(tooltipKey);
    setStepperInputEnabled(skipInput, skipCheckbox.value);

    skipCheckbox.onClick = function () {
        setStepperInputEnabled(skipInput, skipCheckbox.value);
        onChange();
    };
    skipInput.onChange = function () {
        this.text = String(normalizeSkipCount(parseInt(this.text, 10)));
        onChange();
    };

    return { checkbox: skipCheckbox, input: skipInput };
}

/**
 * ダイアログ下部のボタン列を追加する（左：画面モード／右：キャンセル・OK）
 * @param {Window} dialog 対象のダイアログ
 * @param {object} ui UI オブジェクト
 * @returns {void}
 */
function addDialogButtons(dialog, ui) {
    var buttonRow = addButtonRow(dialog);
    ui.btnScreenMode = addScreenModeButton(buttonRow.leftGroup);
    var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
    var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
    alignRightOnlyButtonRow(buttonRow);
}

/**
 * ダイアログを組み立てる
 * @param {Array<SwatchChoice>} swatchChoices スウォッチ一覧
 * @param {{odd: object, even: object}} defaultFills 奇数行・偶数行の初期値
 * @param {function} onChange 値が変わったときに呼ぶ処理
 * @returns {object} ダイアログとコントロールをまとめた UI オブジェクト
 */
function buildDialog(swatchChoices, defaultFills, onChange) {
    var dialog = new Window("dialog", getLabel("dialog.title"));
    dialog.opacity = DIALOG_OPACITY;
    setupWindow(dialog);

    /* 左に奇数行、右に偶数行の2カラム / Two columns: odd rows on the left, even rows on the right */
    var rowPanelsGroup = dialog.add("group");
    setupRow(rowPanelsGroup, "fill", COLUMN_SPACING);
    rowPanelsGroup.alignChildren = ["left", "top"];

    var ui = { dialog: dialog };
    ui.oddRowFill = createRowFillPanel(rowPanelsGroup, "panel.oddRows", "tooltip.oddRows",
        swatchChoices, defaultFills.odd, onChange);
    ui.evenRowFill = createRowFillPanel(rowPanelsGroup, "panel.evenRows", "tooltip.evenRows",
        swatchChoices, defaultFills.even, onChange);

    addOptions(dialog, ui, onChange);
    addDialogButtons(dialog, ui);

    refreshRowFill(ui.oddRowFill);
    refreshRowFill(ui.evenRowFill);
    return ui;
}

// =========================================
// UIの値の読み取り / Read UI values
// =========================================

/**
 * @typedef {object} ZebraSettings
 * @property {CellFill} oddFill 奇数行の塗り
 * @property {CellFill} evenFill 偶数行の塗り
 * @property {boolean} swapRows 奇数行と偶数行を入れ替えるか
 * @property {number} skipRowCount 上からスキップする行数
 * @property {number} skipColumnCount 左からスキップする列数
 */

/**
 * パネルの設定を、セルに適用する形の塗りとして読み取る
 * @param {RowFillControls} rowFill 対象のパネル
 * @returns {CellFill} 読み取った塗り
 */
function readRowFill(rowFill) {
    var swatchChoice = getRowFillChoice(rowFill);
    return {
        color: findSwatch(swatchChoice.swatchName),
        tint: isTintDisabledKind(swatchChoice.swatchKind) ? null : normalizeTint(parseFloat(rowFill.tintInput.text))
    };
}

/**
 * スキップ数を読み取る（チェックが外れていれば 0）
 * @param {Checkbox} skipCheckbox スキップのチェックボックス
 * @param {EditText} skipInput スキップ数の入力欄
 * @returns {number} スキップする数
 */
function readSkipCount(skipCheckbox, skipInput) {
    return skipCheckbox.value ? normalizeSkipCount(parseInt(skipInput.text, 10)) : 0;
}

/**
 * ダイアログの設定をまとめて読み取る
 * @param {object} ui UI オブジェクト
 * @returns {ZebraSettings} 読み取った設定
 */
function readZebraSettings(ui) {
    return {
        oddFill: readRowFill(ui.oddRowFill),
        evenFill: readRowFill(ui.evenRowFill),
        swapRows: ui.swapCheckbox.value,
        skipRowCount: readSkipCount(ui.skipRowCheckbox, ui.skipRowInput),
        skipColumnCount: readSkipCount(ui.skipColumnCheckbox, ui.skipColumnInput)
    };
}

// =========================================
// 塗りの適用 / Apply fills
// =========================================

/**
 * @typedef {object} ZebraContext
 * @property {Array<Cell>} targetCells 対象のセル
 * @property {Array<CellFill>} originalFills 実行前の塗り（セルと同じ並び）
 * @property {boolean} previewApplied プレビューを当てたままかどうか
 */

/**
 * 選択セルが使っている行または列の位置を、重複なく昇順で集める
 * @param {Array<Cell>} cells 対象のセル
 * @param {string} parentName "parentRow" または "parentColumn"
 * @returns {Array<number>} 昇順に並べた位置
 */
function collectSortedIndices(cells, parentName) {
    var sortedIndices = [];
    var seen = {};
    for (var i = 0; i < cells.length; i++) {
        var parentIndex = cells[i][parentName].index;
        if (seen[parentIndex]) continue;
        seen[parentIndex] = true;
        sortedIndices.push(parentIndex);
    }
    sortedIndices.sort(function (a, b) { return a - b; });
    return sortedIndices;
}

/**
 * 先頭から指定数ぶんを「スキップする位置」として控える
 * @param {Array<number>} sortedIndices 昇順に並べた位置
 * @param {number} skipCount スキップする数
 * @returns {object} スキップする位置をキーに持つオブジェクト
 */
function buildSkipLookup(sortedIndices, skipCount) {
    var skipped = {};
    for (var i = 0; i < skipCount && i < sortedIndices.length; i++) {
        skipped[sortedIndices[i]] = true;
    }
    return skipped;
}

/**
 * スキップしていない行に、選択範囲の上から 0, 1, 2, … の順番を振る
 * @param {Array<number>} rowIndices 昇順に並べた行の位置
 * @param {object} skippedRows スキップする行
 * @returns {object} 行の位置をキー、順番を値に持つオブジェクト
 */
function buildRowOrderMap(rowIndices, skippedRows) {
    var rowOrderByIndex = {};
    var rowOrder = 0;
    for (var i = 0; i < rowIndices.length; i++) {
        if (skippedRows[rowIndices[i]]) continue;
        rowOrderByIndex[rowIndices[i]] = rowOrder++;
    }
    return rowOrderByIndex;
}

/**
 * セルに塗りを設定する
 * @param {Cell} cell 対象のセル
 * @param {CellFill} fill 設定する塗り。tint が null のときは濃淡を触らない
 * @returns {void}
 */
function applyCellFill(cell, fill) {
    if (!fill || !fill.color) return;
    cell.fillColor = fill.color;
    if (fill.tint === null) return;

    /* グラデーションなど濃淡を持たない塗りでは無視する / Fills without a tint, such as gradients, are left alone */
    try {
        cell.fillTint = fill.tint;
    } catch (e) { }
}

/**
 * 選択範囲内の行の並びを基準に、交互の塗りを適用する
 * @param {ZebraContext} context 対象のセルと実行前の塗り
 * @param {ZebraSettings} settings ダイアログの設定
 * @returns {void}
 */
function applyAlternatingFills(context, settings) {
    var targetCells = context.targetCells;
    if (targetCells.length === 0) return;

    var oddFill = settings.swapRows ? settings.evenFill : settings.oddFill;
    var evenFill = settings.swapRows ? settings.oddFill : settings.evenFill;

    var rowIndices = collectSortedIndices(targetCells, "parentRow");
    var columnIndices = collectSortedIndices(targetCells, "parentColumn");
    var skippedRows = buildSkipLookup(rowIndices, settings.skipRowCount);
    var skippedColumns = buildSkipLookup(columnIndices, settings.skipColumnCount);
    var rowOrderByIndex = buildRowOrderMap(rowIndices, skippedRows);

    for (var i = 0; i < targetCells.length; i++) {
        var cell = targetCells[i];
        var rowIndex = cell.parentRow.index;
        var columnIndex = cell.parentColumn.index;

        /* スキップした行・列は実行前の塗りに戻す / Skipped rows and columns go back to their previous fill */
        if (skippedRows[rowIndex] || skippedColumns[columnIndex]) {
            applyCellFill(cell, context.originalFills[i]);
            continue;
        }

        var rowOrder = rowOrderByIndex[rowIndex];
        if (rowOrder === undefined) continue;
        applyCellFill(cell, (rowOrder % 2 === 0) ? oddFill : evenFill);
    }
}

// =========================================
// プレビューと確定 / Preview & apply
// =========================================

/**
 * プレビューとして適用した塗りを取り消す
 * @param {ZebraContext} context 対象のセルと実行前の塗り
 * @returns {void}
 */
function clearPreview(context) {
    if (!context.previewApplied) return;
    context.previewApplied = false;

    /* プレビュー1回分の取り消し。失敗しても続行する / Undo the single preview step; keep going if it fails */
    try {
        app.undo();
        app.activeDocument.recompose();
    } catch (e) { }
}

/**
 * 現在の設定で塗りのプレビューを描き直す
 * @param {ZebraContext} context 対象のセルと実行前の塗り
 * @param {object} ui UI オブジェクト
 * @returns {void}
 */
function refreshPreview(context, ui) {
    clearPreview(context);
    var settings = readZebraSettings(ui);

    /* 取り消しを1ステップにまとめる / Keep the preview to a single undo step */
    try {
        app.doScript(function () {
            applyAlternatingFills(context, settings);
        }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, getLabel("undo.previewFills"));
        context.previewApplied = true;
        app.activeDocument.recompose();
    } catch (e) {
        context.previewApplied = false;
    }
}

/**
 * 選択セルに交互の塗りを適用するダイアログを表示して実行する
 * @returns {void}
 */
function main() {
    if (app.documents.length === 0) {
        alert(getLabel("alert.noDocument"));
        return;
    }

    var targetCells = getSelectedCells(app.selection[0]);
    if (targetCells.length === 0) {
        alert(getLabel("alert.noCellSelection"));
        return;
    }

    var swatchChoices = getSwatchChoices();
    if (swatchChoices.length === 0) {
        alert(getLabel("alert.noUsableSwatch"));
        return;
    }

    var context = {
        targetCells: targetCells,
        originalFills: captureCellFills(targetCells),
        previewApplied: false
    };
    var defaultFills = detectDefaultFills(targetCells, swatchChoices[0].swatchName);

    /* セルの青い選択ハイライトがプレビューの邪魔になるため、選択は一旦解除する
       / The blue selection highlight hides the preview, so clear the selection */
    app.selection = null;

    var ui = null;
    ui = buildDialog(swatchChoices, defaultFills, function () {
        refreshPreview(context, ui);
    });

    refreshPreview(context, ui);

    addVersionFooter(ui.dialog);
    if (ui.dialog.show() === 1) {
        clearPreview(context);
        var settings = readZebraSettings(ui);
        app.doScript(function () {
            applyAlternatingFills(context, settings);
        }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, getLabel("undo.applyFills"));
    } else {
        clearPreview(context);
    }
}

main();

})();
