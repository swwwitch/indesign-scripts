#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdTypeScaleStyleApplier
Name=タイプスケールから段落スタイルを一括適用（本文・見出し・リスト・表）
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.7.6
Release-Date=2026-05-05
Description-BEGIN
基準サイズとスケール倍率からタイプスケールを組み立て、本文・見出し・リスト・表の段落スタイルへ一括適用します。

Builds a type scale from a base size and a scale ratio, then applies it to the body, heading, list and table paragraph styles at once.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

基準サイズとスケール倍率からタイプスケールを組み立て、本文・見出し・リスト・表の段落スタイルへ一括適用します。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdTypeScaleStyleApplier.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n4f9b0666db66

### Overview

Builds a type scale from a base size and a scale ratio, then applies it to the body, heading, list and table paragraph styles at once.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdTypeScaleStyleApplier.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdTypeScaleStyleApplier";      /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.7.6";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-05-05";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "タイプスケールから段落スタイルを一括適用（本文・見出し・リスト・表）"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdTypeScaleStyleApplier.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdTypeScaleStyleApplier.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n4f9b0666db66"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/style/IdTypeScaleStyleApplier.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

// ==============================
// UIレイアウトの共通設定 / Shared UI layout
// ==============================

// UIレイアウト（再利用パーツ） / UI layout (reusable)

/* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

/**
 * ウィンドウの共通設定
 * @param {Window} targetWindow - 対象のウィンドウ
 * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
 * @returns {void}
 */
function setupWindow(targetWindow, spacing) {
    targetWindow.orientation = "column";
    targetWindow.alignChildren = "fill";
    targetWindow.margins = WINDOW_MARGINS;
    targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
}

/**
 * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
 * @param {Panel} targetPanel - 対象のパネル
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupPanel(targetPanel, spacing) {
    targetPanel.orientation = "column";
    targetPanel.alignChildren = ["fill", "top"];
    targetPanel.alignment = "fill";
    targetPanel.margins = PANEL_MARGINS;
    targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * タブの共通設定
 * @param {Tab} targetTab - 対象のタブ
 * @param {number} [spacing] - 要素間隔（省略時は変えない）
 * @returns {void}
 */
function setupTab(targetTab, spacing) {
    targetTab.orientation = "column";
    targetTab.alignChildren = "fill";
    targetTab.margins = TAB_MARGINS;
    if (typeof spacing === "number") targetTab.spacing = spacing;
}

/**
 * 横並びの行グループの共通設定（ボタン列など）。
 * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
 * @param {Group} rowGroup - 対象のグループ
 * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupRow(rowGroup, rowAlignment, spacing) {
    rowGroup.orientation = "row";
    rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
    rowGroup.alignChildren = ["left", "center"];
    rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
 * @param {Button} targetButton - 対象のボタン
 * @param {number} trimPixels - 詰める量（px）
 * @returns {void}
 */
function trimButtonHeight(targetButton, trimPixels) {
    /* レイアウト前は size が無い / size is not set until the layout runs */
    if (!targetButton.size) return;
    targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
}

// UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

// =========================================
// ユーザー設定 / User settings
// =========================================

/* 基準サイズとスケール / Base size and scale */
var DEFAULT_BASE_SIZE_PT  = 9;      /* 基準サイズ（本文, pt）/ base body size (pt) */
var DEFAULT_BASE_SIZE_Q   = 13;     /* 基準サイズ（本文, Q）/ base body size (Q) */
var DEFAULT_RATIO         = 1.309;  /* スケール倍率 / scale ratio */
var DEFAULT_LEVEL_COUNT   = 4;      /* 見出しレベル数 / number of heading levels */

/* 行送りとアキの既定値（%）/ Default leading and spacing (%) */
var DEFAULT_BODY_LEADING_PERCENT      = 160;  /* 本文の行送り / body leading */
var DEFAULT_HEADING_LEADING_PERCENT   = 115;  /* 見出しの行送り / heading leading */
var MAX_AUTO_LEADING_PERCENT          = 500;  /* 自動行送りの上限。超えると「データが範囲外です」 / auto leading upper limit */
var DEFAULT_SPACE_BEFORE_PERCENT      = 10;   /* 見出しの段落前のアキ / space before headings */
var DEFAULT_SPACE_AFTER_PERCENT       = 10;   /* 見出しの段落後のアキ / space after headings */
var DEFAULT_BODY_SPACE_BEFORE_PERCENT = 15;   /* 本文の段落前のアキ / space before body */
var DEFAULT_BODY_SPACE_AFTER_PERCENT  = 15;   /* 本文の段落後のアキ / space after body */

/* 本文サイズに対するリスト／表の文字サイズ比率（%）/ List and table size as a percentage of the body size */
var DEFAULT_LIST_SIZE_PERCENT  = 100;  /* ul-li / ol-li / List Paragraph */
var DEFAULT_TABLE_SIZE_PERCENT = 94;   /* td / th */

/* 段落前後のアキを段落スタイルへ適用するか / Whether to write spaceBefore and spaceAfter to the styles */
var ENABLE_SPACE_BEFORE = true;
var ENABLE_SPACE_AFTER  = true;

/* 「同じスタイルの段落間隔」を適用するか。スタイル名ごとのルールは resolveSameStyleSpacing を参照
   / Whether to write sameParaStyleSpacing; see resolveSameStyleSpacing for the per-style rules
     ul-li      → 0（箇条書きの項目どうしは詰める / bullet items are kept tight）
     p / ol-li  → 段落前のアキと同じ値 / same value as spaceBefore
     それ以外   → 変更しない / left unchanged */
var ENABLE_SAME_STYLE_SPACING = true;

/* 字揃えを強制適用するか。false なら元の字揃えを保持する
   / Whether to force the justification; false keeps the original justification */
var ENABLE_JUSTIFICATION = false;

// UI の明暗（再利用パーツ） / UI theme (reusable)

/**
 * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
 * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
 */
function isDarkUI() {
    try {
        if (app.preferences && app.preferences.getRealPreference) {
            return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
        }
        return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
    } catch (e) {
        return false;
    }
}

// UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

// ステップボタン（再利用パーツ） / Stepper buttons (reusable)

// -----------------------------------------
// ステップボタンの寸法・増減量 / Stepper metrics and steps
// -----------------------------------------
var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

/* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
   UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
   「p」は「1p6」（1パイカ6ポイント）の形にも使う
   Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
var STEPPER_UNIT_ALIASES = {
    "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
    "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
    "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
};

// -----------------------------------------
// ステップボタンの配色 / Stepper colors
// -----------------------------------------
var STEPPER_UI_DARK           = isDarkUI();
/* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
   ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
   UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
   dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

// -----------------------------------------
// 数値欄を作る（外から呼ぶ関数） / Public API
// -----------------------------------------
/**
 * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
 * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
 * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
 * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と異なる単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
 * @param {Group|Panel} parent - 追加先
 * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
 *     step / min / max / integer（true で整数のみ）/ unit / onStep
 * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
 */
function addSteppedField(parent, fieldOptions) {
    var fieldRowGroup = parent.add("group");
    fieldRowGroup.orientation = "row";
    fieldRowGroup.alignChildren = ["left", "center"];
    fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

    var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
    if (fieldOptions.labelWidth) {
        fieldLabel.preferredSize.width = fieldOptions.labelWidth;
        fieldLabel.justify = "right";
    }

    /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
    var stepperInputGroup = fieldRowGroup.add("group");
    stepperInputGroup.orientation = "row";
    stepperInputGroup.alignChildren = ["left", "center"];
    stepperInputGroup.spacing = 0;
    stepperInputGroup.margins = 0;

    var numberInput;
    var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
    numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
    numberInput.characters = fieldOptions.characters || 6;
    numberInput.fieldLabel = fieldLabel;
    numberInput.stepperGroup = stepperGroup;

    /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
    bindSteppedArrowKeys(numberInput, stepperGroup);

    /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
    numberInput.lastValidText = numberInput.text;
    numberInput.onChange = function () {
        var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
        if (isNaN(value)) {
            numberInput.text = numberInput.lastValidText;
            return;
        }
        writeSteppedValue(numberInput, value, fieldOptions);
    };
    return numberInput;
}

/**
 * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
 * @param {EditText} numberInput - addSteppedField() で作った入力欄
 * @param {boolean} isEnabled - 有効にするなら true
 * @returns {void}
 */
function setSteppedFieldEnabled(numberInput, isEnabled) {
    numberInput.enabled = isEnabled;
    numberInput.fieldLabel.enabled = isEnabled;
    numberInput.stepperGroup.enabled = isEnabled;
    /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
    for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
        redrawStepperGroup(numberInput.stepperGroup.children[i]);
    }
}

/**
 * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
 * @param {Group|Panel} parent - 追加先
 * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
 * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
 * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
 */
function addStepper(parent, getNumberInput, stepOptions) {
    var stepperGroup = parent.add("group");
    stepperGroup.orientation = "column";
    stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
    stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
    stepperGroup.alignment = ["left", "center"];

    /**
     * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @returns {void}
     */
    function stepBy(direction) {
        var numberInput = getNumberInput();
        if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
        var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
        if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
        if (isNaN(value)) value = 0;
        writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
        if (stepOptions.onStep) stepOptions.onStep(numberInput);
    }

    /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
    var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
    var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
    makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); }).helpTip = getLabel(upTooltip);
    makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); }).helpTip = getLabel(downTooltip);
    stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
    stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
    return stepperGroup;
}

/**
 * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
 * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
 * @param {EditText} numberInput - 対象の入力欄
 * @param {Group} stepperGroup - addStepper() で作った∧∨
 * @returns {void}
 */
function bindSteppedArrowKeys(numberInput, stepperGroup) {
    numberInput.addEventListener("keydown", function (event) {
        if (event.keyName !== "Up" && event.keyName !== "Down") return;
        stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
        event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
    });
    numberInput.addEventListener("change", function () {
        var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
        var value = evaluateArithmetic(numberInput.text, fieldUnit);
        if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
        /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
        var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
        if (!hasOperator && value === parseFloat(numberInput.text)) return;
        numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
    });
}

// -----------------------------------------
// 値の計算 / Value helpers
// -----------------------------------------
/**
 * 押された修飾キーに応じて、1回分増減した値を返す
 * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
 * 整数の欄では option を無視して step の倍数へ）
 * @param {number} value - 元の値
 * @param {number} direction - 増やすなら 1、減らすなら -1
 * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
 * @returns {number} 増減した値（下限・上限は未適用）
 */
function computeSteppedValue(value, direction, stepOptions) {
    var keyState = ScriptUI.environment.keyboardState;
    if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
    if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
    return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
}

/**
 * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
 * @param {number} value - 元の値
 * @param {number} multiple - 倍数の単位（例 10）
 * @param {number} direction - 上げるなら 1、下げるなら -1
 * @returns {number} 移した値
 */
function snapStepperToNextMultiple(value, multiple, direction) {
    /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
       round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
    var quotient = Math.round(value / multiple * 1e6) / 1e6;
    if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
    return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
}

/**
 * 値を下限・上限の範囲に収める
 * @param {number} value - 数値
 * @param {Object} rangeOptions - min / max（どちらも省略可）
 * @returns {number} 範囲に収めた値
 */
function clampSteppedValue(value, rangeOptions) {
    if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
    if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
    return value;
}

/**
 * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
 * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
 * 全角の数字・記号と × ÷ は半角に直す
 * @param {string} text - 入力欄の文字列
 * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
 * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
 */
function evaluateArithmetic(text, fieldUnit) {
    var source = String(text)
        .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
        .replace(/×/g, "*")
        .replace(/÷/g, "/")
        .replace(/[−–—]/g, "-")
        .replace(/\s/g, "");
    if (source === "") return NaN;
    var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
    var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
    var position = 0;

    /**
     * 加減算の並び（項 ± 項 …）を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readSum() {
        var total = readProduct();
        while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
            var operator = source.charAt(position++);
            var operand = readProduct();
            total = (operator === "+") ? total + operand : total - operand;
        }
        return total;
    }

    /**
     * 乗除算の並び（因子 × 因子 …）を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readProduct() {
        var total = readFactor();
        while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
            var operator = source.charAt(position++);
            var operand = readFactor();
            if (operator === "/" && operand === 0) return NaN;
            total = (operator === "*") ? total * operand : total / operand;
        }
        return total;
    }

    /**
     * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readFactor() {
        var ch = source.charAt(position);
        if (ch === "+" || ch === "-") {
            position++;
            var signedValue = readFactor();
            return (ch === "-") ? -signedValue : signedValue;
        }
        if (ch === "(") {
            position++;
            var innerValue = readSum();
            if (source.charAt(position) !== ")") return NaN;
            position++;
            return innerValue;
        }
        var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
        if (!numberMatch) return NaN;
        position += numberMatch[0].length;
        return readUnitSuffix(parseFloat(numberMatch[0]));
    }

    /**
     * 数値の直後の単位を読み、欄の単位へ換算する
     * @param {number} value - 単位の前の数値
     * @returns {number} 欄の単位での値（換算できない単位なら NaN）
     */
    function readUnitSuffix(value) {
        var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
        if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
        position += unitMatch[0].length;
        var unitKey = unitMatch[0].toLowerCase();
        if (unitKey === fieldUnitKey) return value;
        var typedValue = createStepperUnitValue(value, unitKey);
        if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
        var points = typedValue.as("pt");
        /* 「1p6」＝1パイカ6ポイント / pica-point notation */
        if (unitKey === "p") {
            var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (pointMatch) {
                position += pointMatch[0].length;
                points += parseFloat(pointMatch[0]);
            }
        }
        return points / fieldUnitValue.as("pt");
    }

    var result = readSum();
    if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
    return result;
}

/**
 * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
 * %（percent）は基準の長さが無いと換算できないので扱わない
 * @param {number} value - 数値
 * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
 * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
 */
function createStepperUnitValue(value, unitKey) {
    if (unitKey === "" || unitKey === "%") return null;
    var alias = STEPPER_UNIT_ALIASES[unitKey];
    var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
    if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
    return unitValue;
}

/**
 * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
 * @param {EditText} numberInput - 書き込む入力欄
 * @param {number} value - 数値
 * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
 * @returns {void}
 */
function writeSteppedValue(numberInput, value, valueOptions) {
    numberInput.text = formatSteppedValue(value, valueOptions);
    numberInput.lastValidText = numberInput.text;
}

/**
 * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
 * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
 * @param {number} value - 数値
 * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
 * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
 */
function formatSteppedValue(value, valueOptions) {
    if (valueOptions.integer) value = Math.round(value);
    return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
}

/**
 * 小数第2位で丸めた数値を文字列で返す
 * @param {number} value - 数値
 * @returns {string} 表示用の数値文字列
 */
function formatStepperNumber(value) {
    return String(Math.round(value * 100) / 100);
}

// -----------------------------------------
// ∧∨ボタンの描画 / Drawing
// -----------------------------------------
/**
 * 山形（∧／∨）の極小ボタンを作成する。
 * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
 * 継ぎ目に線は引かない
 * @param {Group|Panel} parent - 追加先
 * @param {string} direction - "up" または "down"
 * @param {Function} onClickFn - クリック時の処理
 * @returns {Group} ボタンとして使う group
 */
function makeStepperChevronButton(parent, direction, onClickFn) {
    var buttonWidth = STEPPER_BUTTON_WIDTH;
    var buttonHeight = STEPPER_BUTTON_HEIGHT;
    var isUp = (direction === "up");
    var chevronBox = parent.add("group");
    chevronBox.margins = 0;
    chevronBox.spacing = 0;
    chevronBox.preferredSize = [buttonWidth, buttonHeight];
    chevronBox.minimumSize = [buttonWidth, buttonHeight];
    chevronBox.maximumSize = [buttonWidth, buttonHeight];
    chevronBox.isPressed = false;
    chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

    chevronBox.onDraw = function () {
        var boxGraphics = chevronBox.graphics;
        /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
           Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
        var isDimmed = !isStepperEnabledInTree(chevronBox);

        /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
        var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
        boxGraphics.newPath();
        boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
        boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

        drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
        drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
    };

    /**
     * 押下状態を変えて描き直す
     * @param {boolean} isPressed - 押下中なら true
     * @returns {void}
     */
    function repaint(isPressed) {
        if (chevronBox.isPressed === isPressed) return;
        chevronBox.isPressed = isPressed;
        redrawStepperGroup(chevronBox);
    }
    chevronBox.addEventListener("mousedown", function () {
        if (!isStepperEnabledInTree(chevronBox)) return;
        repaint(true);
        if (onClickFn) onClickFn();
    });
    chevronBox.addEventListener("mouseup", function () { repaint(false); });
    /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
    chevronBox.addEventListener("mouseout", function () { repaint(false); });
    return chevronBox;
}

/**
 * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
 * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
 * @param {ScriptUIGraphics} boxGraphics - 描画先
 * @param {number} boxWidth - ボタンの幅
 * @param {number} boxHeight - ボタンの高さ
 * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
 * @param {number[]} frameColor - [r, g, b, a]
 * @returns {void}
 */
function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
    var frameLeft = 0.5;
    var frameRight = boxWidth - 0.5;
    var outerY = isUp ? 0.5 : boxHeight - 0.5;
    var seamY = isUp ? boxHeight : 0;
    var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
    var radius = STEPPER_CORNER_RADIUS;
    var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
    var angle, k;

    boxGraphics.newPath();
    boxGraphics.moveTo(frameLeft, seamY);
    /* 左の角丸 / left corner */
    for (k = 0; k <= arcSteps; k++) {
        angle = (Math.PI / 2) * k / arcSteps;
        boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
    }
    /* 右の角丸 / right corner */
    for (k = 0; k <= arcSteps; k++) {
        angle = (Math.PI / 2) * k / arcSteps;
        boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
    }
    boxGraphics.lineTo(frameRight, seamY);
    boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
}

/**
 * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
 * @param {ScriptUIGraphics} boxGraphics - 描画先
 * @param {number} boxWidth - ボタンの幅
 * @param {number} boxHeight - ボタンの高さ
 * @param {boolean} isUp - ∧なら true、∨なら false
 * @param {number[]} chevronColor - [r, g, b, a]
 * @returns {void}
 */
function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
    var centerX = boxWidth / 2;
    var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
    var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
    var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
    boxGraphics.newPath();
    boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
    boxGraphics.lineTo(centerX, centerY + tipOffsetY);
    boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
    boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
}

/**
 * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
 * @param {Object} control - 対象のコントロール
 * @returns {boolean} すべて有効なら true
 */
function isStepperEnabledInTree(control) {
    for (var node = control; node; node = node.parent) {
        if (!node.enabled) return false;
    }
    return true;
}

/**
 * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
 * @param {Object} container - 行・グループ・パネルなど
 * @returns {void}
 */
function redrawSteppersIn(container) {
    if (!container.children) return;
    for (var i = 0; i < container.children.length; i++) {
        var child = container.children[i];
        if (child.isStepperButton) redrawStepperGroup(child);
        else redrawSteppersIn(child);
    }
}

/**
 * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
 * @param {Group} targetGroup - 描き直す group
 * @returns {void}
 */
function redrawStepperGroup(targetGroup) {
    targetGroup.hide();
    targetGroup.show();
}

// ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

// =========================================
// ラベル定義 / Labels
// =========================================

// ローカライズ（再利用パーツ） / Localization (reusable)

/**
 * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
 * @returns {string} "ja" または "en"
 */
function getCurrentLang() {
    return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
}

var uiLang = getCurrentLang();

/**
 * LABELS から今の UI 言語の文言を取り出す。
 * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
 * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
 * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
 */
function getLabel(labelRef, placeholderValues) {
    var labelEntry = labelRef;
    if (typeof labelRef === "string") {
        var labelPathKeys = labelRef.split(".");
        labelEntry = LABELS;
        for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
            labelEntry = labelEntry[labelPathKeys[i]];
        }
    }
    var labelString;
    if (typeof labelEntry === "string") labelString = labelEntry;
    else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
    else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
    else return (typeof labelRef === "string") ? labelRef : "";
    return fillLabelPlaceholders(String(labelString), placeholderValues);
}

/**
 * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {Object|Array} [placeholderValues] - getLabel と同じ
 * @returns {string} コロン付きの文言
 */
function labelText(labelRef, placeholderValues) {
    return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
}

/**
 * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {string|number} value - コロンのあとに続ける値
 * @returns {string} 項目名と値をつないだ文字列
 */
function labelValueText(labelRef, value) {
    return labelText(labelRef) + " " + value;
}

/**
 * 文言の {name} や %1 に値を差し込む
 * @param {string} labelString - 文言
 * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
 * @returns {string} 差し込んだ文言
 */
function fillLabelPlaceholders(labelString, placeholderValues) {
    if (placeholderValues == null) return labelString;
    if (placeholderValues instanceof Array) {
        /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
        for (var i = placeholderValues.length; i >= 1; i--) {
            labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
        }
        return labelString;
    }
    for (var placeholderKey in placeholderValues) {
        if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
        labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
    }
    return labelString;
}

// ローカライズ（再利用パーツ）ここまで / End of the reusable localization

// ボタン行（再利用パーツ） / Button row (reusable)

var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

/**
 * ダイアログ下部のボタン行を作る。
 * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
 * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
 * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
 * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
 */
function addButtonRow(parent, rowOptions) {
    var isCentered = !!(rowOptions && rowOptions.centered);
    var btnRowGroup = parent.add("group");
    btnRowGroup.orientation = "row";
    btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
    btnRowGroup.spacing = BUTTON_ROW_SPACING;

    if (isCentered) {
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
    }

    btnRowGroup.alignment = ["fill", "bottom"];

    var btnLeftGroup = btnRowGroup.add("group");
    btnLeftGroup.alignChildren = ["left", "center"];
    btnLeftGroup.spacing = BUTTON_ROW_SPACING;

    /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
    var spacer = btnRowGroup.add("group");
    spacer.alignment = ["fill", "fill"];
    spacer.minimumSize.width = 0;

    var btnRightGroup = btnRowGroup.add("group");
    btnRightGroup.alignChildren = ["right", "center"];
    btnRightGroup.spacing = BUTTON_ROW_SPACING;

    return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
}

/**
 * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
 * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
 * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
 * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
 * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
 * @returns {void}
 */
function alignRightOnlyButtonRow(buttonRow) {
    if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
    var dialogWindow = buttonRow.rowGroup.window;
    dialogWindow.addEventListener("show", function () {
        if (!buttonRow.leftGroup) return;
        var btnRowGroup = buttonRow.rowGroup;
        /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
        if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
        /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
        btnRowGroup.remove(buttonRow.leftGroup);
        btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        buttonRow.leftGroup = null;
        dialogWindow.layout.layout(true);
    });
}

// ボタン行（再利用パーツ）ここまで / End of the reusable button row

// バージョン表示（再利用パーツ） / Version footer (reusable)

var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

/* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
   9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
   / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
     nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
var VERSION_FOOTER_GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
    "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
    "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
    "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
    "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
    "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
    "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
    "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
    "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
    "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
    "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
    "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
    "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
    "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
    "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
    "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
    "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
    "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
    "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
    "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
    "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
    "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
    "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
    "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
    "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
    "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
    "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
    "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
    "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
    "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
    "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
    "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
    "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
    "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
    "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
    "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
    "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
    "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
    ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
    "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
    "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
    "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
    " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
};

/**
 * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
 * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
 * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
 * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
 * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
 */
function addVersionFooter(targetWindow) {
    if (targetWindow.versionFooter) return null;

    /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
    var lastChild = targetWindow.children[targetWindow.children.length - 1];
    if (lastChild && lastChild.type === "group") {
        var rowMargins = lastChild.margins;
        lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
    }
    var windowMargins = targetWindow.margins;
    targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

    var footerGroup = targetWindow.add("group");
    footerGroup.orientation = "row";
    footerGroup.alignment = ["fill", "bottom"];
    footerGroup.alignChildren = ["left", "center"];
    footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

    /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
       左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
       / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
         or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
    var versionText = String(SCRIPT_VERSION);
    var leftCandidates = [versionText];
    if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
    var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
    versionCanvas.alignment = ["fill", "center"];
    bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
    var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
    brandCanvas.alignment = ["right", "center"];
    brandCanvas.maximumSize = brandCanvas.preferredSize;
    targetWindow.versionFooter = footerGroup;
    return versionCanvas;
}

/**
 * 文字列のすべての文字に字形があるかを返す
 * @param {string} dotText - 文字列
 * @returns {boolean} すべてあれば true
 */
function hasVersionFooterGlyphs(dotText) {
    for (var i = 0; i < dotText.length; i++) {
        if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
    }
    return dotText.length > 0;
}

/**
 * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
 * @param {Group} parentGroup - 足す先
 * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
 * @returns {Group} 描くグループ
 */
function addVersionFooterCanvas(parentGroup, dotTexts) {
    var dotCanvas = parentGroup.add("group");
    var shortestText = dotTexts[dotTexts.length - 1];
    dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
    dotCanvas.helpTip = dotTexts[0];
    dotCanvas.onDraw = function () {
        var availableWidth = this.size ? this.size.width : 0;
        var drawText = shortestText;
        for (var i = 0; i < dotTexts.length; i++) {
            if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                drawText = dotTexts[i];
                break;
            }
        }
        drawVersionFooterDots(this.graphics, drawText);
    };
    return dotCanvas;
}

/**
 * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
 * @param {string} versionText - 文字列
 * @returns {number} 幅（ドット）
 */
function measureVersionFooterDots(versionText) {
    var dotCount = 0;
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
        dotCount += glyphRows[0].length;
    }
    return dotCount;
}

/**
 * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
 * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
 * @param {string} versionText - 文字列
 * @returns {void}
 */
function drawVersionFooterDots(canvasGraphics, versionText) {
    var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
    var dotSize = VERSION_FOOTER_PIXEL_SIZE;
    var cursorDots = 0;
    canvasGraphics.newPath();
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
        for (var row = 0; row < glyphRows.length; row++) {
            var rowText = glyphRows[row];
            var runStart = -1;
            for (var col = 0; col <= rowText.length; col++) {
                var isDot = col < rowText.length && rowText.charAt(col) === "#";
                if (isDot && runStart < 0) runStart = col;
                if (!isDot && runStart >= 0) {
                    canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                    runStart = -1;
                }
            }
        }
        cursorDots += glyphRows[0].length;
    }
    canvasGraphics.fillPath(footerBrush);
}

// -----------------------------------------
// このスクリプトについて / About this script
// -----------------------------------------
/* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
   この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
   Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
   and keeps its own labels and layout values so the part works on its own */

var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
/* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
   The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
/* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

var VERSION_INFO_LABELS = {
    dialog: {
        title: { ja: "このスクリプトについて", en: "About This Script" }
    },
    panel: {
        generalInfo: { ja: "基本情報", en: "General" },
        links: { ja: "リンク", en: "Links" }
    },
    fieldLabel: {
        scriptName: { ja: "スクリプト名", en: "Script Name" },
        scriptFeature: { ja: "機能", en: "Feature" },
        scriptVersion: { ja: "バージョン", en: "Version" }
    },
    button: {
        openReadme: { ja: "README", en: "README" },
        openSourceCode: { ja: "ソースコード", en: "Source Code" },
        openArticle: { ja: "記事（note）", en: "Article (note)" },
        revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
        revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
        close: { ja: "閉じる", en: "Close" }
    },
    tooltip: {
        versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
        copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
    },
    alert: {
        copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
    }
};

/**
 * VERSION_INFO_LABELS の文言を今の言語で返す
 * @param {Object} labelEntry - { ja, en }
 * @returns {string} 文言
 */
function getVersionInfoLabel(labelEntry) {
    return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
}

/**
 * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
 * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
 * @returns {string} 値
 */
function getVersionInfoValue(variableKey) {
    var infoValue;
    if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
    else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
    else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
    else if (variableKey === "readme") {
        if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
        else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
    }
    else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
    else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
    return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
}

/**
 * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
 * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
 * @returns {void}
 */
function bindVersionInfoClick(versionCanvas) {
    versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
    /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
       Open on mouseup so the release does not land on the footer after the dialog closes */
    versionCanvas.addEventListener("mouseup", function () {
        showVersionInfoDialog(versionCanvas.window.type === "palette");
    });
}

/**
 * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
 * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
 * @returns {void}
 */
function showVersionInfoDialog(isFromPalette) {
    var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
    infoDialog.orientation = "column";
    infoDialog.alignChildren = "fill";
    infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
    infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

    var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
    /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
    /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
    if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
    }
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
    alignVersionInfoLabels(infoPanel);

    /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
    var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
    var linkButtonRow = linksPanel.add("group");
    linkButtonRow.orientation = "row";
    linkButtonRow.alignment = ["left", "center"];
    linkButtonRow.alignChildren = ["left", "center"];
    linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

    /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
    var buttonRow = infoDialog.add("group");
    buttonRow.orientation = "row";
    buttonRow.alignment = ["fill", "bottom"];
    buttonRow.alignChildren = ["left", "center"];
    buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
    buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
    var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
    if (VERSION_INFO_SCRIPT_FILE.exists) {
        revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
        revealButton.onClick = function () {
            revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
            infoDialog.close();
        };
    } else {
        revealButton.enabled = false;
    }
    /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
    var buttonSpacer = buttonRow.add("group");
    buttonSpacer.alignment = ["fill", "fill"];
    buttonSpacer.minimumSize.width = 0;
    var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
    closeButton.alignment = ["right", "center"];
    /* return でも esc でも閉じる / Close with both Return and Esc */
    infoDialog.defaultElement = closeButton;
    infoDialog.cancelElement = closeButton;
    infoDialog.onShow = function () {
        pinVersionInfoCopyButton(infoPanel);
    };
    infoDialog.show();
}

/**
 * 「このスクリプトについて」のダイアログにパネルを足す
 * @param {Window} infoDialog - 足す先のダイアログ
 * @param {Object} titleEntry - パネル名の文言 { ja, en }
 * @returns {Panel} パネル
 */
function addVersionInfoPanel(infoDialog, titleEntry) {
    var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
    infoPanel.orientation = "column";
    infoPanel.alignChildren = ["fill", "top"];
    infoPanel.alignment = "fill";
    infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
    infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
    return infoPanel;
}

/**
 * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
 * @param {Panel} infoPanel - 足す先のパネル
 * @param {Object} labelEntry - 項目名の文言 { ja, en }
 * @param {string} valueText - 表示する値
 * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
 * @returns {StaticText} 値の statictext
 */
function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
    var infoRow = infoPanel.add("group");
    infoRow.orientation = "row";
    infoRow.alignment = ["fill", "center"];
    infoRow.alignChildren = ["left", "center"];
    infoRow.spacing = VERSION_INFO_ROW_SPACING;
    /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
    var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
    rowLabel.justify = "right";
    var valueLabel = infoRow.add("statictext", undefined, valueText);
    if (copyFromPalette === null) return valueLabel;
    /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
       A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
    var copySpacer = infoRow.add("group");
    copySpacer.alignment = ["fill", "fill"];
    copySpacer.minimumSize.width = 0;
    infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
    return valueLabel;
}

/**
 * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
 * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
 * @param {Panel} infoPanel - ［基本情報］パネル
 * @returns {void}
 */
function pinVersionInfoCopyButton(infoPanel) {
    var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
    for (var i = 0; i < infoPanel.children.length; i++) {
        var infoRow = infoPanel.children[i];
        if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
        infoRow.size = [innerWidth, infoRow.size.height];
        infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
    }
}

/**
 * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
 * @param {Panel} infoPanel - 対象のパネル
 * @returns {void}
 */
function alignVersionInfoLabels(infoPanel) {
    var rowLabels = [];
    var labelWidth = 0;
    for (var i = 0; i < infoPanel.children.length; i++) {
        var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
        rowLabels.push(rowLabel);
        labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
    }
    for (var j = 0; j < rowLabels.length; j++) {
        rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
    }
}

/**
 * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
 * @param {Window} infoDialog - ボタンを置くダイアログ
 * @param {Group} buttonGroup - 足す先のグループ
 * @param {Object} labelEntry - ボタンの文言 { ja, en }
 * @param {string} targetUrl - 開く URL（空ならディム表示）
 * @returns {void}
 */
function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
    var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
    if (!targetUrl) {
        linkButton.enabled = false;
        return;
    }
    linkButton.helpTip = targetUrl;
    linkButton.onClick = function () {
        openVersionInfoUrl(targetUrl);
        infoDialog.close();
    };
}

/**
 * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
 * @param {Group} infoRow - 足す先の行
 * @param {StaticText} valueLabel - コピーする値の statictext
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {Group} ボタンとして使う group
 */
function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
    var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
    var copyButton = infoRow.add("group");
    copyButton.preferredSize = [buttonSize, buttonSize];
    copyButton.minimumSize = [buttonSize, buttonSize];
    copyButton.maximumSize = [buttonSize, buttonSize];
    copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
    copyButton.isPressed = false;
    copyButton.isCopied = false;

    copyButton.onDraw = function () {
        var buttonGraphics = copyButton.graphics;
        var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
        buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
        if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
        else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
    };

    /**
     * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
     * @param {boolean} isPressed - 押下中なら true
     * @param {boolean} isCopied - コピー済みなら true
     * @returns {void}
     */
    function repaint(isPressed, isCopied) {
        if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
        copyButton.isPressed = isPressed;
        copyButton.isCopied = isCopied;
        copyButton.hide();
        copyButton.show();
    }
    copyButton.addEventListener("mousedown", function () { repaint(true, false); });
    copyButton.addEventListener("mouseup", function () {
        if (!copyButton.isPressed) return;
        var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
        repaint(false, hasCopied);
        if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
    });
    /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
    copyButton.addEventListener("mouseout", function () { repaint(false, false); });
    return copyButton;
}

/**
 * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
    var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
    var sheetSize = 9;
    var offset = 3;
    var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var backLeft = frontLeft - offset;
    var backTop = frontTop - offset;
    /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
    buttonGraphics.newPath();
    buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
    buttonGraphics.strokePath(iconPen);
    buttonGraphics.newPath();
    buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
    buttonGraphics.strokePath(iconPen);
}

/**
 * コピーしたあとのチェックマークを描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
    var center = buttonSize / 2;
    buttonGraphics.newPath();
    buttonGraphics.moveTo(center - 4.5, center);
    buttonGraphics.lineTo(center - 1.5, center + 3);
    buttonGraphics.lineTo(center + 4.5, center - 3.5);
    buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
}

/**
 * 文字列をクリップボードにコピーする。
 * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
 * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
 * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
 * @param {string} copyText - コピーする文字列
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {boolean} コピーの操作まで進めたら true
 */
function copyVersionInfoText(copyText, isFromPalette) {
    try {
        if (VERSION_INFO_IS_INDESIGN) {
            if (File.fs === "Windows") {
                app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
            } else {
                app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
            }
            return true;
        }
        var copyScript = buildVersionInfoCopyScript(copyText);
        if (!isFromPalette) return eval(copyScript) === true;
        var copyMessage = new BridgeTalk();
        copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
        copyMessage.body = copyScript;
        copyMessage.send();
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
 * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
 * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
 * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
 * @param {string} copyText - コピーする文字列
 * @returns {string} 実行すると true / false を返すスクリプト
 */
function buildVersionInfoCopyScript(copyText) {
    return [
        "(function (copyText) {",
        "    var usingTempDoc = (app.documents.length === 0);",
        "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
        "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
        "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
        "    var tempLayer = null;",
        "    var hasCopied = false;",
        "    try {",
        "        tempLayer = targetDoc.layers.add();",
        "        var tempFrame = tempLayer.textFrames.add();",
        "        tempFrame.contents = copyText;",
        "        app.redraw();",
        "        app.executeMenuCommand('deselectall');",
        "        tempFrame.selected = true;",
        "        app.redraw();",
        "        app.executeMenuCommand('copy');",
        "        app.redraw();",
        "        hasCopied = true;",
        "    } catch (e) { }",
        "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
        "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
        "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
        "    targetDoc.selection = null;",
        "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
        "    app.redraw();",
        "    return hasCopied;",
        "})(" + quoteVersionInfoString(copyText) + ");"
    ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
}

/**
 * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
 * @param {string} sourceText - 文字列
 * @returns {string} "…" の形のリテラル
 */
function quoteVersionInfoString(sourceText) {
    return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

/**
 * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
 * @param {File} scriptFile - 表示するファイル
 * @returns {void}
 */
function revealVersionInfoScriptFile(scriptFile) {
    /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
    var hasRevealApp = (File.fs === "Macintosh")
        && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
    /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
    if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
    /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
    scriptFile.parent.execute();
}

/**
 * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
 * @param {string} targetPath - 絶対パス
 * @returns {boolean} 書き出せたら true
 */
function writeVersionInfoRevealPath(targetPath) {
    var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
    pathFile.encoding = "UTF-8";
    pathFile.lineFeed = "Unix";
    if (!pathFile.open("w")) return false;
    var hasWritten = pathFile.write(targetPath);
    pathFile.close();
    return hasWritten;
}

/**
 * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
 * @param {string} targetUrl - 開く URL
 * @returns {void}
 */
function openVersionInfoUrl(targetUrl) {
    var isMac = (File.fs === "Macintosh");
    var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
    shortcutFile.encoding = "UTF-8";
    shortcutFile.open("w");
    if (isMac) {
        var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
        shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
            + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
    } else {
        shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
    }
    shortcutFile.close();
    shortcutFile.execute();
}

// バージョン表示（再利用パーツ）ここまで / End of the reusable version footer


/* 日英ラベル定義（カテゴリ別） / Japanese-English labels by category */
var LABELS = {
    dialog: {
        title: { ja: "タイプスケールで一括設定", en: "Type Scale Settings" }
    },
    undo: {
        applyTypeScale: { ja: "タイプスケールで一括設定", en: "Apply Type Scale" }
    },
    error: {
        noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
        invalidBaseSize: {
            ja: "基準サイズ（本文）には正の数値を入力してください。",
            en: "Enter a positive number for Base Size (Body)."
        },
        missingStyle: {
            ja: "段落スタイル「%1」が見つかりません。",
            en: "Paragraph style \"%1\" was not found."
        }
    },
    progress: {
        title: { ja: "処理中", en: "Processing" },
        loadingFonts: {
            ja: "フォント情報を読み込んでいます…",
            en: "Loading font information..."
        },
        preparingDialog: {
            ja: "ダイアログを準備しています…",
            en: "Preparing dialog..."
        }
    },
    panel: {
        bodyText: { ja: "本文", en: "Body" },
        headingText: { ja: "見出し", en: "Headings" },
        fontAssignment: { ja: "フォント指定オプション", en: "Font Assignment" },
        scaleSettings: { ja: "スケール設定", en: "Scale Settings" },
        preview: { ja: "段落スタイルとサイズプレビュー", en: "Paragraph Styles & Size Preview" }
    },
    fontMode: {
        same: {
            ja: "本文と見出しで共通",
            en: "Use same font for body and headings"
        },
        separate: {
            ja: "本文と見出しで別々に指定",
            en: "Specify body and heading fonts separately"
        }
    },
    checkbox: {
        includeFonts: { ja: "フォント、スタイルを含める", en: "Include fonts & styles" },
        sizeOnly: { ja: "サイズのみ", en: "Size only" }
    },
    field: {
        baseSize: { ja: "基準サイズ", en: "Base Size (Body)" },
        font: { ja: "フォント", en: "Font" },
        fontStyle: { ja: "スタイル", en: "Style" },
        bodyLeading: { ja: "行送り", en: "Leading Ratio (Body)" },
        headingLeading: { ja: "行送り", en: "Leading Ratio (Headings)" },
        kerning: { ja: "カーニング", en: "Kerning Method" },
        scaleMethod: { ja: "スケール方式", en: "Scale Method" },
        headingLevels: { ja: "見出しレベル数", en: "Heading Levels" },
        sizeRounding: { ja: "サイズの丸め", en: "Size Rounding" }
    },
    kerning: {
        japaneseMono: { ja: "和文等幅", en: "Japanese Mono" },
        metrics: { ja: "メトリクス", en: "Metrics" },
        optical: { ja: "オプティカル", en: "Optical" }
    },
    rounding: {
        integer: { ja: "整数", en: "Integer" },
        firstDecimal: { ja: "小数点第1位", en: "1 decimal place" },
        secondDecimal: { ja: "小数点第2位", en: "2 decimal places" }
    },
    column: {
        level: { ja: "レベル", en: "Level" },
        size: { ja: "サイズ", en: "Size" },
        spaceBefore: { ja: "段落前アキ", en: "Space Before" },
        spaceAfter: { ja: "段落後のアキ", en: "Space After" },
        paragraphStyle: { ja: "段落スタイル", en: "Paragraph Style" },
        fontStyle: { ja: "ウエイト", en: "Weight" }
    },
    row: {
        levelPrefix: { ja: "レベル", en: "Level " },
        baseBody: { ja: "★基準（本文）", en: "★Base (Body)" },
        list: { ja: "リスト", en: "List" },
        table: { ja: "テーブル", en: "Table" },
        caption: { ja: "キャプション", en: "Caption" }
    },
    option: {
        noFontChange: { ja: "（変更しない）", en: "(No change)" },
        refBodyFont: { ja: "本文のフォントを参照", en: "Reference body font" },
        notAvailable: { ja: "—", en: "—" }
    },
    tooltip: {
        stepUp: {
            ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
            en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
        },
        stepDown: {
            ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
            en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
        },
        stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
        stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
    },
    button: {
        cancel: { ja: "キャンセル", en: "Cancel" },
        ok: { ja: "OK", en: "OK" }
    },
    ratio: {
        minorSecond: { ja: "短2度", en: "Minor Second" },
        majorSecond: { ja: "長2度", en: "Major Second" },
        minorThird: { ja: "短3度", en: "Minor Third" },
        majorThird: { ja: "長3度", en: "Major Third" },
        goldenHalf: { ja: "黄金比：1/2", en: "Golden Ratio: ½" },
        perfectFourth: { ja: "完全4度", en: "Perfect Fourth" },
        augmentedFourth: { ja: "増4度", en: "Augmented Fourth" },
        golden: { ja: "黄金比", en: "Golden Ratio" },
        browserDefault: { ja: "ブラウザー既定", en: "Browser Default" }
    }
};

/**
 * 進捗表示用のパレットを作る
 * @param {string} message 最初に表示するメッセージ
 * @returns {Window|null} パレット。作成できない場合は null
 */
function createProgressPalette(message) {
    var palette = new Window("palette", getLabel("progress.title"));
    setupWindow(palette, 10);

    var messageText = palette.add("statictext", undefined, message);
    messageText.preferredSize.width = 260;

    var progressBar = palette.add("progressbar", undefined, 0, 100);
    progressBar.preferredSize.width = 260;
    progressBar.preferredSize.height = 6; // バーを細く
    progressBar.value = 20;

    // 後からメッセージ・進捗を更新できるよう参照を保持 / Keep references so the message/value can be updated later
    palette.messageText = messageText;
    palette.progressBar = progressBar;

    palette.show();
    try { palette.update(); } catch (e) { }
    return palette;
}

/**
 * 進捗パレットのメッセージを更新する
 * @param {Window} palette 対象のパレット
 * @param {string} message 表示するメッセージ
 * @param {number} value 進捗バーの値（0〜100）
 * @returns {void}
 */
function updateProgressPalette(palette, message, value) {
    if (!palette) return;
    try {
        if (message && palette.messageText) palette.messageText.text = message;
        if (typeof value === "number" && palette.progressBar) palette.progressBar.value = value;
        palette.update();
    } catch (e) { }
}

/**
 * 進捗パレットを閉じる
 * @param {Window} palette 対象のパレット
 * @returns {void}
 */
function closeProgressPalette(palette) {
    if (!palette) return;
    try { palette.close(); } catch (e) { }
}

// =========================================
// 単位 / Units
// =========================================

/* ポイント換算係数（pt = 値 × factor） / Point conversion factor per unit */
var UNIT_POINT_CONVERTERS = [
    { name: "POINTS", label: "pt", factor: 1 },
    { name: "MILLIMETERS", label: "mm", factor: 2.834645669 },
    { name: "CENTIMETERS", label: "cm", factor: 28.34645669 },
    { name: "INCHES", label: "inch", factor: 72 },
    { name: "INCHES_DECIMAL", label: "inch", factor: 72 },
    { name: "PICAS", label: "pica", factor: 12 },
    { name: "CICEROS", label: "c", factor: 12.7896 },
    { name: "AGATES", label: "ag", factor: 1 },
    { name: "PIXELS", label: "px", factor: 1 },
    { name: "Q", label: "Q", factor: 0.708661417 }, /* 1Q = 0.25mm / 1Q = 0.25mm */
    { name: "HA", label: "H", factor: 0.708661417 }
];

/**
 * 単位の列挙値を数値として取得する
 * @param {MeasurementUnits} unitName 対象の単位
 * @returns {number} 単位を表す数値
 */
function getMeasurementUnitValue(unitName) {
    try {
        return MeasurementUnits[unitName];
    } catch (e) { }
    return null;
}

/**
 * 環境設定のテキストサイズ単位を取得する
 * @returns {MeasurementUnits} テキストサイズの単位
 */
function getTextSizeUnit() {
    // ドキュメントの文字サイズ単位 → アプリ既定 → 定規単位 → pt の順にフォールバック
    // （単位はドキュメントごとに持つため、開いている書類がある間はそちらが実際の表示単位）
    try {
        if (app.documents.length > 0) {
            var documentTextSizeUnit = app.activeDocument.viewPreferences.textSizeMeasurementUnits;
            if (documentTextSizeUnit !== undefined && documentTextSizeUnit !== null) return documentTextSizeUnit;
        }
    } catch (eDocumentUnit) { }
    try {
        var textSizeUnit = app.viewPreferences.textSizeMeasurementUnits;
        if (textSizeUnit !== undefined && textSizeUnit !== null) return textSizeUnit;
    } catch (e) { }
    try {
        return app.viewPreferences.horizontalMeasurementUnits;
    } catch (e) { }
    return MeasurementUnits.POINTS;
}

/**
 * 単位の表示記号を返す
 * @param {MeasurementUnits} unit 対象の単位
 * @returns {string} 単位の記号
 */
function unitSymbol(unit) {
    for (var unitIndex = 0; unitIndex < UNIT_POINT_CONVERTERS.length; unitIndex++) {
        if (unit === getMeasurementUnitValue(UNIT_POINT_CONVERTERS[unitIndex].name)) {
            return UNIT_POINT_CONVERTERS[unitIndex].label;
        }
    }
    return "pt";
}

/**
 * 現在の単位の数値をポイントへ換算する
 * @param {number} value 現在の単位での数値
 * @param {MeasurementUnits} unit 対象の単位
 * @returns {number} ポイント値
 */
function toPoints(value, unit) {
    // 各種単位をポイントに変換（内部計算はpt基準）
    for (var unitIndex = 0; unitIndex < UNIT_POINT_CONVERTERS.length; unitIndex++) {
        if (unit === getMeasurementUnitValue(UNIT_POINT_CONVERTERS[unitIndex].name)) {
            return value * UNIT_POINT_CONVERTERS[unitIndex].factor;
        }
    }
    return value;
}

/* 測定値の代入は必ず単位付き文字列で行う。素の数値は InDesign 側の現在単位で解釈されるため、
   pt のつもりの値が mm 環境では mm として入ってしまう（spaceBefore は縦の定規単位で解釈される）
   / Always assign measurements as unit-qualified strings; bare numbers are read in the current unit */
/**
 * ポイント値を単位付きの文字列にする
 * @param {number} valueInPoints ポイント値
 * @returns {string} "12.5pt" 形式の文字列
 */
function toPointString(valueInPoints) {
    return String(valueInPoints) + "pt";
}

/**
 * ポイント値を現在の単位へ換算する
 * @param {number} valueInPoints ポイント値
 * @param {MeasurementUnits} unit 対象の単位
 * @returns {number} 現在の単位での数値
 */
function fromPoints(valueInPoints, unit) {
    // ポイントを表示単位へ逆変換（pt → 表示単位）
    for (var unitIndex = 0; unitIndex < UNIT_POINT_CONVERTERS.length; unitIndex++) {
        if (unit === getMeasurementUnitValue(UNIT_POINT_CONVERTERS[unitIndex].name)) {
            return valueInPoints / UNIT_POINT_CONVERTERS[unitIndex].factor;
        }
    }
    return valueInPoints;
}

/* フォント一覧のキャッシュ：app.fonts.everyItem().getElements() が遅いので、ファミリー名・スタイル名のテーブルをディスクに保存して再利用する */
var FONT_CACHE_VERSION = "v1";
var FONT_CACHE_FILENAME = "TypeScaleStyleApplier_fontcache.txt";

/**
 * フォント一覧キャッシュのファイルを取得する
 * @returns {File} キャッシュファイル
 */
function getFontCacheFile() {
    try {
        var dir = new Folder(Folder.userData.fsName + "/TypeScaleStyleApplier");
        if (!dir.exists) dir.create();
        return new File(dir.fsName + "/" + FONT_CACHE_FILENAME);
    } catch (e) {
        return null;
    }
}

/**
 * ディスクからフォント一覧キャッシュを読み込む
 * @param {number} currentFontCount 現在のフォント数。キャッシュの有効判定に使う
 * @returns {object|null} キャッシュ。読み込めない場合は null
 */
function loadFontCache(currentFontCount) {
    var file = getFontCacheFile();
    if (!file || !file.exists) return null;
    file.encoding = "UTF-8";
    if (!file.open("r")) return null;
    try {
        var headerLine = file.readln();
        if (!headerLine) return null;
        var headerParts = headerLine.split("\t");
        if (headerParts[0] !== FONT_CACHE_VERSION) return null;
        var cachedCount = parseInt(headerParts[1], 10);
        if (isNaN(cachedCount) || cachedCount !== currentFontCount) return null;

        var families = [];
        var fontMap = {};
        while (!file.eof) {
            var line = file.readln();
            if (!line) continue;
            var parts = line.split("\t");
            var family = parts[0];
            if (!family) continue;
            var styles = [];
            for (var i = 1; i < parts.length; i++) {
                if (parts[i] && parts[i].length > 0) styles.push(parts[i]);
            }
            families.push(family);
            fontMap[family] = styles;
        }
        return { families: families, fontMap: fontMap };
    } catch (e) {
        return null;
    } finally {
        try { file.close(); } catch (e2) { }
    }
}

/**
 * フォント一覧をキャッシュとして書き出す
 * @param {number} fontCount 保存時のフォント数
 * @param {Array<string>} families フォントファミリー名の配列
 * @param {object} fontMap ファミリー名をキーにしたスタイル名の配列
 * @returns {void}
 */
function saveFontCache(fontCount, families, fontMap) {
    var file = getFontCacheFile();
    if (!file) return false;
    file.encoding = "UTF-8";
    if (!file.open("w")) return false;
    try {
        file.writeln(FONT_CACHE_VERSION + "\t" + fontCount);
        for (var i = 0; i < families.length; i++) {
            var family = families[i];
            var styles = fontMap[family] || [];
            file.writeln(family + "\t" + styles.join("\t"));
        }
        return true;
    } catch (e) {
        return false;
    } finally {
        try { file.close(); } catch (e2) { }
    }
}

/* ウエイトランクテーブル（TypefaceSampler.jsx より移植） */
/* IIFE 外に置くのは、ExtendScript の hoisting で IIFE 内 var が初期化前に参照されるのを避けるため */
var WEIGHT_GROUPS = [
    ["hairline"],                                                                  // 0
    ["ultra thin", "ultrathin", "ut"],                                              // 1
    ["thin", "th", "极细体", "極細體", "얇은체"],                                     // 2
    ["default"],                                                                    // 3
    ["ultralight", "ultra light", "ultlt", "ul"],                                   // 4
    ["extralight", "extra light", "el", "xlight", "xl", "xlig",
     "纤细体", "纖細體", "纤黑", "纖黑", "아주옅은체"],                                  // 5
    ["lightsemi"],                                                                  // 6
    ["light", "lt", "lite", "l", "ライト", "细体", "細體", "옅은체"],                  // 7
    ["lb", "semilight", "semi light", "demilight", "demi light"],                   // 8
    ["book", "bk"],                                                                 // 9
    ["n"],                                                                          // 10
    ["middle"],                                                                     // 11
    ["regular", "roman", "normal", "r", "レギュラー", "標準", "中", "rg",
     "常规体", "標準體", "标准", "中等", "일반체", "רגיל"],                              // 12
    ["rb"],                                                                         // 13
    ["medium", "md", "ミディアム", "m", "med", "中黑体", "中黑體", "中黑", "중간체"],    // 14
    ["semibold", "semi bold", "sb", "semi", "中粗体", "中粗體", "세미볼드체"],          // 15
    ["demibold", "demi bold", "db", "デミボールド", "demi", "d", "demixtra", "dm"],  // 16
    ["bold", "bd", "ボールド", "b", "粗体", "粗體", "볼드체", "עבה"],                  // 17
    ["extrabold", "extra bold", "xbold", "エクストラボールド", "e", "eb", "xb",
     "강한볼드체"],                                                                  // 18
    ["heavy", "h", "hv", "特黑"],                                                    // 19
    ["black", "extraheavy", "extra heavy", "eh", "黑体", "무거운"],                    // 20
    ["xblack", "extra black", "extrablack"],                                        // 21
    ["ultra", "u", "ub", "ultra black", "ultrablack", "ultrabold", "ultra bold",
     "ultraheavy", "ultra heavy", "uh"]                                             // 22
];
var WEIGHT_REGULAR_INDEX = 12;

/* 幅を表す複合語（Ultra Condensed など）。ultra / extra / semi をウェイト語と取り違えないよう照合前に除く
   / Width compounds, removed before matching so "ultra" or "semi" is not read as a weight */
var WEIGHT_WIDTH_COMPOUND_PATTERN = /(^|\s)(ultra|extra|semi)\s+(condensed|cond|compressed|comp|expanded|extended|wide)(?=\s|$)/g;

/* 大文字の続き書きで、語に分けない幅の複合語（ExtraCondensed は従来どおり1語として扱う）
   / Width compounds kept as one word when splitting camel case */
var WEIGHT_WIDTH_CAMEL_COMPOUND_PATTERN = /(Ultra|Extra|Semi)(Condensed|Expanded|Extended|Compressed|Wide)/g;

/* ファミリー独自の呼び方の上書き（スタイル名から斜体の語を除いた全体で照合し、WEIGHT_GROUPS の語に読み替える）
   / Family-specific style names, mapped to a WEIGHT_GROUPS term */
var WEIGHT_FAMILY_OVERRIDES = [
    /* YoOne・YoOrganic：Ut は Heavy と Black の間、Bk は Black、Ft はさらに太い */
    { familyPattern: /^(fot-)?yo(one|organic)/, terms: { "ut": "black", "bk": "xblack", "ft": "ultra" } },
    /* 芯・鉛筆：鉛筆の濃さ H＜F＜HB＜B＜2B */
    { familyPattern: /芯・鉛筆/, terms: { "h": "light", "f": "regular", "hb": "medium", "b": "bold", "2b": "extrabold" } },
    /* MLチョコレート：Regular＜SemiMelt＜Melt */
    { familyPattern: /^(ml|moolong)\s*チョコレート/, terms: { "semi melt": "bold", "melt": "black" } },
    /* Othoro Pro：Book は Regular より太い */
    { familyPattern: /^othoro/, terms: { "book": "rb" } }
];
var WEIGHT_REGULAR_SINGLES = [
    "display", "compressed", "comp", "compact", "expanded", "extended", "semiextended",
    "ultracondensed", "extracondensed", "semicondensed", "cond", "condensed", "wide",
    "headline", "text", "low", "micro", "extra compressed", "semi expanded", "semiexpanded"
];

/* 用語 → ランクの照合テーブル。長い用語を先に照合したいので長さの降順に並べ、
   正規表現もここで 1 度だけ作る（フォント数ぶん呼ばれるため、都度の生成は避ける）
   / Term-to-rank table, longest first; the regexes are built once */
var WEIGHT_TERM_PATTERNS = (function () {
    var terms = [];
    for (var groupIndex = 0; groupIndex < WEIGHT_GROUPS.length; groupIndex++) {
        for (var termIndex = 0; termIndex < WEIGHT_GROUPS[groupIndex].length; termIndex++) {
            terms.push({ term: WEIGHT_GROUPS[groupIndex][termIndex], index: groupIndex });
        }
    }
    terms.sort(function (a, b) { return b.term.length - a.term.length; });
    for (var patternIndex = 0; patternIndex < terms.length; patternIndex++) {
        terms[patternIndex].pattern = new RegExp(
            "\\b" + terms[patternIndex].term.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&") + "\\b"
        );
    }
    return terms;
})();

/**
 * スタイル名を照合用に正規化する
 * 全角英数字を半角にし、BoldItalic・LtIt のような大文字の続き書きを語に分ける
 * @param {string} rawStyleName フォントスタイル名
 * @returns {string} 小文字化し、区切り記号を空白に置き換えた文字列
 */
function normalizeWeightStyle(rawStyleName) {
    var styleText = (rawStyleName || "").toString().replace(/[\uFF01-\uFF5E]/g, function (fullWidthChar) {
        return String.fromCharCode(fullWidthChar.charCodeAt(0) - 0xFEE0);
    }).replace(/\u3000/g, " ");
    /* 幅の複合語に目印を挟んで分割から守る / Protect width compounds with a marker */
    styleText = styleText.replace(WEIGHT_WIDTH_CAMEL_COMPOUND_PATTERN, "$1\u0001$2");
    styleText = styleText.replace(/([a-z])([A-Z])/g, "$1 $2").replace(/([A-Z]{2,})([A-Z][a-z])/g, "$1 $2");
    styleText = styleText.replace(/\u0001/g, "");
    return styleText.toLowerCase().replace(/[_\-]+/g, " ").replace(/^\s+|\s+$/g, "");
}

/**
 * ファミリー独自の呼び方に当たるとき、その WEIGHT_GROUPS のインデックスを返す
 * @param {string} style 正規化済みのフォントスタイル名
 * @param {string} family フォントファミリー名
 * @returns {number} 一致したインデックス。上書きの対象でなければ -1
 */
function getFamilyOverrideGroupIndex(style, family) {
    var familyLower = (family || "").toLowerCase();
    var weightStyle = style.replace(/(^|\s)(it|italic|oblique)(?=\s|$)/g, " ").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
    for (var overrideIndex = 0; overrideIndex < WEIGHT_FAMILY_OVERRIDES.length; overrideIndex++) {
        var familyOverride = WEIGHT_FAMILY_OVERRIDES[overrideIndex];
        if (!familyOverride.familyPattern.test(familyLower)) continue;
        if (!familyOverride.terms.hasOwnProperty(weightStyle)) return -1;
        var targetTerm = familyOverride.terms[weightStyle];
        for (var groupIndex = 0; groupIndex < WEIGHT_GROUPS.length; groupIndex++) {
            for (var termIndex = 0; termIndex < WEIGHT_GROUPS[groupIndex].length; termIndex++) {
                if (WEIGHT_GROUPS[groupIndex][termIndex] === targetTerm) return groupIndex;
            }
        }
        return -1;
    }
    return -1;
}

/**
 * フォントスタイル名から太さの基準ランクを求める
 * @param {string} style 小文字化・正規化済みのフォントスタイル名
 * @param {string} family フォントファミリー名
 * @returns {number} 基準ランク
 */
function getStyleWeightBaseRank(style, family) {
    /* 空白を除いてから判定する（"Helvetica Neue" → "helveticaneue"）/ Strip spaces before matching */
    var familyLower = (family || "").toLowerCase().replace(/\s+/g, "");
    var words = style.split(/\s+/);

    /* ファミリー独自の呼び方を最優先 / Family-specific names come first */
    var overrideGroupIndex = getFamilyOverrideGroupIndex(style, family);
    if (overrideGroupIndex !== -1) return 1000 + overrideGroupIndex;

    var wMatch = style.match(/^w(\d)$/);
    if (wMatch !== null) return parseInt(wMatch[1], 10);
    var w3Match = style.match(/^w(\d{3})$/);
    if (w3Match !== null) return parseInt(w3Match[1], 10);
    var headNumMatch = style.match(/^(\d{1,3})(?=\D|$)/);
    /* 09 のような0始まりの2桁以上は通し番号として扱う / Leading-zero numbers are serials, not weights */
    if (headNumMatch && !(headNumMatch[1].length > 1 && headNumMatch[1].charAt(0) === "0")) return parseInt(headNumMatch[1], 10);

    // 特例：Helvetica Neue / Tazugane / Univers Next + Ultra Light → 999
    if (
        (/helveticaneue/.test(familyLower) || /tazugane/.test(familyLower) || /universnextpro/.test(familyLower)) &&
        /ultralight|ultra light|ultlt/.test(style)
    ) {
        return 999;
    }

    if (words.length === 1 && /^(italic|oblique|it|wide)$/.test(words[0])) {
        return 1000 + WEIGHT_REGULAR_INDEX;
    }
    if (words.length === 1) {
        for (var sIndex = 0; sIndex < WEIGHT_REGULAR_SINGLES.length; sIndex++) {
            if (words[0] === WEIGHT_REGULAR_SINGLES[sIndex]) return 1000 + WEIGHT_REGULAR_INDEX;
        }
    }

    /* 幅の複合語を除いてから照合する / Drop width compounds before matching */
    var weightStyle = style.replace(WEIGHT_WIDTH_COMPOUND_PATTERN, " ").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
    if (weightStyle === "") return 1000 + WEIGHT_REGULAR_INDEX;

    for (var groupIndex = 0; groupIndex < WEIGHT_GROUPS.length; groupIndex++) {
        for (var termIndex = 0; termIndex < WEIGHT_GROUPS[groupIndex].length; termIndex++) {
            if (weightStyle === WEIGHT_GROUPS[groupIndex][termIndex]) return 1000 + groupIndex;
        }
    }

    for (var patternIndex = 0; patternIndex < WEIGHT_TERM_PATTERNS.length; patternIndex++) {
        if (WEIGHT_TERM_PATTERNS[patternIndex].pattern.test(weightStyle)) {
            return 1000 + WEIGHT_TERM_PATTERNS[patternIndex].index;
        }
    }

    return 1000 + WEIGHT_REGULAR_INDEX;
}

/**
 * フォントスタイル名から並べ替え用の太さランクを求める
 * @param {string} styleName フォントスタイル名
 * @param {string} familyName フォントファミリー名
 * @returns {number} 太さランク
 */
function getStyleWeightRank(styleName, familyName) {
    var style = normalizeWeightStyle(styleName);
    var words = style.split(/\s+/);
    var baseRank = getStyleWeightBaseRank(style, familyName);
    var offset = 0;

    var flags = {
        hasText: false, hasHeadline: false, hasCondensed: false, hasCn: false,
        hasExpanded: false, hasExtended: false, hasUltraCondensed: false,
        hasExtraCondensed: false, hasSemiCondensed: false, hasCompressed: false,
        hasExtraCompressed: false, hasCompact: false, hasDisplay: false,
        hasMicro: false, hasLow: false, hasWide: false
    };
    for (var w = 0; w < words.length; w++) {
        var word = words[w], next = words[w + 1];
        if (word === "text") flags.hasText = true;
        if (word === "headline") flags.hasHeadline = true;
        if (word === "cond" || word === "condensed") flags.hasCondensed = true;
        if (word === "cn") flags.hasCn = true;
        if (word === "expanded") flags.hasExpanded = true;
        if (word === "extended") flags.hasExtended = true;
        if (word === "semiextended" || (word === "semi" && next === "extended")) flags.hasExtended = true;
        if (word === "semiexpanded" || (word === "semi" && next === "expanded")) flags.hasExpanded = true;
        if (word === "ultracondensed" || (word === "ultra" && next === "condensed")) flags.hasUltraCondensed = true;
        if (word === "extracondensed" || (word === "extra" && next === "condensed")) flags.hasExtraCondensed = true;
        if (word === "semicondensed" || (word === "semi" && next === "condensed")) flags.hasSemiCondensed = true;
        if (word === "compressed" || word === "comp") flags.hasCompressed = true;
        if (word === "extra" && next === "compressed") flags.hasExtraCompressed = true;
        if (word === "compact") flags.hasCompact = true;
        if (word === "display") flags.hasDisplay = true;
        if (word === "micro") flags.hasMicro = true;
        if (word === "low") flags.hasLow = true;
        if (word === "wide") flags.hasWide = true;
    }
    var isItalic = /italic|oblique|slanted|inclined|kursiv|\bit\b/.test(style);

    if (flags.hasDisplay) offset += 100;
    if (flags.hasCompressed) offset += 200;
    if (flags.hasCompact) offset += 300;
    if (flags.hasExpanded) offset += 400;
    if (flags.hasExtended) offset += 500;
    if (flags.hasUltraCondensed) offset += 600;
    if (flags.hasExtraCondensed) offset += 700;
    if (flags.hasSemiCondensed) offset += 850;
    /* hasSemiCondensed をここにも含めるのは、1 語の "semicondensed"（hasCondensed が立たない）を
       2 語の "semi condensed"（hasCondensed も立つ）と同じランクに揃えるため。二重加算ではない
       / semiCondensed is listed here so the one-word and two-word spellings land on the same rank */
    if (flags.hasCondensed || flags.hasCn || flags.hasWide || flags.hasSemiCondensed || flags.hasExtraCompressed) offset += 900;
    if (flags.hasHeadline) offset += 1000;
    if (flags.hasText) offset += 1100;
    if (flags.hasLow) offset += 1200;
    if (flags.hasMicro) offset += 1250;
    if (flags.hasWide) offset += 1275;
    if (flags.hasExtraCompressed) offset += 150;
    if (isItalic) offset += 1300;

    return baseRank + offset;
}

(function () {

    if (app.documents.length === 0) {
        alert(getLabel("error.noDocument"));
        return;
    }

    var targetDocument = app.activeDocument;
    var unit = getTextSizeUnit();

    // ライブプレビュー／適用で書き換えた段落スタイル名（キャンセル時の復元対象）
    // showTypescaleDialog 内のライブプレビューより前に初期化しておく
    var _previewModifiedStyles = {};

    /* 以下のキャッシュもダイアログより前に初期化する。関数宣言は巻き上げられるが var への代入は
       されないため、後ろで宣言するとライブプレビュー中は undefined のまま参照されてしまう
       / These caches must be initialized before the dialog, not after it */

    /* 段落スタイル名 → スタイルの対応表。ライブプレビューは 1 キーストロークごとに
       行数ぶんスタイルを引くため、allParagraphStyles の走査を毎回行わずキャッシュする。
       ダイアログはモーダルで、表示中にスタイルが増減することはない
       / Cached name-to-style table; the live preview looks styles up on every keystroke */
    var _paragraphStyleMap = null;

    /* 利用できるフォントファミリーとスタイルの一覧 / Cached font family and style list */
    var _fontInfo = null;

    // 基準サイズの初期値は段落スタイル "p" → "Normal" の本文サイズを参照する
    var defaultBaseSize = getBodyStyleBaseSize(targetDocument);
    if (defaultBaseSize === null) {
        // "p" / "Normal" が無ければ単位ごとの既定値にフォールバック
        defaultBaseSize = DEFAULT_BASE_SIZE_PT;
        try {
            if (unit === MeasurementUnits.Q) {
                defaultBaseSize = DEFAULT_BASE_SIZE_Q;
            } else if (unit === MeasurementUnits.MILLIMETERS) {
                defaultBaseSize = DEFAULT_BASE_SIZE_Q * 0.25; // Q→mm
            }
        } catch (e) { }
    }

    // 段落スタイル "p" → "Normal" の本文サイズを表示単位で返す（無ければ null）
    /**
     * 本文スタイルの基準サイズを取得する
     * @param {Document} targetDocument 対象ドキュメント
     * @returns {number|null} 基準サイズ（表示単位）。取得できない場合は null
     */
    function getBodyStyleBaseSize(targetDocument) {
        var candidateNames = ["p", "Normal"];
        for (var nameIndex = 0; nameIndex < candidateNames.length; nameIndex++) {
            var style = findParagraphStyle(targetDocument, candidateNames[nameIndex]);
            if (style === null) continue;
            /* pointSize は文字サイズ単位で読み書きされる＝表示単位そのものなので換算しない
               / pointSize is already in the text size unit, so no conversion here */
            var sizeInUnit = null;
            try { sizeInUnit = style.pointSize; } catch (eSize) { sizeInUnit = null; }
            if (typeof sizeInUnit !== "number" || isNaN(sizeInUnit) || sizeInUnit <= 0) continue;
            return roundTo(sizeInUnit, 2);
        }
        return null;
    }

    var typescaleSettings = showTypescaleDialog(targetDocument, defaultBaseSize, DEFAULT_RATIO, DEFAULT_LEVEL_COUNT, unit);

    if (typescaleSettings !== null) {
        // ライブプレビューは doScript の外でスタイルを直接書き換えているため、
        // そのままだと doScript のステップを取り消してもプレビュー時の値が残る。
        // 最終適用の前に起動時の状態へ戻し、doScript の 1 ステップで起動時 → 適用後にする
        restoreParagraphStyleProps(targetDocument, typescaleSettings.originalStyleProps, _previewModifiedStyles);
        // OK 時の最終適用は 1 つの undo ステップにまとめる（Edit > 取り消し で一括に戻せる）
        app.doScript(function () {
            applyTypescaleSettings(targetDocument, typescaleSettings, false, unit);
        }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, getLabel("undo.applyTypeScale"));
    }

    /**
     * 基準サイズとスケール倍率から各レベルのサイズを計算する
     * @param {number} base 基準サイズ（本文）
     * @param {number} ratio スケール倍率
     * @param {number} levelCount 見出しレベル数
     * @param {Array<number>} [multipliers] レベルごとの倍率。省略時は ratio の累乗で算出
     * @param {number} [captionMultiplier] キャプションの倍率
     * @returns {object} headingSizes・base・caption を持つオブジェクト
     */
    function computeSizes(base, ratio, levelCount, multipliers, captionMultiplier) {
        /* 本文サイズを基準に、タイプスケールで見出しとキャプションのサイズを算出 / Calculate heading and caption sizes from the body size using the type scale */
        /* multipliers が与えられればレベルごとの倍率を直接使用、なければ ratio の累乗で算出 */
        var headingSizes = [];
        if (multipliers && multipliers.length > 0) {
            var fixedCount = Math.min(levelCount, multipliers.length);
            for (var fixedIndex = 1; fixedIndex <= fixedCount; fixedIndex++) {
                headingSizes.push(base * multipliers[fixedIndex - 1]);
            }
            var captionSize = (typeof captionMultiplier === "number") ? base * captionMultiplier : base;
            return { headingSizes: headingSizes, base: base, caption: captionSize };
        }
        for (var levelIndex = 1; levelIndex <= levelCount; levelIndex++) {
            headingSizes.push(base * Math.pow(ratio, levelCount - levelIndex + 1));
        }
        return { headingSizes: headingSizes, base: base, caption: base / ratio };
    }

    /**
     * 確定したタイプスケール設定を段落スタイルへ適用する
     * @param {Document} targetDocument 対象ドキュメント
     * @param {object} typescaleSettings ダイアログで確定した設定
     * @param {boolean} silent スタイル未検出時に警告を出さないなら true
     * @param {MeasurementUnits} unit 表示単位
     * @returns {void}
     */
    function applyTypescaleSettings(targetDocument, typescaleSettings, silent, unit) {
        var computedSizes = computeSizes(typescaleSettings.baseSize, typescaleSettings.ratio, typescaleSettings.levelCount, typescaleSettings.scaleMultipliers, typescaleSettings.captionMultiplier);
        // 無効値時はデフォルトにフォールバック
        var headingSpaceAfterPercent = (typeof typescaleSettings.headingSpaceAfterPercent === "number" && typescaleSettings.headingSpaceAfterPercent >= 0)
            ? typescaleSettings.headingSpaceAfterPercent
            : DEFAULT_SPACE_AFTER_PERCENT;
        var headingSpaceBeforePercent = (typeof typescaleSettings.headingSpaceBeforePercent === "number" && typescaleSettings.headingSpaceBeforePercent >= 0)
            ? typescaleSettings.headingSpaceBeforePercent
            : DEFAULT_SPACE_BEFORE_PERCENT;
        var bodySpaceAfterPercent = (typeof typescaleSettings.bodySpaceAfterPercent === "number" && typescaleSettings.bodySpaceAfterPercent >= 0)
            ? typescaleSettings.bodySpaceAfterPercent
            : DEFAULT_BODY_SPACE_AFTER_PERCENT;
        var bodySpaceBeforePercent = (typeof typescaleSettings.bodySpaceBeforePercent === "number" && typescaleSettings.bodySpaceBeforePercent >= 0)
            ? typescaleSettings.bodySpaceBeforePercent
            : DEFAULT_BODY_SPACE_BEFORE_PERCENT;
        /**
         * 1 つの段落スタイルへサイズ・行送り・アキなどを適用する
         * @param {object} rowSettings 適用する行の設定
         * @param {string} rowSettings.styleName 対象の段落スタイル名
         * @param {number} rowSettings.sizeInUnit 表示単位での文字サイズ
         * @param {number} rowSettings.leadingMult 文字サイズに対する行送りの倍率
         * @param {boolean} rowSettings.isHeading 見出しなら true
         * @param {string} [rowSettings.fontFamilyName] フォントファミリー名
         * @param {string} [rowSettings.fontStyleName] フォントスタイル名
         * @param {number} [rowSettings.sizeOverride] 表示単位での文字サイズの個別指定
         * @param {number} [rowSettings.spaceBeforeOverride] 表示単位での段落前アキの個別指定
         * @param {number} [rowSettings.spaceAfterOverride] 表示単位での段落後アキの個別指定
         * @returns {void}
         */
        function applyParagraphStyleSettings(rowSettings) {
            var styleName = rowSettings.styleName;
            if (!styleName) return;
            var isHeading = !!rowSettings.isHeading;
            var roundDigits = typescaleSettings.roundDigits;

            var effectiveSize = (typeof rowSettings.sizeOverride === "number") ? rowSettings.sizeOverride : rowSettings.sizeInUnit;
            var sizePt = toPoints(roundTo(effectiveSize, roundDigits), unit);

            /* 段落前後のアキ：個別指定があればその値、なければ文字サイズに対する割合
               / Space before/after: the per-row override if given, otherwise a ratio of the size */
            var spaceBeforePt = (typeof rowSettings.spaceBeforeOverride === "number")
                ? toPoints(roundTo(rowSettings.spaceBeforeOverride, roundDigits), unit)
                : sizePt * (isHeading ? headingSpaceBeforePercent : bodySpaceBeforePercent) / 100;
            var spaceAfterPt = (typeof rowSettings.spaceAfterOverride === "number")
                ? toPoints(roundTo(rowSettings.spaceAfterOverride, roundDigits), unit)
                : sizePt * (isHeading ? headingSpaceAfterPercent : bodySpaceAfterPercent) / 100;

            // フォントファミリー＋スタイルで解決。未指定時はファミリー内の推奨スタイルを使用
            var fontToUse = null;
            if (rowSettings.fontFamilyName) {
                fontToUse = rowSettings.fontStyleName
                    ? findFontByFamilyAndStyle(rowSettings.fontFamilyName, rowSettings.fontStyleName)
                    : findFontInFamily(rowSettings.fontFamilyName);
            }

            setParagraphStyleProps(targetDocument, styleName, {
                size: sizePt,
                font: fontToUse,
                fontStyleName: rowSettings.fontStyleName,
                autoLeadingPercent: (typeof rowSettings.leadingMult === "number") ? rowSettings.leadingMult * 100 : null,
                spaceBefore: spaceBeforePt,
                spaceAfter: spaceAfterPt,
                kerningMethod: isHeading ? typescaleSettings.headingKerningMethod : typescaleSettings.bodyKerningMethod,
                isHeading: isHeading,
                silent: silent,
                sizeOnly: !!typescaleSettings.sizeOnly,
                originalProps: (typescaleSettings.originalStyleProps && typescaleSettings.originalStyleProps[styleName]) || null
            });
        }
        applyParagraphStyleSettings({
            styleName: typescaleSettings.baseStyleName,
            sizeInUnit: computedSizes.base,
            leadingMult: typescaleSettings.bodyLeading,
            isHeading: false,
            fontFamilyName: typescaleSettings.fontFamily,
            fontStyleName: typescaleSettings.baseFontStyleName,
            sizeOverride: typescaleSettings.baseSizeOverride,
            spaceBeforeOverride: typescaleSettings.baseSpaceBeforeOverride,
            spaceAfterOverride: typescaleSettings.baseSpaceAfterOverride
        });
        applyParagraphStyleSettings({
            styleName: typescaleSettings.captionStyleName,
            sizeInUnit: computedSizes.caption,
            leadingMult: typescaleSettings.bodyLeading,
            isHeading: false,
            fontFamilyName: typescaleSettings.fontFamily,
            fontStyleName: typescaleSettings.captionFontStyleName,
            sizeOverride: typescaleSettings.captionSizeOverride,
            spaceBeforeOverride: typescaleSettings.captionSpaceBeforeOverride,
            spaceAfterOverride: typescaleSettings.captionSpaceAfterOverride
        });
        // 本文派生行（リスト・テーブル）: 文字サイズは基準（本文）×係数。行送り・カーニング・フォントは本文と同じ
        var bodyDerivedRows = typescaleSettings.bodyDerivedRows || [];
        for (var bodyRowIndex = 0; bodyRowIndex < bodyDerivedRows.length; bodyRowIndex++) {
            var bodyDerivedRow = bodyDerivedRows[bodyRowIndex];
            applyParagraphStyleSettings({
                styleName: bodyDerivedRow.styleName,
                sizeInUnit: computedSizes.base * bodyDerivedRow.sizeFactor,
                leadingMult: typescaleSettings.bodyLeading,
                isHeading: false,
                fontFamilyName: typescaleSettings.fontFamily,
                fontStyleName: bodyDerivedRow.fontStyleName,
                sizeOverride: bodyDerivedRow.sizeOverride,
                spaceBeforeOverride: bodyDerivedRow.spaceBeforeOverride,
                spaceAfterOverride: bodyDerivedRow.spaceAfterOverride
            });
        }
        for (var levelNumber = 1; levelNumber <= typescaleSettings.levelCount; levelNumber++) {
            var levelStyleName = typescaleSettings.levelStyleNames && typescaleSettings.levelStyleNames[levelNumber - 1];
            var fontStyleName = typescaleSettings.levelFontStyleNames && typescaleSettings.levelFontStyleNames[levelNumber - 1];
            var levelSizeOverride = typescaleSettings.levelSizeOverrides ? typescaleSettings.levelSizeOverrides[levelNumber - 1] : null;
            var levelSpaceBeforeOverride = typescaleSettings.levelSpaceBeforeOverrides ? typescaleSettings.levelSpaceBeforeOverrides[levelNumber - 1] : null;
            var levelSpaceAfterOverride = typescaleSettings.levelSpaceAfterOverrides ? typescaleSettings.levelSpaceAfterOverrides[levelNumber - 1] : null;
            applyParagraphStyleSettings({
                styleName: levelStyleName,
                sizeInUnit: computedSizes.headingSizes[levelNumber - 1],
                leadingMult: typescaleSettings.headingLeading,
                isHeading: true,
                fontFamilyName: typescaleSettings.headingFontFamily,
                fontStyleName: fontStyleName,
                sizeOverride: levelSizeOverride,
                spaceBeforeOverride: levelSpaceBeforeOverride,
                spaceAfterOverride: levelSpaceAfterOverride
            });
        }
    }

    /**
     * 指定桁数で丸める
     * @param {number} num 対象の数値
     * @param {number} places 小数点以下の桁数
     * @returns {number} 丸めた数値
     */
    function roundTo(num, places) {
        var factor = Math.pow(10, places);
        return Math.round(num * factor) / factor;
    }

    /**
     * 配列に値が含まれるかを判定する
     * @param {Array} array 対象の配列
     * @param {*} value 探す値
     * @returns {boolean} 含まれていれば true
     */
    function arrayContains(array, value) {
        for (var itemIndex = 0; itemIndex < array.length; itemIndex++) {
            if (array[itemIndex] === value) return true;
        }
        return false;
    }

    /**
     * ドキュメント内の段落スタイル名を集める
     * @param {Document} targetDocument 対象ドキュメント
     * @returns {Array<string>} 段落スタイル名の配列
     */
    function getParagraphStyleNames(targetDocument) {
        var names = [];
        var styles = targetDocument.allParagraphStyles;
        for (var styleIndex = 0; styleIndex < styles.length; styleIndex++) {
            names.push(styles[styleIndex].name);
        }
        return names;
    }

    /**
     * 利用できるフォントファミリーとスタイルの一覧を作る
     * @returns {object} フォント情報
     */
    function getFontInfo() {
        if (_fontInfo) return _fontInfo;

        var currentFontCount = 0;
        try { currentFontCount = app.fonts.length; } catch (eCount) { currentFontCount = 0; }

        // ディスクキャッシュが有効ならそれを使う（Font オブジェクトは findFontByFamilyAndStyle で遅延解決）
        var cached = loadFontCache(currentFontCount);
        if (cached) {
            _fontInfo = {
                families: cached.families,
                fontMap: cached.fontMap,
                fontObjectMap: {}
            };
            return _fontInfo;
        }

        var fonts = [];
        var fontMap = {};
        var fontObjectMap = {};
        var families = [];

        try { fonts = app.fonts.everyItem().getElements(); } catch (e1) { fonts = []; }

        for (var fontIndex = 0; fontIndex < fonts.length; fontIndex++) {
            try {
                var fontItem = fonts[fontIndex];
                var familyName = fontItem.fontFamily;
                var styleName = fontItem.fontStyleName;

                if (!familyName || !styleName) continue;

                if (!fontMap[familyName]) {
                    fontMap[familyName] = [];
                    families.push(familyName);
                }

                if (!arrayContains(fontMap[familyName], styleName)) {
                    fontMap[familyName].push(styleName);
                }

                fontObjectMap[familyName + "\t" + styleName] = fontItem;
            } catch (e2) { }
        }

        families.sort();

        for (var familyIndex = 0; familyIndex < families.length; familyIndex++) {
            var sortFamilyName = families[familyIndex];
            fontMap[sortFamilyName].sort(function (a, b) {
                return getStyleWeightRank(a, sortFamilyName) - getStyleWeightRank(b, sortFamilyName);
            });
        }

        _fontInfo = {
            families: families,
            fontMap: fontMap,
            fontObjectMap: fontObjectMap
        };
        saveFontCache(currentFontCount > 0 ? currentFontCount : fonts.length, families, fontMap);
        return _fontInfo;
    }

    /**
     * フォントファミリー名の一覧を取得する
     * @returns {Array<string>} ファミリー名の配列
     */
    function getFontFamilyNames() {
        return getFontInfo().families.slice(0);
    }

    /**
     * ファミリー内で優先して選ぶスタイル名を求める
     * @param {string} styleNames フォントファミリー名
     * @returns {string} スタイル名
     */
    function getPreferredFontStyleName(styleNames) {
        if (!styleNames || styleNames.length === 0) return null;

        var preferredStyleNames = [
            "Thin",
            "ExtraLight",
            "Extra Light",
            "UltraLight",
            "Ultra Light",
            "Light",
            "EL",
            "L",
            "W1",
            "W2",
            "100",
            "200",
            "細",
            "極細",
            "ライト",
            "Regular",
            "Roman",
            "Book",
            "Normal",
            "Medium",
            "R",
            "レギュラー",
            "標準",
            "中"
        ];

        for (var preferredIndex = 0; preferredIndex < preferredStyleNames.length; preferredIndex++) {
            for (var styleIndex = 0; styleIndex < styleNames.length; styleIndex++) {
                if (styleNames[styleIndex] === preferredStyleNames[preferredIndex]) {
                    return styleNames[styleIndex];
                }
            }
        }

        return styleNames[0];
    }

    /**
     * ファミリーとスタイルからフォントのフルネームを作る
     * @param {string} familyName フォントファミリー名
     * @param {string} styleName フォントスタイル名
     * @returns {string} フォントのフルネーム
     */
    function getFontFullName(familyName, styleName) {
        if (!familyName || !styleName) return null;
        return familyName + "\t" + styleName;
    }

    /**
     * ファミリー内のフォントを探す
     * @param {string} familyName フォントファミリー名
     * @returns {Font|null} フォント。見つからない場合は null
     */
    function findFontInFamily(familyName) {
        if (!familyName) return null;
        var styleNames = getFontStylesInFamily(familyName);
        var preferredStyleName = getPreferredFontStyleName(styleNames);
        if (!preferredStyleName) return null;
        return findFontByFamilyAndStyle(familyName, preferredStyleName);
    }

    /**
     * ファミリー内のスタイル名を集める
     * @param {string} familyName フォントファミリー名
     * @returns {Array<string>} スタイル名の配列
     */
    function getFontStylesInFamily(familyName) {
        if (!familyName) return [];
        var fontInfo = getFontInfo();
        if (!fontInfo.fontMap[familyName]) return [];
        return fontInfo.fontMap[familyName].slice(0);
    }

    /**
     * 段落スタイルが現在使っているフォントファミリー名を返す
     * @param {Document} targetDocument 対象ドキュメント
     * @param {string} styleName 段落スタイル名
     * @returns {string|null} フォントファミリー名。取得できない場合は null
     */
    function getStyleFontFamily(targetDocument, styleName) {
        if (!styleName) return null;
        var style = findParagraphStyle(targetDocument, styleName);
        if (style === null) return null;
        // appliedFont は文字列で設定しても Font オブジェクトで返るため fontFamily を読める
        try {
            var familyName = style.appliedFont.fontFamily;
            return familyName ? familyName : null;
        } catch (e) {
            return null;
        }
    }

    /**
     * ファミリーとスタイルからフォントを探す
     * @param {string} familyName フォントファミリー名
     * @param {string} styleName フォントスタイル名
     * @returns {Font|null} フォント。見つからない場合は null
     */
    function findFontByFamilyAndStyle(familyName, styleName) {
        var fontFullName = getFontFullName(familyName, styleName);
        if (!fontFullName) return null;

        var fontInfo = getFontInfo();
        if (fontInfo.fontObjectMap[fontFullName]) {
            return fontInfo.fontObjectMap[fontFullName];
        }
        // キャッシュ経由で fontObjectMap が空の場合は app.fonts.itemByName で遅延解決
        try {
            var resolved = app.fonts.itemByName(fontFullName);
            if (resolved && resolved.isValid) {
                fontInfo.fontObjectMap[fontFullName] = resolved;
                return resolved;
            }
        } catch (e) { }
        return null;
    }

    /**
     * 表示名でドロップダウンの項目を選択する
     * @param {DropDownList} dropdownList 対象のドロップダウン
     * @param {string} text 選択したい項目名
     * @returns {boolean} 選択できたら true
     */
    function selectDropdownByText(dropdownList, text) {
        var itemIndex = findDropdownItemIndexByText(dropdownList, text);
        if (itemIndex >= 0) {
            dropdownList.selection = itemIndex;
            return true;
        }
        if (dropdownList.items.length > 0) dropdownList.selection = 0;
        return false;
    }

    /**
     * 表示名が一致するドロップダウンの項目の位置を探す
     * @param {DropDownList} dropdownList 対象のドロップダウン
     * @param {string} text 探す項目名
     * @returns {number} 見つかった位置。なければ -1
     */
    function findDropdownItemIndexByText(dropdownList, text) {
        for (var itemIndex = 0; itemIndex < dropdownList.items.length; itemIndex++) {
            if (dropdownList.items[itemIndex].text === text) return itemIndex;
        }
        return -1;
    }

    /**
     * ドロップダウンで選択中の表示名を取得する
     * @param {DropDownList} dropdownList 対象のドロップダウン
     * @returns {string} 選択中の表示名
     */
    function getDropdownText(dropdownList) {
        return dropdownList.selection ? dropdownList.selection.text : null;
    }

    /**
     * タイプスケール設定ダイアログを表示する
     * @param {Document} targetDocument 対象ドキュメント
     * @param {number} defaultBase 基準サイズの初期値
     * @param {number} defaultRatio スケール倍率の初期値
     * @param {number} defaultLevelCount 見出しレベル数の初期値
     * @param {MeasurementUnits} unit 表示単位
     * @returns {object|null} 設定内容。キャンセル時は null
     */
    function showTypescaleDialog(targetDocument, defaultBase, defaultRatio, defaultLevelCount, unit) {
        var unitSym = unitSymbol(unit);
        var styleNames = getParagraphStyleNames(targetDocument);
        // ダイアログ表示中のライブプレビューが値を書き換えるため、元値を退避する（取得はダイアログ構築直前に実行）
        var originalStyleProps = null;

        // フォント一覧は UI（パレット／ダイアログ Window）を組み立てる前に読み込む。
        // ダイアログ Window 生成後やモーダル表示中に重いフォント列挙を行うと InDesign が落ちるため、
        // 「パレット表示 → 読み込み → … → ダイアログ表示直前にパレットを閉じる」の順を厳守する。
        // パレットはフォント読み込み後も閉じず、ダイアログ構築の間も表示し続けて空白時間をなくす。
        var loadingPalette = createProgressPalette(getLabel("progress.loadingFonts"));
        var fontFamilies = getFontFamilyNames();
        updateProgressPalette(loadingPalette, getLabel("progress.preparingDialog"), 60);
        var fontOptions = [getLabel("option.noFontChange")].concat(fontFamilies);
        var roundOptions = [
            { label: getLabel("rounding.integer"), digits: 0 },
            { label: getLabel("rounding.firstDecimal"), digits: 1 },
            { label: getLabel("rounding.secondDecimal"), digits: 2 }
        ];
        var defaultRoundDigits = 1;
        var kerningOptions = [
            { label: getLabel("kerning.japaneseMono"), value: "和文等幅" },
            { label: getLabel("kerning.metrics"), value: "メトリクス" },
            { label: getLabel("kerning.optical"), value: "オプティカル" }
        ];

        /**
         * 幅を固定したラベルを追加する
         * @param {object} parent 追加先のコンテナ
         * @param {string} text 表示する文字列
         * @param {number} width ラベルの幅（px）
         * @returns {StaticText} 追加したラベル
         */
        function addFixedWidthLabel(parent, text, width) {
            var label = parent.add("statictext", undefined, text);
            label.preferredSize.width = width;
            return label;
        }

        /**
         * ラベル付きの行グループを追加する
         * @param {object} panel 追加先のコンテナ
         * @param {string} labelString ラベルの文字列（コロン付き）
         * @param {number} labelWidth ラベルの幅（px）
         * @returns {Group} 追加したグループ
         */
        function addLabeledGroup(panel, labelString, labelWidth) {
            var group = panel.add("group");
            setupRow(group, "left", 10);
            addFixedWidthLabel(group, labelString, labelWidth);
            return group;
        }

        /**
         * 行グループに∧∨と入力欄を隙間なく並べて追加する（↑↓キーも∧∨と同じ処理で増減する）
         * @param {Group} rowGroup 追加先の行グループ
         * @param {string} text 入力欄の初期値
         * @param {number} characters 入力欄の文字数
         * @param {object} stepOptions addStepper() に渡す増減の設定（step / min / max / integer / onStep）
         * @returns {EditText} 追加した入力欄（∧∨は .stepperGroup で参照できる）
         */
        function addSteppedInput(rowGroup, text, characters, stepOptions) {
            var stepperInputGroup = rowGroup.add("group");
            stepperInputGroup.orientation = "row";
            stepperInputGroup.alignChildren = ["left", "center"];
            stepperInputGroup.spacing = 0;
            stepperInputGroup.margins = 0;

            var numberInput;
            var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, stepOptions);
            numberInput = stepperInputGroup.add("edittext", undefined, text);
            numberInput.characters = characters;
            numberInput.stepperGroup = stepperGroup;
            bindSteppedArrowKeys(numberInput, stepperGroup);
            return numberInput;
        }

        /* ∧∨・↑↓キーの増減設定。手入力（onChanging）と同じくプレビューを更新する（DOM には触れない）
           / Stepper settings; refresh the preview the same way as typing (no DOM access) */
        var baseSizeStepOptions = {
            min: 0,
            onStep: function () {
                clearAllPreviewOverrides(dialogUi);
                updateTypescalePreview(dialogUi);
            }
        };
        var leadingStepOptions = {
            min: 0,
            max: MAX_AUTO_LEADING_PERCENT,
            onStep: function () { updateTypescalePreview(dialogUi); }
        };

        var scaleOptions = [
            { type: "scale", key: "ratio.minorSecond", ratio: 1.067 },
            { type: "scale", key: "ratio.majorSecond", ratio: 1.125 },
            { type: "scale", key: "ratio.minorThird", ratio: 1.2 },
            { type: "scale", key: "ratio.majorThird", ratio: 1.25 },
            { type: "scale", key: "ratio.goldenHalf", ratio: 1.309 },
            { type: "scale", key: "ratio.perfectFourth", ratio: 1.333 },
            { type: "scale", key: "ratio.augmentedFourth", ratio: 1.414 },
            { type: "scale", key: "ratio.golden", ratio: 1.618 },
            {
                type: "preset",
                key: "ratio.browserDefault",
                multipliers: [2.00, 1.50, 1.17, 1.00],
                captionMultiplier: 0.83,
                forcedLevelCount: 4
            }
        ];
        var levelOptions = [3, 4, 5, 6];

        /**
         * カーニング方式の表示名を取得する
         * @returns {Array<string>} 表示名の配列
         */
        function getKerningOptionLabels() {
            var labels = [];
            for (var kerningOptionIndex = 0; kerningOptionIndex < kerningOptions.length; kerningOptionIndex++) {
                labels.push(kerningOptions[kerningOptionIndex].label);
            }
            return labels;
        }

        /**
         * カーニング方式の値でドロップダウンを選択する
         * @param {DropDownList} dropdownList 対象のドロップダウン
         * @param {string} value 選択したい値
         * @returns {void}
         */
        function selectKerningDropdownByValue(dropdownList, value) {
            for (var kerningOptionIndex = 0; kerningOptionIndex < kerningOptions.length; kerningOptionIndex++) {
                if (kerningOptions[kerningOptionIndex].value === value) {
                    dropdownList.selection = kerningOptionIndex;
                    return;
                }
            }
            dropdownList.selection = 0;
        }

        /**
         * 本文設定パネルを組み立てる
         * @param {object} parent 追加先のコンテナ
         * @param {number} labelWidth ラベルの幅（px）
         * @returns {object} パネル内のコントロール
         */
        function createBodyTextPanel(parent, labelWidth) {
            var bodyPanel = parent.add("panel", undefined, getLabel("panel.bodyText"));
            setupPanel(bodyPanel, 4);
            bodyPanel.alignment = ["fill", "top"];

            var fontGrp = addLabeledGroup(bodyPanel, labelText("field.font"), labelWidth);
            var fontDD = fontGrp.add("dropdownlist", undefined, fontOptions);
            fontDD.preferredSize.width = 180;
            fontDD.selection = 0;

            var fontStyleGrp = addLabeledGroup(bodyPanel, labelText("field.fontStyle"), labelWidth);
            var fontStyleDD = fontStyleGrp.add("dropdownlist", undefined, [getLabel("option.noFontChange")]);
            fontStyleDD.preferredSize.width = 130;
            fontStyleDD.selection = 0;

            var leadingBodyGrp = addLabeledGroup(bodyPanel, labelText("field.bodyLeading"), labelWidth);
            var leadingBodyInput = addSteppedInput(leadingBodyGrp, String(DEFAULT_BODY_LEADING_PERCENT), 4, leadingStepOptions);
            leadingBodyGrp.add("statictext", undefined, "%");

            var bodyKerningGrp = addLabeledGroup(bodyPanel, labelText("field.kerning"), labelWidth);
            var bodyKerningDD = bodyKerningGrp.add("dropdownlist", undefined, getKerningOptionLabels());
            bodyKerningDD.preferredSize.width = 110;
            selectKerningDropdownByValue(bodyKerningDD, "和文等幅");

            return {
                fontDD: fontDD,
                fontStyleDD: fontStyleDD,
                leadingBodyInput: leadingBodyInput,
                bodyKerningDD: bodyKerningDD
            };
        }

        /**
         * 見出し設定パネルを組み立てる
         * @param {object} parent 追加先のコンテナ
         * @param {number} labelWidth ラベルの幅（px）
         * @returns {object} パネル内のコントロール
         */
        function createHeadingTextPanel(parent, labelWidth) {
            var headingPanel = parent.add("panel", undefined, getLabel("panel.headingText"));
            setupPanel(headingPanel, 4);
            headingPanel.alignment = ["fill", "top"];

            // Font controls (like body panel)
            var headingFontGrp = addLabeledGroup(headingPanel, labelText("field.font"), labelWidth);
            var headingFontOptions = [getLabel("option.refBodyFont")].concat(fontFamilies);
            var headingFontDD = headingFontGrp.add("dropdownlist", undefined, headingFontOptions);
            headingFontDD.preferredSize.width = 180;
            headingFontDD.selection = 0;

            var headingFontStyleGrp = addLabeledGroup(headingPanel, labelText("field.fontStyle"), labelWidth);
            var headingFontStyleDD = headingFontStyleGrp.add("dropdownlist", undefined, [getLabel("option.noFontChange")]);
            headingFontStyleDD.preferredSize.width = 130;
            headingFontStyleDD.selection = 0;

            var leadingHeadingGrp = addLabeledGroup(headingPanel, labelText("field.headingLeading"), labelWidth);
            var leadingHeadingInput = addSteppedInput(leadingHeadingGrp, String(DEFAULT_HEADING_LEADING_PERCENT), 4, leadingStepOptions);
            leadingHeadingGrp.add("statictext", undefined, "%");

            var headingKerningGrp = addLabeledGroup(headingPanel, labelText("field.kerning"), labelWidth);
            var headingKerningDD = headingKerningGrp.add("dropdownlist", undefined, getKerningOptionLabels());
            headingKerningDD.preferredSize.width = 110;
            selectKerningDropdownByValue(headingKerningDD, "メトリクス");

            return {
                headingFontDD: headingFontDD,
                headingFontStyleDD: headingFontStyleDD,
                leadingHeadingInput: leadingHeadingInput,
                headingKerningDD: headingKerningDD
            };
        }

        /**
         * 本文・見出しをまとめたテキスト設定パネルを組み立てる
         * @param {Window} dialog 対象のダイアログ
         * @returns {object} パネル内のコントロール
         */
        function createTextSettingsPanel(dialog) {
            var textSettingsGroup = dialog.add("group");
            textSettingsGroup.orientation = "column";
            textSettingsGroup.alignChildren = "fill";
            textSettingsGroup.alignment = "fill";
            textSettingsGroup.spacing = 6;

            var BODY_LABEL_WIDTH = 80;
            var HEADING_LABEL_WIDTH = 94;

            var textColumnGroup = textSettingsGroup.add("group");
            setupRow(textColumnGroup, "fill", COLUMN_SPACING);
            textColumnGroup.alignChildren = ["fill", "top"];

            var bodyUi = createBodyTextPanel(textColumnGroup, BODY_LABEL_WIDTH);
            var headingUi = createHeadingTextPanel(textColumnGroup, HEADING_LABEL_WIDTH);

            return {
                fontDD: bodyUi.fontDD,
                fontStyleDD: bodyUi.fontStyleDD,
                headingFontDD: headingUi.headingFontDD,
                headingFontStyleDD: headingUi.headingFontStyleDD,
                leadingBodyInput: bodyUi.leadingBodyInput,
                leadingHeadingInput: headingUi.leadingHeadingInput,
                bodyKerningDD: bodyUi.bodyKerningDD,
                headingKerningDD: headingUi.headingKerningDD
            };
        }

        /**
         * フォント指定オプションのパネルを組み立てる
         * @param {Window} dialog 対象のダイアログ
         * @returns {object} パネル内のコントロール
         */
        function createFontSettingsPanel(dialog) {
            var fontPanel = dialog.add("panel", undefined, getLabel("panel.fontAssignment"));
            fontPanel.alignment = ["fill", "top"];
            setupPanel(fontPanel, 6);

            // OFF のあいだはフォント・スタイルを変更しない（以前の「フォントを変更しない」ラジオの役目を兼ねる）
            var includeFontsCheckbox = fontPanel.add("checkbox", undefined, getLabel("checkbox.includeFonts"));
            includeFontsCheckbox.value = false;

            // ラジオはチェックボックスに従属するので字下げして並べる
            var fontModeGroup = fontPanel.add("group");
            fontModeGroup.orientation = "column";
            fontModeGroup.alignChildren = ["left", "center"];
            fontModeGroup.margins = [16, 0, 0, 0];

            var useSameFontRadio = fontModeGroup.add("radiobutton", undefined, getLabel("fontMode.same"));
            var separateFontRadio = fontModeGroup.add("radiobutton", undefined, getLabel("fontMode.separate"));

            // ディム状態のまま既定の選択を見せておく（チェックを入れた時点でこの指定になる）
            useSameFontRadio.value = true;
            separateFontRadio.value = false;

            // 「サイズのみ」: ON にするとサイズだけ更新し、フォント／行送り／アキ等は元の値を保持する
            // （保持の実体は setParagraphStyleProps の sizeOnly 分岐。ON 時に上のチェックを外すのは onClick ハンドラ側）
            // 既定 OFF：行送り・段落前後のアキ・カーニングも入力どおりに適用する
            var sizeOnlyCheckbox = fontPanel.add("checkbox", undefined, getLabel("checkbox.sizeOnly"));
            sizeOnlyCheckbox.value = false;

            return {
                includeFontsCheckbox: includeFontsCheckbox,
                useSameFontRadio: useSameFontRadio,
                separateFontRadio: separateFontRadio,
                sizeOnlyCheckbox: sizeOnlyCheckbox
            };
        }

        /**
         * スケール設定パネルを組み立てる
         * @param {Window} dialog 対象のダイアログ
         * @returns {object} パネル内のコントロール
         */
        function createScaleSettingsPanel(dialog) {
            var scaleSettingsPanel = dialog.add("panel", undefined, getLabel("panel.scaleSettings"));
            scaleSettingsPanel.alignment = ["fill", "top"];
            setupPanel(scaleSettingsPanel, 6);

            var OPTIONS_LABEL_WIDTH = 110;

            var baseGrp = addLabeledGroup(scaleSettingsPanel, labelText("field.baseSize"), OPTIONS_LABEL_WIDTH);
            var baseInput = addSteppedInput(baseGrp, String(defaultBase), 4, baseSizeStepOptions);
            baseGrp.add("statictext", undefined, unitSym);

            var scaleGrp = addLabeledGroup(scaleSettingsPanel, labelText("field.scaleMethod"), OPTIONS_LABEL_WIDTH);
            var scaleLabels = [];
            for (var scaleOptionIndex = 0; scaleOptionIndex < scaleOptions.length; scaleOptionIndex++) {
                var scaleLabel = getLabel(scaleOptions[scaleOptionIndex].key);
                if (scaleOptions[scaleOptionIndex].type === "scale") {
                    scaleLabel += "  " + scaleOptions[scaleOptionIndex].ratio;
                }
                scaleLabels.push(scaleLabel);
            }
            var scaleDD = scaleGrp.add("dropdownlist", undefined, scaleLabels);
            scaleDD.preferredSize.width = 200;
            for (var selectedScaleOptionIndex = 0; selectedScaleOptionIndex < scaleOptions.length; selectedScaleOptionIndex++) {
                if (scaleOptions[selectedScaleOptionIndex].type === "scale" && scaleOptions[selectedScaleOptionIndex].ratio === defaultRatio) {
                    scaleDD.selection = selectedScaleOptionIndex;
                    break;
                }
            }
            if (!scaleDD.selection) scaleDD.selection = 0;

            var levelGrp = addLabeledGroup(scaleSettingsPanel, labelText("field.headingLevels"), OPTIONS_LABEL_WIDTH);
            levelGrp.alignChildren = ["left", "bottom"];
            var levelRadios = [];
            for (var levelOptionIndex = 0; levelOptionIndex < levelOptions.length; levelOptionIndex++) {
                var levelRadio = levelGrp.add("radiobutton", undefined, String(levelOptions[levelOptionIndex]));
                levelRadio.alignment = ["left", "bottom"];
                if (levelOptions[levelOptionIndex] === defaultLevelCount) levelRadio.value = true;
                levelRadios.push(levelRadio);
            }
            if (!getSelectedRadioValue(levelRadios, levelOptions, null, null)) {
                levelRadios[0].value = true;
            }

            var roundGrp = addLabeledGroup(scaleSettingsPanel, labelText("field.sizeRounding"), OPTIONS_LABEL_WIDTH);
            roundGrp.alignChildren = ["left", "bottom"];
            var roundRadios = [];
            for (var roundOptionIndex = 0; roundOptionIndex < roundOptions.length; roundOptionIndex++) {
                var roundRadio = roundGrp.add("radiobutton", undefined, roundOptions[roundOptionIndex].label);
                roundRadio.alignment = ["left", "bottom"];
                if (roundOptions[roundOptionIndex].digits === defaultRoundDigits) roundRadio.value = true;
                roundRadios.push(roundRadio);
            }

            return {
                baseInput: baseInput,
                scaleDD: scaleDD,
                levelRadios: levelRadios,
                roundRadios: roundRadios
            };
        }

        /**
         * プレビューパネルを組み立てる
         * @param {Window} dialog 対象のダイアログ
         * @returns {object} パネル内のコントロール
         */
        function createPreviewPanel(dialog) {
            var previewPanel = dialog.add("panel", undefined, getLabel("panel.preview"));
            setupPanel(previewPanel, 2);

            var PREVIEW_LABEL_WIDTH = 96; // 1列目（レベル名）を約1文字分広げる（★基準（本文）などに対応）
            var PREVIEW_SIZE_WIDTH = 80;
            var PREVIEW_SPACE_BEFORE_WIDTH = 80;
            var PREVIEW_SPACE_AFTER_WIDTH = 80;

            var headerRow = previewPanel.add("group");
            setupRow(headerRow, "left", 10);
            headerRow.add("statictext", undefined, labelText("column.level")).preferredSize.width = PREVIEW_LABEL_WIDTH;
            headerRow.add("statictext", undefined, labelText("column.size")).preferredSize.width = PREVIEW_SIZE_WIDTH;
            var spaceBeforeHeader = headerRow.add("statictext", undefined, labelText("column.spaceBefore"));
            spaceBeforeHeader.preferredSize.width = PREVIEW_SPACE_BEFORE_WIDTH;
            var spaceAfterHeader = headerRow.add("statictext", undefined, labelText("column.spaceAfter"));
            spaceAfterHeader.preferredSize.width = PREVIEW_SPACE_AFTER_WIDTH;
            headerRow.add("statictext", undefined, labelText("column.paragraphStyle")).preferredSize.width = 100;
            var fontStyleHeader = headerRow.add("statictext", undefined, labelText("column.fontStyle"));
            fontStyleHeader.preferredSize.width = 100;
            fontStyleHeader.enabled = true;

            var previewHeaderSpacer = previewPanel.add("group");
            previewHeaderSpacer.preferredSize.height = 4;

            /**
             * 候補名を順に試してドロップダウンを選択する
             * @param {DropDownList} dropdownList 対象のドロップダウン
             * @param {Array<string>} candidates 候補となる項目名
             * @returns {boolean} 選択できたら true
             */
            function selectDropdownByCandidates(dropdownList, candidates) {
                for (var candidateIndex = 0; candidateIndex < candidates.length; candidateIndex++) {
                    var itemIndex = findDropdownItemIndexByText(dropdownList, candidates[candidateIndex]);
                    if (itemIndex >= 0) {
                        dropdownList.selection = itemIndex;
                        return true;
                    }
                }
                // 候補が見つからない場合、ルート／組み込みスタイル（[...]）への誤適用（error 516）を避けるため
                // 先頭の通常スタイルを選ぶ。通常スタイルが無ければ未選択のままにする。
                for (var fallbackIndex = 0; fallbackIndex < dropdownList.items.length; fallbackIndex++) {
                    if (dropdownList.items[fallbackIndex].text.charAt(0) !== "[") {
                        dropdownList.selection = fallbackIndex;
                        return false;
                    }
                }
                dropdownList.selection = null;
                return false;
            }

            /**
             * プレビューの 1 行を組み立てる
             * @param {object} parent 追加先のコンテナ
             * @param {string} label 行ラベル
             * @param {string|Array<string>} defaultStyleNames 既定で選ぶ段落スタイル名の候補
             * @param {boolean} isHeading 見出し行なら true
             * @returns {object} 行のコントロール
             */
            function createPreviewRow(parent, label, defaultStyleNames, isHeading) {
                var row = parent.add("group");
                setupRow(row, "left", 10);
                var rowLabel = row.add("statictext", undefined, label);
                rowLabel.preferredSize.width = PREVIEW_LABEL_WIDTH;
                var sizeText = row.add("edittext", undefined, "");
                sizeText.preferredSize.width = PREVIEW_SIZE_WIDTH;
                var spaceBeforeText = row.add("edittext", undefined, "");
                spaceBeforeText.preferredSize.width = PREVIEW_SPACE_BEFORE_WIDTH;
                var spaceAfterText = row.add("edittext", undefined, "");
                spaceAfterText.preferredSize.width = PREVIEW_SPACE_AFTER_WIDTH;
                var styleDD = row.add("dropdownlist", undefined, styleNames);
                styleDD.preferredSize.width = 100;
                var candidateList = (typeof defaultStyleNames === "string") ? [defaultStyleNames] : defaultStyleNames;
                selectDropdownByCandidates(styleDD, candidateList);

                var fontStyleDD = row.add("dropdownlist", undefined, [getLabel("option.noFontChange")]);
                fontStyleDD.preferredSize.width = 100;
                fontStyleDD.selection = 0;
                fontStyleDD.enabled = true;

                return {
                    lbl: rowLabel,
                    sizeText: sizeText,
                    spaceBeforeText: spaceBeforeText,
                    spaceAfterText: spaceAfterText,
                    styleDD: styleDD,
                    fontStyleDD: fontStyleDD,
                    isHeading: !!isHeading,
                    sizeOverride: null,
                    spaceBeforeOverride: null,
                    spaceAfterOverride: null
                };
            }

            var levelRows = [];
            for (var levelNumber = 1; levelNumber <= 6; levelNumber++) {
                var levelCandidates = ["h" + levelNumber, "Heading " + levelNumber];
                levelRows.push(createPreviewRow(previewPanel, getLabel("row.levelPrefix") + levelNumber, levelCandidates, true));
            }

            // 基準（本文）の下に並ぶ、本文サイズ×係数で算出する行（係数はユーザー設定の比率(%)から）
            var baseRow = createPreviewRow(previewPanel, getLabel("row.baseBody"), ["p", "Normal"], false);
            var listRow = createPreviewRow(previewPanel, getLabel("row.list"), ["ul-li", "ol-li", "List Paragraph"], false);
            listRow.bodySizeFactor = DEFAULT_LIST_SIZE_PERCENT / 100;
            var tableRow = createPreviewRow(previewPanel, getLabel("row.table"), ["td", "th"], false);
            tableRow.bodySizeFactor = DEFAULT_TABLE_SIZE_PERCENT / 100;
            var captionRow = createPreviewRow(previewPanel, getLabel("row.caption"), "p.caption", false);

            return {
                levelRows: levelRows,
                baseRow: baseRow,
                bodyDerivedRows: [listRow, tableRow],
                captionRow: captionRow,
                spaceBeforeHeader: spaceBeforeHeader,
                spaceAfterHeader: spaceAfterHeader,
                fontStyleHeader: fontStyleHeader
            };
        }

        /**
         * ダイアログ下部のボタン行を組み立てる
         * @param {Window} dialog 対象のダイアログ
         * @returns {object} 生成したボタン
         */
        function createButtonRow(dialog) {
            var buttonRow = addButtonRow(dialog);

            // 「フォント、スタイルを含める」適用中の進捗バー。左のグループを伸ばしてボタンの左に置く
            // モーダル表示中は別ウィンドウ（パレット）を出すと落ちるため、ダイアログ内に置く
            buttonRow.leftGroup.alignment = ["fill", "center"];
            var applyProgressBar = buttonRow.leftGroup.add("progressbar", undefined, 0, 100);
            applyProgressBar.alignment = ["fill", "center"];
            applyProgressBar.preferredSize.height = 6;
            applyProgressBar.visible = false;

            var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
            var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
            /* 左に進捗バーがあるので左右分割のまま / Stays split because the progress bar sits on the left */
            alignRightOnlyButtonRow(buttonRow);

            return { applyProgressBar: applyProgressBar };
        }

        /**
         * タイプスケールダイアログ全体を組み立てる
         * @returns {object} ダイアログとコントロール
         */
        function createTypescaleDialog() {
            var dialogWindow = new Window('dialog', getLabel('dialog.title'));
            setupWindow(dialogWindow, 10);

            var textSettingsUi = createTextSettingsPanel(dialogWindow);

            var optionColumnGroup = dialogWindow.add("group");
            setupRow(optionColumnGroup, "fill", COLUMN_SPACING);
            optionColumnGroup.alignChildren = ["fill", "top"];

            var scaleSettingsUi = createScaleSettingsPanel(optionColumnGroup);
            var fontSettingsUi = createFontSettingsPanel(optionColumnGroup);
            var previewUi = createPreviewPanel(dialogWindow);

            var buttonUi = createButtonRow(dialogWindow);

            return {
                dialog: dialogWindow,
                baseInput: scaleSettingsUi.baseInput,
                fontDD: textSettingsUi.fontDD,
                fontStyleDD: textSettingsUi.fontStyleDD,
                headingFontDD: textSettingsUi.headingFontDD,
                headingFontStyleDD: textSettingsUi.headingFontStyleDD,
                leadingBodyInput: textSettingsUi.leadingBodyInput,
                leadingHeadingInput: textSettingsUi.leadingHeadingInput,
                bodyKerningDD: textSettingsUi.bodyKerningDD,
                headingKerningDD: textSettingsUi.headingKerningDD,
                scaleDD: scaleSettingsUi.scaleDD,
                levelRadios: scaleSettingsUi.levelRadios,
                roundRadios: scaleSettingsUi.roundRadios,
                levelRows: previewUi.levelRows,
                baseRow: previewUi.baseRow,
                bodyDerivedRows: previewUi.bodyDerivedRows,
                captionRow: previewUi.captionRow,
                spaceBeforeHeader: previewUi.spaceBeforeHeader,
                spaceAfterHeader: previewUi.spaceAfterHeader,
                fontStyleHeader: previewUi.fontStyleHeader,
                applyProgressBar: buttonUi.applyProgressBar,
                includeFontsCheckbox: fontSettingsUi.includeFontsCheckbox,
                useSameFontRadio: fontSettingsUi.useSameFontRadio,
                separateFontRadio: fontSettingsUi.separateFontRadio,
                sizeOnlyCheckbox: fontSettingsUi.sizeOnlyCheckbox
            };
        }

        var dialogUi = createTypescaleDialog();

        /**
         * 正の数値として解釈する
         * @param {string} text 入力文字列
         * @param {number} fallbackValue 解釈できない場合の値
         * @returns {number} 数値
         */
        function parsePositiveNumber(text, fallbackValue) {
            var value = parseFloat(text);
            return (isNaN(value) || value <= 0) ? fallbackValue : value;
        }

        /**
         * 0 以上の数値として解釈する
         * @param {string} text 入力文字列
         * @param {number} fallbackValue 解釈できない場合の値
         * @returns {number} 数値
         */
        function parseNonNegativeNumber(text, fallbackValue) {
            var value = parseFloat(text);
            return (isNaN(value) || value < 0) ? fallbackValue : value;
        }

        /**
         * パーセント入力を倍率として解釈する
         * @param {string} text 入力文字列
         * @param {number} fallbackValue 解釈できない場合の倍率
         * @returns {number} 倍率
         */
        function parsePositivePercentMultiplier(text, fallbackValue) {
            var value = parseFloat(text);
            return (isNaN(value) || value <= 0) ? fallbackValue : value / 100;
        }

        /**
         * 行送りの入力を自動行送りの範囲に収めた倍率として解釈する
         * @param {string} text 入力文字列
         * @param {number} fallbackValue 解釈できない場合の倍率
         * @returns {number} 行送り倍率
         */
        function parseAutoLeadingMultiplier(text, fallbackValue) {
            var multiplier = parsePositivePercentMultiplier(text, fallbackValue);
            var maxMultiplier = MAX_AUTO_LEADING_PERCENT / 100;
            return (multiplier > maxMultiplier) ? maxMultiplier : multiplier;
        }

        /**
         * ラジオボタン群で選択中の値を取得する
         * @param {Array} radioButtons 対象のラジオボタン
         * @param {Array} options 対応する選択肢
         * @param {string} [valueKey] 選択肢から取り出すキー。省略時は選択肢そのもの
         * @param {*} fallbackValue どれも選ばれていない場合の値
         * @returns {string|null} 選択中の値
         */
        function getSelectedRadioValue(radioButtons, options, valueKey, fallbackValue) {
            for (var radioIndex = 0; radioIndex < radioButtons.length; radioIndex++) {
                if (radioButtons[radioIndex].value) {
                    return valueKey ? options[radioIndex][valueKey] : options[radioIndex];
                }
            }
            return fallbackValue;
        }

        /**
         * ドロップダウンで選択中の値を取得する
         * @param {DropDownList} dropdownList 対象のドロップダウン
         * @param {Array} options 対応する選択肢
         * @param {string} [valueKey] 選択肢から取り出すキー。省略時は選択肢そのもの
         * @param {*} fallbackValue 未選択の場合の値
         * @returns {string|null} 選択中の値
         */
        function getSelectedDropdownOptionValue(dropdownList, options, valueKey, fallbackValue) {
            if (!dropdownList.selection) return fallbackValue;
            return valueKey ? options[dropdownList.selection.index][valueKey] : options[dropdownList.selection.index];
        }

        /**
         * 現在のスケール倍率を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} スケール倍率
         */
        function getCurrentScaleRatio(dialogUi) {
            if (!dialogUi.scaleDD.selection) return defaultRatio;
            var scaleOption = scaleOptions[dialogUi.scaleDD.selection.index];
            return (scaleOption && scaleOption.type === "scale") ? scaleOption.ratio : defaultRatio;
        }

        /**
         * 現在選択中のスケールプリセットを取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {string} プリセットを表す識別子
         */
        function getCurrentScaleOption(dialogUi) {
            if (!dialogUi.scaleDD.selection) return null;
            return scaleOptions[dialogUi.scaleDD.selection.index];
        }

        /**
         * 現在の見出しレベル数を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 見出しレベル数
         */
        function getCurrentLevelCount(dialogUi) {
            var scaleOption = getCurrentScaleOption(dialogUi);
            if (scaleOption && scaleOption.type === "preset" && typeof scaleOption.forcedLevelCount === "number") {
                return scaleOption.forcedLevelCount;
            }
            return getSelectedRadioValue(dialogUi.levelRadios, levelOptions, null, defaultLevelCount);
        }

        /**
         * 現在のサイズ丸め桁数を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 丸め桁数
         */
        function getCurrentRoundDigits(dialogUi) {
            return getSelectedRadioValue(dialogUi.roundRadios, roundOptions, "digits", defaultRoundDigits);
        }

        /**
         * フォント・スタイルを適用する設定かどうかを判定する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {boolean} 適用するなら true
         */
        function isFontAssignmentEnabled(dialogUi) {
            return !!(dialogUi.includeFontsCheckbox && dialogUi.includeFontsCheckbox.value);
        }

        /**
         * 本文で選択中のフォントファミリーを取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {string} フォントファミリー名
         */
        function getSelectedFontFamily(dialogUi) {
            if (!isFontAssignmentEnabled(dialogUi)) return null;
            if (!dialogUi.fontDD.selection || dialogUi.fontDD.selection.index === 0) return null;
            return dialogUi.fontDD.selection.text;
        }

        /**
         * 見出しで選択中のフォントファミリーを取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {string} フォントファミリー名
         */
        function getSelectedHeadingFontFamily(dialogUi) {
            if (!isFontAssignmentEnabled(dialogUi)) return null;

            // 常に本文フォントを参照（ウエイトのみ変更できるようにする）
            var bodyFont = getSelectedFontFamily(dialogUi);

            // 見出し側で別フォントが明示指定されている場合のみそれを優先
            if (dialogUi.separateFontRadio && dialogUi.separateFontRadio.value) {
                if (dialogUi.headingFontDD.selection && dialogUi.headingFontDD.selection.index !== 0) {
                    return dialogUi.headingFontDD.selection.text;
                }
            }

            return bodyFont;
        }

        /**
         * プレビュー行で選択中のフォントスタイル名を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @param {object} previewRow 対象のプレビュー行
         * @returns {string} フォントスタイル名
         */
        function getRowFontStyleName(dialogUi, previewRow) {
            if (!isFontAssignmentEnabled(dialogUi)) return null;
            return getFontStyleDropdownValue(previewRow.fontStyleDD);
        }

        /* ウエイトの候補。フォントファミリーを指定していないときは、その段落スタイルが今使っている
           フォントから拾う（ファミリーは変えずウエイトだけ変更できるようにする）
           / Weight options fall back to the font the paragraph style already uses */
        /**
         * プレビュー行のウエイト候補を作る
         * @param {string} familyName 選択中のフォントファミリー名。未指定なら null
         * @param {object} previewRow 対象のプレビュー行
         * @returns {Array<string>} ウエイト名の配列
         */
        function getFontStyleOptionsForRow(familyName, previewRow) {
            var effectiveFamilyName = familyName || getStyleFontFamily(targetDocument, getDropdownText(previewRow.styleDD));
            var fontStyleOptions = effectiveFamilyName ? getFontStylesInFamily(effectiveFamilyName) : [];
            return (fontStyleOptions.length > 0) ? fontStyleOptions : [getLabel("option.noFontChange")];
        }

        /**
         * 本文の行送り倍率を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 行送り倍率
         */
        function getBodyLeadingMultiplier(dialogUi) {
            return parseAutoLeadingMultiplier(dialogUi.leadingBodyInput.text, DEFAULT_BODY_LEADING_PERCENT / 100);
        }

        /**
         * 見出しの行送り倍率を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 行送り倍率
         */
        function getHeadingLeadingMultiplier(dialogUi) {
            return parseAutoLeadingMultiplier(dialogUi.leadingHeadingInput.text, DEFAULT_HEADING_LEADING_PERCENT / 100);
        }

        /**
         * 本文のカーニング方式を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {string} カーニング方式
         */
        function getBodyKerningMethod(dialogUi) {
            return getSelectedDropdownOptionValue(dialogUi.bodyKerningDD, kerningOptions, "value", "和文等幅");
        }

        /**
         * 見出しのカーニング方式を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {string} カーニング方式
         */
        function getHeadingKerningMethod(dialogUi) {
            return getSelectedDropdownOptionValue(dialogUi.headingKerningDD, kerningOptions, "value", "メトリクス");
        }

        /**
         * 本文の段落前アキ（%）を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 段落前のアキ（%）
         */
        function getBodySpaceBeforePercent(dialogUi) {
            return DEFAULT_BODY_SPACE_BEFORE_PERCENT;
        }

        /**
         * 本文の段落後アキ（%）を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 段落後のアキ（%）
         */
        function getBodySpaceAfterPercent(dialogUi) {
            return DEFAULT_BODY_SPACE_AFTER_PERCENT;
        }

        /**
         * 見出しの段落前アキ（%）を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 段落前のアキ（%）
         */
        function getHeadingSpaceBeforePercent(dialogUi) {
            return DEFAULT_SPACE_BEFORE_PERCENT;
        }

        /**
         * 見出しの段落後アキ（%）を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 段落後のアキ（%）
         */
        function getHeadingSpaceAfterPercent(dialogUi) {
            return DEFAULT_SPACE_AFTER_PERCENT;
        }

        /**
         * 入力されている基準サイズを取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {number} 基準サイズ
         */
        function getBaseSize(dialogUi) {
            return parsePositiveNumber(dialogUi.baseInput.text, null);
        }

        /**
         * 段落前後のアキの表示用文字列を作る
         * @param {number} value 対象の数値
         * @param {number} roundDigits 小数点以下の桁数
         * @returns {string} 表示する文字列
         */
        function formatSpacingValue(value, roundDigits) {
            if (typeof value !== "number" || isNaN(value)) return getLabel("option.notAvailable");
            return String(roundTo(value, roundDigits)) + unitSym;
        }

        /**
         * 見出しレベルに対応する段落スタイル名を返す
         * @param {number} dialogUi 見出しレベル数
         * @returns {Array<string>} 段落スタイル名の配列
         */
        function getLevelStyleNames(dialogUi) {
            var levelStyleNames = [];
            for (var levelRowIndex = 0; levelRowIndex < dialogUi.levelRows.length; levelRowIndex++) {
                levelStyleNames.push(getDropdownText(dialogUi.levelRows[levelRowIndex].styleDD));
            }
            return levelStyleNames;
        }

        /**
         * フォントスタイルのドロップダウンから値を取得する
         * @param {DropDownList} dropdownList 対象のドロップダウン
         * @returns {string} フォントスタイル名
         */
        function getFontStyleDropdownValue(dropdownList) {
            if (!dropdownList.selection) return null;
            if (dropdownList.selection.text === getLabel("option.noFontChange")) return null;
            return dropdownList.selection.text;
        }

        /**
         * プレビュー行の有効／無効を切り替える
         * @param {object} previewRow 対象の行
         * @param {boolean} enabled 有効にするなら true
         * @returns {void}
         */
        function setRowEnabled(previewRow, enabled) {
            previewRow.lbl.enabled = enabled;
            previewRow.sizeText.enabled = enabled;
            previewRow.spaceBeforeText.enabled = enabled;
            previewRow.spaceAfterText.enabled = enabled;
            previewRow.styleDD.enabled = enabled;
            previewRow.fontStyleDD.enabled = enabled;
        }

        /**
         * プレビューの全行を取得する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {Array<object>} プレビュー行の配列
         */
        function getAllPreviewRows(dialogUi) {
            var previewRows = [];
            for (var levelRowIndex = 0; levelRowIndex < dialogUi.levelRows.length; levelRowIndex++) {
                previewRows.push(dialogUi.levelRows[levelRowIndex]);
            }
            previewRows.push(dialogUi.baseRow);
            for (var bodyRowIndex = 0; bodyRowIndex < dialogUi.bodyDerivedRows.length; bodyRowIndex++) {
                previewRows.push(dialogUi.bodyDerivedRows[bodyRowIndex]);
            }
            previewRows.push(dialogUi.captionRow);
            return previewRows;
        }

        /**
         * ドロップダウンの項目を入れ替える
         * @param {DropDownList} dropdownList 対象のドロップダウン
         * @param {Array<string>} items 新しい項目
         * @returns {void}
         */
        function resetDropdownItems(dropdownList, items) {
            var currentText = getDropdownText(dropdownList);

            while (dropdownList.items.length > 0) {
                dropdownList.remove(dropdownList.items[0]);
            }

            for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
                dropdownList.add("item", items[itemIndex]);
            }

            if (!selectDropdownByText(dropdownList, currentText) && dropdownList.items.length > 0) {
                dropdownList.selection = 0;
            }
        }

        /**
         * プレビュー各行のフォントスタイルをまとめて選択する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @param {string} styleName 選択したいフォントスタイル名
         * @returns {void}
         */
        function selectAllPreviewFontStyleDropdowns(dialogUi, styleName) {
            var previewRows = getAllPreviewRows(dialogUi);
            for (var previewRowIndex = 0; previewRowIndex < previewRows.length; previewRowIndex++) {
                selectDropdownByText(previewRows[previewRowIndex].fontStyleDD, styleName);
            }
        }

        /**
         * テキスト設定のフォントスタイルをプレビューへ反映する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function syncPreviewFontStylesFromTextSettings(dialogUi) {
            var selectedFontStyleName = getDropdownText(dialogUi.fontStyleDD);
            if (!selectedFontStyleName || selectedFontStyleName === getLabel("option.noFontChange")) return;
            selectAllPreviewFontStyleDropdowns(dialogUi, selectedFontStyleName);
        }

        /**
         * 見出しのフォントスタイルをプレビューへ反映する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function syncHeadingPreviewFontStylesFromTextSettings(dialogUi) {
            var sourceFontStyleDropdown = (dialogUi.useSameFontRadio && dialogUi.useSameFontRadio.value)
                ? dialogUi.fontStyleDD
                : dialogUi.headingFontStyleDD;
            var selectedFontStyleName = getDropdownText(sourceFontStyleDropdown);
            if (!selectedFontStyleName || selectedFontStyleName === getLabel("option.noFontChange")) return;
            for (var levelRowIndex = 0; levelRowIndex < dialogUi.levelRows.length; levelRowIndex++) {
                selectDropdownByText(dialogUi.levelRows[levelRowIndex].fontStyleDD, selectedFontStyleName);
            }
        }

        /**
         * 「サイズのみ」設定に応じて列のディム表示を切り替える
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function syncSizeOnlyColumnDimming(dialogUi) {
            // 「サイズのみ」に連動して、段落前後のアキ列だけを淡色化する
            // （「スタイル」列のヘッダーは syncFontSelectionEnabled 側で制御）
            var enabled = !(dialogUi.sizeOnlyCheckbox && dialogUi.sizeOnlyCheckbox.value);
            if (dialogUi.spaceBeforeHeader) dialogUi.spaceBeforeHeader.enabled = enabled;
            if (dialogUi.spaceAfterHeader) dialogUi.spaceAfterHeader.enabled = enabled;
            var previewRows = getAllPreviewRows(dialogUi);
            for (var previewRowIndex = 0; previewRowIndex < previewRows.length; previewRowIndex++) {
                previewRows[previewRowIndex].spaceBeforeText.enabled = enabled;
                previewRows[previewRowIndex].spaceAfterText.enabled = enabled;
            }
        }

        /**
         * フォント指定モードに応じてコントロールの有効／無効を切り替える
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function syncFontSelectionEnabled(dialogUi) {
            var enabled = isFontAssignmentEnabled(dialogUi);
            var headingFontEnabled = enabled && !(dialogUi.useSameFontRadio && dialogUi.useSameFontRadio.value);
            dialogUi.fontDD.enabled = enabled;
            dialogUi.fontStyleDD.enabled = enabled;
            dialogUi.headingFontDD.enabled = headingFontEnabled;
            dialogUi.headingFontStyleDD.enabled = headingFontEnabled;
            // 「スタイル（ウエイト）」列は、フォント指定が有効なときだけ操作可能にする
            if (dialogUi.fontStyleHeader) dialogUi.fontStyleHeader.enabled = enabled;
            // フォント指定モードのラジオは「フォント、スタイルを含める」がオンのときだけ操作できる
            if (dialogUi.useSameFontRadio) dialogUi.useSameFontRadio.enabled = enabled;
            if (dialogUi.separateFontRadio) dialogUi.separateFontRadio.enabled = enabled;
            if (!enabled) {
                selectDropdownByText(dialogUi.fontDD, getLabel("option.noFontChange"));
                resetDropdownItems(dialogUi.fontStyleDD, [getLabel("option.noFontChange")]);
                selectDropdownByText(dialogUi.headingFontDD, getLabel("option.refBodyFont"));
                resetDropdownItems(dialogUi.headingFontStyleDD, [getLabel("option.noFontChange")]);
            }
            var previewRows = getAllPreviewRows(dialogUi);
            for (var previewRowIndex = 0; previewRowIndex < previewRows.length; previewRowIndex++) {
                previewRows[previewRowIndex].fontStyleDD.enabled = enabled;
                if (!enabled) {
                    resetDropdownItems(previewRows[previewRowIndex].fontStyleDD, [getLabel("option.noFontChange")]);
                }
            }
        }

        /**
         * 本文のフォントスタイル候補を更新する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function updateFontStyleDropdowns(dialogUi) {
            if (!isFontAssignmentEnabled(dialogUi)) {
                syncFontSelectionEnabled(dialogUi);
                return;
            }
            var selectedFontFamily = getSelectedFontFamily(dialogUi);

            // マスターのウエイト欄は基準（本文）スタイルのフォントを基準にする
            resetDropdownItems(dialogUi.fontStyleDD, getFontStyleOptionsForRow(selectedFontFamily, dialogUi.baseRow));
            dialogUi.fontStyleDD.enabled = true;

            var selectedMasterFontStyleName = getDropdownText(dialogUi.fontStyleDD);
            var previewRows = getAllPreviewRows(dialogUi);
            for (var previewRowIndex = 0; previewRowIndex < previewRows.length; previewRowIndex++) {
                var previewRow = previewRows[previewRowIndex];
                resetDropdownItems(previewRow.fontStyleDD, getFontStyleOptionsForRow(selectedFontFamily, previewRow));
                previewRow.fontStyleDD.enabled = true;
            }
            if (selectedMasterFontStyleName && selectedMasterFontStyleName !== getLabel("option.noFontChange")) {
                selectAllPreviewFontStyleDropdowns(dialogUi, selectedMasterFontStyleName);
            }
        }

        /**
         * 見出しのフォントスタイル候補を更新する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function updateHeadingFontStyleDropdowns(dialogUi) {
            if (!isFontAssignmentEnabled(dialogUi)) {
                syncFontSelectionEnabled(dialogUi);
                return;
            }
            if (dialogUi.useSameFontRadio && dialogUi.useSameFontRadio.value) {
                syncFontSelectionEnabled(dialogUi);
                return;
            }
            var selectedFontFamily = getSelectedHeadingFontFamily(dialogUi);

            // ここに到達するのは「別指定」モードのみ（共通指定は冒頭で return 済み）。見出しフォントは選択可能
            dialogUi.headingFontDD.enabled = true;
            dialogUi.headingFontDD.helpTip = "";

            // マスターのウエイト欄はレベル 1 のスタイルのフォントを基準にする
            var headingMasterRow = dialogUi.levelRows.length > 0 ? dialogUi.levelRows[0] : dialogUi.baseRow;
            resetDropdownItems(dialogUi.headingFontStyleDD, getFontStyleOptionsForRow(selectedFontFamily, headingMasterRow));
            dialogUi.headingFontStyleDD.enabled = true;

            var selectedHeadingFontStyleName = getDropdownText(dialogUi.headingFontStyleDD);
            for (var levelRowIndex = 0; levelRowIndex < dialogUi.levelRows.length; levelRowIndex++) {
                var levelRow = dialogUi.levelRows[levelRowIndex];
                resetDropdownItems(levelRow.fontStyleDD, getFontStyleOptionsForRow(selectedFontFamily, levelRow));
                levelRow.fontStyleDD.enabled = true;
            }
            if (selectedHeadingFontStyleName && selectedHeadingFontStyleName !== getLabel("option.noFontChange")) {
                syncHeadingPreviewFontStylesFromTextSettings(dialogUi);
            }
        }

        /**
         * 見出しレベルごとのフォントスタイル名を集める
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {Array<string>} フォントスタイル名の配列
         */
        function getHeadingLevelFontStyleNames(dialogUi) {
            var levelFontStyleNames = [];
            for (var levelRowIndex = 0; levelRowIndex < dialogUi.levelRows.length; levelRowIndex++) {
                levelFontStyleNames.push(getRowFontStyleName(dialogUi, dialogUi.levelRows[levelRowIndex]));
            }
            return levelFontStyleNames;
        }

        /**
         * プレビューで上書きされたサイズを集める
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {object} レベルごとのサイズ
         */
        function collectLevelSizeOverrides(dialogUi) {
            var levelOverrides = [];
            for (var i = 0; i < dialogUi.levelRows.length; i++) {
                levelOverrides.push(dialogUi.levelRows[i].sizeOverride);
            }
            return levelOverrides;
        }

        /**
         * プレビューで上書きされた段落前アキを集める
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {object} レベルごとの段落前アキ
         */
        function collectLevelSpaceBeforeOverrides(dialogUi) {
            var levelOverrides = [];
            for (var i = 0; i < dialogUi.levelRows.length; i++) {
                levelOverrides.push(dialogUi.levelRows[i].spaceBeforeOverride);
            }
            return levelOverrides;
        }

        /**
         * プレビューで上書きされた段落後アキを集める
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {object} レベルごとの段落後アキ
         */
        function collectLevelSpaceAfterOverrides(dialogUi) {
            var levelOverrides = [];
            for (var i = 0; i < dialogUi.levelRows.length; i++) {
                levelOverrides.push(dialogUi.levelRows[i].spaceAfterOverride);
            }
            return levelOverrides;
        }

        // 本文派生行（リスト・テーブル）の適用情報を収集する
        /**
         * 本文サイズから派生する行（リスト・表など）の設定を集める
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {Array<object>} 派生行の設定
         */
        function collectBodyDerivedRows(dialogUi) {
            var rows = [];
            for (var bodyRowIndex = 0; bodyRowIndex < dialogUi.bodyDerivedRows.length; bodyRowIndex++) {
                var bodyRow = dialogUi.bodyDerivedRows[bodyRowIndex];
                rows.push({
                    styleName: getDropdownText(bodyRow.styleDD),
                    fontStyleName: getRowFontStyleName(dialogUi, bodyRow),
                    sizeFactor: bodyRow.bodySizeFactor,
                    sizeOverride: bodyRow.sizeOverride,
                    spaceBeforeOverride: bodyRow.spaceBeforeOverride,
                    spaceAfterOverride: bodyRow.spaceAfterOverride
                });
            }
            return rows;
        }

        /**
         * ダイアログの入力内容を設定オブジェクトにまとめる
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {object} 適用に使う設定
         */
        function collectTypescaleSettings(dialogUi) {
            var baseSize = getBaseSize(dialogUi);
            var scaleOption = getCurrentScaleOption(dialogUi);
            return {
                baseSize: baseSize,
                ratio: getCurrentScaleRatio(dialogUi),
                scaleMultipliers: (scaleOption && scaleOption.type === "preset") ? scaleOption.multipliers : null,
                captionMultiplier: (scaleOption && scaleOption.type === "preset") ? scaleOption.captionMultiplier : null,
                levelCount: getCurrentLevelCount(dialogUi),
                levelStyleNames: getLevelStyleNames(dialogUi),
                levelFontStyleNames: getHeadingLevelFontStyleNames(dialogUi),
                baseStyleName: getDropdownText(dialogUi.baseRow.styleDD),
                captionStyleName: getDropdownText(dialogUi.captionRow.styleDD),
                baseFontStyleName: getRowFontStyleName(dialogUi, dialogUi.baseRow),
                captionFontStyleName: getRowFontStyleName(dialogUi, dialogUi.captionRow),
                fontFamily: getSelectedFontFamily(dialogUi),

                headingFontFamily: getSelectedHeadingFontFamily(dialogUi),

                roundDigits: getCurrentRoundDigits(dialogUi),
                bodyLeading: getBodyLeadingMultiplier(dialogUi),
                headingLeading: getHeadingLeadingMultiplier(dialogUi),
                bodyKerningMethod: getBodyKerningMethod(dialogUi),
                headingKerningMethod: getHeadingKerningMethod(dialogUi),
                bodySpaceBeforePercent: getBodySpaceBeforePercent(dialogUi),
                bodySpaceAfterPercent: getBodySpaceAfterPercent(dialogUi),
                headingSpaceBeforePercent: getHeadingSpaceBeforePercent(dialogUi),
                headingSpaceAfterPercent: getHeadingSpaceAfterPercent(dialogUi),
                levelSizeOverrides: collectLevelSizeOverrides(dialogUi),
                levelSpaceBeforeOverrides: collectLevelSpaceBeforeOverrides(dialogUi),
                levelSpaceAfterOverrides: collectLevelSpaceAfterOverrides(dialogUi),
                baseSizeOverride: dialogUi.baseRow.sizeOverride,
                baseSpaceBeforeOverride: dialogUi.baseRow.spaceBeforeOverride,
                baseSpaceAfterOverride: dialogUi.baseRow.spaceAfterOverride,
                captionSizeOverride: dialogUi.captionRow.sizeOverride,
                captionSpaceBeforeOverride: dialogUi.captionRow.spaceBeforeOverride,
                captionSpaceAfterOverride: dialogUi.captionRow.spaceAfterOverride,
                bodyDerivedRows: collectBodyDerivedRows(dialogUi),
                sizeOnly: !!(dialogUi.sizeOnlyCheckbox && dialogUi.sizeOnlyCheckbox.value),
                originalStyleProps: originalStyleProps
            };
        }

        /**
         * 現在の設定でプレビューを描き直す
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function updateTypescalePreview(dialogUi) {
            var baseSize = getBaseSize(dialogUi);
            var ratio = getCurrentScaleRatio(dialogUi);
            var levelCount = getCurrentLevelCount(dialogUi);
            var roundDigits = getCurrentRoundDigits(dialogUi);

            if (baseSize === null) {
                for (var levelRowIndex = 0; levelRowIndex < dialogUi.levelRows.length; levelRowIndex++) {
                    dialogUi.levelRows[levelRowIndex].sizeText.text = getLabel("option.notAvailable");
                    dialogUi.levelRows[levelRowIndex].spaceBeforeText.text = getLabel("option.notAvailable");
                    dialogUi.levelRows[levelRowIndex].spaceAfterText.text = getLabel("option.notAvailable");
                    setRowEnabled(dialogUi.levelRows[levelRowIndex], false);
                }
                dialogUi.baseRow.sizeText.text = getLabel("option.notAvailable");
                dialogUi.baseRow.spaceBeforeText.text = getLabel("option.notAvailable");
                dialogUi.baseRow.spaceAfterText.text = getLabel("option.notAvailable");
                for (var bodyRowIndex = 0; bodyRowIndex < dialogUi.bodyDerivedRows.length; bodyRowIndex++) {
                    dialogUi.bodyDerivedRows[bodyRowIndex].sizeText.text = getLabel("option.notAvailable");
                    dialogUi.bodyDerivedRows[bodyRowIndex].spaceBeforeText.text = getLabel("option.notAvailable");
                    dialogUi.bodyDerivedRows[bodyRowIndex].spaceAfterText.text = getLabel("option.notAvailable");
                }
                dialogUi.captionRow.sizeText.text = getLabel("option.notAvailable");
                dialogUi.captionRow.spaceBeforeText.text = getLabel("option.notAvailable");
                dialogUi.captionRow.spaceAfterText.text = getLabel("option.notAvailable");
                return;
            }

            var scaleOption = getCurrentScaleOption(dialogUi);
            var multipliers = (scaleOption && scaleOption.type === "preset") ? scaleOption.multipliers : null;
            var captionMultiplier = (scaleOption && scaleOption.type === "preset") ? scaleOption.captionMultiplier : null;
            var computedSizes = computeSizes(baseSize, ratio, levelCount, multipliers, captionMultiplier);
            var headingSpaceBeforeRatio = getHeadingSpaceBeforePercent(dialogUi) / 100;
            var bodySpaceBeforeRatio = getBodySpaceBeforePercent(dialogUi) / 100;
            var headingSpaceAfterRatio = getHeadingSpaceAfterPercent(dialogUi) / 100;
            var bodySpaceAfterRatio = getBodySpaceAfterPercent(dialogUi) / 100;
            for (var levelNumber = 1; levelNumber <= dialogUi.levelRows.length; levelNumber++) {
                var levelRow = dialogUi.levelRows[levelNumber - 1];
                if (levelNumber <= levelCount) {
                    var computedHeadingSize = computedSizes.headingSizes[levelNumber - 1];
                    var effectiveHeadingSize = (typeof levelRow.sizeOverride === "number") ? levelRow.sizeOverride : computedHeadingSize;
                    levelRow.sizeText.text = roundTo(effectiveHeadingSize, roundDigits) + " " + unitSym;
                    var effectiveHeadingSpaceBefore = (typeof levelRow.spaceBeforeOverride === "number") ? levelRow.spaceBeforeOverride : effectiveHeadingSize * headingSpaceBeforeRatio;
                    levelRow.spaceBeforeText.text = formatSpacingValue(effectiveHeadingSpaceBefore, roundDigits);
                    var effectiveHeadingSpaceAfter = (typeof levelRow.spaceAfterOverride === "number") ? levelRow.spaceAfterOverride : effectiveHeadingSize * headingSpaceAfterRatio;
                    levelRow.spaceAfterText.text = formatSpacingValue(effectiveHeadingSpaceAfter, roundDigits);
                    setRowEnabled(levelRow, true);
                } else {
                    levelRow.sizeText.text = getLabel("option.notAvailable");
                    levelRow.spaceBeforeText.text = getLabel("option.notAvailable");
                    levelRow.spaceAfterText.text = getLabel("option.notAvailable");
                    setRowEnabled(levelRow, false);
                }
            }
            var effectiveBaseSize = (typeof dialogUi.baseRow.sizeOverride === "number") ? dialogUi.baseRow.sizeOverride : computedSizes.base;
            dialogUi.baseRow.sizeText.text = roundTo(effectiveBaseSize, roundDigits) + " " + unitSym;
            var effectiveBaseSpaceBefore = (typeof dialogUi.baseRow.spaceBeforeOverride === "number") ? dialogUi.baseRow.spaceBeforeOverride : effectiveBaseSize * bodySpaceBeforeRatio;
            dialogUi.baseRow.spaceBeforeText.text = formatSpacingValue(effectiveBaseSpaceBefore, roundDigits);
            var effectiveBaseSpaceAfter = (typeof dialogUi.baseRow.spaceAfterOverride === "number") ? dialogUi.baseRow.spaceAfterOverride : effectiveBaseSize * bodySpaceAfterRatio;
            dialogUi.baseRow.spaceAfterText.text = formatSpacingValue(effectiveBaseSpaceAfter, roundDigits);
            // 本文派生行（リスト・テーブル）: 文字サイズは基準（本文）×係数
            for (var bodyRowIndex = 0; bodyRowIndex < dialogUi.bodyDerivedRows.length; bodyRowIndex++) {
                var bodyRow = dialogUi.bodyDerivedRows[bodyRowIndex];
                var bodyRowSize = computedSizes.base * bodyRow.bodySizeFactor;
                var effectiveBodyRowSize = (typeof bodyRow.sizeOverride === "number") ? bodyRow.sizeOverride : bodyRowSize;
                bodyRow.sizeText.text = roundTo(effectiveBodyRowSize, roundDigits) + " " + unitSym;
                var effectiveBodyRowSpaceBefore = (typeof bodyRow.spaceBeforeOverride === "number") ? bodyRow.spaceBeforeOverride : effectiveBodyRowSize * bodySpaceBeforeRatio;
                bodyRow.spaceBeforeText.text = formatSpacingValue(effectiveBodyRowSpaceBefore, roundDigits);
                var effectiveBodyRowSpaceAfter = (typeof bodyRow.spaceAfterOverride === "number") ? bodyRow.spaceAfterOverride : effectiveBodyRowSize * bodySpaceAfterRatio;
                bodyRow.spaceAfterText.text = formatSpacingValue(effectiveBodyRowSpaceAfter, roundDigits);
            }
            var effectiveCaptionSize = (typeof dialogUi.captionRow.sizeOverride === "number") ? dialogUi.captionRow.sizeOverride : computedSizes.caption;
            dialogUi.captionRow.sizeText.text = roundTo(effectiveCaptionSize, roundDigits) + " " + unitSym;
            var effectiveCaptionSpaceBefore = (typeof dialogUi.captionRow.spaceBeforeOverride === "number") ? dialogUi.captionRow.spaceBeforeOverride : effectiveCaptionSize * bodySpaceBeforeRatio;
            dialogUi.captionRow.spaceBeforeText.text = formatSpacingValue(effectiveCaptionSpaceBefore, roundDigits);
            var effectiveCaptionSpaceAfter = (typeof dialogUi.captionRow.spaceAfterOverride === "number") ? dialogUi.captionRow.spaceAfterOverride : effectiveCaptionSize * bodySpaceAfterRatio;
            dialogUi.captionRow.spaceAfterText.text = formatSpacingValue(effectiveCaptionSpaceAfter, roundDigits);

            applyTypescaleSettings(targetDocument, collectTypescaleSettings(dialogUi), true, unit);
            syncSizeOnlyColumnDimming(dialogUi);
        }

        /**
         * 選択範囲の文字オーバーライドを消去する
         * @returns {void}
         */
        function clearTextOverridesInSelection() {
            var selectionItems = app.selection;
            if (!selectionItems || selectionItems.length === 0) return;

            for (var selectionIndex = 0; selectionIndex < selectionItems.length; selectionIndex++) {
                var selectedItem = selectionItems[selectionIndex];
                try { selectedItem.clearOverrides(OverrideType.ALL); } catch (e1) { }
                try { selectedItem.texts[0].clearOverrides(OverrideType.ALL); } catch (e2) { }
                try { selectedItem.paragraphs.everyItem().clearOverrides(OverrideType.ALL); } catch (e3) { }
            }
        }

        /**
         * 選択があればオーバーライドを消去する
         * @returns {void}
         */
        function clearOverridesIfActive() {
            clearTextOverridesInSelection();
            try { app.menuActions.itemByID(8489).invoke(); } catch (e) { }
            try { app.redraw(); } catch (e2) { }
        }

        /**
         * フォント変更後にプレビューを更新する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function refreshPreviewAfterFontChange(dialogUi) {
            clearOverridesIfActive();
            updateTypescalePreview(dialogUi);
        }

        /**
         * ダイアログ内の進捗バーの表示を切り替える
         * @param {object} dialogUi ダイアログのコントロール一式
         * @param {boolean} visible 表示するなら true
         * @param {number} value 進捗値（0〜100）
         * @returns {void}
         */
        function setApplyProgressVisible(dialogUi, visible, value) {
            if (!dialogUi.applyProgressBar) return;
            dialogUi.applyProgressBar.value = value;
            dialogUi.applyProgressBar.visible = visible;
            try { dialogUi.dialog.update(); } catch (eProgress) { }
        }

        // 「フォント、スタイルを含める」のオン・オフをフォント指定コントロールとプレビューへ反映する
        /**
         * フォント・スタイル指定の有効／無効を切り替え、プレビューへ反映する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function applyFontAssignmentToggle(dialogUi) {
            var enabled = isFontAssignmentEnabled(dialogUi);
            // フォントを適用する以上「サイズのみ」とは両立しない
            if (enabled && dialogUi.sizeOnlyCheckbox) dialogUi.sizeOnlyCheckbox.value = false;
            // フォント適用（フォントオブジェクト解決＋段落スタイル反映）は時間がかかるため、
            // ダイアログ内の進捗バーを表示する（モーダル中は別ウィンドウを出せないため）
            if (enabled) setApplyProgressVisible(dialogUi, true, 40);
            syncFontSelectionEnabled(dialogUi);
            updateFontStyleDropdowns(dialogUi);
            updateHeadingFontStyleDropdowns(dialogUi);
            if (enabled) syncPreviewFontStylesFromTextSettings(dialogUi);
            syncSizeOnlyColumnDimming(dialogUi);
            updateTypescalePreview(dialogUi);
            if (enabled) setApplyProgressVisible(dialogUi, false, 100);
        }

        /**
         * フォント指定モードを切り替える
         * @param {object} dialogUi ダイアログのコントロール一式
         * @param {string} mode "same" / "separate" のいずれか
         * @returns {void}
         */
        function setFontOptionMode(dialogUi, mode) {
            dialogUi.useSameFontRadio.value = (mode === "same");
            dialogUi.separateFontRadio.value = (mode === "separate");
        }

        /**
         * スケールプリセットに合わせて見出しレベルの選択を揃える
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function syncLevelRadiosWithScaleOption(dialogUi) {
            var scaleOption = getCurrentScaleOption(dialogUi);
            var forcedLevelCount = (scaleOption && scaleOption.type === "preset" && typeof scaleOption.forcedLevelCount === "number")
                ? scaleOption.forcedLevelCount
                : null;

            for (var radioIndex = 0; radioIndex < dialogUi.levelRadios.length; radioIndex++) {
                if (forcedLevelCount !== null) {
                    dialogUi.levelRadios[radioIndex].value = (levelOptions[radioIndex] === forcedLevelCount);
                    dialogUi.levelRadios[radioIndex].enabled = false;
                } else {
                    dialogUi.levelRadios[radioIndex].enabled = true;
                }
            }
        }

        /**
         * プレビューの上書き入力をすべて消去する
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function clearAllPreviewOverrides(dialogUi) {
            for (var levelClearIndex = 0; levelClearIndex < dialogUi.levelRows.length; levelClearIndex++) {
                dialogUi.levelRows[levelClearIndex].sizeOverride = null;
                dialogUi.levelRows[levelClearIndex].spaceBeforeOverride = null;
                dialogUi.levelRows[levelClearIndex].spaceAfterOverride = null;
            }
            dialogUi.baseRow.sizeOverride = null;
            dialogUi.baseRow.spaceBeforeOverride = null;
            dialogUi.baseRow.spaceAfterOverride = null;
            for (var bodyClearIndex = 0; bodyClearIndex < dialogUi.bodyDerivedRows.length; bodyClearIndex++) {
                dialogUi.bodyDerivedRows[bodyClearIndex].sizeOverride = null;
                dialogUi.bodyDerivedRows[bodyClearIndex].spaceBeforeOverride = null;
                dialogUi.bodyDerivedRows[bodyClearIndex].spaceAfterOverride = null;
            }
            dialogUi.captionRow.sizeOverride = null;
            dialogUi.captionRow.spaceBeforeOverride = null;
            dialogUi.captionRow.spaceAfterOverride = null;
        }

        /**
         * プレビューの入力欄に上下キーでの増減操作を追加する
         * @param {EditText} editText 対象の入力欄
         * @param {boolean} allowZero 0 を許可するなら true
         * @param {function} applyValue 変更後の値を適用する処理
         * @returns {void}
         */
        function changePreviewValueByArrowKey(editText, allowZero, applyValue) {
            editText.addEventListener("keydown", function (event) {
                if (event.keyName !== "Up" && event.keyName !== "Down") return;
                var value = parseFloat(editText.text);
                if (isNaN(value)) return;
                var direction = (event.keyName === "Up") ? 1 : -1;
                var keyboard = ScriptUI.environment.keyboardState;
                if (keyboard.shiftKey) {
                    var stepShift = 10;
                    if (direction > 0) {
                        value = Math.ceil((value + 1) / stepShift) * stepShift;
                    } else {
                        value = Math.floor((value - 1) / stepShift) * stepShift;
                    }
                } else if (keyboard.altKey) {
                    value += 0.1 * direction;
                } else {
                    value += 1 * direction;
                }
                if (keyboard.altKey) {
                    value = Math.round(value * 10) / 10;
                } else {
                    value = Math.round(value);
                }
                if (allowZero) {
                    if (value < 0) value = 0;
                } else {
                    if (value < 1) value = 1;
                }
                event.preventDefault();
                applyValue(value);
            });
        }

        /**
         * プレビューのセル編集にイベントを結び付ける
         * @param {object} dialogUi ダイアログのコントロール一式
         * @param {object} previewRow 対象のプレビュー行
         * @param {function} [sizeCallback] 文字サイズ変更時の処理。省略時は行の個別指定を更新する
         * @returns {void}
         */
        function bindPreviewCellEdit(dialogUi, previewRow, sizeCallback) {
            var defaultSizeCallback = function (parsedValue) {
                previewRow.sizeOverride = parsedValue;
                updateTypescalePreview(dialogUi);
            };
            var resolvedSizeCallback = sizeCallback || defaultSizeCallback;
            previewRow.sizeText.onChange = function () {
                resolvedSizeCallback(parsePositiveNumber(previewRow.sizeText.text, null));
            };
            previewRow.spaceBeforeText.onChange = function () {
                var parsed = parseNonNegativeNumber(previewRow.spaceBeforeText.text, null);
                previewRow.spaceBeforeOverride = parsed;
                updateTypescalePreview(dialogUi);
            };
            previewRow.spaceAfterText.onChange = function () {
                var parsed = parseNonNegativeNumber(previewRow.spaceAfterText.text, null);
                previewRow.spaceAfterOverride = parsed;
                updateTypescalePreview(dialogUi);
            };
            changePreviewValueByArrowKey(previewRow.sizeText, false, resolvedSizeCallback);
            changePreviewValueByArrowKey(previewRow.spaceBeforeText, true, function (newValue) {
                previewRow.spaceBeforeOverride = newValue;
                updateTypescalePreview(dialogUi);
            });
            changePreviewValueByArrowKey(previewRow.spaceAfterText, true, function (newValue) {
                previewRow.spaceAfterOverride = newValue;
                updateTypescalePreview(dialogUi);
            });
        }

        /**
         * ダイアログ全体のイベントを結び付ける
         * @param {object} dialogUi ダイアログのコントロール一式
         * @returns {void}
         */
        function bindTypescaleDialogEvents(dialogUi) {
            dialogUi.baseInput.onChanging = function () {
                clearAllPreviewOverrides(dialogUi);
                updateTypescalePreview(dialogUi);
            };
            dialogUi.baseInput.onChange = function () {
                clearAllPreviewOverrides(dialogUi);
                updateTypescalePreview(dialogUi);
            };
            dialogUi.scaleDD.onChange = function () {
                clearAllPreviewOverrides(dialogUi);
                syncLevelRadiosWithScaleOption(dialogUi);
                updateTypescalePreview(dialogUi);
            };
            for (var levelRowEditIndex = 0; levelRowEditIndex < dialogUi.levelRows.length; levelRowEditIndex++) {
                bindPreviewCellEdit(dialogUi, dialogUi.levelRows[levelRowEditIndex]);
            }
            bindPreviewCellEdit(dialogUi, dialogUi.baseRow, function (parsedValue) {
                if (parsedValue !== null) {
                    dialogUi.baseInput.text = String(parsedValue);
                }
                clearAllPreviewOverrides(dialogUi);
                updateTypescalePreview(dialogUi);
            });
            bindPreviewCellEdit(dialogUi, dialogUi.captionRow);
            for (var bodyBindIndex = 0; bodyBindIndex < dialogUi.bodyDerivedRows.length; bodyBindIndex++) {
                bindPreviewCellEdit(dialogUi, dialogUi.bodyDerivedRows[bodyBindIndex]);
                dialogUi.bodyDerivedRows[bodyBindIndex].styleDD.onChange = function () { updateTypescalePreview(dialogUi); };
                dialogUi.bodyDerivedRows[bodyBindIndex].fontStyleDD.onChange = function () { updateTypescalePreview(dialogUi); };
            }
            for (var levelRadioIndex = 0; levelRadioIndex < dialogUi.levelRadios.length; levelRadioIndex++) {
                dialogUi.levelRadios[levelRadioIndex].onClick = function () { updateTypescalePreview(dialogUi); };
            }
            for (var levelRowIndex = 0; levelRowIndex < dialogUi.levelRows.length; levelRowIndex++) {
                dialogUi.levelRows[levelRowIndex].styleDD.onChange = function () { updateTypescalePreview(dialogUi); };
            }
            for (var levelFontStyleRowIndex = 0; levelFontStyleRowIndex < dialogUi.levelRows.length; levelFontStyleRowIndex++) {
                dialogUi.levelRows[levelFontStyleRowIndex].fontStyleDD.onChange = function () { updateTypescalePreview(dialogUi); };
            }
            dialogUi.baseRow.styleDD.onChange = function () { updateTypescalePreview(dialogUi); };
            dialogUi.captionRow.styleDD.onChange = function () { updateTypescalePreview(dialogUi); };
            dialogUi.baseRow.fontStyleDD.onChange = function () { updateTypescalePreview(dialogUi); };
            dialogUi.captionRow.fontStyleDD.onChange = function () { updateTypescalePreview(dialogUi); };
            dialogUi.useSameFontRadio.onClick = function () {
                setFontOptionMode(dialogUi, "same");
                if (dialogUi.sizeOnlyCheckbox) dialogUi.sizeOnlyCheckbox.value = false;
                syncFontSelectionEnabled(dialogUi);
                updateFontStyleDropdowns(dialogUi);
                updateHeadingFontStyleDropdowns(dialogUi);
                syncPreviewFontStylesFromTextSettings(dialogUi);
                updateTypescalePreview(dialogUi);
            };
            dialogUi.separateFontRadio.onClick = function () {
                setFontOptionMode(dialogUi, "separate");
                if (dialogUi.sizeOnlyCheckbox) dialogUi.sizeOnlyCheckbox.value = false;
                syncFontSelectionEnabled(dialogUi);
                updateFontStyleDropdowns(dialogUi);
                updateHeadingFontStyleDropdowns(dialogUi);
                updateTypescalePreview(dialogUi);
            };
            dialogUi.sizeOnlyCheckbox.onClick = function () {
                if (dialogUi.sizeOnlyCheckbox.value) {
                    if (dialogUi.includeFontsCheckbox) dialogUi.includeFontsCheckbox.value = false;
                    syncFontSelectionEnabled(dialogUi);
                    updateFontStyleDropdowns(dialogUi);
                    updateHeadingFontStyleDropdowns(dialogUi);
                }
                syncSizeOnlyColumnDimming(dialogUi);
                updateTypescalePreview(dialogUi);
            };
            dialogUi.fontDD.onChange = function () {
                updateFontStyleDropdowns(dialogUi);
                if (dialogUi.useSameFontRadio && dialogUi.useSameFontRadio.value) updateHeadingFontStyleDropdowns(dialogUi);
                syncPreviewFontStylesFromTextSettings(dialogUi);
                refreshPreviewAfterFontChange(dialogUi);
            };
            dialogUi.fontStyleDD.onChange = function () {
                syncPreviewFontStylesFromTextSettings(dialogUi);
                if (dialogUi.useSameFontRadio && dialogUi.useSameFontRadio.value) syncHeadingPreviewFontStylesFromTextSettings(dialogUi);
                refreshPreviewAfterFontChange(dialogUi);
            };
            dialogUi.headingFontDD.onChange = function () {
                updateHeadingFontStyleDropdowns(dialogUi);
                syncHeadingPreviewFontStylesFromTextSettings(dialogUi);
                refreshPreviewAfterFontChange(dialogUi);
            };
            dialogUi.headingFontStyleDD.onChange = function () {
                syncHeadingPreviewFontStylesFromTextSettings(dialogUi);
                refreshPreviewAfterFontChange(dialogUi);
            };
            for (var roundRadioIndex = 0; roundRadioIndex < dialogUi.roundRadios.length; roundRadioIndex++) {
                dialogUi.roundRadios[roundRadioIndex].onClick = function () { updateTypescalePreview(dialogUi); };
            }
            dialogUi.leadingBodyInput.onChanging = function () { updateTypescalePreview(dialogUi); };
            dialogUi.leadingBodyInput.onChange = function () { updateTypescalePreview(dialogUi); };
            dialogUi.leadingHeadingInput.onChanging = function () { updateTypescalePreview(dialogUi); };
            dialogUi.leadingHeadingInput.onChange = function () { updateTypescalePreview(dialogUi); };
            dialogUi.bodyKerningDD.onChange = function () { updateTypescalePreview(dialogUi); };
            dialogUi.headingKerningDD.onChange = function () { updateTypescalePreview(dialogUi); };
            dialogUi.includeFontsCheckbox.onClick = function () { applyFontAssignmentToggle(dialogUi); };
        }

        bindTypescaleDialogEvents(dialogUi);
        // フォントドロップダウンはファミリー一覧を反映済みの状態で構築されている（先頭でロード済み）
        updateFontStyleDropdowns(dialogUi);
        updateHeadingFontStyleDropdowns(dialogUi);
        syncLevelRadiosWithScaleOption(dialogUi);
        syncFontSelectionEnabled(dialogUi);
        // ライブプレビューが書き換える前の段落スタイルを退避し、初回プレビューを反映してから開く
        originalStyleProps = snapshotParagraphStyleProps(targetDocument);
        updateTypescalePreview(dialogUi);

        // モーダルダイアログを表示する直前にパレットを閉じる（モーダル表示中は表示しない）
        closeProgressPalette(loadingPalette);
        addVersionFooter(dialogUi.dialog);
        var dialogResult = dialogUi.dialog.show();
        clearOverridesIfActive();

        if (dialogResult !== 1) {
            // キャンセル：ライブプレビューで書き換えた段落スタイルを起動時の状態へ戻す
            restoreParagraphStyleProps(targetDocument, originalStyleProps, _previewModifiedStyles);
            return null;
        }

        if (getBaseSize(dialogUi) === null) {
            alert(getLabel("error.invalidBaseSize"));
            return null;
        }
        return collectTypescaleSettings(dialogUi);
    }

    // スタイル名に応じた「同じスタイルの段落間隔」を返す（適用対象外は null） / Resolve same-style spacing by style name (null = leave unchanged)
    /**
     * スタイル名に応じた「同じスタイルの段落間隔」を決める
     * @param {string} styleName 段落スタイル名
     * @param {number} spaceBeforePt 段落前のアキ
     * @returns {number|null} 設定する間隔。変更しない場合は null
     */
    function resolveSameStyleSpacing(styleName, spaceBeforePt) {
        if (styleName === "ul-li") return 0;
        if (styleName === "ol-li" || styleName === "p") {
            return (typeof spaceBeforePt === "number" && spaceBeforePt >= 0) ? spaceBeforePt : null;
        }
        return null;
    }

    /* 控えた値を段落スタイルへ書き戻す。プロパティごとに設定できない場合があるので個別に握りつぶす
       / Write a snapshot back to a style; each property is guarded because some may be read-only */
    /**
     * 控えておいた値を段落スタイルへ書き戻す
     * @param {ParagraphStyle} style 対象の段落スタイル
     * @param {object} snapshot 控えたプロパティ
     * @param {boolean} includePointSize 文字サイズも戻すなら true
     * @returns {void}
     */
    function assignSnapshotToStyle(style, snapshot, includePointSize) {
        if (!style || !snapshot) return;
        if (includePointSize && typeof snapshot.pointSize !== "undefined") {
            try { style.pointSize = snapshot.pointSize; } catch (ePS) { }
        }
        if (snapshot.appliedFont) { try { style.appliedFont = snapshot.appliedFont; } catch (eF) { } }
        if (snapshot.fontStyle) { try { style.fontStyle = snapshot.fontStyle; } catch (eFS) { } }
        if (typeof snapshot.autoLeading !== "undefined") { try { style.autoLeading = snapshot.autoLeading; } catch (eAL) { } }
        if (typeof snapshot.leading !== "undefined") { try { style.leading = snapshot.leading; } catch (eL) { } }
        if (typeof snapshot.spaceBefore !== "undefined") { try { style.spaceBefore = snapshot.spaceBefore; } catch (eSB) { } }
        if (typeof snapshot.spaceAfter !== "undefined") { try { style.spaceAfter = snapshot.spaceAfter; } catch (eSA) { } }
        if (typeof snapshot.kerningMethod !== "undefined") { try { style.kerningMethod = snapshot.kerningMethod; } catch (eK) { } }
        if (typeof snapshot.justification !== "undefined") { try { style.justification = snapshot.justification; } catch (eJ) { } }
        if (typeof snapshot.sameParaStyleSpacing !== "undefined") {
            try { style.sameParaStyleSpacing = snapshot.sameParaStyleSpacing; } catch (eSSS) { }
        }
    }

    /**
     * 段落スタイルへ各プロパティを適用する
     * @param {Document} targetDocument 対象ドキュメント
     * @param {string} styleName 対象の段落スタイル名
     * @param {object} styleProps 適用するプロパティ
     * @param {number} styleProps.size 文字サイズ（pt）
     * @param {Font} [styleProps.font] 適用するフォント
     * @param {string} [styleProps.fontStyleName] ウエイト名。font が無いときはこれだけを適用する
     * @param {number} [styleProps.autoLeadingPercent] 自動行送りの割合（%）
     * @param {number} [styleProps.spaceBefore] 段落前のアキ（pt）
     * @param {number} [styleProps.spaceAfter] 段落後のアキ（pt）
     * @param {string} [styleProps.kerningMethod] カーニング方式
     * @param {boolean} styleProps.isHeading 見出しなら true
     * @param {boolean} styleProps.silent スタイル未検出時に警告を出さないなら true
     * @param {boolean} styleProps.sizeOnly 文字サイズだけを更新するなら true
     * @param {object} [styleProps.originalProps] ダイアログ起動時に控えた値
     * @returns {boolean} 適用できたら true
     */
    function setParagraphStyleProps(targetDocument, styleName, styleProps) {
        var size = styleProps.size;
        var font = styleProps.font;
        var fontStyleName = styleProps.fontStyleName;
        var autoLeadingPercent = styleProps.autoLeadingPercent;
        var spaceBefore = styleProps.spaceBefore;
        var spaceAfter = styleProps.spaceAfter;
        var kerningMethod = styleProps.kerningMethod;
        var isHeading = styleProps.isHeading;
        var silent = styleProps.silent;
        var originalProps = styleProps.originalProps;

        var style = findParagraphStyle(targetDocument, styleName);
        if (style === null) {
            if (!silent) alert(getLabel("error.missingStyle", [styleName]));
            return false;
        }
        // ルート／組み込みスタイル（[基本段落] / [Basic Paragraph] / [段落スタイルなし] など）は
        // pointSize 等の設定で error 516「ルートスタイルに対する無効な要求」になるためスキップ
        if (isRootParagraphStyle(style)) return false;
        // 書き換えるスタイルを記録（キャンセル時にこのスタイルだけ起動時状態へ戻す）
        _previewModifiedStyles[styleName] = true;
        // サイズのみモード: サイズだけを更新し、その他はダイアログ起動時の値に戻す
        if (styleProps.sizeOnly) {
            style.pointSize = toPointString(size);
            assignSnapshotToStyle(style, originalProps, false);
            return true;
        }
        // 環境差異に対応するため、複数パターンでフォントを設定（fullName → object → name）
        if (font) {
            var assigned = false;
            var fontFullName = getFontFullName(font.fontFamily, font.fontStyleName);
            if (fontFullName) {
                try {
                    style.appliedFont = fontFullName;
                    assigned = true;
                } catch (e1) { }
            }
            if (!assigned) {
                try {
                    style.appliedFont = font;
                    assigned = true;
                } catch (e2) { }
            }
            if (!assigned && font.name) {
                try {
                    style.appliedFont = font.name;
                    assigned = true;
                } catch (e3) { }
            }
            if (assigned && font.fontStyleName) {
                try { style.fontStyle = font.fontStyleName; } catch (e4) { }
            }
        } else if (fontStyleName) {
            /* フォントファミリー未指定：今のファミリーを保ったままウエイトだけ差し替える
               / No family chosen: swap only the weight and keep the family the style already uses */
            try { style.fontStyle = fontStyleName; } catch (e5) { }
        }
        style.pointSize = toPointString(size);
        // 行送りは自動行送り（%）で設定する。上限は入力側（parseAutoLeadingMultiplier）で
        // 丸めているが、念のため例外は握りつぶす（範囲外はエラー「データが範囲外です」になる）
        if (typeof autoLeadingPercent === "number" && autoLeadingPercent > 0) {
            try {
                style.autoLeading = autoLeadingPercent;
                style.leading = Leading.AUTO;
            } catch (eL) { }
        }
        if (ENABLE_SPACE_BEFORE && typeof spaceBefore === "number" && spaceBefore >= 0) {
            style.spaceBefore = toPointString(spaceBefore);
        }
        if (ENABLE_SPACE_AFTER && typeof spaceAfter === "number" && spaceAfter >= 0) {
            style.spaceAfter = toPointString(spaceAfter);
        }
        // 同じスタイルの段落間隔（sameParaStyleSpacing）をスタイル名ごとのルールで設定
        if (ENABLE_SAME_STYLE_SPACING) {
            var sameStyleSpacing = resolveSameStyleSpacing(styleName, spaceBefore);
            if (sameStyleSpacing !== null) {
                try { style.sameParaStyleSpacing = toPointString(sameStyleSpacing); } catch (eSSS) { }
            }
        }
        // フォントによっては設定不可のため、安全に無視
        if (kerningMethod) {
            try { style.kerningMethod = kerningMethod; } catch (ke) { }
        }
        // 字揃えは既定では変更しない（元の字揃えを保持）。ENABLE_JUSTIFICATION を true にすると強制適用する
        if (ENABLE_JUSTIFICATION) {
            try {
                if (isHeading) {
                    // 見出しは左揃え / Headings are left aligned
                    style.justification = Justification.LEFT_ALIGN;
                } else {
                    // 本文・キャプションは均等配置（最終行左） / Body and captions are left-justified
                    style.justification = Justification.LEFT_JUSTIFIED;
                }
            } catch (e) { }
        }
        return true;
    }

    // 「サイズのみ」復元・キャンセル復元用に、ダイアログ起動時点の段落スタイルのプロパティを記録する
    /**
     * すべての段落スタイルの現在値を控える
     * @param {Document} targetDocument 対象ドキュメント
     * @returns {object} 段落スタイル名をキーにしたプロパティの控え
     */
    function snapshotParagraphStyleProps(targetDocument) {
        var snapshot = {};
        var styles = targetDocument.allParagraphStyles;
        for (var snapshotIndex = 0; snapshotIndex < styles.length; snapshotIndex++) {
            var paragraphStyle = styles[snapshotIndex];
            var styleSnapshot = {};
            try { styleSnapshot.pointSize = paragraphStyle.pointSize; } catch (ePS) { }
            try { styleSnapshot.leading = paragraphStyle.leading; } catch (eL) { }
            try { styleSnapshot.autoLeading = paragraphStyle.autoLeading; } catch (eAL) { }
            try { styleSnapshot.spaceBefore = paragraphStyle.spaceBefore; } catch (eSB) { }
            try { styleSnapshot.spaceAfter = paragraphStyle.spaceAfter; } catch (eSA) { }
            try { styleSnapshot.justification = paragraphStyle.justification; } catch (eJ) { }
            try { styleSnapshot.appliedFont = paragraphStyle.appliedFont; } catch (eF) { }
            try { styleSnapshot.fontStyle = paragraphStyle.fontStyle; } catch (eFS) { }
            try { styleSnapshot.kerningMethod = paragraphStyle.kerningMethod; } catch (eK) { }
            try { styleSnapshot.sameParaStyleSpacing = paragraphStyle.sameParaStyleSpacing; } catch (eSSS) { }
            snapshot[paragraphStyle.name] = styleSnapshot;
        }
        return snapshot;
    }

    // キャンセル時：プレビューで書き換えたスタイルだけを起動時の状態へ戻す
    /**
     * 書き換えた段落スタイルを控えておいた値に戻す
     * @param {Document} targetDocument 対象ドキュメント
     * @param {object} originalStyleProps 控えたプロパティ。段落スタイル名がキー
     * @param {object} modifiedStyleNames 書き換えた段落スタイル名の集合
     * @returns {void}
     */
    function restoreParagraphStyleProps(targetDocument, originalStyleProps, modifiedStyleNames) {
        if (!originalStyleProps || !modifiedStyleNames) return;
        for (var styleName in modifiedStyleNames) {
            if (!modifiedStyleNames.hasOwnProperty(styleName)) continue;
            var snap = originalStyleProps[styleName];
            if (!snap) continue;
            var style = findParagraphStyle(targetDocument, styleName);
            if (style === null) continue;
            assignSnapshotToStyle(style, snap, true);
        }
    }

    /**
     * 段落スタイル名から段落スタイルを引くための対応表を返す
     * @param {Document} targetDocument 対象ドキュメント
     * @returns {object} スタイル名をキーにした対応表
     */
    function getParagraphStyleMap(targetDocument) {
        if (_paragraphStyleMap) return _paragraphStyleMap;
        var map = {};
        var styles = targetDocument.allParagraphStyles;
        for (var styleIndex = 0; styleIndex < styles.length; styleIndex++) {
            var style = styles[styleIndex];
            /* 同名スタイルが複数ある場合は最初のものを採用（従来の探索と同じ）
               / Keep the first match when names collide, as the previous scan did */
            if (!map.hasOwnProperty(style.name)) map[style.name] = style;
        }
        _paragraphStyleMap = map;
        return map;
    }

    /**
     * 名前から段落スタイルを探す
     * @param {Document} targetDocument 対象ドキュメント
     * @param {string} styleName 段落スタイル名
     * @returns {ParagraphStyle|null} 段落スタイル。見つからない場合は null
     */
    function findParagraphStyle(targetDocument, styleName) {
        var map = getParagraphStyleMap(targetDocument);
        return map.hasOwnProperty(styleName) ? map[styleName] : null;
    }

    // ルート／組み込みスタイルかどうか（名前が "[" で始まる：[基本段落] / [Basic Paragraph] / [段落スタイルなし] など）
    /**
     * 組み込みスタイル（名前が [ で始まる）かどうかを判定する
     * @param {ParagraphStyle} style 対象の段落スタイル
     * @returns {boolean} 組み込みスタイルなら true
     */
    function isRootParagraphStyle(style) {
        try {
            return !!(style && style.name && style.name.charAt(0) === "[");
        } catch (e) {
            return false;
        }
    }

})();