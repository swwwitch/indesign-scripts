#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdRemoveMarkerApplyStyle
Name=Markdown の目印を削除してスタイルを適用
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.1.7
Release-Date=2026-09-09
Description-BEGIN
行頭の目印（Markdown の見出し・箇条書き・番号リストなど）を手がかりに段落スタイルと文字スタイルを適用し、その目印を後ろに続くスペースごと削除します。目印は検索対象から自動判別でき、対象箇所の件数を確かめてから実行できます。

Applies a paragraph style and a character style to paragraphs carrying a leading marker — Markdown headings, bullets, numbered lists and the like — then deletes the marker together with the spaces that follow it. Markers can be detected from the search target, and the number of matches is shown before the run.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

行頭の目印（Markdown の見出し・箇条書き・番号リストなど）を手がかりに段落スタイルと文字スタイルを適用し、その目印を後ろに続くスペースごと削除します。目印は検索対象から自動判別でき、対象箇所の件数を確かめてから実行できます。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdRemoveMarkerApplyStyle.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n3a0d4c0dacdb

### Overview

Applies a paragraph style and a character style to paragraphs carrying a leading marker — Markdown headings, bullets, numbered lists and the like — then deletes the marker together with the spaces that follow it. Markers can be detected from the search target, and the number of matches is shown before the run.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdRemoveMarkerApplyStyle.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdRemoveMarkerApplyStyle";    /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.1.7";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)"; /* 作者 / author */
var SCRIPT_RELEASED = "2026-09-09";                  /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                  /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "Markdown の目印を削除してスタイルを適用"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdRemoveMarkerApplyStyle.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdRemoveMarkerApplyStyle.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n3a0d4c0dacdb"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/style/IdRemoveMarkerApplyStyle.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

// =========================================
// 基本設定 / Settings
// =========================================

/* 検索文字列の指定方法 / How the search text is specified */
var SEARCH_MODE_TEXT = 0;
var SEARCH_MODE_AUTO = 1;

/* ダイアログの初期状態 / Dialog defaults */
var DEFAULT_SEARCH_MODE      = SEARCH_MODE_TEXT;
var DEFAULT_SEARCH_TEXT      = "###";
var DEFAULT_MATCH_LEVEL      = true;  /* 見出しレベルに合わせて段落スタイルを選ぶ / match the style to the level */
var DEFAULT_APPLY_ALL_LEVELS = false; /* 見出しを連続適用する / apply every heading level */
var DEFAULT_USE_GREP         = false; /* 検索文字列を GREP として扱う / treat the search text as GREP */

/* 自動判別で拾う行頭記号 / Line-head markers picked up by auto detection */
/* 半角記号に加え、箇条書きに使う約物と全角記号を含める / ASCII symbols plus Japanese bullets and full-width symbols */
var LINE_HEAD_MARKER_PATTERN = /^([#*\->+~=|_`●○◎◆◇■□▲△▼▽★☆・※＊＃－＋＞]{1,10})[ \t　]?/;

/* 太字（**文字列**）。行頭記号ではなく囲みなので個別に判定する /
   Bold spans are enclosing, not line-head markers */
var BOLD_PATTERN = /\*\*[^*]+\*\*/;
var BOLD_SEARCH_TEXT = "\\*\\*";

/* 行頭の "**" は太字として拾うので、行頭記号からは除く / "**" at the line head belongs to bold */
var EXCLUDED_LINE_HEAD_PATTERN = /^\*{2,}/;

/* 漢数字（十・百・千を含む） / Kanji numerals */
var KANJI_NUMBER = "[〇一二三四五六七八九十百千]+";

/* 自動判別で拾うナンバリング（数字が変わるので GREP 検索になる） / Numbering (searched with GREP) */
/* pattern は JavaScript の正規表現と InDesign の GREP の両方で通る書き方にそろえる /
   Each pattern is written so it works both as a JavaScript RegExp and as an InDesign GREP query */
var NUMBERED_LIST_PATTERNS = [
    { pattern: "^\\d+\\. ", labelKey: "marker.numberedDot" },
    { pattern: "^\\d+\\) ", labelKey: "marker.numberedParen" },
    { pattern: "^[（(]" + KANJI_NUMBER + "[）)][ 　]?", labelKey: "marker.kanjiParen" },
    { pattern: "^" + KANJI_NUMBER + "\\. ", labelKey: "marker.kanjiDot" },
    { pattern: "^" + KANJI_NUMBER + "、", labelKey: "marker.kanjiComma" },
    { pattern: "^" + KANJI_NUMBER + "[）)][ 　]?", labelKey: "marker.kanjiCloseParen" }
];

/* 判定用の正規表現をあらかじめ用意する / Compile the detection patterns once */
for (var patternIndex = 0; patternIndex < NUMBERED_LIST_PATTERNS.length; patternIndex++) {
    NUMBERED_LIST_PATTERNS[patternIndex].regex =
        new RegExp(NUMBERED_LIST_PATTERNS[patternIndex].pattern);
}

/* 自動判別で「繰り返し」とみなす最小段落数 / Minimum paragraphs to treat a marker as repeated */
var MIN_REPEAT_COUNT = 2;

/* Markdown の見出しマーカー（# 〜 ######） / Markdown heading markers */
var HEADING_MARKER_PATTERN = /^#{1,6}[ \t　]*$/;
var MAX_HEADING_LEVEL = 6;

/* 目印に続く区切り（見つかれば一緒に削除する） / Separator after the marker (deleted together) */
/* 半角スペース・全角スペース・タブ。連続していてもまとめて削除し、無くてもよい /
   Spaces, full-width spaces and tabs: all of them are deleted, and none is fine too */
var TRAILING_SEPARATOR_PATTERN = "[ 　\\t]*";

/* 見出しレベルに対応する段落スタイル名（先に見つかったものを使う） / Paragraph style names per heading level */
var HEADING_STYLE_NAME_FORMATS = ["h%1", "H%1", "heading %1", "Heading %1"];

/* 検索オプション（前回の「検索/置換」の設定を引き継がない） / Find options (never inherited) */
var FIND_WIDTH_SENSITIVE        = true;  /* 半角と全角を区別（＃ と # を分ける） / width sensitive */
var FIND_KANA_SENSITIVE         = true;  /* ひらがなとカタカナを区別 / kana sensitive */
var FIND_INCLUDE_FOOTNOTES      = false; /* 脚注を含む / include footnotes */
var FIND_INCLUDE_MASTER_PAGES   = false; /* マスターページを含む / include master pages */
var FIND_INCLUDE_HIDDEN_LAYERS  = false; /* 非表示レイヤーを含む / include hidden layers */
var FIND_INCLUDE_LOCKED_LAYERS  = false; /* ロックされたレイヤーを含む / include locked layers */
var FIND_INCLUDE_LOCKED_STORIES = false; /* ロックされたストーリーを含む / include locked stories */

/* スコープ（検索対象） / Search scope */
var SCOPE_ALL_DOCUMENTS = 0;
var SCOPE_DOCUMENT      = 1;
var SCOPE_STORY         = 2;

/* ダイアログの初期スコープ / Default scope */
var DEFAULT_SCOPE = SCOPE_STORY;

// =========================================
// UIレイアウトの共通設定 / Shared UI layout
// =========================================

// UIレイアウト（再利用パーツ） / UI layout (reusable)

/* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

/**
 * ウィンドウの共通設定
 * @param {Window} targetWindow - 対象のウィンドウ
 * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
 * @returns {void}
 */
function setupWindow(targetWindow, spacing) {
    targetWindow.orientation = "column";
    targetWindow.alignChildren = "fill";
    targetWindow.margins = WINDOW_MARGINS;
    targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
}

/**
 * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
 * @param {Panel} targetPanel - 対象のパネル
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupPanel(targetPanel, spacing) {
    targetPanel.orientation = "column";
    targetPanel.alignChildren = ["fill", "top"];
    targetPanel.alignment = "fill";
    targetPanel.margins = PANEL_MARGINS;
    targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * タブの共通設定
 * @param {Tab} targetTab - 対象のタブ
 * @param {number} [spacing] - 要素間隔（省略時は変えない）
 * @returns {void}
 */
function setupTab(targetTab, spacing) {
    targetTab.orientation = "column";
    targetTab.alignChildren = "fill";
    targetTab.margins = TAB_MARGINS;
    if (typeof spacing === "number") targetTab.spacing = spacing;
}

/**
 * 横並びの行グループの共通設定（ボタン列など）。
 * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
 * @param {Group} rowGroup - 対象のグループ
 * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupRow(rowGroup, rowAlignment, spacing) {
    rowGroup.orientation = "row";
    rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
    rowGroup.alignChildren = ["left", "center"];
    rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
 * @param {Button} targetButton - 対象のボタン
 * @param {number} trimPixels - 詰める量（px）
 * @returns {void}
 */
function trimButtonHeight(targetButton, trimPixels) {
    /* レイアウト前は size が無い / size is not set until the layout runs */
    if (!targetButton.size) return;
    targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
}

// UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

var RADIO_SPACING  = 4;                /* ラジオボタンの間隔 / radio button spacing */

/* 行の寸法 / Row metrics */
var LABEL_WIDTH        = 110; /* ラベル・ラジオボタンの幅 / label & radio button width */
var SEARCH_TEXT_LENGTH = 16;  /* 検索文字列入力欄の文字数 / search field length */
var BUTTON_WIDTH       = 90;  /* ダイアログボタンの幅 / dialog button width */
var COUNT_WIDTH        = 60;  /* 対象箇所の数値の幅 / match count width */

// =========================================
// ラベル定義 / Labels
// =========================================

// ローカライズ（再利用パーツ） / Localization (reusable)

/**
 * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
 * @returns {string} "ja" または "en"
 */
function getCurrentLang() {
    return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
}

var uiLang = getCurrentLang();

/**
 * LABELS から今の UI 言語の文言を取り出す。
 * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
 * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
 * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
 */
function getLabel(labelRef, placeholderValues) {
    var labelEntry = labelRef;
    if (typeof labelRef === "string") {
        var labelPathKeys = labelRef.split(".");
        labelEntry = LABELS;
        for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
            labelEntry = labelEntry[labelPathKeys[i]];
        }
    }
    var labelString;
    if (typeof labelEntry === "string") labelString = labelEntry;
    else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
    else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
    else return (typeof labelRef === "string") ? labelRef : "";
    return fillLabelPlaceholders(String(labelString), placeholderValues);
}

/**
 * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {Object|Array} [placeholderValues] - getLabel と同じ
 * @returns {string} コロン付きの文言
 */
function labelText(labelRef, placeholderValues) {
    return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
}

/**
 * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {string|number} value - コロンのあとに続ける値
 * @returns {string} 項目名と値をつないだ文字列
 */
function labelValueText(labelRef, value) {
    return labelText(labelRef) + " " + value;
}

/**
 * 文言の {name} や %1 に値を差し込む
 * @param {string} labelString - 文言
 * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
 * @returns {string} 差し込んだ文言
 */
function fillLabelPlaceholders(labelString, placeholderValues) {
    if (placeholderValues == null) return labelString;
    if (placeholderValues instanceof Array) {
        /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
        for (var i = placeholderValues.length; i >= 1; i--) {
            labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
        }
        return labelString;
    }
    for (var placeholderKey in placeholderValues) {
        if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
        labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
    }
    return labelString;
}

// ローカライズ（再利用パーツ）ここまで / End of the reusable localization

// ボタン行（再利用パーツ） / Button row (reusable)

var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

/**
 * ダイアログ下部のボタン行を作る。
 * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
 * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
 * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
 * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
 */
function addButtonRow(parent, rowOptions) {
    var isCentered = !!(rowOptions && rowOptions.centered);
    var btnRowGroup = parent.add("group");
    btnRowGroup.orientation = "row";
    btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
    btnRowGroup.spacing = BUTTON_ROW_SPACING;

    if (isCentered) {
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
    }

    btnRowGroup.alignment = ["fill", "bottom"];

    var btnLeftGroup = btnRowGroup.add("group");
    btnLeftGroup.alignChildren = ["left", "center"];
    btnLeftGroup.spacing = BUTTON_ROW_SPACING;

    /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
    var spacer = btnRowGroup.add("group");
    spacer.alignment = ["fill", "fill"];
    spacer.minimumSize.width = 0;

    var btnRightGroup = btnRowGroup.add("group");
    btnRightGroup.alignChildren = ["right", "center"];
    btnRightGroup.spacing = BUTTON_ROW_SPACING;

    return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
}

/**
 * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
 * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
 * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
 * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
 * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
 * @returns {void}
 */
function alignRightOnlyButtonRow(buttonRow) {
    if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
    var dialogWindow = buttonRow.rowGroup.window;
    dialogWindow.addEventListener("show", function () {
        if (!buttonRow.leftGroup) return;
        var btnRowGroup = buttonRow.rowGroup;
        /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
        if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
        /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
        btnRowGroup.remove(buttonRow.leftGroup);
        btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        buttonRow.leftGroup = null;
        dialogWindow.layout.layout(true);
    });
}

// ボタン行（再利用パーツ）ここまで / End of the reusable button row

// UI の明暗（再利用パーツ） / UI theme (reusable)

/**
 * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
 * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
 */
function isDarkUI() {
    try {
        if (app.preferences && app.preferences.getRealPreference) {
            return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
        }
        return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
    } catch (e) {
        return false;
    }
}

// UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

// バージョン表示（再利用パーツ） / Version footer (reusable)

var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

/* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
   9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
   / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
     nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
var VERSION_FOOTER_GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
    "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
    "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
    "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
    "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
    "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
    "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
    "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
    "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
    "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
    "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
    "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
    "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
    "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
    "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
    "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
    "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
    "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
    "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
    "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
    "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
    "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
    "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
    "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
    "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
    "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
    "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
    "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
    "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
    "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
    "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
    "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
    "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
    "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
    "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
    "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
    "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
    "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
    ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
    "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
    "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
    "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
    " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
};

/**
 * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
 * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
 * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
 * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
 * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
 */
function addVersionFooter(targetWindow) {
    if (targetWindow.versionFooter) return null;

    /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
    var lastChild = targetWindow.children[targetWindow.children.length - 1];
    if (lastChild && lastChild.type === "group") {
        var rowMargins = lastChild.margins;
        lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
    }
    var windowMargins = targetWindow.margins;
    targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

    var footerGroup = targetWindow.add("group");
    footerGroup.orientation = "row";
    footerGroup.alignment = ["fill", "bottom"];
    footerGroup.alignChildren = ["left", "center"];
    footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

    /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
       左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
       / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
         or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
    var versionText = String(SCRIPT_VERSION);
    var leftCandidates = [versionText];
    if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
    var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
    versionCanvas.alignment = ["fill", "center"];
    bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
    var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
    brandCanvas.alignment = ["right", "center"];
    brandCanvas.maximumSize = brandCanvas.preferredSize;
    targetWindow.versionFooter = footerGroup;
    return versionCanvas;
}

/**
 * 文字列のすべての文字に字形があるかを返す
 * @param {string} dotText - 文字列
 * @returns {boolean} すべてあれば true
 */
function hasVersionFooterGlyphs(dotText) {
    for (var i = 0; i < dotText.length; i++) {
        if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
    }
    return dotText.length > 0;
}

/**
 * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
 * @param {Group} parentGroup - 足す先
 * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
 * @returns {Group} 描くグループ
 */
function addVersionFooterCanvas(parentGroup, dotTexts) {
    var dotCanvas = parentGroup.add("group");
    var shortestText = dotTexts[dotTexts.length - 1];
    dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
    dotCanvas.helpTip = dotTexts[0];
    dotCanvas.onDraw = function () {
        var availableWidth = this.size ? this.size.width : 0;
        var drawText = shortestText;
        for (var i = 0; i < dotTexts.length; i++) {
            if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                drawText = dotTexts[i];
                break;
            }
        }
        drawVersionFooterDots(this.graphics, drawText);
    };
    return dotCanvas;
}

/**
 * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
 * @param {string} versionText - 文字列
 * @returns {number} 幅（ドット）
 */
function measureVersionFooterDots(versionText) {
    var dotCount = 0;
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
        dotCount += glyphRows[0].length;
    }
    return dotCount;
}

/**
 * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
 * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
 * @param {string} versionText - 文字列
 * @returns {void}
 */
function drawVersionFooterDots(canvasGraphics, versionText) {
    var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
    var dotSize = VERSION_FOOTER_PIXEL_SIZE;
    var cursorDots = 0;
    canvasGraphics.newPath();
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
        for (var row = 0; row < glyphRows.length; row++) {
            var rowText = glyphRows[row];
            var runStart = -1;
            for (var col = 0; col <= rowText.length; col++) {
                var isDot = col < rowText.length && rowText.charAt(col) === "#";
                if (isDot && runStart < 0) runStart = col;
                if (!isDot && runStart >= 0) {
                    canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                    runStart = -1;
                }
            }
        }
        cursorDots += glyphRows[0].length;
    }
    canvasGraphics.fillPath(footerBrush);
}

// -----------------------------------------
// このスクリプトについて / About this script
// -----------------------------------------
/* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
   この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
   Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
   and keeps its own labels and layout values so the part works on its own */

var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
/* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
   The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
/* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

var VERSION_INFO_LABELS = {
    dialog: {
        title: { ja: "このスクリプトについて", en: "About This Script" }
    },
    panel: {
        generalInfo: { ja: "基本情報", en: "General" },
        links: { ja: "リンク", en: "Links" }
    },
    fieldLabel: {
        scriptName: { ja: "スクリプト名", en: "Script Name" },
        scriptFeature: { ja: "機能", en: "Feature" },
        scriptVersion: { ja: "バージョン", en: "Version" }
    },
    button: {
        openReadme: { ja: "README", en: "README" },
        openSourceCode: { ja: "ソースコード", en: "Source Code" },
        openArticle: { ja: "記事（note）", en: "Article (note)" },
        revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
        revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
        close: { ja: "閉じる", en: "Close" }
    },
    tooltip: {
        versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
        copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
    },
    alert: {
        copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
    }
};

/**
 * VERSION_INFO_LABELS の文言を今の言語で返す
 * @param {Object} labelEntry - { ja, en }
 * @returns {string} 文言
 */
function getVersionInfoLabel(labelEntry) {
    return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
}

/**
 * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
 * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
 * @returns {string} 値
 */
function getVersionInfoValue(variableKey) {
    var infoValue;
    if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
    else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
    else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
    else if (variableKey === "readme") {
        if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
        else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
    }
    else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
    else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
    return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
}

/**
 * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
 * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
 * @returns {void}
 */
function bindVersionInfoClick(versionCanvas) {
    versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
    /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
       Open on mouseup so the release does not land on the footer after the dialog closes */
    versionCanvas.addEventListener("mouseup", function () {
        showVersionInfoDialog(versionCanvas.window.type === "palette");
    });
}

/**
 * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
 * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
 * @returns {void}
 */
function showVersionInfoDialog(isFromPalette) {
    var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
    infoDialog.orientation = "column";
    infoDialog.alignChildren = "fill";
    infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
    infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

    var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
    /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
    /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
    if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
    }
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
    alignVersionInfoLabels(infoPanel);

    /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
    var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
    var linkButtonRow = linksPanel.add("group");
    linkButtonRow.orientation = "row";
    linkButtonRow.alignment = ["left", "center"];
    linkButtonRow.alignChildren = ["left", "center"];
    linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

    /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
    var buttonRow = infoDialog.add("group");
    buttonRow.orientation = "row";
    buttonRow.alignment = ["fill", "bottom"];
    buttonRow.alignChildren = ["left", "center"];
    buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
    buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
    var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
    if (VERSION_INFO_SCRIPT_FILE.exists) {
        revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
        revealButton.onClick = function () {
            revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
            infoDialog.close();
        };
    } else {
        revealButton.enabled = false;
    }
    /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
    var buttonSpacer = buttonRow.add("group");
    buttonSpacer.alignment = ["fill", "fill"];
    buttonSpacer.minimumSize.width = 0;
    var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
    closeButton.alignment = ["right", "center"];
    /* return でも esc でも閉じる / Close with both Return and Esc */
    infoDialog.defaultElement = closeButton;
    infoDialog.cancelElement = closeButton;
    infoDialog.onShow = function () {
        pinVersionInfoCopyButton(infoPanel);
    };
    infoDialog.show();
}

/**
 * 「このスクリプトについて」のダイアログにパネルを足す
 * @param {Window} infoDialog - 足す先のダイアログ
 * @param {Object} titleEntry - パネル名の文言 { ja, en }
 * @returns {Panel} パネル
 */
function addVersionInfoPanel(infoDialog, titleEntry) {
    var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
    infoPanel.orientation = "column";
    infoPanel.alignChildren = ["fill", "top"];
    infoPanel.alignment = "fill";
    infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
    infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
    return infoPanel;
}

/**
 * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
 * @param {Panel} infoPanel - 足す先のパネル
 * @param {Object} labelEntry - 項目名の文言 { ja, en }
 * @param {string} valueText - 表示する値
 * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
 * @returns {StaticText} 値の statictext
 */
function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
    var infoRow = infoPanel.add("group");
    infoRow.orientation = "row";
    infoRow.alignment = ["fill", "center"];
    infoRow.alignChildren = ["left", "center"];
    infoRow.spacing = VERSION_INFO_ROW_SPACING;
    /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
    var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
    rowLabel.justify = "right";
    var valueLabel = infoRow.add("statictext", undefined, valueText);
    if (copyFromPalette === null) return valueLabel;
    /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
       A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
    var copySpacer = infoRow.add("group");
    copySpacer.alignment = ["fill", "fill"];
    copySpacer.minimumSize.width = 0;
    infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
    return valueLabel;
}

/**
 * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
 * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
 * @param {Panel} infoPanel - ［基本情報］パネル
 * @returns {void}
 */
function pinVersionInfoCopyButton(infoPanel) {
    var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
    for (var i = 0; i < infoPanel.children.length; i++) {
        var infoRow = infoPanel.children[i];
        if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
        infoRow.size = [innerWidth, infoRow.size.height];
        infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
    }
}

/**
 * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
 * @param {Panel} infoPanel - 対象のパネル
 * @returns {void}
 */
function alignVersionInfoLabels(infoPanel) {
    var rowLabels = [];
    var labelWidth = 0;
    for (var i = 0; i < infoPanel.children.length; i++) {
        var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
        rowLabels.push(rowLabel);
        labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
    }
    for (var j = 0; j < rowLabels.length; j++) {
        rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
    }
}

/**
 * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
 * @param {Window} infoDialog - ボタンを置くダイアログ
 * @param {Group} buttonGroup - 足す先のグループ
 * @param {Object} labelEntry - ボタンの文言 { ja, en }
 * @param {string} targetUrl - 開く URL（空ならディム表示）
 * @returns {void}
 */
function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
    var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
    if (!targetUrl) {
        linkButton.enabled = false;
        return;
    }
    linkButton.helpTip = targetUrl;
    linkButton.onClick = function () {
        openVersionInfoUrl(targetUrl);
        infoDialog.close();
    };
}

/**
 * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
 * @param {Group} infoRow - 足す先の行
 * @param {StaticText} valueLabel - コピーする値の statictext
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {Group} ボタンとして使う group
 */
function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
    var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
    var copyButton = infoRow.add("group");
    copyButton.preferredSize = [buttonSize, buttonSize];
    copyButton.minimumSize = [buttonSize, buttonSize];
    copyButton.maximumSize = [buttonSize, buttonSize];
    copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
    copyButton.isPressed = false;
    copyButton.isCopied = false;

    copyButton.onDraw = function () {
        var buttonGraphics = copyButton.graphics;
        var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
        buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
        if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
        else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
    };

    /**
     * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
     * @param {boolean} isPressed - 押下中なら true
     * @param {boolean} isCopied - コピー済みなら true
     * @returns {void}
     */
    function repaint(isPressed, isCopied) {
        if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
        copyButton.isPressed = isPressed;
        copyButton.isCopied = isCopied;
        copyButton.hide();
        copyButton.show();
    }
    copyButton.addEventListener("mousedown", function () { repaint(true, false); });
    copyButton.addEventListener("mouseup", function () {
        if (!copyButton.isPressed) return;
        var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
        repaint(false, hasCopied);
        if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
    });
    /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
    copyButton.addEventListener("mouseout", function () { repaint(false, false); });
    return copyButton;
}

/**
 * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
    var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
    var sheetSize = 9;
    var offset = 3;
    var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var backLeft = frontLeft - offset;
    var backTop = frontTop - offset;
    /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
    buttonGraphics.newPath();
    buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
    buttonGraphics.strokePath(iconPen);
    buttonGraphics.newPath();
    buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
    buttonGraphics.strokePath(iconPen);
}

/**
 * コピーしたあとのチェックマークを描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
    var center = buttonSize / 2;
    buttonGraphics.newPath();
    buttonGraphics.moveTo(center - 4.5, center);
    buttonGraphics.lineTo(center - 1.5, center + 3);
    buttonGraphics.lineTo(center + 4.5, center - 3.5);
    buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
}

/**
 * 文字列をクリップボードにコピーする。
 * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
 * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
 * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
 * @param {string} copyText - コピーする文字列
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {boolean} コピーの操作まで進めたら true
 */
function copyVersionInfoText(copyText, isFromPalette) {
    try {
        if (VERSION_INFO_IS_INDESIGN) {
            if (File.fs === "Windows") {
                app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
            } else {
                app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
            }
            return true;
        }
        var copyScript = buildVersionInfoCopyScript(copyText);
        if (!isFromPalette) return eval(copyScript) === true;
        var copyMessage = new BridgeTalk();
        copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
        copyMessage.body = copyScript;
        copyMessage.send();
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
 * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
 * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
 * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
 * @param {string} copyText - コピーする文字列
 * @returns {string} 実行すると true / false を返すスクリプト
 */
function buildVersionInfoCopyScript(copyText) {
    return [
        "(function (copyText) {",
        "    var usingTempDoc = (app.documents.length === 0);",
        "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
        "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
        "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
        "    var tempLayer = null;",
        "    var hasCopied = false;",
        "    try {",
        "        tempLayer = targetDoc.layers.add();",
        "        var tempFrame = tempLayer.textFrames.add();",
        "        tempFrame.contents = copyText;",
        "        app.redraw();",
        "        app.executeMenuCommand('deselectall');",
        "        tempFrame.selected = true;",
        "        app.redraw();",
        "        app.executeMenuCommand('copy');",
        "        app.redraw();",
        "        hasCopied = true;",
        "    } catch (e) { }",
        "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
        "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
        "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
        "    targetDoc.selection = null;",
        "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
        "    app.redraw();",
        "    return hasCopied;",
        "})(" + quoteVersionInfoString(copyText) + ");"
    ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
}

/**
 * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
 * @param {string} sourceText - 文字列
 * @returns {string} "…" の形のリテラル
 */
function quoteVersionInfoString(sourceText) {
    return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

/**
 * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
 * @param {File} scriptFile - 表示するファイル
 * @returns {void}
 */
function revealVersionInfoScriptFile(scriptFile) {
    /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
    var hasRevealApp = (File.fs === "Macintosh")
        && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
    /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
    if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
    /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
    scriptFile.parent.execute();
}

/**
 * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
 * @param {string} targetPath - 絶対パス
 * @returns {boolean} 書き出せたら true
 */
function writeVersionInfoRevealPath(targetPath) {
    var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
    pathFile.encoding = "UTF-8";
    pathFile.lineFeed = "Unix";
    if (!pathFile.open("w")) return false;
    var hasWritten = pathFile.write(targetPath);
    pathFile.close();
    return hasWritten;
}

/**
 * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
 * @param {string} targetUrl - 開く URL
 * @returns {void}
 */
function openVersionInfoUrl(targetUrl) {
    var isMac = (File.fs === "Macintosh");
    var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
    shortcutFile.encoding = "UTF-8";
    shortcutFile.open("w");
    if (isMac) {
        var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
        shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
            + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
    } else {
        shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
    }
    shortcutFile.close();
    shortcutFile.execute();
}

// バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

var LABELS = {
    dialog: {
        title: { ja: "目印を削除してスタイルを適用", en: "Delete Markers and Apply Styles" }
    },
    panel: {
        searchText: { ja: "検索文字列", en: "Find What" },
        style:      { ja: "適用するスタイル", en: "Styles to Apply" },
        scope:      { ja: "検索対象", en: "Search In" },
        markdown:   { ja: "Markdown", en: "Markdown" }
    },
    marker: {
        detected:        { ja: "%1（%2箇所）", en: "%1 (%2 found)" },
        numberedDot:     { ja: "1. 2. 3.", en: "1. 2. 3." },
        numberedParen:   { ja: "1) 2) 3)", en: "1) 2) 3)" },
        kanjiParen:      { ja: "（一）（二）（三）", en: "(1) (2) (3) in kanji" },
        kanjiDot:        { ja: "一. 二. 三.", en: "1. 2. 3. in kanji" },
        kanjiComma:      { ja: "一、二、三、", en: "1, 2, 3, in kanji" },
        kanjiCloseParen: { ja: "一）二）三）", en: "1) 2) 3) in kanji" },
        bold:            { ja: "**文字列**", en: "**text**" }
    },
    mode: {
        text: { ja: "文字列を指定", en: "Enter text" },
        auto: { ja: "自動判別", en: "Detect automatically" }
    },
    field: {
        paragraphStyle: { ja: "段落スタイル", en: "Paragraph style" },
        characterStyle: { ja: "文字スタイル", en: "Character style" },
        useGrep:        { ja: "正規表現（GREP）で検索", en: "Search with GREP" },
        matchCount:     { ja: "対象箇所", en: "Matches" },
        matchUnknown:   { ja: "—", en: "—" },
        matchLevel:     { ja: "見出しレベルに合わせる", en: "Match the heading level" },
        applyAllLevels: { ja: "連続適用（見出しのみ）", en: "Apply every Markdown heading level" }
    },
    option: {
        none: { ja: "（なし）", en: "(None)" }
    },
    button: {
        cancel: { ja: "キャンセル", en: "Cancel" },
        ok:     { ja: "OK", en: "OK" }
    },
    tooltip: {
        searchText: {
            ja: "削除したい目印の文字列を入力します。例：###\n同じ文字が続く並びの一部には一致しません。「##」は「###」に一致しません。\n目印に続くスペースやタブも一緒に削除します。\n「正規表現（GREP）で検索」がオンのときは、いずれも当てはまりません。",
            en: "Enter the marker text to delete, for example ###.\nIt never matches part of a longer run of the same character, so ## does not match ###.\nSpaces and tabs after the marker are deleted with it.\nNone of this applies while Search with GREP is on."
        },
        useGrep: {
            ja: "入力した文字列を GREP（正規表現）としてそのまま検索します。オフのときは記号も文字として扱い、同じ文字が続く並びの一部には一致しません。\n後読み（?<! …）や段落の区切り（\\r）を含むパターンは対象箇所を数えられないので「—」と表示します。\n「#*」「^」のように長さ0で一致した箇所は、段落スタイルだけが広がらないように読み飛ばします。",
            en: "Searches with the entered text as a GREP pattern. While it is off the symbols are matched literally and never match part of a longer run.\nA pattern with a lookbehind, (?<! …), or one touching the paragraph mark (\\r) cannot be counted, so the match count shows —.\nA zero-length match, from a pattern such as #* or ^, is skipped so that it cannot spread the paragraph style."
        },
        auto: {
            ja: "検索対象の行頭に繰り返し現れる記号（Markdown 記法を含む）を多い順に並べます。検索対象を変えると再判定します。非表示・ロックされたレイヤーのテキストは数えません。",
            en: "Lists the line-head markers that repeat in the search target, most frequent first. Changing the search target runs the detection again. Text on hidden or locked layers is not counted."
        },
        matchCount: {
            ja: "現在の設定で見つかる件数です。「自動判別」は段落数、「文字列を指定」は削除する箇所の数を表示します。非表示・ロックされたレイヤーのテキストは数えません。",
            en: "The number of matches for the current settings: paragraphs when a marker is detected automatically, markers to delete when the text is entered by hand. Text on hidden or locked layers is not counted."
        },
        paragraphStyle: { ja: "目印が見つかった段落に適用する段落スタイルです。", en: "The paragraph style applied to paragraphs that contain the marker." },
        characterStyle: { ja: "（なし）以外を選ぶと、その段落全体に文字スタイルを適用します。", en: "Anything other than (None) applies a character style to the whole paragraph." },
        scope: {
            allDocuments: {
                ja: "開いているドキュメントすべてが対象です。スタイルの一覧はアクティブドキュメントのものなので、同名のスタイルが無いドキュメントは飛ばします。",
                en: "Every open document is searched. The style lists come from the active document, so a document without a style of the same name is skipped."
            },
            document: {
                ja: "アクティブドキュメント全体が対象です。",
                en: "The whole active document is searched."
            },
            story: {
                ja: "テキストの選択、またはカーソルを置いたストーリーが対象です。未選択のまま実行すると対象が見つかりません。",
                en: "The story that holds the selection or the cursor is searched. Without one there is no search target."
            }
        },
        matchLevel:     { ja: "### を選ぶと h3／heading 3 の段落スタイルを自動で選びます。選び直しても構いません。", en: "Selecting ### picks the paragraph style named h3 / heading 3. You can still change it by hand." },
        applyAllLevels: { ja: "見出し # 〜 ###### の6レベルをまとめて処理し、各レベルに h1／heading 1 …… の段落スタイルを割り当てます。検索文字列と適用するスタイルの設定は使いません。対応するスタイルが無いレベルは飛ばします。", en: "Processes all six heading levels (# through ######) in one run, applying h1 / heading 1 and so on. The Find What and Styles panels are not used. Levels without a matching style are skipped." },
        cancel:         { ja: "何も変更せずに閉じます。", en: "Close without making any changes." },
        ok:             { ja: "目印を削除してスタイルを適用します。", en: "Delete the markers and apply the styles." }
    },
    scope: {
        allDocuments: { ja: "すべてのドキュメント", en: "All Documents" },
        document:     { ja: "ドキュメント", en: "Document" },
        story:        { ja: "ストーリー", en: "Story" }
    },
    error: {
        noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
        noTarget:   { ja: "検索対象が見つかりません。\nテキストを選択するか、カーソルを配置してください。", en: "No search target found.\nSelect text or place the cursor in a story." },
        searchFailed: {
            ja: "検索を実行できませんでした。検索文字列（GREP）を見直してください。",
            en: "The search could not be run. Check the search text (GREP)."
        }
    },
    result: {
        processed: { ja: "%1箇所の目印を削除しました。", en: "Deleted %1 marker(s)." },
        skipped:   { ja: "段落スタイルが見つからないため、次のドキュメントはスキップしました。", en: "Skipped these documents because the paragraph style was not found." },
        partial:   { ja: "文字スタイルが見つからないため、次のドキュメントは段落スタイルだけ適用しました。", en: "Applied only the paragraph style in these documents because the character style was not found." }
    },
    undo: {
        apply: { ja: "目印を削除してスタイルを適用", en: "Delete Markers and Apply Styles" }
    }
};

// =========================================
// 共通処理 / Helpers
// =========================================

/**
 * 名前でスタイルを探す（スタイルグループ内も対象）
 * @param {array} styleCollection allParagraphStyles / allCharacterStyles
 * @param {string} styleName 探すスタイル名
 * @returns {object} 見つかったスタイル。無い場合は null
 */
function findStyleByName(styleCollection, styleName) {
    for (var i = 0; i < styleCollection.length; i++) {
        if (styleCollection[i].name === styleName) return styleCollection[i];
    }

    return null;
}

/**
 * スタイル名の一覧を取得する
 * @param {array} styleCollection allParagraphStyles / allCharacterStyles
 * @param {boolean} includeNoneOption 先頭に「（なし）」を追加するかどうか
 * @returns {array} スタイル名の配列
 */
function getStyleNames(styleCollection, includeNoneOption) {
    var styleNames = includeNoneOption ? [getLabel("option.none")] : [];

    for (var i = 0; i < styleCollection.length; i++) {
        styleNames.push(styleCollection[i].name);
    }

    return styleNames;
}

/**
 * GREP 検索用に正規表現の特殊文字をエスケープする
 * @param {string} plainText エスケープする文字列
 * @returns {string} エスケープした文字列
 * @description エスケープの対象は GREP と JavaScript の正規表現で共通なので、件数の集計にも使う
 */
function escapeGrepText(plainText) {
    return plainText.replace(/([\\^$.|?*+()\[\]{}])/g, "\\$1");
}

/**
 * 末尾の区切り（半角／全角スペース・タブ）を落とす
 * @param {string} text 対象の文字列
 * @returns {string} 末尾の区切りを落とした文字列
 * @description 区切りは目印と一緒に一致範囲で拾うので、パターンに含めない
 */
function trimTrailingSeparators(text) {
    return text.replace(/[ \t　]+$/, "");
}

/**
 * 目印の直後に同じ記号が続くときは一致させない先読みを組み立てる
 * @param {string} markerText 目印の文字列
 * @returns {string} 先読みのパターン
 * @description これが無いと "#" が "## 見出し" の1文字目に一致してしまう
 */
function buildRunGuard(markerText) {
    return "(?!" + escapeGrepText(markerText.charAt(markerText.length - 1)) + ")";
}

/**
 * 行頭の目印を GREP パターンに組み立てる
 * @param {string} markerText 目印の文字列（区切りを含まない記号そのもの）
 * @returns {string} 行頭に固定した GREP パターン
 * @description 続く区切り（スペース・タブ）は一致範囲に含めて、目印と一緒に削除する
 */
function buildLineHeadGrep(markerText) {
    return "^" + escapeGrepText(markerText) + buildRunGuard(markerText) +
        TRAILING_SEPARATOR_PATTERN;
}

/**
 * 検索文字列にぴったり一致する GREP パターンを組み立てる
 * @param {string} searchText 検索文字列
 * @returns {string} GREP パターン
 * @description 前後を後読み・先読みで止めることで、同じ文字が続く並びの一部には一致させない。
 *              これが無いと "##" が "### 見出し" の先頭2文字に一致してしまう。
 *              続く区切り（スペース・タブ）は一致範囲に含めて、目印と一緒に削除する
 */
function buildExactGrep(searchText) {
    var markerText = trimTrailingSeparators(searchText);

    if (markerText === "") return escapeGrepText(searchText);

    return "(?<!" + escapeGrepText(markerText.charAt(0)) + ")" +
        escapeGrepText(markerText) + buildRunGuard(markerText) +
        TRAILING_SEPARATOR_PATTERN;
}

/**
 * 検索文字列から GREP パターンを組み立てる
 * @param {string} searchText 入力された検索文字列
 * @param {boolean} useGrep 入力をそのまま GREP として扱うかどうか
 * @returns {string} GREP パターン
 * @description GREP として扱うときはエスケープも前後の止めも付けず、入力をそのまま渡す
 */
function buildSearchGrep(searchText, useGrep) {
    return useGrep ? searchText : buildExactGrep(searchText);
}

/**
 * 同じ文字を繰り返した文字列を作る
 * @param {string} character 繰り返す文字
 * @param {number} repeatCount 繰り返す回数
 * @returns {string} 繰り返した文字列
 */
function repeatCharacter(character, repeatCount) {
    var repeatedText = "";

    for (var i = 0; i < repeatCount; i++) {
        repeatedText += character;
    }

    return repeatedText;
}

/**
 * 見出しマーカーからレベルを取り出す
 * @param {string} markerText 検索文字列
 * @returns {number} 見出しレベル（1〜6）。見出しマーカーでない場合は 0
 */
function getHeadingLevel(markerText) {
    if (!HEADING_MARKER_PATTERN.test(markerText)) return 0;

    return markerText.replace(/[^#]/g, "").length;
}

/**
 * 見出しレベルに対応する段落スタイル名の候補を作る
 * @param {number} headingLevel 見出しレベル（1〜6）
 * @returns {array} スタイル名の配列（先に見つかったものを使う順）
 */
function getHeadingStyleNames(headingLevel) {
    var headingStyleNames = [];

    for (var i = 0; i < HEADING_STYLE_NAME_FORMATS.length; i++) {
        headingStyleNames.push(fillLabelPlaceholders(HEADING_STYLE_NAME_FORMATS[i], [headingLevel]));
    }

    return headingStyleNames;
}

/**
 * 見出しレベルに対応する段落スタイルをドロップダウンから探す
 * @param {DropDownList} styleDropdown 段落スタイルのドロップダウン
 * @param {number} headingLevel 見出しレベル（1〜6）
 * @returns {number} 見つかった項目のインデックス。無い場合は -1
 */
function findHeadingStyleIndex(styleDropdown, headingLevel) {
    var headingStyleNames = getHeadingStyleNames(headingLevel);

    for (var i = 0; i < headingStyleNames.length; i++) {
        for (var j = 0; j < styleDropdown.items.length; j++) {
            if (styleDropdown.items[j].text === headingStyleNames[i]) return j;
        }
    }

    return -1;
}

/**
 * 見出しレベルに対応する段落スタイルを探す
 * @param {Document} targetDoc 対象ドキュメント
 * @param {number} headingLevel 見出しレベル（1〜6）
 * @returns {ParagraphStyle} 見つかった段落スタイル。無い場合は null
 */
function findHeadingStyle(targetDoc, headingLevel) {
    var headingStyleNames = getHeadingStyleNames(headingLevel);

    for (var i = 0; i < headingStyleNames.length; i++) {
        var headingStyle = findStyleByName(targetDoc.allParagraphStyles, headingStyleNames[i]);

        if (headingStyle) return headingStyle;
    }

    return null;
}

/**
 * ドキュメントから適用するスタイルを取得する
 * @param {Document} targetDoc 対象ドキュメント
 * @param {string} paragraphStyleName 段落スタイル名
 * @param {string} characterStyleName 文字スタイル名。適用しない場合は null
 * @param {number} headingLevel 見出しレベル（1〜6）。段落スタイル名を使う場合は 0
 * @returns {object} { paragraphStyle: ParagraphStyle, characterStyle: CharacterStyle,
 *                     missingCharacterStyle: string }。
 *                   段落スタイルが無い場合は { skip: true, missingParagraphStyle: string }。
 *                   missingParagraphStyle が null のときは報告せずに飛ばす
 */
function resolveStyles(targetDoc, paragraphStyleName, characterStyleName, headingLevel) {
    var paragraphStyle;

    if (headingLevel > 0) {
        /* その書類に無いレベルは報告せずに飛ばす / A level the document does not define is skipped quietly */
        paragraphStyle = findHeadingStyle(targetDoc, headingLevel);
        if (!paragraphStyle) return { skip: true, missingParagraphStyle: null };
    } else {
        paragraphStyle = findStyleByName(targetDoc.allParagraphStyles, paragraphStyleName);
        if (!paragraphStyle) return { skip: true, missingParagraphStyle: paragraphStyleName };
    }

    var characterStyle = null;
    var missingCharacterStyle = null;

    if (characterStyleName) {
        characterStyle = findStyleByName(targetDoc.allCharacterStyles, characterStyleName);

        /* 文字スタイルが無くても段落スタイルは適用する / Apply the paragraph style even without it */
        if (!characterStyle) missingCharacterStyle = characterStyleName;
    }

    return {
        paragraphStyle: paragraphStyle,
        characterStyle: characterStyle,
        missingCharacterStyle: missingCharacterStyle
    };
}

/**
 * 実行する検索の一覧を作る
 * @param {object} dialogSettings ダイアログの設定
 * @returns {array} { searchText: string, headingLevel: number } の配列
 */
function buildSearchPlans(dialogSettings) {
    if (!dialogSettings.applyAllLevels) {
        return [{ searchText: dialogSettings.searchText, headingLevel: 0 }];
    }

    var searchPlans = [];

    /* 先読みでレベルを確定し、後ろの区切り（半角／全角スペース・タブ）は続くだけまとめて拾う /
       A lookahead pins the level, and every separator after it is picked up */
    for (var headingLevel = MAX_HEADING_LEVEL; headingLevel >= 1; headingLevel--) {
        searchPlans.push({
            searchText: "^" + repeatCharacter("#", headingLevel) +
                "(?!#)" + TRAILING_SEPARATOR_PATTERN,
            headingLevel: headingLevel
        });
    }

    return searchPlans;
}

/**
 * 見つからなかったスタイルを書類ごとに重複なく記録する
 * @param {array} documentNotes 記録先の配列
 * @param {string} documentNote 「ドキュメント名: スタイル名」の文字列
 * @returns {void}
 */
function addDocumentNote(documentNotes, documentNote) {
    for (var i = 0; i < documentNotes.length; i++) {
        if (documentNotes[i] === documentNote) return;
    }

    documentNotes.push(documentNote);
}

/**
 * 判別した行頭記号の表示ラベル一覧を取得する
 * @param {array} detectedMarkers { markerText: string, labelKey: string, count: number } の配列
 * @returns {array} ドロップダウンに並べる文字列の配列
 */
function getDetectedMarkerLabels(detectedMarkers) {
    var markerLabels = [];

    for (var i = 0; i < detectedMarkers.length; i++) {
        var displayText = detectedMarkers[i].labelKey ?
            getLabel(detectedMarkers[i].labelKey) :
            detectedMarkers[i].markerText;

        markerLabels.push(getLabel("marker.detected",
            [displayText, detectedMarkers[i].count]));
    }

    return markerLabels;
}

/**
 * 行ラベルを追加する（幅を固定して右揃え）
 * @param {Group} parentGroup 追加先の行グループ
 * @param {string} labelKey ラベルキー
 * @returns {StaticText} 追加したラベル
 */
function addRowLabel(parentGroup, labelKey) {
    var rowLabel = parentGroup.add("statictext", undefined, labelText(labelKey));
    rowLabel.preferredSize.width = LABEL_WIDTH;
    rowLabel.justify = "right";
    return rowLabel;
}

/**
 * 選ばれているラジオボタンの位置を取得する
 * @param {array} radioButtons ラジオボタンの配列
 * @returns {number} 選ばれている位置。無い場合は 0
 */
function getSelectedRadioIndex(radioButtons) {
    for (var i = 0; i < radioButtons.length; i++) {
        if (radioButtons[i].value) return i;
    }

    return 0;
}

/**
 * 選択範囲の親ストーリーを取得する
 * @returns {Story} 選択（またはカーソル位置）のストーリー。取得できない場合は null
 */
function getSelectedStory() {
    if (app.selection.length === 0) return null;

    try {
        return app.selection[0].parentStory;
    } catch (e) {
        /* テキスト以外が選択されている / Selection is not text */
        return null;
    }
}

/**
 * スコープに応じた検索対象を取得する
 * @param {number} searchScope SCOPE_* のいずれか
 * @param {Document} activeDoc アクティブドキュメント
 * @returns {array} { doc: Document, searchRange: Document|Story } の配列
 */
function getSearchTargets(searchScope, activeDoc) {
    var searchTargets = [];

    if (searchScope === SCOPE_ALL_DOCUMENTS) {
        for (var i = 0; i < app.documents.length; i++) {
            searchTargets.push({ doc: app.documents[i], searchRange: app.documents[i] });
        }
        return searchTargets;
    }

    if (searchScope === SCOPE_DOCUMENT) {
        searchTargets.push({ doc: activeDoc, searchRange: activeDoc });
        return searchTargets;
    }

    /* ストーリーは選択（またはカーソル位置）が必要 / The story scope needs a text selection */
    var story = getSelectedStory();
    if (story) searchTargets.push({ doc: activeDoc, searchRange: story });

    return searchTargets;
}

/**
 * ストーリーが検索対象になるかを判定する
 * @param {Story} story 対象のストーリー
 * @returns {boolean} 検索対象なら true
 * @description 検索オプションに合わせ、非表示レイヤー・ロックされたレイヤーだけに
 *              置かれているストーリーは対象外にする。件数の判定を実際の検索とそろえるため。
 *              フレームを持たないストーリーは対象に含める
 */
function isSearchableStory(story) {
    var textContainers = story.textContainers;

    if (!textContainers || textContainers.length === 0) return true;

    for (var i = 0; i < textContainers.length; i++) {
        var itemLayer = textContainers[i].itemLayer;

        if ((FIND_INCLUDE_HIDDEN_LAYERS || itemLayer.visible) &&
            (FIND_INCLUDE_LOCKED_LAYERS || !itemLayer.locked)) return true;
    }

    return false;
}

/**
 * マスタースプレッド上のストーリーかどうかを判定する
 * @param {Story} story 対象のストーリー
 * @returns {boolean} マスタースプレッド上なら true
 */
function isMasterSpreadStory(story) {
    var textContainers = story.textContainers;

    if (!textContainers || textContainers.length === 0) return false;

    return isOnMasterSpread(textContainers[0]);
}

/**
 * マスタースプレッド上のオブジェクトかどうかを判定する
 * @param {object} pageItem 対象のページアイテム
 * @returns {boolean} マスタースプレッド上なら true
 * @description グループの中に置かれていることもあるので、親をたどって判定する
 */
function isOnMasterSpread(pageItem) {
    var ancestor = pageItem;

    while (ancestor && ancestor.parent) {
        ancestor = ancestor.parent;

        if (ancestor instanceof MasterSpread) return true;
        if (ancestor instanceof Spread || ancestor instanceof Document) return false;
    }

    return false;
}

/**
 * everyItem() の戻り値を配列に正規化する（要素が1件のときスカラーで返るため）
 * @param {*} everyItemValue everyItem() で取得した値
 * @returns {array} 正規化した配列
 */
function toArray(everyItemValue) {
    return (everyItemValue instanceof Array) ? everyItemValue : [everyItemValue];
}

/**
 * 検索範囲に含まれる段落の文字列を取得する
 * @param {object} searchRange 検索対象（Document / Story）
 * @returns {array} 段落の文字列の配列
 */
function getParagraphTexts(searchRange) {
    /* Story はそのまま段落を持つ。Document はストーリーごとにたどる /
       A Story exposes paragraphs directly, a Document is walked story by story */
    var isDocumentRange = (searchRange instanceof Document);
    var stories = isDocumentRange ?
        searchRange.stories.everyItem().getElements() : [searchRange];

    var paragraphTexts = [];

    for (var i = 0; i < stories.length; i++) {
        /* ドキュメント全体の検索は検索オプションに合わせてマスターページを除く。
           ストーリー指定でマスターページを選んだときは、そのまま数える /
           A document-wide search follows the find option; a story picked by hand is always counted */
        if (isDocumentRange && !FIND_INCLUDE_MASTER_PAGES &&
            isMasterSpreadStory(stories[i])) continue;

        if (!isSearchableStory(stories[i])) continue;

        paragraphTexts = paragraphTexts.concat(
            toArray(stories[i].paragraphs.everyItem().contents));
    }

    return paragraphTexts;
}

/**
 * 検索対象に含まれる段落の文字列をまとめて取得する
 * @param {array} searchTargets 検索対象の配列
 * @returns {array} 段落の文字列の配列
 */
function getParagraphTextsInTargets(searchTargets) {
    var paragraphTexts = [];

    for (var i = 0; i < searchTargets.length; i++) {
        paragraphTexts = paragraphTexts.concat(
            getParagraphTexts(searchTargets[i].searchRange));
    }

    return paragraphTexts;
}

/**
 * GREP パターンを ExtendScript の正規表現にする
 * @param {string} searchPattern GREP パターン
 * @returns {RegExp} 正規表現。評価できないパターンは null
 */
function toGrepRegExp(searchPattern) {
    try {
        return new RegExp(searchPattern, "g");
    } catch (e) {
        return null;
    }
}

/**
 * 段落の文字列を照合できる形にそろえる
 * @param {string} paragraphText 段落の文字列
 * @returns {string} 末尾の改行を外した文字列
 * @description 表を含む段落は contents が配列で返る。末尾の改行を外して "$" を段落の終わりに合わせる
 */
function toPlainParagraphText(paragraphText) {
    return String(paragraphText).replace(/[\r\n]+$/, "");
}

/**
 * 検索文字列に該当する箇所を数える
 * @param {array} paragraphTexts 段落の文字列の配列
 * @param {string} searchText 検索文字列
 * @param {boolean} useGrep 入力をそのまま GREP として扱うかどうか
 * @returns {number} 該当箇所の数。数えられないパターンは -1
 */
function countMatches(paragraphTexts, searchText, useGrep) {
    return useGrep ?
        countGrepMatches(paragraphTexts, searchText) :
        countMarkerMatches(paragraphTexts, searchText);
}

/**
 * 検索文字列（目印）に該当する箇所を数える
 * @param {array} paragraphTexts 段落の文字列の配列
 * @param {string} searchText 検索文字列
 * @returns {number} 該当箇所の数
 * @description モーダルダイアログの表示中は findGrep() を使えないので、段落の文字列を直接数える。
 *              ExtendScript の正規表現には後読みが無いため、直前の1文字だけ自分で見る。
 *              末尾の区切りは buildExactGrep() と同じく落として数える
 */
function countMarkerMatches(paragraphTexts, searchText) {
    var markerText = trimTrailingSeparators(searchText);

    if (markerText === "") return 0;

    var firstCharacter = markerText.charAt(0);
    var matchPattern = new RegExp(escapeGrepText(markerText) + buildRunGuard(markerText), "g");
    var matchCount = 0;

    for (var i = 0; i < paragraphTexts.length; i++) {
        var paragraphText = toPlainParagraphText(paragraphTexts[i]);
        var matchResult;

        matchPattern.lastIndex = 0;

        while ((matchResult = matchPattern.exec(paragraphText)) !== null) {
            /* 同じ文字が続く並びの一部は数えない / Skip a match inside a longer run */
            if (matchResult.index === 0 ||
                paragraphText.charAt(matchResult.index - 1) !== firstCharacter) {
                matchCount++;
            }
        }
    }

    return matchCount;
}

/**
 * GREP パターンに該当する箇所を数える
 * @param {array} paragraphTexts 段落の文字列の配列
 * @param {string} searchPattern GREP パターン
 * @returns {number} 該当箇所の数。ExtendScript で評価できないパターンは -1
 * @description ExtendScript の正規表現は後読みなどを解釈できないので、
 *              評価できないパターンは件数を出さずに -1 を返す
 */
function countGrepMatches(paragraphTexts, searchPattern) {
    if (searchPattern === "") return 0;

    /* 段落の区切りに触れるパターンは、段落ごとに数える方法では数えられない /
       A pattern touching the paragraph mark cannot be counted paragraph by paragraph */
    if (/\\[rn]|[\r\n]/.test(searchPattern)) return -1;

    var matchPattern = toGrepRegExp(searchPattern);
    if (!matchPattern) return -1;

    var matchCount = 0;

    for (var i = 0; i < paragraphTexts.length; i++) {
        var paragraphText = toPlainParagraphText(paragraphTexts[i]);
        var matchResult;

        matchPattern.lastIndex = 0;

        while ((matchResult = matchPattern.exec(paragraphText)) !== null) {
            matchCount++;

            /* 空文字列に一致したときは自力で進めないと止まらない / An empty match never advances on its own */
            if (matchResult.index === matchPattern.lastIndex) matchPattern.lastIndex++;
        }
    }

    return matchCount;
}

/**
 * 検索条件と検索オプションを初期化する
 * @returns {void}
 * @description 前回の「検索/置換」の設定を引き継がないよう、実行の前後でそろえ直す
 */
function resetFindPreferences() {
    app.findGrepPreferences = NothingEnum.nothing;
    app.changeGrepPreferences = NothingEnum.nothing;

    var findChangeOptions = app.findChangeGrepOptions;
    findChangeOptions.widthSensitive = FIND_WIDTH_SENSITIVE;
    findChangeOptions.kanaSensitive = FIND_KANA_SENSITIVE;
    findChangeOptions.includeFootnotes = FIND_INCLUDE_FOOTNOTES;
    findChangeOptions.includeMasterPages = FIND_INCLUDE_MASTER_PAGES;
    findChangeOptions.includeHiddenLayers = FIND_INCLUDE_HIDDEN_LAYERS;
    findChangeOptions.includeLockedLayersForFind = FIND_INCLUDE_LOCKED_LAYERS;
    findChangeOptions.includeLockedStoriesForFind = FIND_INCLUDE_LOCKED_STORIES;
}

/**
 * 段落の行頭にある目印を判定する
 * @param {string} paragraphText 段落の文字列
 * @returns {object} { key: string, markerText: string, searchText: string, labelKey: string }。
 *                   目印がない場合は null
 * @description 行頭記号の searchText は行頭（^）に固定した GREP。段落の途中にある同じ記号は拾わない。
 *              太字（**文字列**）だけは囲みなので、行頭に固定せず ** そのものを削除する
 */
function matchLineHeadMarker(paragraphText) {
    for (var i = 0; i < NUMBERED_LIST_PATTERNS.length; i++) {
        if (!NUMBERED_LIST_PATTERNS[i].regex.test(paragraphText)) continue;

        return {
            key: NUMBERED_LIST_PATTERNS[i].labelKey,
            markerText: "",
            searchText: NUMBERED_LIST_PATTERNS[i].pattern,
            labelKey: NUMBERED_LIST_PATTERNS[i].labelKey
        };
    }

    var matchResult = LINE_HEAD_MARKER_PATTERN.exec(paragraphText);

    /* 区切りを含まない記号そのものを目印にする（"## " と "##" を同じものとして数える） /
       The marker is the symbol run itself, so "## " and "##" count as one */
    if (matchResult && !EXCLUDED_LINE_HEAD_PATTERN.test(matchResult[1])) {
        var lineHeadMarker = matchResult[1];

        return {
            key: lineHeadMarker,
            markerText: lineHeadMarker,
            searchText: buildLineHeadGrep(lineHeadMarker),
            labelKey: null
        };
    }

    /* 太字は行頭に限らないので、行頭記号を拾えなかったときに判定する /
       Bold is not tied to the line head, so it is checked last */
    if (BOLD_PATTERN.test(paragraphText)) {
        return {
            key: "marker.bold",
            markerText: "",
            searchText: BOLD_SEARCH_TEXT,
            labelKey: "marker.bold"
        };
    }

    return null;
}

/**
 * 段落の文字列を調べ、行頭に繰り返し現れる記号を多い順に集める
 * @param {array} paragraphTexts 段落の文字列の配列
 * @returns {array} { markerText: string, searchText: string, labelKey: string, count: number }
 *                  の配列
 */
function detectLineHeadMarkers(paragraphTexts) {
    var markerEntries = {};

    for (var i = 0; i < paragraphTexts.length; i++) {
        var markerEntry = matchLineHeadMarker(paragraphTexts[i]);
        if (!markerEntry) continue;

        if (markerEntries[markerEntry.key]) {
            markerEntries[markerEntry.key].count++;
        } else {
            markerEntry.count = 1;
            markerEntries[markerEntry.key] = markerEntry;
        }
    }

    var detectedMarkers = [];

    for (var markerKey in markerEntries) {
        if (!markerEntries.hasOwnProperty(markerKey)) continue;
        if (markerEntries[markerKey].count < MIN_REPEAT_COUNT) continue;

        detectedMarkers.push(markerEntries[markerKey]);
    }

    /* 多い順、同数なら長い記号を先に（### を # より先に） / Most frequent first, longer marker wins a tie */
    detectedMarkers.sort(function (a, b) {
        if (b.count !== a.count) return b.count - a.count;
        return b.markerText.length - a.markerText.length;
    });

    return detectedMarkers;
}

/**
 * 検索範囲内の検索文字列にスタイルを適用して削除する
 * @param {object} searchRange 検索対象（Document / Story）
 * @param {ParagraphStyle} paragraphStyle 適用する段落スタイル
 * @param {CharacterStyle} characterStyle 適用する文字スタイル。適用しない場合は null
 * @returns {number} 処理した箇所数
 */
function applyStylesAndRemoveMarker(searchRange, paragraphStyle, characterStyle) {
    var foundTexts = searchRange.findGrep();
    var appliedCount = 0;

    /* 後ろから処理 / Process from the end */
    for (var i = foundTexts.length - 1; i >= 0; i--) {
        try {
            var foundText = foundTexts[i];

            /* 長さ0の一致は目印ではないので、段落スタイルを広げない /
               A zero-length match is not a marker, so the style must not spread */
            if (foundText.characters.length === 0) continue;

            /* 検索文字列を含む段落にスタイルを適用 / Apply the styles to the paragraph */
            var targetParagraph = foundText.paragraphs[0];
            targetParagraph.appliedParagraphStyle = paragraphStyle;

            if (characterStyle) {
                targetParagraph.appliedCharacterStyle = characterStyle;
            }

            /* 検索文字列を削除 / Delete the marker */
            foundText.remove();

            appliedCount++;
        } catch (e) {
            /* 処理できない箇所はスキップ / Skip locations that cannot be processed */
        }
    }

    return appliedCount;
}

/**
 * 検索文字列パネルを作る
 * @param {Window} dialog 追加先のダイアログ
 * @returns {object} { panel: Panel, modeRadios: array, searchTextField: EditText,
 *                     detectedMarkerDropdown: DropDownList, matchCountValue: StaticText }
 */
function addSearchPanel(dialog) {
    var searchPanel = dialog.add("panel", undefined, getLabel("panel.searchText"));
    setupPanel(searchPanel);

    var textModeRow = searchPanel.add("group");
    setupRow(textModeRow, "fill");
    var textModeRadio = textModeRow.add("radiobutton", undefined, getLabel("mode.text"));
    textModeRadio.preferredSize.width = LABEL_WIDTH;
    var searchTextField = textModeRow.add("edittext", undefined, DEFAULT_SEARCH_TEXT);
    searchTextField.characters = SEARCH_TEXT_LENGTH;
    searchTextField.alignment = ["fill", "center"];
    searchTextField.helpTip = getLabel("tooltip.searchText");
    textModeRadio.helpTip = getLabel("tooltip.searchText");

    var grepModeRow = searchPanel.add("group");
    setupRow(grepModeRow, "fill");
    /* 検索文字列の入力欄に合わせて字下げする / Indent to line up with the search field */
    grepModeRow.add("statictext", undefined, "").preferredSize.width = LABEL_WIDTH;
    var useGrepCheckbox = grepModeRow.add("checkbox", undefined, getLabel("field.useGrep"));
    useGrepCheckbox.value = DEFAULT_USE_GREP;
    useGrepCheckbox.helpTip = getLabel("tooltip.useGrep");

    var autoModeRow = searchPanel.add("group");
    setupRow(autoModeRow, "fill");
    var autoModeRadio = autoModeRow.add("radiobutton", undefined, getLabel("mode.auto"));
    autoModeRadio.preferredSize.width = LABEL_WIDTH;
    autoModeRadio.helpTip = getLabel("tooltip.auto");
    var detectedMarkerDropdown = autoModeRow.add("dropdownlist", undefined, []);
    detectedMarkerDropdown.alignment = ["fill", "center"];
    detectedMarkerDropdown.helpTip = getLabel("tooltip.auto");

    var matchCountRow = searchPanel.add("group");
    setupRow(matchCountRow, "fill");
    addRowLabel(matchCountRow, "field.matchCount").helpTip = getLabel("tooltip.matchCount");
    var matchCountValue = matchCountRow.add("statictext", undefined, "0");
    matchCountValue.preferredSize.width = COUNT_WIDTH;
    matchCountValue.helpTip = getLabel("tooltip.matchCount");

    return {
        panel: searchPanel,
        modeRadios: [textModeRadio, autoModeRadio],
        searchTextField: searchTextField,
        useGrepCheckbox: useGrepCheckbox,
        detectedMarkerDropdown: detectedMarkerDropdown,
        matchCountValue: matchCountValue
    };
}

/**
 * スタイルパネルを作る
 * @param {Window} dialog 追加先のダイアログ
 * @param {Document} activeDoc アクティブドキュメント
 * @returns {object} { panel: Panel, paragraphStyleDropdown: DropDownList,
 *                     characterStyleDropdown: DropDownList }
 */
function addStylePanel(dialog, activeDoc) {
    var stylePanel = dialog.add("panel", undefined, getLabel("panel.style"));
    setupPanel(stylePanel);

    var paragraphStyleRow = stylePanel.add("group");
    setupRow(paragraphStyleRow, "fill");
    addRowLabel(paragraphStyleRow, "field.paragraphStyle").helpTip =
        getLabel("tooltip.paragraphStyle");
    var paragraphStyleDropdown = paragraphStyleRow.add(
        "dropdownlist", undefined, getStyleNames(activeDoc.allParagraphStyles, false));
    paragraphStyleDropdown.selection = 0;
    paragraphStyleDropdown.alignment = ["fill", "center"];
    paragraphStyleDropdown.helpTip = getLabel("tooltip.paragraphStyle");

    var characterStyleRow = stylePanel.add("group");
    setupRow(characterStyleRow, "fill");
    addRowLabel(characterStyleRow, "field.characterStyle").helpTip =
        getLabel("tooltip.characterStyle");
    var characterStyleDropdown = characterStyleRow.add(
        "dropdownlist", undefined, getStyleNames(activeDoc.allCharacterStyles, true));
    characterStyleDropdown.selection = 0;
    characterStyleDropdown.alignment = ["fill", "center"];
    characterStyleDropdown.helpTip = getLabel("tooltip.characterStyle");

    return {
        panel: stylePanel,
        paragraphStyleDropdown: paragraphStyleDropdown,
        characterStyleDropdown: characterStyleDropdown
    };
}

/**
 * 検索対象パネルを作る（縦並びのラジオボタン）
 * @param {Window} dialog 追加先のダイアログ
 * @returns {array} SCOPE_* の並び順に対応するラジオボタンの配列
 */
function addScopePanel(dialog) {
    var scopePanel = dialog.add("panel", undefined, getLabel("panel.scope"));
    setupPanel(scopePanel, RADIO_SPACING);

    var scopeLabelKeys = ["scope.allDocuments", "scope.document", "scope.story"];
    var searchScopeRadios = [];

    for (var i = 0; i < scopeLabelKeys.length; i++) {
        var scopeRadio = scopePanel.add("radiobutton", undefined, getLabel(scopeLabelKeys[i]));
        scopeRadio.helpTip = getLabel("tooltip." + scopeLabelKeys[i]);
        searchScopeRadios.push(scopeRadio);
    }

    searchScopeRadios[DEFAULT_SCOPE].value = true;

    return searchScopeRadios;
}

/**
 * Markdown パネルを作る
 * @param {Window} dialog 追加先のダイアログ
 * @returns {object} { matchLevelCheckbox: Checkbox, applyAllLevelsCheckbox: Checkbox }
 */
function addMarkdownPanel(dialog) {
    var markdownPanel = dialog.add("panel", undefined, getLabel("panel.markdown"));
    setupPanel(markdownPanel);

    var matchLevelRow = markdownPanel.add("group");
    setupRow(matchLevelRow, "fill");
    var matchLevelCheckbox =
        matchLevelRow.add("checkbox", undefined, getLabel("field.matchLevel"));
    matchLevelCheckbox.value = DEFAULT_MATCH_LEVEL;
    matchLevelCheckbox.helpTip = getLabel("tooltip.matchLevel");

    var applyAllLevelsRow = markdownPanel.add("group");
    setupRow(applyAllLevelsRow, "fill");
    var applyAllLevelsCheckbox =
        applyAllLevelsRow.add("checkbox", undefined, getLabel("field.applyAllLevels"));
    applyAllLevelsCheckbox.value = DEFAULT_APPLY_ALL_LEVELS;
    applyAllLevelsCheckbox.helpTip = getLabel("tooltip.applyAllLevels");

    return {
        matchLevelCheckbox: matchLevelCheckbox,
        applyAllLevelsCheckbox: applyAllLevelsCheckbox
    };
}

/**
 * ダイアログを表示して設定を取得する
 * @param {Document} activeDoc アクティブドキュメント
 * @returns {object} { searchText: string, applyAllLevels: boolean,
 *                     paragraphStyleName: string, characterStyleName: string,
 *                     searchScope: number }。キャンセル時は null
 * @description 「自動判別」の候補と対象箇所は、検索対象を変えるたびに取り直す
 */
function showDialog(activeDoc) {
    var dialog = new Window("dialog", getLabel("dialog.title"));
    setupWindow(dialog);

    var searchControls = addSearchPanel(dialog);
    var styleControls = addStylePanel(dialog, activeDoc);
    var searchScopeRadios = addScopePanel(dialog);
    var markdownControls = addMarkdownPanel(dialog);

    /* ボタン行（キャンセル → OK）/ Button row (Cancel, then OK) */
    var buttonRow = addButtonRow(dialog);
    var btnCancel = buttonRow.rightGroup.add(
        "button", undefined, getLabel("button.cancel"), { name: "cancel" });
    var btnOK = buttonRow.rightGroup.add(
        "button", undefined, getLabel("button.ok"), { name: "ok" });
    btnCancel.preferredSize.width = BUTTON_WIDTH;
    btnOK.preferredSize.width = BUTTON_WIDTH;
    btnCancel.helpTip = getLabel("tooltip.cancel");
    btnOK.helpTip = getLabel("tooltip.ok");
    alignRightOnlyButtonRow(buttonRow);

    var searchModeRadios = searchControls.modeRadios;
    var searchTextField = searchControls.searchTextField;
    var useGrepCheckbox = searchControls.useGrepCheckbox;
    var detectedMarkerDropdown = searchControls.detectedMarkerDropdown;
    var matchCountValue = searchControls.matchCountValue;
    var paragraphStyleDropdown = styleControls.paragraphStyleDropdown;
    var characterStyleDropdown = styleControls.characterStyleDropdown;
    var matchLevelCheckbox = markdownControls.matchLevelCheckbox;
    var applyAllLevelsCheckbox = markdownControls.applyAllLevelsCheckbox;

    var detectedMarkers = [];
    var currentMatchCount = 0;
    var detectedMarkerCache = {};
    var paragraphTextCache = {};

    /**
     * 現在選ばれている指定方法を取得する
     * @returns {number} SEARCH_MODE_* のいずれか
     */
    function getSelectedSearchMode() {
        return getSelectedRadioIndex(searchModeRadios);
    }

    /**
     * 現在の検索対象に含まれる段落の文字列を取得する
     * @returns {array} 段落の文字列の配列
     * @description 同じ検索対象を選び直したときは走査し直さない。
     *              自動判別と対象箇所の集計で同じ結果を使い回す
     */
    function getCurrentParagraphTexts() {
        var searchScope = getSelectedRadioIndex(searchScopeRadios);

        if (!paragraphTextCache[searchScope]) {
            paragraphTextCache[searchScope] = getParagraphTextsInTargets(
                getSearchTargets(searchScope, activeDoc));
        }

        return paragraphTextCache[searchScope];
    }

    /**
     * 現在選ばれている目印の文字列を取得する（GREP に組み立てる前の記号そのまま）
     * @returns {string} 目印の文字列。取得できない場合は空文字列
     */
    function getCurrentMarkerText() {
        if (getSelectedSearchMode() !== SEARCH_MODE_AUTO) {
            /* GREP は目印そのものではないので、見出しマーカーとしては読まない /
               A GREP pattern is not the marker itself, so it is never read as a heading marker */
            return useGrepCheckbox.value ? "" : searchTextField.text;
        }

        return detectedMarkerDropdown.selection ?
            detectedMarkers[detectedMarkerDropdown.selection.index].markerText :
            "";
    }

    /**
     * 対象箇所の表示を更新する
     * @returns {void}
     * @description 自動判別は判別時に数えた段落数をそのまま出し、
     *              文字列を指定したときは入力のたびに数え直す
     */
    function updateMatchCount() {
        if (getSelectedSearchMode() === SEARCH_MODE_AUTO) {
            currentMatchCount = detectedMarkerDropdown.selection ?
                detectedMarkers[detectedMarkerDropdown.selection.index].count :
                0;
            matchCountValue.text = currentMatchCount + "";
            return;
        }

        currentMatchCount = countMatches(
            getCurrentParagraphTexts(), searchTextField.text, useGrepCheckbox.value);

        /* 数えられないパターンは件数を出さない / A pattern that cannot be evaluated shows no count */
        matchCountValue.text = (currentMatchCount < 0) ?
            getLabel("field.matchUnknown") :
            currentMatchCount + "";
    }

    /**
     * 見出しマーカーの選択に合わせて、Markdown パネルの状態を更新する
     * @returns {void}
     */
    function updateHeadingOptions() {
        var headingLevel = getHeadingLevel(getCurrentMarkerText());
        var isHeadingMarker = (headingLevel > 0);

        /* 見出しマーカー以外を選んでいる間は両方とも使えない。チェック状態は残す /
           Both options need a heading marker; the checked state is kept as it is */
        var applyAllLevels = isHeadingMarker && applyAllLevelsCheckbox.value;

        applyAllLevelsCheckbox.enabled = isHeadingMarker;

        /* 連続適用中は検索文字列もスタイルもレベルごとに決まるので、両パネルを使わない /
           While applying every level both panels are unused */
        searchControls.panel.enabled = !applyAllLevels;
        styleControls.panel.enabled = !applyAllLevels;
        matchLevelCheckbox.enabled = isHeadingMarker && !applyAllLevels;

        if (!matchLevelCheckbox.enabled || !matchLevelCheckbox.value) return;

        var styleIndex = findHeadingStyleIndex(paragraphStyleDropdown, headingLevel);
        if (styleIndex >= 0) paragraphStyleDropdown.selection = styleIndex;
    }

    /**
     * 目印の選び直しに合わせて、Markdown パネルと対象箇所を更新する
     * @returns {void}
     */
    function refreshMarkerSelection() {
        updateHeadingOptions();
        updateMatchCount();
    }

    /**
     * 「文字列を指定」の入力で実行できるかどうかを判定する
     * @returns {boolean} 実行できるなら true
     * @description 該当箇所が無いまま実行すると、区切りだけの検索文字列（スペースなど）が
     *              検索対象すべてのスペースを削除してしまうので、0件では実行させない
     */
    function canRunSearchText() {
        if (searchTextField.text === "") return false;

        /* GREP は InDesign 側の解釈のほうが広いので、数えられなくても実行させる /
           InDesign reads a GREP query more broadly than ExtendScript, so an uncountable pattern still runs */
        if (useGrepCheckbox.value) return true;

        return currentMatchCount > 0;
    }

    /**
     * 選ばれた指定方法に合わせて、ラジオボタンと入力欄の状態をそろえる
     * @param {number} searchMode SEARCH_MODE_* のいずれか
     * @returns {void}
     */
    function selectSearchMode(searchMode) {
        for (var i = 0; i < searchModeRadios.length; i++) {
            searchModeRadios[i].value = (i === searchMode);
        }

        searchTextField.enabled = (searchMode === SEARCH_MODE_TEXT);

        /* 自動判別の候補はもともと GREP なので、文字列を指定したときだけ使う /
           Detected markers are GREP already, so the option belongs to manual entry */
        useGrepCheckbox.enabled = (searchMode === SEARCH_MODE_TEXT);
        detectedMarkerDropdown.enabled =
            (searchMode === SEARCH_MODE_AUTO) && (detectedMarkers.length > 0);
        refreshMarkerSelection();

        /* 件数を数え直したあとに判定する / Decide once the count has been refreshed */
        btnOK.enabled = (searchMode === SEARCH_MODE_AUTO) ?
            (detectedMarkers.length > 0) :
            canRunSearchText();
    }

    /**
     * 検索対象を調べ直し、見つかった行頭記号をドロップダウンに展開する
     * @returns {void}
     */
    function refreshDetectedMarkers() {
        var searchScope = getSelectedRadioIndex(searchScopeRadios);

        /* 同じ検索対象を選び直したときは判別し直さない / Reuse the result for a scope already scanned */
        if (!detectedMarkerCache[searchScope]) {
            detectedMarkerCache[searchScope] =
                detectLineHeadMarkers(getCurrentParagraphTexts());
        }

        detectedMarkers = detectedMarkerCache[searchScope];

        var markerLabels = getDetectedMarkerLabels(detectedMarkers);

        detectedMarkerDropdown.removeAll();
        for (var i = 0; i < markerLabels.length; i++) {
            detectedMarkerDropdown.add("item", markerLabels[i]);
        }
        detectedMarkerDropdown.selection = (detectedMarkers.length > 0) ? 0 : null;

        searchModeRadios[SEARCH_MODE_AUTO].enabled = (detectedMarkers.length > 0);

        /* 候補が無くなったら文字列指定に戻す / Fall back to manual entry when nothing was detected */
        var searchMode = getSelectedSearchMode();
        if (detectedMarkers.length === 0 && searchMode === SEARCH_MODE_AUTO) {
            searchMode = SEARCH_MODE_TEXT;
        }
        selectSearchMode(searchMode);
    }

    searchModeRadios[SEARCH_MODE_TEXT].onClick = function () {
        selectSearchMode(SEARCH_MODE_TEXT);
    };
    searchModeRadios[SEARCH_MODE_AUTO].onClick = function () {
        selectSearchMode(SEARCH_MODE_AUTO);
    };
    searchTextField.onChanging = function () { selectSearchMode(getSelectedSearchMode()); };
    useGrepCheckbox.onClick = function () { selectSearchMode(getSelectedSearchMode()); };
    detectedMarkerDropdown.onChange = refreshMarkerSelection;
    matchLevelCheckbox.onClick = updateHeadingOptions;
    applyAllLevelsCheckbox.onClick = updateHeadingOptions;

    for (var i = 0; i < searchScopeRadios.length; i++) {
        searchScopeRadios[i].onClick = refreshDetectedMarkers;
    }

    selectSearchMode(DEFAULT_SEARCH_MODE);
    refreshDetectedMarkers();

    addVersionFooter(dialog);
    if (dialog.show() !== 1) return null;

    var selectedMarker = (getSelectedSearchMode() === SEARCH_MODE_AUTO) ?
        detectedMarkers[detectedMarkerDropdown.selection.index] :
        { searchText: buildSearchGrep(searchTextField.text, useGrepCheckbox.value) };

    var applyAllLevels = applyAllLevelsCheckbox.enabled && applyAllLevelsCheckbox.value;

    /* ディム表示にしたパネルの設定は使わない / Settings in the dimmed panels are not used */
    var characterStyleName = (applyAllLevels || characterStyleDropdown.selection.index === 0) ?
        null :
        characterStyleDropdown.selection.text;

    return {
        searchText: selectedMarker.searchText,
        applyAllLevels: applyAllLevels,
        paragraphStyleName: paragraphStyleDropdown.selection.text,
        characterStyleName: characterStyleName,
        searchScope: getSelectedRadioIndex(searchScopeRadios)
    };
}

// =========================================
// 実行 / Run
// =========================================

/**
 * ひとつの検索を検索対象ぶん実行する
 * @param {object} searchPlan { searchText: string, headingLevel: number }
 * @param {array} searchTargets 検索対象の配列
 * @param {object} dialogSettings ダイアログの設定
 * @param {object} runResult 結果の記録先
 * @returns {void}
 */
function runSearchPlan(searchPlan, searchTargets, dialogSettings, runResult) {
    /* 検索条件を初期化 / Reset the find preferences */
    resetFindPreferences();
    app.findGrepPreferences.findWhat = searchPlan.searchText;

    for (var i = 0; i < searchTargets.length; i++) {
        var targetDoc = searchTargets[i].doc;
        var resolvedStyles = resolveStyles(
            targetDoc,
            dialogSettings.paragraphStyleName,
            dialogSettings.characterStyleName,
            searchPlan.headingLevel);

        /* 段落スタイルを持たないドキュメントはスキップ / Skip documents without the paragraph style */
        if (resolvedStyles.skip) {
            if (resolvedStyles.missingParagraphStyle) {
                addDocumentNote(runResult.skippedDocumentNotes,
                    targetDoc.name + ": " + resolvedStyles.missingParagraphStyle);
            }
            continue;
        }

        if (resolvedStyles.missingCharacterStyle) {
            addDocumentNote(runResult.partialDocumentNotes,
                targetDoc.name + ": " + resolvedStyles.missingCharacterStyle);
        }

        runResult.processedCount += applyStylesAndRemoveMarker(
            searchTargets[i].searchRange,
            resolvedStyles.paragraphStyle,
            resolvedStyles.characterStyle);
    }
}

/**
 * 検索の一覧を順に実行する
 * @param {array} searchPlans 検索の一覧
 * @param {array} searchTargets 検索対象の配列
 * @param {object} dialogSettings ダイアログの設定
 * @param {object} runResult 結果の記録先
 * @returns {void}
 * @description 途中で落ちても結果を残せるように、記録先は呼び出し側で用意する
 */
function runSearchPlans(searchPlans, searchTargets, dialogSettings, runResult) {
    for (var i = 0; i < searchPlans.length; i++) {
        runSearchPlan(searchPlans[i], searchTargets, dialogSettings, runResult);
    }
}

/**
 * 完了メッセージを組み立てる
 * @param {object} runResult 実行結果
 * @returns {string} 表示するメッセージ
 */
function buildResultMessage(runResult) {
    var resultMessage = getLabel("result.processed", [runResult.processedCount]);

    if (runResult.partialDocumentNotes.length > 0) {
        resultMessage += "\n\n" + getLabel("result.partial") +
            "\n" + runResult.partialDocumentNotes.join("\n");
    }

    if (runResult.skippedDocumentNotes.length > 0) {
        resultMessage += "\n\n" + getLabel("result.skipped") +
            "\n" + runResult.skippedDocumentNotes.join("\n");
    }

    return resultMessage;
}

// =========================================
// メイン処理 / Main
// =========================================

(function () {
    if (app.documents.length === 0) {
        alert(getLabel("error.noDocument"));
        return;
    }

    var activeDoc = app.activeDocument;

    var dialogSettings = showDialog(activeDoc);
    if (!dialogSettings) return;

    var searchTargets = getSearchTargets(dialogSettings.searchScope, activeDoc);
    if (searchTargets.length === 0) {
        alert(getLabel("error.noTarget"));
        return;
    }

    var searchPlans = buildSearchPlans(dialogSettings);
    var runResult = {
        processedCount: 0,
        skippedDocumentNotes: [],
        partialDocumentNotes: []
    };
    var runError = null;

    /* 一括で取り消せるように doScript でまとめて実行 / Run through doScript so the whole run is a single undo step */
    try {
        app.doScript(function () {
            runSearchPlans(searchPlans, searchTargets, dialogSettings, runResult);
        }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, getLabel("undo.apply"));
    } catch (e) {
        /* GREP の書き方に無理があると findGrep() で落ちる / An impossible GREP query throws in findGrep() */
        runError = e;
    }

    /* 途中で落ちても検索条件は残さない / The find preferences are cleared even after a failure */
    resetFindPreferences();

    if (runError) {
        /* 途中まで処理していたら、その結果も添える / A partial run is reported together with the error */
        alert(getLabel("error.searchFailed") +
            (runError.message ? "\n\n" + runError.message : "") +
            (runResult.processedCount > 0 ? "\n\n" + buildResultMessage(runResult) : ""));
        return;
    }

    alert(buildResultMessage(runResult));
})();
