#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdJapaneseParagraphTypesettingManager
Name=日本語組版設定をマトリックスで一括適用
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.3.5
Release-Date=2026-05-05
Description-BEGIN
段落スタイルの日本語組版設定（禁則処理セット・禁則調整方式・文字組みアキ量・コンポーザー）をマトリックス UI で確認・一括適用します。

Reviews and batch-applies the Japanese composition settings of paragraph styles (kinsoku set, kinsoku adjustment, mojikumi and composer) through a matrix UI.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

段落スタイルの日本語組版設定（禁則処理セット・禁則調整方式・文字組みアキ量・コンポーザー）をマトリックス UI で確認・一括適用します。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdJapaneseParagraphTypesettingManager.md

### Overview

Reviews and batch-applies the Japanese composition settings of paragraph styles (kinsoku set, kinsoku adjustment, mojikumi and composer) through a matrix UI.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdJapaneseParagraphTypesettingManager.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdJapaneseParagraphTypesettingManager"; /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.3.5";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";          /* 作者 / author */
var SCRIPT_RELEASED = "2026-05-05";                           /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                           /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "日本語組版設定をマトリックスで一括適用"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdJapaneseParagraphTypesettingManager.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdJapaneseParagraphTypesettingManager.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/style/IdJapaneseParagraphTypesettingManager.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

// ==============================
// UIレイアウトの共通設定 / Shared UI layout
// ==============================

// UIレイアウト（再利用パーツ） / UI layout (reusable)

/* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

/**
 * ウィンドウの共通設定
 * @param {Window} targetWindow - 対象のウィンドウ
 * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
 * @returns {void}
 */
function setupWindow(targetWindow, spacing) {
    targetWindow.orientation = "column";
    targetWindow.alignChildren = "fill";
    targetWindow.margins = WINDOW_MARGINS;
    targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
}

/**
 * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
 * @param {Panel} targetPanel - 対象のパネル
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupPanel(targetPanel, spacing) {
    targetPanel.orientation = "column";
    targetPanel.alignChildren = ["fill", "top"];
    targetPanel.alignment = "fill";
    targetPanel.margins = PANEL_MARGINS;
    targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * タブの共通設定
 * @param {Tab} targetTab - 対象のタブ
 * @param {number} [spacing] - 要素間隔（省略時は変えない）
 * @returns {void}
 */
function setupTab(targetTab, spacing) {
    targetTab.orientation = "column";
    targetTab.alignChildren = "fill";
    targetTab.margins = TAB_MARGINS;
    if (typeof spacing === "number") targetTab.spacing = spacing;
}

/**
 * 横並びの行グループの共通設定（ボタン列など）。
 * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
 * @param {Group} rowGroup - 対象のグループ
 * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupRow(rowGroup, rowAlignment, spacing) {
    rowGroup.orientation = "row";
    rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
    rowGroup.alignChildren = ["left", "center"];
    rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
 * @param {Button} targetButton - 対象のボタン
 * @param {number} trimPixels - 詰める量（px）
 * @returns {void}
 */
function trimButtonHeight(targetButton, trimPixels) {
    /* レイアウト前は size が無い / size is not set until the layout runs */
    if (!targetButton.size) return;
    targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
}

// UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

// =========================================
// ユーザー設定 / User settings
// =========================================

/* 既定で選択する設定名 / Values preselected on launch */
var DEFAULT_KINSOKU_SET_NAME  = "弱い禁則";
var DEFAULT_KINSOKU_TYPE_NAME = "調整量を優先";
var DEFAULT_MOJIKUMI_NAME     = "行末約物半角";
var DEFAULT_COMPOSER_NAME     = "日本語単数行コンポーザー";

/* 対象から除外する段落スタイルグループの接頭辞 / Prefix marking style groups to skip */
var EXCLUDED_STYLE_GROUP_PREFIX = "_";

// =========================================
// レイアウト設定 / Layout settings
// =========================================

/* マトリックス UI の列幅（px）/ Column widths of the matrix UI (px) */
var COLUMN_WIDTH_NAME      = 160;  /* 段落スタイル名 / paragraph style name */
var COLUMN_WIDTH_DROPDOWN  = 120;  /* 禁則処理セット・禁則調整方式 / kinsoku set and adjustment */
var COLUMN_WIDTH_DROPDOWN_WIDE = 200; /* 文字組み・コンポーザー / mojikumi and composer */

/* マトリックス各行の要素間隔（px）/ Spacing between controls in a matrix row (px) */
var MATRIX_ROW_SPACING = 8;

// =========================================
// ラベル定義 / Labels
// =========================================

// ローカライズ（再利用パーツ） / Localization (reusable)

/**
 * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
 * @returns {string} "ja" または "en"
 */
function getCurrentLang() {
    return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
}

var uiLang = getCurrentLang();

/**
 * LABELS から今の UI 言語の文言を取り出す。
 * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
 * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
 * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
 */
function getLabel(labelRef, placeholderValues) {
    var labelEntry = labelRef;
    if (typeof labelRef === "string") {
        var labelPathKeys = labelRef.split(".");
        labelEntry = LABELS;
        for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
            labelEntry = labelEntry[labelPathKeys[i]];
        }
    }
    var labelString;
    if (typeof labelEntry === "string") labelString = labelEntry;
    else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
    else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
    else return (typeof labelRef === "string") ? labelRef : "";
    return fillLabelPlaceholders(String(labelString), placeholderValues);
}

/**
 * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {Object|Array} [placeholderValues] - getLabel と同じ
 * @returns {string} コロン付きの文言
 */
function labelText(labelRef, placeholderValues) {
    return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
}

/**
 * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {string|number} value - コロンのあとに続ける値
 * @returns {string} 項目名と値をつないだ文字列
 */
function labelValueText(labelRef, value) {
    return labelText(labelRef) + " " + value;
}

/**
 * 文言の {name} や %1 に値を差し込む
 * @param {string} labelString - 文言
 * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
 * @returns {string} 差し込んだ文言
 */
function fillLabelPlaceholders(labelString, placeholderValues) {
    if (placeholderValues == null) return labelString;
    if (placeholderValues instanceof Array) {
        /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
        for (var i = placeholderValues.length; i >= 1; i--) {
            labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
        }
        return labelString;
    }
    for (var placeholderKey in placeholderValues) {
        if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
        labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
    }
    return labelString;
}

// ローカライズ（再利用パーツ）ここまで / End of the reusable localization

// ボタン行（再利用パーツ） / Button row (reusable)

var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

/**
 * ダイアログ下部のボタン行を作る。
 * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
 * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
 * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
 * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
 */
function addButtonRow(parent, rowOptions) {
    var isCentered = !!(rowOptions && rowOptions.centered);
    var btnRowGroup = parent.add("group");
    btnRowGroup.orientation = "row";
    btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
    btnRowGroup.spacing = BUTTON_ROW_SPACING;

    if (isCentered) {
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
    }

    btnRowGroup.alignment = ["fill", "bottom"];

    var btnLeftGroup = btnRowGroup.add("group");
    btnLeftGroup.alignChildren = ["left", "center"];
    btnLeftGroup.spacing = BUTTON_ROW_SPACING;

    /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
    var spacer = btnRowGroup.add("group");
    spacer.alignment = ["fill", "fill"];
    spacer.minimumSize.width = 0;

    var btnRightGroup = btnRowGroup.add("group");
    btnRightGroup.alignChildren = ["right", "center"];
    btnRightGroup.spacing = BUTTON_ROW_SPACING;

    return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
}

/**
 * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
 * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
 * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
 * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
 * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
 * @returns {void}
 */
function alignRightOnlyButtonRow(buttonRow) {
    if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
    var dialogWindow = buttonRow.rowGroup.window;
    dialogWindow.addEventListener("show", function () {
        if (!buttonRow.leftGroup) return;
        var btnRowGroup = buttonRow.rowGroup;
        /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
        if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
        /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
        btnRowGroup.remove(buttonRow.leftGroup);
        btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        buttonRow.leftGroup = null;
        dialogWindow.layout.layout(true);
    });
}

// ボタン行（再利用パーツ）ここまで / End of the reusable button row

// UI の明暗（再利用パーツ） / UI theme (reusable)

/**
 * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
 * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
 */
function isDarkUI() {
    try {
        if (app.preferences && app.preferences.getRealPreference) {
            return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
        }
        return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
    } catch (e) {
        return false;
    }
}

// UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

// バージョン表示（再利用パーツ） / Version footer (reusable)

var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

/* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
   9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
   / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
     nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
var VERSION_FOOTER_GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
    "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
    "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
    "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
    "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
    "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
    "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
    "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
    "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
    "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
    "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
    "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
    "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
    "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
    "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
    "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
    "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
    "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
    "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
    "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
    "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
    "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
    "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
    "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
    "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
    "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
    "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
    "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
    "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
    "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
    "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
    "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
    "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
    "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
    "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
    "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
    "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
    "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
    ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
    "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
    "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
    "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
    " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
};

/**
 * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
 * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
 * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
 * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
 * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
 */
function addVersionFooter(targetWindow) {
    if (targetWindow.versionFooter) return null;

    /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
    var lastChild = targetWindow.children[targetWindow.children.length - 1];
    if (lastChild && lastChild.type === "group") {
        var rowMargins = lastChild.margins;
        lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
    }
    var windowMargins = targetWindow.margins;
    targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

    var footerGroup = targetWindow.add("group");
    footerGroup.orientation = "row";
    footerGroup.alignment = ["fill", "bottom"];
    footerGroup.alignChildren = ["left", "center"];
    footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

    /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
       左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
       / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
         or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
    var versionText = String(SCRIPT_VERSION);
    var leftCandidates = [versionText];
    if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
    var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
    versionCanvas.alignment = ["fill", "center"];
    bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
    var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
    brandCanvas.alignment = ["right", "center"];
    brandCanvas.maximumSize = brandCanvas.preferredSize;
    targetWindow.versionFooter = footerGroup;
    return versionCanvas;
}

/**
 * 文字列のすべての文字に字形があるかを返す
 * @param {string} dotText - 文字列
 * @returns {boolean} すべてあれば true
 */
function hasVersionFooterGlyphs(dotText) {
    for (var i = 0; i < dotText.length; i++) {
        if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
    }
    return dotText.length > 0;
}

/**
 * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
 * @param {Group} parentGroup - 足す先
 * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
 * @returns {Group} 描くグループ
 */
function addVersionFooterCanvas(parentGroup, dotTexts) {
    var dotCanvas = parentGroup.add("group");
    var shortestText = dotTexts[dotTexts.length - 1];
    dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
    dotCanvas.helpTip = dotTexts[0];
    dotCanvas.onDraw = function () {
        var availableWidth = this.size ? this.size.width : 0;
        var drawText = shortestText;
        for (var i = 0; i < dotTexts.length; i++) {
            if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                drawText = dotTexts[i];
                break;
            }
        }
        drawVersionFooterDots(this.graphics, drawText);
    };
    return dotCanvas;
}

/**
 * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
 * @param {string} versionText - 文字列
 * @returns {number} 幅（ドット）
 */
function measureVersionFooterDots(versionText) {
    var dotCount = 0;
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
        dotCount += glyphRows[0].length;
    }
    return dotCount;
}

/**
 * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
 * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
 * @param {string} versionText - 文字列
 * @returns {void}
 */
function drawVersionFooterDots(canvasGraphics, versionText) {
    var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
    var dotSize = VERSION_FOOTER_PIXEL_SIZE;
    var cursorDots = 0;
    canvasGraphics.newPath();
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
        for (var row = 0; row < glyphRows.length; row++) {
            var rowText = glyphRows[row];
            var runStart = -1;
            for (var col = 0; col <= rowText.length; col++) {
                var isDot = col < rowText.length && rowText.charAt(col) === "#";
                if (isDot && runStart < 0) runStart = col;
                if (!isDot && runStart >= 0) {
                    canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                    runStart = -1;
                }
            }
        }
        cursorDots += glyphRows[0].length;
    }
    canvasGraphics.fillPath(footerBrush);
}

// -----------------------------------------
// このスクリプトについて / About this script
// -----------------------------------------
/* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
   この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
   Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
   and keeps its own labels and layout values so the part works on its own */

var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
/* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
   The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
/* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

var VERSION_INFO_LABELS = {
    dialog: {
        title: { ja: "このスクリプトについて", en: "About This Script" }
    },
    panel: {
        generalInfo: { ja: "基本情報", en: "General" },
        links: { ja: "リンク", en: "Links" }
    },
    fieldLabel: {
        scriptName: { ja: "スクリプト名", en: "Script Name" },
        scriptFeature: { ja: "機能", en: "Feature" },
        scriptVersion: { ja: "バージョン", en: "Version" }
    },
    button: {
        openReadme: { ja: "README", en: "README" },
        openSourceCode: { ja: "ソースコード", en: "Source Code" },
        openArticle: { ja: "記事（note）", en: "Article (note)" },
        revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
        revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
        close: { ja: "閉じる", en: "Close" }
    },
    tooltip: {
        versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
        copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
    },
    alert: {
        copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
    }
};

/**
 * VERSION_INFO_LABELS の文言を今の言語で返す
 * @param {Object} labelEntry - { ja, en }
 * @returns {string} 文言
 */
function getVersionInfoLabel(labelEntry) {
    return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
}

/**
 * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
 * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
 * @returns {string} 値
 */
function getVersionInfoValue(variableKey) {
    var infoValue;
    if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
    else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
    else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
    else if (variableKey === "readme") {
        if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
        else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
    }
    else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
    else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
    return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
}

/**
 * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
 * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
 * @returns {void}
 */
function bindVersionInfoClick(versionCanvas) {
    versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
    /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
       Open on mouseup so the release does not land on the footer after the dialog closes */
    versionCanvas.addEventListener("mouseup", function () {
        showVersionInfoDialog(versionCanvas.window.type === "palette");
    });
}

/**
 * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
 * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
 * @returns {void}
 */
function showVersionInfoDialog(isFromPalette) {
    var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
    infoDialog.orientation = "column";
    infoDialog.alignChildren = "fill";
    infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
    infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

    var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
    /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
    /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
    if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
    }
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
    alignVersionInfoLabels(infoPanel);

    /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
    var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
    var linkButtonRow = linksPanel.add("group");
    linkButtonRow.orientation = "row";
    linkButtonRow.alignment = ["left", "center"];
    linkButtonRow.alignChildren = ["left", "center"];
    linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

    /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
    var buttonRow = infoDialog.add("group");
    buttonRow.orientation = "row";
    buttonRow.alignment = ["fill", "bottom"];
    buttonRow.alignChildren = ["left", "center"];
    buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
    buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
    var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
    if (VERSION_INFO_SCRIPT_FILE.exists) {
        revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
        revealButton.onClick = function () {
            revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
            infoDialog.close();
        };
    } else {
        revealButton.enabled = false;
    }
    /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
    var buttonSpacer = buttonRow.add("group");
    buttonSpacer.alignment = ["fill", "fill"];
    buttonSpacer.minimumSize.width = 0;
    var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
    closeButton.alignment = ["right", "center"];
    /* return でも esc でも閉じる / Close with both Return and Esc */
    infoDialog.defaultElement = closeButton;
    infoDialog.cancelElement = closeButton;
    infoDialog.onShow = function () {
        pinVersionInfoCopyButton(infoPanel);
    };
    infoDialog.show();
}

/**
 * 「このスクリプトについて」のダイアログにパネルを足す
 * @param {Window} infoDialog - 足す先のダイアログ
 * @param {Object} titleEntry - パネル名の文言 { ja, en }
 * @returns {Panel} パネル
 */
function addVersionInfoPanel(infoDialog, titleEntry) {
    var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
    infoPanel.orientation = "column";
    infoPanel.alignChildren = ["fill", "top"];
    infoPanel.alignment = "fill";
    infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
    infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
    return infoPanel;
}

/**
 * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
 * @param {Panel} infoPanel - 足す先のパネル
 * @param {Object} labelEntry - 項目名の文言 { ja, en }
 * @param {string} valueText - 表示する値
 * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
 * @returns {StaticText} 値の statictext
 */
function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
    var infoRow = infoPanel.add("group");
    infoRow.orientation = "row";
    infoRow.alignment = ["fill", "center"];
    infoRow.alignChildren = ["left", "center"];
    infoRow.spacing = VERSION_INFO_ROW_SPACING;
    /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
    var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
    rowLabel.justify = "right";
    var valueLabel = infoRow.add("statictext", undefined, valueText);
    if (copyFromPalette === null) return valueLabel;
    /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
       A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
    var copySpacer = infoRow.add("group");
    copySpacer.alignment = ["fill", "fill"];
    copySpacer.minimumSize.width = 0;
    infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
    return valueLabel;
}

/**
 * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
 * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
 * @param {Panel} infoPanel - ［基本情報］パネル
 * @returns {void}
 */
function pinVersionInfoCopyButton(infoPanel) {
    var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
    for (var i = 0; i < infoPanel.children.length; i++) {
        var infoRow = infoPanel.children[i];
        if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
        infoRow.size = [innerWidth, infoRow.size.height];
        infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
    }
}

/**
 * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
 * @param {Panel} infoPanel - 対象のパネル
 * @returns {void}
 */
function alignVersionInfoLabels(infoPanel) {
    var rowLabels = [];
    var labelWidth = 0;
    for (var i = 0; i < infoPanel.children.length; i++) {
        var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
        rowLabels.push(rowLabel);
        labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
    }
    for (var j = 0; j < rowLabels.length; j++) {
        rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
    }
}

/**
 * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
 * @param {Window} infoDialog - ボタンを置くダイアログ
 * @param {Group} buttonGroup - 足す先のグループ
 * @param {Object} labelEntry - ボタンの文言 { ja, en }
 * @param {string} targetUrl - 開く URL（空ならディム表示）
 * @returns {void}
 */
function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
    var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
    if (!targetUrl) {
        linkButton.enabled = false;
        return;
    }
    linkButton.helpTip = targetUrl;
    linkButton.onClick = function () {
        openVersionInfoUrl(targetUrl);
        infoDialog.close();
    };
}

/**
 * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
 * @param {Group} infoRow - 足す先の行
 * @param {StaticText} valueLabel - コピーする値の statictext
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {Group} ボタンとして使う group
 */
function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
    var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
    var copyButton = infoRow.add("group");
    copyButton.preferredSize = [buttonSize, buttonSize];
    copyButton.minimumSize = [buttonSize, buttonSize];
    copyButton.maximumSize = [buttonSize, buttonSize];
    copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
    copyButton.isPressed = false;
    copyButton.isCopied = false;

    copyButton.onDraw = function () {
        var buttonGraphics = copyButton.graphics;
        var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
        buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
        if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
        else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
    };

    /**
     * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
     * @param {boolean} isPressed - 押下中なら true
     * @param {boolean} isCopied - コピー済みなら true
     * @returns {void}
     */
    function repaint(isPressed, isCopied) {
        if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
        copyButton.isPressed = isPressed;
        copyButton.isCopied = isCopied;
        copyButton.hide();
        copyButton.show();
    }
    copyButton.addEventListener("mousedown", function () { repaint(true, false); });
    copyButton.addEventListener("mouseup", function () {
        if (!copyButton.isPressed) return;
        var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
        repaint(false, hasCopied);
        if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
    });
    /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
    copyButton.addEventListener("mouseout", function () { repaint(false, false); });
    return copyButton;
}

/**
 * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
    var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
    var sheetSize = 9;
    var offset = 3;
    var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var backLeft = frontLeft - offset;
    var backTop = frontTop - offset;
    /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
    buttonGraphics.newPath();
    buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
    buttonGraphics.strokePath(iconPen);
    buttonGraphics.newPath();
    buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
    buttonGraphics.strokePath(iconPen);
}

/**
 * コピーしたあとのチェックマークを描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
    var center = buttonSize / 2;
    buttonGraphics.newPath();
    buttonGraphics.moveTo(center - 4.5, center);
    buttonGraphics.lineTo(center - 1.5, center + 3);
    buttonGraphics.lineTo(center + 4.5, center - 3.5);
    buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
}

/**
 * 文字列をクリップボードにコピーする。
 * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
 * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
 * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
 * @param {string} copyText - コピーする文字列
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {boolean} コピーの操作まで進めたら true
 */
function copyVersionInfoText(copyText, isFromPalette) {
    try {
        if (VERSION_INFO_IS_INDESIGN) {
            if (File.fs === "Windows") {
                app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
            } else {
                app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
            }
            return true;
        }
        var copyScript = buildVersionInfoCopyScript(copyText);
        if (!isFromPalette) return eval(copyScript) === true;
        var copyMessage = new BridgeTalk();
        copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
        copyMessage.body = copyScript;
        copyMessage.send();
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
 * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
 * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
 * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
 * @param {string} copyText - コピーする文字列
 * @returns {string} 実行すると true / false を返すスクリプト
 */
function buildVersionInfoCopyScript(copyText) {
    return [
        "(function (copyText) {",
        "    var usingTempDoc = (app.documents.length === 0);",
        "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
        "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
        "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
        "    var tempLayer = null;",
        "    var hasCopied = false;",
        "    try {",
        "        tempLayer = targetDoc.layers.add();",
        "        var tempFrame = tempLayer.textFrames.add();",
        "        tempFrame.contents = copyText;",
        "        app.redraw();",
        "        app.executeMenuCommand('deselectall');",
        "        tempFrame.selected = true;",
        "        app.redraw();",
        "        app.executeMenuCommand('copy');",
        "        app.redraw();",
        "        hasCopied = true;",
        "    } catch (e) { }",
        "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
        "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
        "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
        "    targetDoc.selection = null;",
        "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
        "    app.redraw();",
        "    return hasCopied;",
        "})(" + quoteVersionInfoString(copyText) + ");"
    ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
}

/**
 * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
 * @param {string} sourceText - 文字列
 * @returns {string} "…" の形のリテラル
 */
function quoteVersionInfoString(sourceText) {
    return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

/**
 * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
 * @param {File} scriptFile - 表示するファイル
 * @returns {void}
 */
function revealVersionInfoScriptFile(scriptFile) {
    /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
    var hasRevealApp = (File.fs === "Macintosh")
        && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
    /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
    if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
    /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
    scriptFile.parent.execute();
}

/**
 * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
 * @param {string} targetPath - 絶対パス
 * @returns {boolean} 書き出せたら true
 */
function writeVersionInfoRevealPath(targetPath) {
    var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
    pathFile.encoding = "UTF-8";
    pathFile.lineFeed = "Unix";
    if (!pathFile.open("w")) return false;
    var hasWritten = pathFile.write(targetPath);
    pathFile.close();
    return hasWritten;
}

/**
 * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
 * @param {string} targetUrl - 開く URL
 * @returns {void}
 */
function openVersionInfoUrl(targetUrl) {
    var isMac = (File.fs === "Macintosh");
    var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
    shortcutFile.encoding = "UTF-8";
    shortcutFile.open("w");
    if (isMac) {
        var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
        shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
            + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
    } else {
        shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
    }
    shortcutFile.close();
    shortcutFile.execute();
}

// バージョン表示（再利用パーツ）ここまで / End of the reusable version footer


var LABELS = {
    dialog: {
        title: { ja: "日本語文字組版設定", en: "Japanese Typesetting Settings" }
    },
    panel: {
        typesetting: { ja: "組版設定", en: "Typesetting" }
    },
    button: {
        ok:      { ja: "OK", en: "OK" },
        cancel:  { ja: "キャンセル", en: "Cancel" },
        reflect: { ja: "↓ 反映", en: "↓ Apply" }
    },
    column: {
        styleName:   { ja: "段落スタイル", en: "Paragraph Style" },
        kinsokuSet:  { ja: "禁則処理セット", en: "Kinsoku Set" },
        kinsokuType: { ja: "禁則調整方式", en: "Kinsoku Adjustment" },
        mojikumi:    { ja: "文字組み", en: "Mojikumi" },
        composer:    { ja: "コンポーザー", en: "Composer" },
        bulkSource:  { ja: "すべて", en: "All" }
    },
    alert: {
        noDocument:      { ja: "ドキュメントを開いてから実行してください。", en: "Please open a document before running." },
        noKinsokuTables: { ja: "このドキュメントには禁則処理セットがありません。", en: "This document has no kinsoku tables." },
        noParagraphStyles: { ja: "適用可能な段落スタイルがありません。", en: "There are no applicable paragraph styles." },
        partialFailurePrefix: { ja: "適用しましたが、", en: "Applied, but " },
        partialFailureSuffix: { ja: " 件の段落スタイルでエラーが発生しました。", en: " paragraph style(s) reported an error." }
    },
    undo: {
        applyTypesetting: { ja: "日本語文字組版設定の適用", en: "Apply Japanese Typesetting Settings" }
    }
};

// =========================================
// 文字組みアキ量プリセット定義 / Mojikumi preset definitions
// =========================================

/* 文字組み「なし」の表示名（プリセットや読み取り結果と名前で照合する） / Display name of "no mojikumi" (matched by name against presets and read values) */
var MOJIKUMI_NONE_NAME = "なし";

/*
組み込みの文字組みアキ量 preset enum と表示名の対応表。
InDesign の enum 名から UI 表示用ラベルへ変換するために使用。

Mapping table between built-in mojikumi preset enums and display labels.
Used to convert internal InDesign enum names into user-facing labels.
*/
var MOJIKUMI_LABELS = {
    "LINE_END_ALL_ONE_HALF_EM_ENUM": "行末約物半角",
    "ONE_EM_INDENT_LINE_END_UKE_ONE_HALF_EM_ENUM": "行末受け約物半角・段落1字下げ（起こし全角）",
    "ONE_OR_ONE_HALF_EM_INDENT_LINE_END_UKE_ONE_HALF_EM_ENUM": "行末受け約物半角・段落1字下げ（起こし食い込み）",
    "ONE_OR_ONE_HALF_EM_INDENT_LINE_END_ALL_ONE_EM_ENUM": "約物全角・段落1字下げ",
    "ONE_EM_INDENT_LINE_END_ALL_ONE_EM_ENUM": "約物全角・段落1字下げ（起こし全角）",
    "ONE_EM_INDENT_LINE_END_ALL_NO_FLOAT_ENUM": "行末約物全角/半角・段落1字下げ",
    "ONE_EM_INDENT_LINE_END_UKE_NO_FLOAT_ENUM": "行末受け約物全角／半角・段落1字下げ（起こし全角）",
    "ONE_OR_ONE_HALF_EM_INDENT_LINE_END_UKE_NO_FLOAT_ENUM": "行末受け約物全角／半角・段落1字下げ（起こし食い込み）",
    "ONE_EM_INDENT_LINE_END_ALL_ONE_HALF_EM_ENUM": "行末約物半角・段落1字下げ",
    "LINE_END_ALL_ONE_EM_ENUM": "約物全角",
    "LINE_END_UKE_NO_FLOAT_ENUM": "行末受け約物全角／半角",
    "ONE_OR_ONE_HALF_EM_INDENT_LINE_END_PERIOD_ONE_EM_ENUM": "行末句点全角・段落1字下げ",
    "ONE_EM_INDENT_LINE_END_PERIOD_ONE_EM_ENUM": "行末句点全角・段落1字下げ（起こし全角）",
    "LINE_END_PERIOD_ONE_EM_ENUM": "行末句点全角",
    "TRAD_CHINESE_DEFAULT": "繁体字中国語デフォルト",
    "SIMP_CHINESE_DEFAULT": "簡体字中国語デフォルト"
};

// =========================================
// 配列の検索 / Array lookup
// =========================================

/**
 * 配列の中で値が一致する（===）最初の位置を探す
 * @param {Array} items 探す配列（表示名・列挙値・オブジェクト参照など）
 * @param {*} target 探す値
 * @returns {number} 見つかった位置。なければ -1
 */
function findIndexInArray(items, target) {
    for (var itemIndex = 0; itemIndex < items.length; itemIndex++) {
        if (items[itemIndex] === target) return itemIndex;
    }
    return -1;
}

/**
 * 既定値の名前から選択位置を求める（見つからなければ先頭）
 * @param {Array<string>} names 表示名の一覧
 * @param {string} defaultName 既定値の名前
 * @returns {number} 選択する位置
 */
function getDefaultIndexByName(names, defaultName) {
    var foundIndex = findIndexInArray(names, defaultName);
    return foundIndex >= 0 ? foundIndex : 0;
}

// =========================================
// ドキュメント情報の取得 / Document data collection
// =========================================

/**
 * ドキュメント内の禁則処理セットを集める
 * @param {Document} documentObject 対象ドキュメント
 * @returns {{tables: Array, names: Array<string>}} 禁則処理セットと表示名
 */
function collectKinsokuTables(documentObject) {
    var tables = [];
    var names = [];
    for (var kinsokuTableIndex = 0; kinsokuTableIndex < documentObject.kinsokuTables.length; kinsokuTableIndex++) {
        var kinsokuTable = documentObject.kinsokuTables.item(kinsokuTableIndex);
        tables.push(kinsokuTable);
        names.push(kinsokuTable.name);
    }
    return { tables: tables, names: names };
}

/**
 * 禁則調整方式の選択肢を作る
 * @returns {{values: Array, names: Array<string>}} 調整方式と表示名
 */
function createKinsokuTypeOptions() {
    return {
        names: ["追い込み優先", "追い出し優先", "追い出しのみ", "調整量を優先"],
        values: [
            KinsokuType.KINSOKU_PUSH_IN_FIRST,
            KinsokuType.KINSOKU_PUSH_OUT_FIRST,
            KinsokuType.KINSOKU_PUSH_OUT_ONLY,
            KinsokuType.KINSOKU_PRIORITIZE_ADJUSTMENT_AMOUNT
        ]
    };
}

/**
 * ドキュメント内の文字組みアキ量設定を集める（先頭は「なし」）
 * @param {Document} documentObject 対象ドキュメント
 * @returns {{tables: Array, names: Array<string>}} 文字組み設定と表示名（「なし」の設定は null）
 */
function collectMojikumiTables(documentObject) {
    var tables = [null];
    var names = [MOJIKUMI_NONE_NAME];
    for (var mojikumiTableIndex = 0; mojikumiTableIndex < documentObject.mojikumiTables.length; mojikumiTableIndex++) {
        var mojikumiTable = documentObject.mojikumiTables.item(mojikumiTableIndex);
        tables.push(mojikumiTable);
        names.push(mojikumiTable.name);
    }
    return { tables: tables, names: names };
}

/**
 * 対象にする段落スタイルをグループ込みで集める
 * @param {Document} documentObject 対象ドキュメント
 * @returns {{styles: Array<ParagraphStyle>, names: Array<string>}} 段落スタイルと表示名
 */
function collectTargetParagraphStyles(documentObject) {
    var styles = [];
    var names = [];

    /**
     * スタイルグループを再帰的にたどって段落スタイルを集める
     * @param {object} container 段落スタイルのコンテナ
     * @param {string} prefix グループ名の接頭辞
     * @returns {void}
     */
    function walk(container, prefix) {
        for (var paragraphStyleIndex = 0; paragraphStyleIndex < container.paragraphStyles.length; paragraphStyleIndex++) {
            var paragraphStyle = container.paragraphStyles.item(paragraphStyleIndex);
            var paragraphStyleName = paragraphStyle.name;
            if (paragraphStyleName === "[段落スタイルなし]" || paragraphStyleName === "[No Paragraph Style]") continue;
            if (paragraphStyleName === "[基本段落]" || paragraphStyleName === "[Basic Paragraph]") continue;
            styles.push(paragraphStyle);
            names.push(prefix + paragraphStyleName);
        }
        for (var styleGroupIndex = 0; styleGroupIndex < container.paragraphStyleGroups.length; styleGroupIndex++) {
            var styleGroup = container.paragraphStyleGroups.item(styleGroupIndex);
            if (styleGroup.name.charAt(0) === EXCLUDED_STYLE_GROUP_PREFIX) continue;
            walk(styleGroup, prefix + styleGroup.name + " / ");
        }
    }

    walk(documentObject, "");
    return { styles: styles, names: names };
}

/**
 * コンポーザーの選択肢と適用用エイリアスを作る
 * @returns {{names: Array<string>, aliases: Array<Array<string>>}} 表示名と、ロケール・バージョン違いの名前の候補
 */
function createComposerOptions() {
    var entries = [
        { name: "日本語段落コンポーザー", aliases: ["Adobe 日本語段落コンポーザー", "Adobe Japanese Paragraph Composer"] },
        { name: "日本語単数行コンポーザー", aliases: ["Adobe 日本語単数行コンポーザー", "Adobe Japanese Single-line Composer"] },
        { name: "多言語対応段落コンポーザー", aliases: ["$ID/HL Composer Optyca", "Adobe World-Ready Paragraph Composer", "Adobe 多言語対応段落コンポーザー", "Adobe World-Ready 段落コンポーザー"] },
        { name: "多言語対応単数行コンポーザー", aliases: ["$ID/HL Single Optyca", "Adobe World-Ready Single-line Composer", "Adobe 多言語対応単数行コンポーザー", "Adobe World-Ready 単数行コンポーザー"] },
        { name: "欧文段落コンポーザー", aliases: ["$ID/HL Composer", "Adobe Paragraph Composer", "Adobe 欧文段落コンポーザー", "Adobe 段落コンポーザー"] },
        { name: "欧文単数行コンポーザー", aliases: ["$ID/HL Single", "Adobe Single-line Composer", "Adobe 欧文単数行コンポーザー", "Adobe 単数行コンポーザー"] }
    ];
    var names = [];
    var aliases = [];
    for (var entryIndex = 0; entryIndex < entries.length; entryIndex++) {
        names.push(entries[entryIndex].name);
        aliases.push(entries[entryIndex].aliases);
    }
    return { names: names, aliases: aliases };
}

// =========================================
// 設定値と選択肢の照合 / Matching setting values to options
// =========================================

/**
 * コンポーザー名（エイリアスのどれか）から選択位置を探す
 * @param {Array<Array<string>>} aliasesList createComposerOptions() の aliases
 * @param {string} target 探すコンポーザー名
 * @returns {number} 見つかった位置。なければ -1
 */
function findIndexByComposerAliases(aliasesList, target) {
    if (!target) return -1;
    for (var listIndex = 0; listIndex < aliasesList.length; listIndex++) {
        if (findIndexInArray(aliasesList[listIndex], target) >= 0) return listIndex;
    }
    return -1;
}

/**
 * エイリアスを順に試して段落スタイルにコンポーザーを設定する
 * @param {ParagraphStyle} targetParagraphStyle 対象の段落スタイル
 * @param {Array<string>} aliases コンポーザー名の候補
 * @returns {boolean} 設定できたら true
 */
function applyComposerAliases(targetParagraphStyle, aliases) {
    if (!aliases) return false;
    for (var aliasIndex = 0; aliasIndex < aliases.length; aliasIndex++) {
        try {
            targetParagraphStyle.composer = aliases[aliasIndex];
            return true;
        } catch (composerAliasError) { }
    }
    return false;
}

/**
 * 禁則処理セットの設定値から選択位置を探す（参照・ID・名前の順に照合）
 * @param {*} kinsokuValue 禁則処理セットの設定値
 * @param {Array} kinsokuTables 禁則処理セットの一覧
 * @param {Array<string>} kinsokuNames 禁則処理セットの表示名
 * @returns {number} 見つかった位置。なければ -1
 */
function findKinsokuIndexFromValue(kinsokuValue, kinsokuTables, kinsokuNames) {
    if (kinsokuValue === null || kinsokuValue === undefined) return -1;
    for (var refIndex = 0; refIndex < kinsokuTables.length; refIndex++) {
        if (kinsokuTables[refIndex] === kinsokuValue) return refIndex;
        try {
            if (kinsokuTables[refIndex].id !== undefined && kinsokuValue.id !== undefined && kinsokuTables[refIndex].id === kinsokuValue.id) return refIndex;
        } catch (eKinsokuIdCompare) { }
    }
    var kinsokuValueName = null;
    try { kinsokuValueName = kinsokuValue.name; } catch (eKinsokuValueName) { }
    if (typeof kinsokuValueName === "string" && kinsokuValueName.length > 0) {
        return findIndexInArray(kinsokuNames, kinsokuValueName);
    }
    return -1;
}

/**
 * 文字組みアキ量設定の表示名を求める
 * @param {*} mojikumiValue 文字組みの設定値（MojikumiTable・文字列・NothingEnum・組み込みプリセットの列挙値）
 * @returns {string} 表示名。求められなければ空文字
 */
function resolveMojikumiName(mojikumiValue) {
    if (mojikumiValue === null || mojikumiValue === undefined || mojikumiValue === NothingEnum.NOTHING) {
        return MOJIKUMI_NONE_NAME;
    }
    if (typeof mojikumiValue === "string") {
        return mojikumiValue;
    }

    /* MojikumiTable は .name を持つ。プリセットの列挙値は持たないため toString() で照合 / MojikumiTable has .name; preset enums are matched via toString() */
    try {
        if (mojikumiValue.isValid && typeof mojikumiValue.name === "string" && mojikumiValue.name.length > 0) {
            return mojikumiValue.name;
        }
    } catch (mojikumiNameError) { }

    var mojikumiKey = "";
    try { mojikumiKey = mojikumiValue.toString(); } catch (mojikumiStringError) { }
    for (var enumKey in MOJIKUMI_LABELS) {
        if (mojikumiKey.indexOf(enumKey) !== -1) {
            return MOJIKUMI_LABELS[enumKey];
        }
    }

    return "";
}

// =========================================
// 段落スタイル設定の読み取り / Paragraph style setting readers
// =========================================

/**
 * 段落スタイルの現在の組版設定を読み取る
 * @param {ParagraphStyle} paragraphStyle 対象の段落スタイル
 * @param {object} kinsokuTableData 禁則処理セットの一覧
 * @param {object} kinsokuTypeOptions 禁則調整方式の一覧
 * @param {object} mojikumiTableData 文字組み設定の一覧
 * @param {object} composerOptions コンポーザーの一覧
 * @param {object} defaultIndexes 既定の選択位置
 * @returns {object} 各設定の選択位置
 */
function readParagraphStyleTypesettingSettings(paragraphStyle, kinsokuTableData, kinsokuTypeOptions, mojikumiTableData, composerOptions, defaultIndexes) {
    var styleSettings = {
        kinsokuIndex: defaultIndexes.kinsokuIndex,
        kinsokuTypeIndex: defaultIndexes.kinsokuTypeIndex,
        mojikumiIndex: defaultIndexes.mojikumiIndex,
        composerIndex: defaultIndexes.composerIndex
    };

    try {
        var kinsokuIndex = findKinsokuIndexFromValue(paragraphStyle.kinsokuSet, kinsokuTableData.tables, kinsokuTableData.names);
        if (kinsokuIndex >= 0) styleSettings.kinsokuIndex = kinsokuIndex;
    } catch (kinsokuReadError) { }

    try {
        var kinsokuTypeIndex = findIndexInArray(kinsokuTypeOptions.values, paragraphStyle.kinsokuType);
        if (kinsokuTypeIndex >= 0) styleSettings.kinsokuTypeIndex = kinsokuTypeIndex;
    } catch (kinsokuTypeReadError) { }

    try {
        var mojikumiIndex = findIndexInArray(mojikumiTableData.names, resolveMojikumiName(paragraphStyle.mojikumi));
        if (mojikumiIndex >= 0) styleSettings.mojikumiIndex = mojikumiIndex;
    } catch (mojikumiReadError) { }

    try {
        var composerIndex = findIndexByComposerAliases(composerOptions.aliases, paragraphStyle.composer);
        if (composerIndex >= 0) styleSettings.composerIndex = composerIndex;
    } catch (composerReadError) { }

    return styleSettings;
}

// =========================================
// ダイアログ UI 生成 / Dialog UI builders
// =========================================

/**
 * マトリックス UI に 1 セル分のコントロールを追加する
 * @param {object} parent 追加先のコンテナ
 * @param {string} controlType コントロールの種類
 * @param {object} properties コントロールのプロパティ
 * @param {number} width 列幅（px）
 * @returns {object} 追加したコントロール
 */
function addMatrixCell(parent, controlType, properties, width) {
    var control;
    if (controlType === "statictext") {
        control = parent.add("statictext", undefined, properties.text);
    } else if (controlType === "dropdownlist") {
        control = parent.add("dropdownlist", undefined, properties.items);
        control.selection = properties.selection;
    }

    if (!control) {
        throw new Error("Unsupported control type: " + controlType);
    }

    control.preferredSize.width = width;
    return control;
}

/**
 * 列単位で値を反映するボタンを追加する
 * @param {object} parent 追加先のコンテナ
 * @param {number} width 列幅（px）
 * @returns {Button} 追加したボタン
 */
function addReflectButton(parent, width) {
    var cell = parent.add("group");
    cell.preferredSize.width = width;
    cell.alignChildren = "center";
    return cell.add("button", undefined, getLabel("button.reflect"));
}

/**
 * 縦方向の余白を追加する
 * @param {object} parent 追加先のコンテナ
 * @param {number} height 余白の高さ（px）
 * @returns {Group} 追加した余白のグループ
 */
function addVerticalSpacer(parent, height) {
    var spacer = parent.add("group");
    spacer.preferredSize.height = height;
    return spacer;
}

/**
 * マトリックス UI の見出し行を追加する
 * @param {Panel} matrixPanel 追加先のパネル
 * @returns {void}
 */
function addHeaderRow(matrixPanel) {
    var headerRowGroup = matrixPanel.add("group");
    setupRow(headerRowGroup, "left", MATRIX_ROW_SPACING);
    addMatrixCell(headerRowGroup, "statictext", { text: getLabel("column.styleName") }, COLUMN_WIDTH_NAME);
    addMatrixCell(headerRowGroup, "statictext", { text: getLabel("column.kinsokuSet") }, COLUMN_WIDTH_DROPDOWN);
    addMatrixCell(headerRowGroup, "statictext", { text: getLabel("column.kinsokuType") }, COLUMN_WIDTH_DROPDOWN);
    addMatrixCell(headerRowGroup, "statictext", { text: getLabel("column.mojikumi") }, COLUMN_WIDTH_DROPDOWN_WIDE);
    addMatrixCell(headerRowGroup, "statictext", { text: getLabel("column.composer") }, COLUMN_WIDTH_DROPDOWN_WIDE);
}

/**
 * 一括反映のコピー元となる「すべて」行を追加する
 * @param {Panel} matrixPanel 追加先のパネル
 * @param {Array<string>} kinsokuNames 禁則処理セットの表示名
 * @param {Array<string>} kinsokuTypeNames 禁則調整方式の表示名
 * @param {Array<string>} mojikumiNames 文字組み設定の表示名
 * @param {Array<string>} composerNames コンポーザーの表示名
 * @param {object} defaultIndexes 既定の選択位置
 * @returns {object} コピー元のコントロール
 */
function addBulkSourceRow(matrixPanel, kinsokuNames, kinsokuTypeNames, mojikumiNames, composerNames, defaultIndexes) {
    var bulkSourceRowGroup = matrixPanel.add("group");
    setupRow(bulkSourceRowGroup, "left", MATRIX_ROW_SPACING);
    addMatrixCell(bulkSourceRowGroup, "statictext", { text: getLabel("column.bulkSource") }, COLUMN_WIDTH_NAME);

    return {
        kinsoku: addMatrixCell(bulkSourceRowGroup, "dropdownlist", { items: kinsokuNames, selection: defaultIndexes.kinsokuIndex }, COLUMN_WIDTH_DROPDOWN),
        kinsokuType: addMatrixCell(bulkSourceRowGroup, "dropdownlist", { items: kinsokuTypeNames, selection: defaultIndexes.kinsokuTypeIndex }, COLUMN_WIDTH_DROPDOWN),
        mojikumi: addMatrixCell(bulkSourceRowGroup, "dropdownlist", { items: mojikumiNames, selection: defaultIndexes.mojikumiIndex }, COLUMN_WIDTH_DROPDOWN_WIDE),
        composer: addMatrixCell(bulkSourceRowGroup, "dropdownlist", { items: composerNames, selection: defaultIndexes.composerIndex }, COLUMN_WIDTH_DROPDOWN_WIDE)
    };
}

/**
 * 列ごとの反映ボタンを並べた行を追加する
 * @param {Panel} matrixPanel 追加先のパネル
 * @returns {object} 反映ボタン
 */
function addReflectButtonRow(matrixPanel) {
    var reflectRowGroup = matrixPanel.add("group");
    setupRow(reflectRowGroup, "left", MATRIX_ROW_SPACING);
    addMatrixCell(reflectRowGroup, "statictext", { text: "" }, COLUMN_WIDTH_NAME);

    return {
        kinsoku: addReflectButton(reflectRowGroup, COLUMN_WIDTH_DROPDOWN),
        kinsokuType: addReflectButton(reflectRowGroup, COLUMN_WIDTH_DROPDOWN),
        mojikumi: addReflectButton(reflectRowGroup, COLUMN_WIDTH_DROPDOWN_WIDE),
        composer: addReflectButton(reflectRowGroup, COLUMN_WIDTH_DROPDOWN_WIDE)
    };
}

/**
 * 段落スタイルごとの設定行を追加する
 * @param {Panel} matrixPanel 追加先のパネル
 * @param {Array<string>} kinsokuNames 禁則処理セットの表示名
 * @param {Array<string>} kinsokuTypeNames 禁則調整方式の表示名
 * @param {Array<string>} mojikumiNames 文字組み設定の表示名
 * @param {Array<string>} composerNames コンポーザーの表示名
 * @param {Array<string>} paragraphStyleDisplayNames 段落スタイルの表示名
 * @param {Array<object>} initialSettingsByStyle 各スタイルの初期設定
 * @returns {Array<object>} 行ごとのコントロール
 */
function addParagraphStyleSettingRows(matrixPanel, kinsokuNames, kinsokuTypeNames, mojikumiNames, composerNames, paragraphStyleDisplayNames, initialSettingsByStyle) {
    var styleSettingRows = [];

    for (var paragraphStyleIndex = 0; paragraphStyleIndex < paragraphStyleDisplayNames.length; paragraphStyleIndex++) {
        var initialStyleSettings = initialSettingsByStyle[paragraphStyleIndex];
        var rowGroup = matrixPanel.add("group");
        setupRow(rowGroup, "left", MATRIX_ROW_SPACING);

        addMatrixCell(rowGroup, "statictext", { text: paragraphStyleDisplayNames[paragraphStyleIndex] }, COLUMN_WIDTH_NAME);
        styleSettingRows.push({
            kinsoku: addMatrixCell(rowGroup, "dropdownlist", { items: kinsokuNames, selection: initialStyleSettings.kinsokuIndex }, COLUMN_WIDTH_DROPDOWN),
            kinsokuType: addMatrixCell(rowGroup, "dropdownlist", { items: kinsokuTypeNames, selection: initialStyleSettings.kinsokuTypeIndex }, COLUMN_WIDTH_DROPDOWN),
            mojikumi: addMatrixCell(rowGroup, "dropdownlist", { items: mojikumiNames, selection: initialStyleSettings.mojikumiIndex }, COLUMN_WIDTH_DROPDOWN_WIDE),
            composer: addMatrixCell(rowGroup, "dropdownlist", { items: composerNames, selection: initialStyleSettings.composerIndex }, COLUMN_WIDTH_DROPDOWN_WIDE)
        });
    }

    return styleSettingRows;
}

/**
 * 反映ボタンにコピー処理を結び付ける
 * @param {object} reflectButtons 反映ボタン
 * @param {object} bulkSourceControls コピー元のコントロール
 * @param {Array<object>} styleSettingRows 行ごとのコントロール
 * @returns {void}
 */
function bindBulkCopyButtons(reflectButtons, bulkSourceControls, styleSettingRows) {
    reflectButtons.kinsoku.onClick = createDropdownBulkCopyHandler(bulkSourceControls.kinsoku, styleSettingRows, "kinsoku");
    reflectButtons.kinsokuType.onClick = createDropdownBulkCopyHandler(bulkSourceControls.kinsokuType, styleSettingRows, "kinsokuType");
    reflectButtons.mojikumi.onClick = createDropdownBulkCopyHandler(bulkSourceControls.mojikumi, styleSettingRows, "mojikumi");
    reflectButtons.composer.onClick = createDropdownBulkCopyHandler(bulkSourceControls.composer, styleSettingRows, "composer");
}

/**
 * 各行の選択内容を読み取る
 * @param {Array<object>} styleSettingRows 行ごとのコントロール
 * @returns {Array<object>} 段落スタイルごとの設定
 */
function readStyleSettingRows(styleSettingRows) {
    var settingsByStyle = [];

    for (var rowIndex = 0; rowIndex < styleSettingRows.length; rowIndex++) {
        settingsByStyle.push({
            kinsokuIndex: styleSettingRows[rowIndex].kinsoku.selection.index,
            kinsokuTypeIndex: styleSettingRows[rowIndex].kinsokuType.selection.index,
            mojikumiIndex: styleSettingRows[rowIndex].mojikumi.selection.index,
            composerIndex: styleSettingRows[rowIndex].composer.selection.index
        });
    }

    return settingsByStyle;
}

// =========================================
// UI 操作の反映 / UI value propagation
// =========================================

/**
 * 1 列分の値を全行へコピーするハンドラを作る
 * @param {DropDownList} sourceControl コピー元のドロップダウン
 * @param {Array<object>} styleSettingRows 行ごとのコントロール
 * @param {string} controlKey 対象の列を表すキー
 * @returns {function} クリックハンドラ
 */
function createDropdownBulkCopyHandler(sourceControl, styleSettingRows, controlKey) {
    return function () {
        if (!sourceControl.selection) return;
        var selectedIndex = sourceControl.selection.index;
        for (var rowIndex = 0; rowIndex < styleSettingRows.length; rowIndex++) {
            styleSettingRows[rowIndex][controlKey].selection = selectedIndex;
        }
    };
}

// =========================================
// ダイアログ制御 / Dialog controller
// =========================================

/**
 * 組版設定のマトリックスダイアログを表示する
 * @param {Array<string>} kinsokuNames 禁則処理セットの表示名
 * @param {Array<string>} kinsokuTypeNames 禁則調整方式の表示名
 * @param {Array<string>} mojikumiNames 文字組み設定の表示名
 * @param {Array<string>} composerNames コンポーザーの表示名
 * @param {Array<string>} paragraphStyleDisplayNames 段落スタイルの表示名
 * @param {Array<object>} initialSettingsByStyle 各スタイルの初期設定
 * @param {object} defaultIndexes 既定の選択位置
 * @returns {object|null} 設定内容。キャンセル時は null
 */
function showTypesettingSettingsDialog(kinsokuNames, kinsokuTypeNames, mojikumiNames, composerNames, paragraphStyleDisplayNames, initialSettingsByStyle, defaultIndexes) {
    var dialog = new Window("dialog", getLabel("dialog.title"));
    setupWindow(dialog, 10);

    var matrixPanel = dialog.add("panel", undefined, getLabel("panel.typesetting"));
    setupPanel(matrixPanel, 2);
    addHeaderRow(matrixPanel);
    addVerticalSpacer(matrixPanel, 6);

    var bulkSourceControls = addBulkSourceRow(matrixPanel, kinsokuNames, kinsokuTypeNames, mojikumiNames, composerNames, defaultIndexes);
    addVerticalSpacer(matrixPanel, 3);

    var reflectButtons = addReflectButtonRow(matrixPanel);
    addVerticalSpacer(matrixPanel, 8);

    var styleSettingRows = addParagraphStyleSettingRows(
        matrixPanel,
        kinsokuNames,
        kinsokuTypeNames,
        mojikumiNames,
        composerNames,
        paragraphStyleDisplayNames,
        initialSettingsByStyle
    );
    bindBulkCopyButtons(reflectButtons, bulkSourceControls, styleSettingRows);
    addVerticalSpacer(dialog, 10);

    var buttonRow = addButtonRow(dialog);
    var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
    var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
    alignRightOnlyButtonRow(buttonRow);

    addVersionFooter(dialog);
    if (dialog.show() !== 1) return null;

    return { settingsByStyle: readStyleSettingRows(styleSettingRows) };
}

// =========================================
// 設定の適用 / Apply settings
// =========================================

/**
 * 読み取った設定を各段落スタイルへ適用する
 * @param {Array<ParagraphStyle>} targetParagraphStyles 対象の段落スタイル
 * @param {Array<object>} settingsByStyle 段落スタイルごとの設定
 * @param {object} lookupTables 禁則・文字組み・コンポーザーの参照表
 * @returns {void}
 */
function applyTypesettingSettingsToParagraphStyles(targetParagraphStyles, settingsByStyle, lookupTables) {
    /* 一括で取り消せるように doScript でまとめて実行 / Run through doScript so the whole run is a single undo step */
    app.doScript(
        function () {
            var skipped = 0;

            for (var styleIndex = 0; styleIndex < targetParagraphStyles.length; styleIndex++) {
                var paragraphStyle = targetParagraphStyles[styleIndex];
                var styleSettings = settingsByStyle[styleIndex];
                try {
                    paragraphStyle.kinsokuSet = lookupTables.kinsokuTables[styleSettings.kinsokuIndex];
                    paragraphStyle.kinsokuType = lookupTables.kinsokuTypeValues[styleSettings.kinsokuTypeIndex];
                    var mojikumiTable = lookupTables.mojikumiTables[styleSettings.mojikumiIndex];
                    paragraphStyle.mojikumi = mojikumiTable === null ? NothingEnum.NOTHING : mojikumiTable;
                    /* コンポーザーはロケールやバージョンで受理名が違うため候補を順に試し、どれも通らなければ失敗として数える / Try each composer alias; count the style as failed if none is accepted */
                    if (!applyComposerAliases(paragraphStyle, lookupTables.composerAliases[styleSettings.composerIndex])) throw new Error("composer");
                } catch (e) {
                    skipped++;
                    continue;
                }
            }

            if (skipped > 0) {
                alert(getLabel("alert.partialFailurePrefix") + skipped + getLabel("alert.partialFailureSuffix"));
            }
        },
        ScriptLanguage.JAVASCRIPT,
        undefined,
        UndoModes.ENTIRE_SCRIPT,
        getLabel("undo.applyTypesetting")
    );
}

// =========================================
// メイン処理 / Main
// =========================================

(function () {
    if (app.documents.length === 0) {
        alert(getLabel("alert.noDocument"));
        return;
    }

    var activeDocument = app.activeDocument;

    var kinsokuTableData = collectKinsokuTables(activeDocument);
    if (kinsokuTableData.tables.length === 0) {
        alert(getLabel("alert.noKinsokuTables"));
        return;
    }

    var kinsokuTypeOptions = createKinsokuTypeOptions();
    var mojikumiTableData = collectMojikumiTables(activeDocument);
    var targetParagraphStyleData = collectTargetParagraphStyles(activeDocument);

    if (targetParagraphStyleData.styles.length === 0) {
        alert(getLabel("alert.noParagraphStyles"));
        return;
    }

    var composerOptions = createComposerOptions();
    var defaultIndexes = {
        kinsokuIndex: getDefaultIndexByName(kinsokuTableData.names, DEFAULT_KINSOKU_SET_NAME),
        kinsokuTypeIndex: getDefaultIndexByName(kinsokuTypeOptions.names, DEFAULT_KINSOKU_TYPE_NAME),
        mojikumiIndex: getDefaultIndexByName(mojikumiTableData.names, DEFAULT_MOJIKUMI_NAME),
        composerIndex: getDefaultIndexByName(composerOptions.names, DEFAULT_COMPOSER_NAME)
    };

    // 各段落スタイルの現在値を読み取り / Read current settings from each paragraph style
    var initialSettingsByStyle = [];
    for (var styleIndex = 0; styleIndex < targetParagraphStyleData.styles.length; styleIndex++) {
        initialSettingsByStyle.push(readParagraphStyleTypesettingSettings(
            targetParagraphStyleData.styles[styleIndex], kinsokuTableData, kinsokuTypeOptions, mojikumiTableData, composerOptions, defaultIndexes
        ));
    }

    var result = showTypesettingSettingsDialog(
        kinsokuTableData.names,
        kinsokuTypeOptions.names,
        mojikumiTableData.names,
        composerOptions.names,
        targetParagraphStyleData.names,
        initialSettingsByStyle,
        defaultIndexes
    );
    if (result === null) return;

    applyTypesettingSettingsToParagraphStyles(targetParagraphStyleData.styles, result.settingsByStyle, {
        kinsokuTables: kinsokuTableData.tables,
        kinsokuTypeValues: kinsokuTypeOptions.values,
        mojikumiTables: mojikumiTableData.tables,
        composerAliases: composerOptions.aliases
    });

})();