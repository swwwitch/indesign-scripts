#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdCreateFrameFromSelectedText
Name=選択テキストのサイズでグラフィックフレームを作成
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=2.8.1
Release-Date=2026-03-17
Description-BEGIN
選択したテキストのサイズを基準に、インライン（アンカー付き）またはページ上へグラフィックフレームを作成します。

Creates a graphic frame sized from the selected text, either inline (anchored) or placed on the page.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択したテキストのサイズを基準に、インライン（アンカー付き）またはページ上へグラフィックフレームを作成します。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdCreateFrameFromSelectedText.md

note記事も参照してください。
https://note.com/dtp_tranist/n/ndd1b7c5246a3

### Overview

Creates a graphic frame sized from the selected text, either inline (anchored) or placed on the page.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdCreateFrameFromSelectedText.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdCreateFrameFromSelectedText"; /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v2.8.1";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-03-17";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "選択テキストのサイズでグラフィックフレームを作成"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdCreateFrameFromSelectedText.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdCreateFrameFromSelectedText.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/ndd1b7c5246a3"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/frame/IdCreateFrameFromSelectedText.jsx"; /* 最新版のソース / latest source */

// Original idea
// DTP Script note
// https://note.com/yosi2631/n/ned2dbc1cb79d

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

// =========================================
// ユーザー設定 / User settings
// =========================================

/* 既定で選ばれる段落スタイル名の手がかり / Hints used to preselect a paragraph style */
var DEFAULT_PARA_STYLE_NAME = "p.img";
var DEFAULT_PARA_STYLE_HINT = ".img";

/* 「なし」オブジェクトスタイルの名前（日英）/ Names of the "None" object style (JA/EN) */
var NONE_OBJECT_STYLE_NAMES = ["[なし]", "[None]"];

/* 高さ入力の初期値 / Default values of the height field */
var DEFAULT_HEIGHT_IN_LINES = "1";
var DEFAULT_HEIGHT_IN_MM    = "40";

/* 高さの∧∨・↑↓キーで下げられる下限（行数は1行未満を1行として扱う） / lowest value the height stepper reaches */
var MIN_HEIGHT_IN_LINES = 1;
var MIN_HEIGHT_IN_MM    = 0.1;

/* 行送りを取得できないときのフォールバック（pt）/ Fallback used when leading cannot be read (pt) */
var FALLBACK_POINT_SIZE = 14;
var FALLBACK_LEADING    = 14;

/* mm をポイントへ換算する係数 / Millimeter-to-point conversion factor */
var MM_TO_POINTS = 2.834645669;

// =========================================
// レイアウト設定 / Layout settings
// =========================================

/* 高さ入力欄の文字数 / Character width of the height field */
var HEIGHT_INPUT_CHARACTERS = 8;

/* 作成するフレームの縮小図 / Thumbnail of the frame to be created */
var THUMBNAIL_SIZE = [220, 170];           /* 描画域（幅は最小幅。ダイアログの幅いっぱいに伸ばす）/ canvas (minimum width; fills the dialog width) */
var THUMBNAIL_PADDING = 8;                 /* 描画域の内側の余白 / inner padding */

// ==============================
// UIレイアウトの共通設定 / Shared UI layout
// ==============================

// UIレイアウト（再利用パーツ） / UI layout (reusable)

/* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

/**
 * ウィンドウの共通設定
 * @param {Window} targetWindow - 対象のウィンドウ
 * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
 * @returns {void}
 */
function setupWindow(targetWindow, spacing) {
    targetWindow.orientation = "column";
    targetWindow.alignChildren = "fill";
    targetWindow.margins = WINDOW_MARGINS;
    targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
}

/**
 * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
 * @param {Panel} targetPanel - 対象のパネル
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupPanel(targetPanel, spacing) {
    targetPanel.orientation = "column";
    targetPanel.alignChildren = ["fill", "top"];
    targetPanel.alignment = "fill";
    targetPanel.margins = PANEL_MARGINS;
    targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * タブの共通設定
 * @param {Tab} targetTab - 対象のタブ
 * @param {number} [spacing] - 要素間隔（省略時は変えない）
 * @returns {void}
 */
function setupTab(targetTab, spacing) {
    targetTab.orientation = "column";
    targetTab.alignChildren = "fill";
    targetTab.margins = TAB_MARGINS;
    if (typeof spacing === "number") targetTab.spacing = spacing;
}

/**
 * 横並びの行グループの共通設定（ボタン列など）。
 * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
 * @param {Group} rowGroup - 対象のグループ
 * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupRow(rowGroup, rowAlignment, spacing) {
    rowGroup.orientation = "row";
    rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
    rowGroup.alignChildren = ["left", "center"];
    rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
 * @param {Button} targetButton - 対象のボタン
 * @param {number} trimPixels - 詰める量（px）
 * @returns {void}
 */
function trimButtonHeight(targetButton, trimPixels) {
    /* レイアウト前は size が無い / size is not set until the layout runs */
    if (!targetButton.size) return;
    targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
}

// UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

// UI の明暗（再利用パーツ） / UI theme (reusable)

/**
 * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
 * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
 */
function isDarkUI() {
    try {
        if (app.preferences && app.preferences.getRealPreference) {
            return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
        }
        return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
    } catch (e) {
        return false;
    }
}

// UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

// ステップボタン（再利用パーツ） / Stepper buttons (reusable)

// -----------------------------------------
// ステップボタンの寸法・増減量 / Stepper metrics and steps
// -----------------------------------------
var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

/* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
   UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
   「p」は「1p6」（1パイカ6ポイント）の形にも使う
   Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
var STEPPER_UNIT_ALIASES = {
    "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
    "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
    "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
};

// -----------------------------------------
// ステップボタンの配色 / Stepper colors
// -----------------------------------------
var STEPPER_UI_DARK           = isDarkUI();
/* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
   ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
   UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
   dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

// -----------------------------------------
// 数値欄を作る（外から呼ぶ関数） / Public API
// -----------------------------------------
/**
 * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
 * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
 * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
 * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と異なる単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
 * @param {Group|Panel} parent - 追加先
 * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
 *     step / min / max / integer（true で整数のみ）/ unit / onStep
 * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
 */
function addSteppedField(parent, fieldOptions) {
    var fieldRowGroup = parent.add("group");
    fieldRowGroup.orientation = "row";
    fieldRowGroup.alignChildren = ["left", "center"];
    fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

    var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
    if (fieldOptions.labelWidth) {
        fieldLabel.preferredSize.width = fieldOptions.labelWidth;
        fieldLabel.justify = "right";
    }

    /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
    var stepperInputGroup = fieldRowGroup.add("group");
    stepperInputGroup.orientation = "row";
    stepperInputGroup.alignChildren = ["left", "center"];
    stepperInputGroup.spacing = 0;
    stepperInputGroup.margins = 0;

    var numberInput;
    var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
    numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
    numberInput.characters = fieldOptions.characters || 6;
    numberInput.fieldLabel = fieldLabel;
    numberInput.stepperGroup = stepperGroup;

    /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
    bindSteppedArrowKeys(numberInput, stepperGroup);

    /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
    numberInput.lastValidText = numberInput.text;
    numberInput.onChange = function () {
        var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
        if (isNaN(value)) {
            numberInput.text = numberInput.lastValidText;
            return;
        }
        writeSteppedValue(numberInput, value, fieldOptions);
    };
    return numberInput;
}

/**
 * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
 * @param {EditText} numberInput - addSteppedField() で作った入力欄
 * @param {boolean} isEnabled - 有効にするなら true
 * @returns {void}
 */
function setSteppedFieldEnabled(numberInput, isEnabled) {
    numberInput.enabled = isEnabled;
    numberInput.fieldLabel.enabled = isEnabled;
    numberInput.stepperGroup.enabled = isEnabled;
    /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
    for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
        redrawStepperGroup(numberInput.stepperGroup.children[i]);
    }
}

/**
 * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
 * @param {Group|Panel} parent - 追加先
 * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
 * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
 * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
 */
function addStepper(parent, getNumberInput, stepOptions) {
    var stepperGroup = parent.add("group");
    stepperGroup.orientation = "column";
    stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
    stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
    stepperGroup.alignment = ["left", "center"];

    /**
     * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @returns {void}
     */
    function stepBy(direction) {
        var numberInput = getNumberInput();
        if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
        var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
        if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
        if (isNaN(value)) value = 0;
        writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
        if (stepOptions.onStep) stepOptions.onStep(numberInput);
    }

    /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
    var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
    var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
    makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); }).helpTip = getLabel(upTooltip);
    makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); }).helpTip = getLabel(downTooltip);
    stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
    stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
    return stepperGroup;
}

/**
 * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
 * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
 * @param {EditText} numberInput - 対象の入力欄
 * @param {Group} stepperGroup - addStepper() で作った∧∨
 * @returns {void}
 */
function bindSteppedArrowKeys(numberInput, stepperGroup) {
    numberInput.addEventListener("keydown", function (event) {
        if (event.keyName !== "Up" && event.keyName !== "Down") return;
        stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
        event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
    });
    numberInput.addEventListener("change", function () {
        var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
        var value = evaluateArithmetic(numberInput.text, fieldUnit);
        if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
        /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
        var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
        if (!hasOperator && value === parseFloat(numberInput.text)) return;
        numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
    });
}

// -----------------------------------------
// 値の計算 / Value helpers
// -----------------------------------------
/**
 * 押された修飾キーに応じて、1回分増減した値を返す
 * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
 * 整数の欄では option を無視して step の倍数へ）
 * @param {number} value - 元の値
 * @param {number} direction - 増やすなら 1、減らすなら -1
 * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
 * @returns {number} 増減した値（下限・上限は未適用）
 */
function computeSteppedValue(value, direction, stepOptions) {
    var keyState = ScriptUI.environment.keyboardState;
    if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
    if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
    return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
}

/**
 * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
 * @param {number} value - 元の値
 * @param {number} multiple - 倍数の単位（例 10）
 * @param {number} direction - 上げるなら 1、下げるなら -1
 * @returns {number} 移した値
 */
function snapStepperToNextMultiple(value, multiple, direction) {
    /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
       round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
    var quotient = Math.round(value / multiple * 1e6) / 1e6;
    if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
    return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
}

/**
 * 値を下限・上限の範囲に収める
 * @param {number} value - 数値
 * @param {Object} rangeOptions - min / max（どちらも省略可）
 * @returns {number} 範囲に収めた値
 */
function clampSteppedValue(value, rangeOptions) {
    if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
    if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
    return value;
}

/**
 * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
 * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
 * 全角の数字・記号と × ÷ は半角に直す
 * @param {string} text - 入力欄の文字列
 * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
 * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
 */
function evaluateArithmetic(text, fieldUnit) {
    var source = String(text)
        .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
        .replace(/×/g, "*")
        .replace(/÷/g, "/")
        .replace(/[−–—]/g, "-")
        .replace(/\s/g, "");
    if (source === "") return NaN;
    var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
    var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
    var position = 0;

    /**
     * 加減算の並び（項 ± 項 …）を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readSum() {
        var total = readProduct();
        while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
            var operator = source.charAt(position++);
            var operand = readProduct();
            total = (operator === "+") ? total + operand : total - operand;
        }
        return total;
    }

    /**
     * 乗除算の並び（因子 × 因子 …）を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readProduct() {
        var total = readFactor();
        while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
            var operator = source.charAt(position++);
            var operand = readFactor();
            if (operator === "/" && operand === 0) return NaN;
            total = (operator === "*") ? total * operand : total / operand;
        }
        return total;
    }

    /**
     * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
     * @returns {number} 値（読めなければ NaN）
     */
    function readFactor() {
        var ch = source.charAt(position);
        if (ch === "+" || ch === "-") {
            position++;
            var signedValue = readFactor();
            return (ch === "-") ? -signedValue : signedValue;
        }
        if (ch === "(") {
            position++;
            var innerValue = readSum();
            if (source.charAt(position) !== ")") return NaN;
            position++;
            return innerValue;
        }
        var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
        if (!numberMatch) return NaN;
        position += numberMatch[0].length;
        return readUnitSuffix(parseFloat(numberMatch[0]));
    }

    /**
     * 数値の直後の単位を読み、欄の単位へ換算する
     * @param {number} value - 単位の前の数値
     * @returns {number} 欄の単位での値（換算できない単位なら NaN）
     */
    function readUnitSuffix(value) {
        var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
        if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
        position += unitMatch[0].length;
        var unitKey = unitMatch[0].toLowerCase();
        if (unitKey === fieldUnitKey) return value;
        var typedValue = createStepperUnitValue(value, unitKey);
        if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
        var points = typedValue.as("pt");
        /* 「1p6」＝1パイカ6ポイント / pica-point notation */
        if (unitKey === "p") {
            var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (pointMatch) {
                position += pointMatch[0].length;
                points += parseFloat(pointMatch[0]);
            }
        }
        return points / fieldUnitValue.as("pt");
    }

    var result = readSum();
    if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
    return result;
}

/**
 * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
 * %（percent）は基準の長さが無いと換算できないので扱わない
 * @param {number} value - 数値
 * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
 * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
 */
function createStepperUnitValue(value, unitKey) {
    if (unitKey === "" || unitKey === "%") return null;
    var alias = STEPPER_UNIT_ALIASES[unitKey];
    var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
    if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
    return unitValue;
}

/**
 * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
 * @param {EditText} numberInput - 書き込む入力欄
 * @param {number} value - 数値
 * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
 * @returns {void}
 */
function writeSteppedValue(numberInput, value, valueOptions) {
    numberInput.text = formatSteppedValue(value, valueOptions);
    numberInput.lastValidText = numberInput.text;
}

/**
 * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
 * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
 * @param {number} value - 数値
 * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
 * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
 */
function formatSteppedValue(value, valueOptions) {
    if (valueOptions.integer) value = Math.round(value);
    return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
}

/**
 * 小数第2位で丸めた数値を文字列で返す
 * @param {number} value - 数値
 * @returns {string} 表示用の数値文字列
 */
function formatStepperNumber(value) {
    return String(Math.round(value * 100) / 100);
}

// -----------------------------------------
// ∧∨ボタンの描画 / Drawing
// -----------------------------------------
/**
 * 山形（∧／∨）の極小ボタンを作成する。
 * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
 * 継ぎ目に線は引かない
 * @param {Group|Panel} parent - 追加先
 * @param {string} direction - "up" または "down"
 * @param {Function} onClickFn - クリック時の処理
 * @returns {Group} ボタンとして使う group
 */
function makeStepperChevronButton(parent, direction, onClickFn) {
    var buttonWidth = STEPPER_BUTTON_WIDTH;
    var buttonHeight = STEPPER_BUTTON_HEIGHT;
    var isUp = (direction === "up");
    var chevronBox = parent.add("group");
    chevronBox.margins = 0;
    chevronBox.spacing = 0;
    chevronBox.preferredSize = [buttonWidth, buttonHeight];
    chevronBox.minimumSize = [buttonWidth, buttonHeight];
    chevronBox.maximumSize = [buttonWidth, buttonHeight];
    chevronBox.isPressed = false;
    chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

    chevronBox.onDraw = function () {
        var boxGraphics = chevronBox.graphics;
        /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
           Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
        var isDimmed = !isStepperEnabledInTree(chevronBox);

        /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
        var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
        boxGraphics.newPath();
        boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
        boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

        drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
        drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
    };

    /**
     * 押下状態を変えて描き直す
     * @param {boolean} isPressed - 押下中なら true
     * @returns {void}
     */
    function repaint(isPressed) {
        if (chevronBox.isPressed === isPressed) return;
        chevronBox.isPressed = isPressed;
        redrawStepperGroup(chevronBox);
    }
    chevronBox.addEventListener("mousedown", function () {
        if (!isStepperEnabledInTree(chevronBox)) return;
        repaint(true);
        if (onClickFn) onClickFn();
    });
    chevronBox.addEventListener("mouseup", function () { repaint(false); });
    /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
    chevronBox.addEventListener("mouseout", function () { repaint(false); });
    return chevronBox;
}

/**
 * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
 * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
 * @param {ScriptUIGraphics} boxGraphics - 描画先
 * @param {number} boxWidth - ボタンの幅
 * @param {number} boxHeight - ボタンの高さ
 * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
 * @param {number[]} frameColor - [r, g, b, a]
 * @returns {void}
 */
function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
    var frameLeft = 0.5;
    var frameRight = boxWidth - 0.5;
    var outerY = isUp ? 0.5 : boxHeight - 0.5;
    var seamY = isUp ? boxHeight : 0;
    var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
    var radius = STEPPER_CORNER_RADIUS;
    var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
    var angle, k;

    boxGraphics.newPath();
    boxGraphics.moveTo(frameLeft, seamY);
    /* 左の角丸 / left corner */
    for (k = 0; k <= arcSteps; k++) {
        angle = (Math.PI / 2) * k / arcSteps;
        boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
    }
    /* 右の角丸 / right corner */
    for (k = 0; k <= arcSteps; k++) {
        angle = (Math.PI / 2) * k / arcSteps;
        boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
    }
    boxGraphics.lineTo(frameRight, seamY);
    boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
}

/**
 * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
 * @param {ScriptUIGraphics} boxGraphics - 描画先
 * @param {number} boxWidth - ボタンの幅
 * @param {number} boxHeight - ボタンの高さ
 * @param {boolean} isUp - ∧なら true、∨なら false
 * @param {number[]} chevronColor - [r, g, b, a]
 * @returns {void}
 */
function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
    var centerX = boxWidth / 2;
    var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
    var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
    var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
    boxGraphics.newPath();
    boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
    boxGraphics.lineTo(centerX, centerY + tipOffsetY);
    boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
    boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
}

/**
 * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
 * @param {Object} control - 対象のコントロール
 * @returns {boolean} すべて有効なら true
 */
function isStepperEnabledInTree(control) {
    for (var node = control; node; node = node.parent) {
        if (!node.enabled) return false;
    }
    return true;
}

/**
 * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
 * @param {Object} container - 行・グループ・パネルなど
 * @returns {void}
 */
function redrawSteppersIn(container) {
    if (!container.children) return;
    for (var i = 0; i < container.children.length; i++) {
        var child = container.children[i];
        if (child.isStepperButton) redrawStepperGroup(child);
        else redrawSteppersIn(child);
    }
}

/**
 * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
 * @param {Group} targetGroup - 描き直す group
 * @returns {void}
 */
function redrawStepperGroup(targetGroup) {
    targetGroup.hide();
    targetGroup.show();
}

// ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

// =========================================
// ラベル定義 / Labels
// =========================================

// ローカライズ（再利用パーツ） / Localization (reusable)

/**
 * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
 * @returns {string} "ja" または "en"
 */
function getCurrentLang() {
    return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
}

var uiLang = getCurrentLang();

/**
 * LABELS から今の UI 言語の文言を取り出す。
 * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
 * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
 * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
 */
function getLabel(labelRef, placeholderValues) {
    var labelEntry = labelRef;
    if (typeof labelRef === "string") {
        var labelPathKeys = labelRef.split(".");
        labelEntry = LABELS;
        for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
            labelEntry = labelEntry[labelPathKeys[i]];
        }
    }
    var labelString;
    if (typeof labelEntry === "string") labelString = labelEntry;
    else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
    else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
    else return (typeof labelRef === "string") ? labelRef : "";
    return fillLabelPlaceholders(String(labelString), placeholderValues);
}

/**
 * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {Object|Array} [placeholderValues] - getLabel と同じ
 * @returns {string} コロン付きの文言
 */
function labelText(labelRef, placeholderValues) {
    return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
}

/**
 * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {string|number} value - コロンのあとに続ける値
 * @returns {string} 項目名と値をつないだ文字列
 */
function labelValueText(labelRef, value) {
    return labelText(labelRef) + " " + value;
}

/**
 * 文言の {name} や %1 に値を差し込む
 * @param {string} labelString - 文言
 * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
 * @returns {string} 差し込んだ文言
 */
function fillLabelPlaceholders(labelString, placeholderValues) {
    if (placeholderValues == null) return labelString;
    if (placeholderValues instanceof Array) {
        /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
        for (var i = placeholderValues.length; i >= 1; i--) {
            labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
        }
        return labelString;
    }
    for (var placeholderKey in placeholderValues) {
        if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
        labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
    }
    return labelString;
}

// ローカライズ（再利用パーツ）ここまで / End of the reusable localization

// ボタン行（再利用パーツ） / Button row (reusable)

var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

/**
 * ダイアログ下部のボタン行を作る。
 * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
 * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
 * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
 * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
 */
function addButtonRow(parent, rowOptions) {
    var isCentered = !!(rowOptions && rowOptions.centered);
    var btnRowGroup = parent.add("group");
    btnRowGroup.orientation = "row";
    btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
    btnRowGroup.spacing = BUTTON_ROW_SPACING;

    if (isCentered) {
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
    }

    btnRowGroup.alignment = ["fill", "bottom"];

    var btnLeftGroup = btnRowGroup.add("group");
    btnLeftGroup.alignChildren = ["left", "center"];
    btnLeftGroup.spacing = BUTTON_ROW_SPACING;

    /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
    var spacer = btnRowGroup.add("group");
    spacer.alignment = ["fill", "fill"];
    spacer.minimumSize.width = 0;

    var btnRightGroup = btnRowGroup.add("group");
    btnRightGroup.alignChildren = ["right", "center"];
    btnRightGroup.spacing = BUTTON_ROW_SPACING;

    return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
}

/**
 * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
 * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
 * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
 * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
 * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
 * @returns {void}
 */
function alignRightOnlyButtonRow(buttonRow) {
    if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
    var dialogWindow = buttonRow.rowGroup.window;
    dialogWindow.addEventListener("show", function () {
        if (!buttonRow.leftGroup) return;
        var btnRowGroup = buttonRow.rowGroup;
        /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
        if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
        /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
        btnRowGroup.remove(buttonRow.leftGroup);
        btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        buttonRow.leftGroup = null;
        dialogWindow.layout.layout(true);
    });
}

// ボタン行（再利用パーツ）ここまで / End of the reusable button row

// バージョン表示（再利用パーツ） / Version footer (reusable)

var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

/* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
   9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
   / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
     nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
var VERSION_FOOTER_GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
    "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
    "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
    "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
    "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
    "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
    "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
    "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
    "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
    "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
    "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
    "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
    "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
    "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
    "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
    "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
    "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
    "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
    "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
    "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
    "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
    "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
    "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
    "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
    "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
    "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
    "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
    "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
    "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
    "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
    "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
    "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
    "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
    "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
    "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
    "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
    "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
    "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
    ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
    "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
    "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
    "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
    " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
};

/**
 * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
 * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
 * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
 * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
 * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
 */
function addVersionFooter(targetWindow) {
    if (targetWindow.versionFooter) return null;

    /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
    var lastChild = targetWindow.children[targetWindow.children.length - 1];
    if (lastChild && lastChild.type === "group") {
        var rowMargins = lastChild.margins;
        lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
    }
    var windowMargins = targetWindow.margins;
    targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

    var footerGroup = targetWindow.add("group");
    footerGroup.orientation = "row";
    footerGroup.alignment = ["fill", "bottom"];
    footerGroup.alignChildren = ["left", "center"];
    footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

    /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
       左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
       / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
         or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
    var versionText = String(SCRIPT_VERSION);
    var leftCandidates = [versionText];
    if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
    var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
    versionCanvas.alignment = ["fill", "center"];
    bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
    var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
    brandCanvas.alignment = ["right", "center"];
    brandCanvas.maximumSize = brandCanvas.preferredSize;
    targetWindow.versionFooter = footerGroup;
    return versionCanvas;
}

/**
 * 文字列のすべての文字に字形があるかを返す
 * @param {string} dotText - 文字列
 * @returns {boolean} すべてあれば true
 */
function hasVersionFooterGlyphs(dotText) {
    for (var i = 0; i < dotText.length; i++) {
        if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
    }
    return dotText.length > 0;
}

/**
 * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
 * @param {Group} parentGroup - 足す先
 * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
 * @returns {Group} 描くグループ
 */
function addVersionFooterCanvas(parentGroup, dotTexts) {
    var dotCanvas = parentGroup.add("group");
    var shortestText = dotTexts[dotTexts.length - 1];
    dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
    dotCanvas.helpTip = dotTexts[0];
    dotCanvas.onDraw = function () {
        var availableWidth = this.size ? this.size.width : 0;
        var drawText = shortestText;
        for (var i = 0; i < dotTexts.length; i++) {
            if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                drawText = dotTexts[i];
                break;
            }
        }
        drawVersionFooterDots(this.graphics, drawText);
    };
    return dotCanvas;
}

/**
 * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
 * @param {string} versionText - 文字列
 * @returns {number} 幅（ドット）
 */
function measureVersionFooterDots(versionText) {
    var dotCount = 0;
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
        dotCount += glyphRows[0].length;
    }
    return dotCount;
}

/**
 * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
 * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
 * @param {string} versionText - 文字列
 * @returns {void}
 */
function drawVersionFooterDots(canvasGraphics, versionText) {
    var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
    var dotSize = VERSION_FOOTER_PIXEL_SIZE;
    var cursorDots = 0;
    canvasGraphics.newPath();
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
        for (var row = 0; row < glyphRows.length; row++) {
            var rowText = glyphRows[row];
            var runStart = -1;
            for (var col = 0; col <= rowText.length; col++) {
                var isDot = col < rowText.length && rowText.charAt(col) === "#";
                if (isDot && runStart < 0) runStart = col;
                if (!isDot && runStart >= 0) {
                    canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                    runStart = -1;
                }
            }
        }
        cursorDots += glyphRows[0].length;
    }
    canvasGraphics.fillPath(footerBrush);
}

// -----------------------------------------
// このスクリプトについて / About this script
// -----------------------------------------
/* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
   この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
   Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
   and keeps its own labels and layout values so the part works on its own */

var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
/* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
   The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
/* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

var VERSION_INFO_LABELS = {
    dialog: {
        title: { ja: "このスクリプトについて", en: "About This Script" }
    },
    panel: {
        generalInfo: { ja: "基本情報", en: "General" },
        links: { ja: "リンク", en: "Links" }
    },
    fieldLabel: {
        scriptName: { ja: "スクリプト名", en: "Script Name" },
        scriptFeature: { ja: "機能", en: "Feature" },
        scriptVersion: { ja: "バージョン", en: "Version" }
    },
    button: {
        openReadme: { ja: "README", en: "README" },
        openSourceCode: { ja: "ソースコード", en: "Source Code" },
        openArticle: { ja: "記事（note）", en: "Article (note)" },
        revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
        revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
        close: { ja: "閉じる", en: "Close" }
    },
    tooltip: {
        versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
        copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
    },
    alert: {
        copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
    }
};

/**
 * VERSION_INFO_LABELS の文言を今の言語で返す
 * @param {Object} labelEntry - { ja, en }
 * @returns {string} 文言
 */
function getVersionInfoLabel(labelEntry) {
    return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
}

/**
 * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
 * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
 * @returns {string} 値
 */
function getVersionInfoValue(variableKey) {
    var infoValue;
    if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
    else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
    else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
    else if (variableKey === "readme") {
        if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
        else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
    }
    else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
    else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
    return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
}

/**
 * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
 * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
 * @returns {void}
 */
function bindVersionInfoClick(versionCanvas) {
    versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
    /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
       Open on mouseup so the release does not land on the footer after the dialog closes */
    versionCanvas.addEventListener("mouseup", function () {
        showVersionInfoDialog(versionCanvas.window.type === "palette");
    });
}

/**
 * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
 * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
 * @returns {void}
 */
function showVersionInfoDialog(isFromPalette) {
    var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
    infoDialog.orientation = "column";
    infoDialog.alignChildren = "fill";
    infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
    infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

    var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
    /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
    /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
    if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
    }
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
    alignVersionInfoLabels(infoPanel);

    /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
    var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
    var linkButtonRow = linksPanel.add("group");
    linkButtonRow.orientation = "row";
    linkButtonRow.alignment = ["left", "center"];
    linkButtonRow.alignChildren = ["left", "center"];
    linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

    /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
    var buttonRow = infoDialog.add("group");
    buttonRow.orientation = "row";
    buttonRow.alignment = ["fill", "bottom"];
    buttonRow.alignChildren = ["left", "center"];
    buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
    buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
    var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
    if (VERSION_INFO_SCRIPT_FILE.exists) {
        revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
        revealButton.onClick = function () {
            revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
            infoDialog.close();
        };
    } else {
        revealButton.enabled = false;
    }
    /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
    var buttonSpacer = buttonRow.add("group");
    buttonSpacer.alignment = ["fill", "fill"];
    buttonSpacer.minimumSize.width = 0;
    var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
    closeButton.alignment = ["right", "center"];
    /* return でも esc でも閉じる / Close with both Return and Esc */
    infoDialog.defaultElement = closeButton;
    infoDialog.cancelElement = closeButton;
    infoDialog.onShow = function () {
        pinVersionInfoCopyButton(infoPanel);
    };
    infoDialog.show();
}

/**
 * 「このスクリプトについて」のダイアログにパネルを足す
 * @param {Window} infoDialog - 足す先のダイアログ
 * @param {Object} titleEntry - パネル名の文言 { ja, en }
 * @returns {Panel} パネル
 */
function addVersionInfoPanel(infoDialog, titleEntry) {
    var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
    infoPanel.orientation = "column";
    infoPanel.alignChildren = ["fill", "top"];
    infoPanel.alignment = "fill";
    infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
    infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
    return infoPanel;
}

/**
 * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
 * @param {Panel} infoPanel - 足す先のパネル
 * @param {Object} labelEntry - 項目名の文言 { ja, en }
 * @param {string} valueText - 表示する値
 * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
 * @returns {StaticText} 値の statictext
 */
function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
    var infoRow = infoPanel.add("group");
    infoRow.orientation = "row";
    infoRow.alignment = ["fill", "center"];
    infoRow.alignChildren = ["left", "center"];
    infoRow.spacing = VERSION_INFO_ROW_SPACING;
    /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
    var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
    rowLabel.justify = "right";
    var valueLabel = infoRow.add("statictext", undefined, valueText);
    if (copyFromPalette === null) return valueLabel;
    /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
       A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
    var copySpacer = infoRow.add("group");
    copySpacer.alignment = ["fill", "fill"];
    copySpacer.minimumSize.width = 0;
    infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
    return valueLabel;
}

/**
 * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
 * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
 * @param {Panel} infoPanel - ［基本情報］パネル
 * @returns {void}
 */
function pinVersionInfoCopyButton(infoPanel) {
    var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
    for (var i = 0; i < infoPanel.children.length; i++) {
        var infoRow = infoPanel.children[i];
        if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
        infoRow.size = [innerWidth, infoRow.size.height];
        infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
    }
}

/**
 * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
 * @param {Panel} infoPanel - 対象のパネル
 * @returns {void}
 */
function alignVersionInfoLabels(infoPanel) {
    var rowLabels = [];
    var labelWidth = 0;
    for (var i = 0; i < infoPanel.children.length; i++) {
        var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
        rowLabels.push(rowLabel);
        labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
    }
    for (var j = 0; j < rowLabels.length; j++) {
        rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
    }
}

/**
 * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
 * @param {Window} infoDialog - ボタンを置くダイアログ
 * @param {Group} buttonGroup - 足す先のグループ
 * @param {Object} labelEntry - ボタンの文言 { ja, en }
 * @param {string} targetUrl - 開く URL（空ならディム表示）
 * @returns {void}
 */
function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
    var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
    if (!targetUrl) {
        linkButton.enabled = false;
        return;
    }
    linkButton.helpTip = targetUrl;
    linkButton.onClick = function () {
        openVersionInfoUrl(targetUrl);
        infoDialog.close();
    };
}

/**
 * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
 * @param {Group} infoRow - 足す先の行
 * @param {StaticText} valueLabel - コピーする値の statictext
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {Group} ボタンとして使う group
 */
function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
    var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
    var copyButton = infoRow.add("group");
    copyButton.preferredSize = [buttonSize, buttonSize];
    copyButton.minimumSize = [buttonSize, buttonSize];
    copyButton.maximumSize = [buttonSize, buttonSize];
    copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
    copyButton.isPressed = false;
    copyButton.isCopied = false;

    copyButton.onDraw = function () {
        var buttonGraphics = copyButton.graphics;
        var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
        buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
        if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
        else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
    };

    /**
     * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
     * @param {boolean} isPressed - 押下中なら true
     * @param {boolean} isCopied - コピー済みなら true
     * @returns {void}
     */
    function repaint(isPressed, isCopied) {
        if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
        copyButton.isPressed = isPressed;
        copyButton.isCopied = isCopied;
        copyButton.hide();
        copyButton.show();
    }
    copyButton.addEventListener("mousedown", function () { repaint(true, false); });
    copyButton.addEventListener("mouseup", function () {
        if (!copyButton.isPressed) return;
        var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
        repaint(false, hasCopied);
        if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
    });
    /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
    copyButton.addEventListener("mouseout", function () { repaint(false, false); });
    return copyButton;
}

/**
 * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
    var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
    var sheetSize = 9;
    var offset = 3;
    var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var backLeft = frontLeft - offset;
    var backTop = frontTop - offset;
    /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
    buttonGraphics.newPath();
    buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
    buttonGraphics.strokePath(iconPen);
    buttonGraphics.newPath();
    buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
    buttonGraphics.strokePath(iconPen);
}

/**
 * コピーしたあとのチェックマークを描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
    var center = buttonSize / 2;
    buttonGraphics.newPath();
    buttonGraphics.moveTo(center - 4.5, center);
    buttonGraphics.lineTo(center - 1.5, center + 3);
    buttonGraphics.lineTo(center + 4.5, center - 3.5);
    buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
}

/**
 * 文字列をクリップボードにコピーする。
 * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
 * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
 * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
 * @param {string} copyText - コピーする文字列
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {boolean} コピーの操作まで進めたら true
 */
function copyVersionInfoText(copyText, isFromPalette) {
    try {
        if (VERSION_INFO_IS_INDESIGN) {
            if (File.fs === "Windows") {
                app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
            } else {
                app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
            }
            return true;
        }
        var copyScript = buildVersionInfoCopyScript(copyText);
        if (!isFromPalette) return eval(copyScript) === true;
        var copyMessage = new BridgeTalk();
        copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
        copyMessage.body = copyScript;
        copyMessage.send();
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
 * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
 * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
 * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
 * @param {string} copyText - コピーする文字列
 * @returns {string} 実行すると true / false を返すスクリプト
 */
function buildVersionInfoCopyScript(copyText) {
    return [
        "(function (copyText) {",
        "    var usingTempDoc = (app.documents.length === 0);",
        "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
        "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
        "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
        "    var tempLayer = null;",
        "    var hasCopied = false;",
        "    try {",
        "        tempLayer = targetDoc.layers.add();",
        "        var tempFrame = tempLayer.textFrames.add();",
        "        tempFrame.contents = copyText;",
        "        app.redraw();",
        "        app.executeMenuCommand('deselectall');",
        "        tempFrame.selected = true;",
        "        app.redraw();",
        "        app.executeMenuCommand('copy');",
        "        app.redraw();",
        "        hasCopied = true;",
        "    } catch (e) { }",
        "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
        "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
        "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
        "    targetDoc.selection = null;",
        "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
        "    app.redraw();",
        "    return hasCopied;",
        "})(" + quoteVersionInfoString(copyText) + ");"
    ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
}

/**
 * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
 * @param {string} sourceText - 文字列
 * @returns {string} "…" の形のリテラル
 */
function quoteVersionInfoString(sourceText) {
    return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

/**
 * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
 * @param {File} scriptFile - 表示するファイル
 * @returns {void}
 */
function revealVersionInfoScriptFile(scriptFile) {
    /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
    var hasRevealApp = (File.fs === "Macintosh")
        && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
    /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
    if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
    /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
    scriptFile.parent.execute();
}

/**
 * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
 * @param {string} targetPath - 絶対パス
 * @returns {boolean} 書き出せたら true
 */
function writeVersionInfoRevealPath(targetPath) {
    var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
    pathFile.encoding = "UTF-8";
    pathFile.lineFeed = "Unix";
    if (!pathFile.open("w")) return false;
    var hasWritten = pathFile.write(targetPath);
    pathFile.close();
    return hasWritten;
}

/**
 * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
 * @param {string} targetUrl - 開く URL
 * @returns {void}
 */
function openVersionInfoUrl(targetUrl) {
    var isMac = (File.fs === "Macintosh");
    var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
    shortcutFile.encoding = "UTF-8";
    shortcutFile.open("w");
    if (isMac) {
        var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
        shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
            + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
    } else {
        shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
    }
    shortcutFile.close();
    shortcutFile.execute();
}

// バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

var LABELS = {
    dialog: {
        title:            { ja: "選択した文字列からフレーム作成", en: "Create Frame from Selected Text" },
        titleNoSelection: { ja: "グラフィックフレーム作成", en: "Create Graphic Frame" }
    },
    panel: {
        method:         { ja: "配置方法", en: "Placement" },
        frameSize:      { ja: "フレームサイズ", en: "Frame Size" },
        width:          { ja: "幅", en: "Width" },
        height:         { ja: "高さ", en: "Height" },
        textSettings:   { ja: "テキスト設定", en: "Text Settings" },
        objectSettings: { ja: "オブジェクト設定", en: "Object Settings" }
    },
    radio: {
        graphicFrame: { ja: "グラフィックフレーム", en: "Graphic Frame" },
        inlineFrame:  { ja: "インライン（アンカー付き）", en: "Inline (Anchored)" },
        widthText:    { ja: "選択したテキスト", en: "Selected Text" },
        widthColumn:  { ja: "カラム幅", en: "Column Width" },
        widthFrame:   { ja: "親フレーム", en: "Parent Frame" },
        widthMargin:  { ja: "ページのマージン", en: "Page Margins" },
        heightLines:  { ja: "行数", en: "Line Count" },
        heightSize:   { ja: "サイズ指定", en: "Specify Size" }
    },
    field: {
        paraStyle: { ja: "挿入行の段落スタイル:", en: "Paragraph Style for Inserted Line:" },
        objStyle:  { ja: "オブジェクトスタイル:", en: "Object Style:" },
        wrap:      { ja: "テキストの回り込み:", en: "Text Wrap:" }
    },
    checkbox: {
        autoLeading: { ja: "行送り：自動", en: "Leading: Auto" }
    },
    wrap: {
        none:        { ja: "なし", en: "None" },
        boundingBox: { ja: "境界線ボックスで回り込む", en: "Wrap Around Bounding Box" },
        contour:     { ja: "オブジェクトのシェイプで回り込む", en: "Wrap Around Object Shape" },
        jumpObject:  { ja: "オブジェクトを挟んで回り込む", en: "Jump Object" },
        nextColumn:  { ja: "次の段へテキストを送る", en: "Jump to Next Column" }
    },
    unit: {
        lines: { ja: "行", en: "lines" },
        mm:    { ja: "mm", en: "mm" }
    },
    button: {
        ok:     { ja: "OK", en: "OK" },
        cancel: { ja: "キャンセル", en: "Cancel" }
    },
    tooltip: {
        heightLines: {
            ja: "行数モードの高さは概算です。1行目の文字サイズ＋残り行数×行送りで計算します。",
            en: "Line Count height is approximate. It is calculated as first-line point size plus leading for the remaining lines."
        },
        /* ステップボタン用 / for the stepper */
        stepUp: {
            ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
            en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
        },
        stepDown: {
            ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
            en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
        },
        stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
        stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" },
        thumbnail: {
            ja: "作成するフレームの位置と大きさの縮小図です。青が作成するフレーム、黄色が選択したテキスト、マゼンタがマージン、水色が親フレームです。インラインの位置は目安です。",
            en: "Thumbnail of where the frame will be created and how large it is. Blue is the new frame, yellow the selected text, magenta the margins and light blue the parent frame. The inline position is approximate."
        }
    },
    alert: {
        noDocument:          { ja: "ドキュメントが開かれていません。", en: "No document is open." },
        selectText:          { ja: "テキストを選択してください。", en: "Please select text." },
        selectTextBeforeRun: { ja: "テキスト項目を1つだけ選択してから実行してください。", en: "Select only one text item before running the script." },
        boundsError:         { ja: "選択したテキストの座標を取得できませんでした。", en: "Could not get the bounds of the selected text." },
        parentPageError:     { ja: "配置先のページを取得できませんでした。", en: "Could not determine the destination page." },
        parentFrameError:    { ja: "挿入位置の親テキストフレームを取得できませんでした。", en: "Could not get the parent text frame for the insertion point." }
    },
    undo: {
        createFrame: { ja: "フレーム作成", en: "Create Frame" }
    }
};

// =========================================
// テキスト判定と座標取得 / Text detection and bounds
// =========================================

/**
 * 選択オブジェクトがテキストかどうかを判定する
 * @param {object} selectionItem 選択オブジェクト
 * @returns {boolean} テキストなら true
 */
function isTextSelection(selectionItem) {
    if (!selectionItem) return false;

    try {
        if (selectionItem.hasOwnProperty("baseline")) return true;
    } catch (e) {}

    try {
        if (selectionItem.hasOwnProperty("characters") && selectionItem.characters && selectionItem.characters.length > 0) {
            return true;
        }
    } catch (e) {}

    try {
        if (selectionItem.constructor && selectionItem.constructor.name) {
            var typeName = String(selectionItem.constructor.name);
            if (typeName === "Text" || typeName === "Word" || typeName === "Line" ||
                typeName === "Paragraph" || typeName === "TextStyleRange" || typeName === "Character") {
                return true;
            }
        }
    } catch (e) {}

    return false;
}

/**
 * 2つの外接矩形を合わせた外接矩形を返す
 * @param {Array<number>|null} baseBounds [上, 左, 下, 右]。まだ無ければ null
 * @param {Array<number>} addedBounds 合わせる [上, 左, 下, 右]
 * @returns {Array<number>} 合わせた [上, 左, 下, 右]
 */
function unionBounds(baseBounds, addedBounds) {
    if (baseBounds === null) return [addedBounds[0], addedBounds[1], addedBounds[2], addedBounds[3]];
    return [
        Math.min(baseBounds[0], addedBounds[0]),
        Math.min(baseBounds[1], addedBounds[1]),
        Math.max(baseBounds[2], addedBounds[2]),
        Math.max(baseBounds[3], addedBounds[3])
    ];
}

/**
 * アウトライン化した一時オブジェクトから外接矩形を求め、そのオブジェクトを削除する
 * @param {Array} outlineItems アウトライン化で得られたオブジェクトの配列
 * @returns {Array<number>|null} [上, 左, 下, 右]。求められない場合は null
 */
function getAndRemoveOutlineBounds(outlineItems) {
    var mergedBounds = null;

    try {
        for (var i = 0; i < outlineItems.length; i++) {
            mergedBounds = unionBounds(mergedBounds, outlineItems[i].geometricBounds);
        }
    } finally {
        for (var j = outlineItems.length - 1; j >= 0; j--) {
            try { outlineItems[j].remove(); } catch (e) {}
        }
    }

    return mergedBounds;
}

/**
 * テキスト（選択全体または1文字）を一度にアウトライン化して外接矩形を求める
 * @param {object} textObject 対象のテキスト
 * @returns {Array<number>|null} [上, 左, 下, 右]。求められない場合は null
 */
function getOutlineBounds(textObject) {
    try {
        if (!textObject || !textObject.characters || textObject.characters.length === 0) return null;
        var outlineItems = textObject.createOutlines(false);
        if (!outlineItems || outlineItems.length === 0) return null;
        return getAndRemoveOutlineBounds(outlineItems);
    } catch (e) {
        return null;
    }
}

/**
 * 1 文字ずつアウトライン化して外接矩形を合成する
 * @param {object} textObject 対象のテキスト
 * @returns {Array<number>|null} [上, 左, 下, 右]。求められない場合は null
 */
function getTextSelectionBoundsPerCharacter(textObject) {
    try {
        var characterList = textObject.characters;
        if (!characterList || characterList.length === 0) return null;

        var mergedBounds = null;

        for (var i = 0; i < characterList.length; i++) {
            var character = characterList[i];

            try {
                /* 改行類はアウトライン化できないので除外 / Skip break characters, which cannot be outlined */
                if (character.contents === "\r" || character.contents === "\n" || character.contents === "\u0003") continue;
            } catch (e) {}

            var characterBounds = getOutlineBounds(character);
            if (!characterBounds) continue;
            mergedBounds = unionBounds(mergedBounds, characterBounds);
        }

        if (mergedBounds === null) {
            try {
                return textObject.parentTextFrames[0].geometricBounds;
            } catch (e) {
                return null;
            }
        }

        return mergedBounds;
    } catch (e) {
        return null;
    }
}

/**
 * 選択テキストの外接矩形を求める
 * @param {object} textObject 対象のテキスト
 * @returns {Array<number>|null} [上, 左, 下, 右]。求められない場合は null
 */
function getTextSelectionBounds(textObject) {
    return getOutlineBounds(textObject) || getTextSelectionBoundsPerCharacter(textObject);
}

/**
 * 挿入ポイントが属するテキストフレームを取得する
 * @param {InsertionPoint} insertionPoint 対象の挿入ポイント
 * @returns {TextFrame|null} テキストフレーム。取得できない場合は null
 */
function getInsertionPointTextFrame(insertionPoint) {
    try {
        if (insertionPoint && insertionPoint.parentTextFrames && insertionPoint.parentTextFrames.length > 0) {
            return insertionPoint.parentTextFrames[0];
        }
    } catch (e) {}
    return null;
}

/**
 * テキストが配置されているページを取得する
 * @param {object} textObject 対象のテキスト
 * @returns {Page|null} ページ。取得できない場合は null
 */
function getParentPage(textObject) {
    try {
        if (textObject.parentTextFrames.length > 0) return textObject.parentTextFrames[0].parentPage;
    } catch (e) {}
    return null;
}

// =========================================
// フレームの大きさと位置 / Frame size and position
// =========================================

/**
 * フレームを置くページを返す（未選択は表示中のページ、挿入ポイントはその親フレームのページ、テキストはそのページ）
 * @param {Object} frameContext - 選択の情報（selectedText / isInsertionPoint / hasNoSelection）
 * @returns {Page|null} ページ。取得できない場合は null
 */
function resolveDestinationPage(frameContext) {
    if (frameContext.hasNoSelection) return app.activeWindow.activePage;
    if (frameContext.isInsertionPoint) {
        var insertionFrame = getInsertionPointTextFrame(frameContext.selectedText);
        return insertionFrame ? insertionFrame.parentPage : null;
    }
    return getParentPage(frameContext.selectedText);
}

/**
 * フレームの高さを求める。高さの指定が無いとき（テキストを選択しているとき）は選択テキストの高さ
 * @param {Object} frameContext - 選択の情報
 * @param {{useLines: boolean, inputText: string}|null} heightSettings - 高さの指定（行数モードか・入力欄の文字列）。高さの欄が無いときは null
 * @returns {number} 高さ
 */
function resolveFrameHeight(frameContext, heightSettings) {
    var frameHeight = frameContext.selectionHeight;
    if (!heightSettings) return frameHeight;

    if (heightSettings.useLines) {
        /* 行数モード: 1行目の文字サイズ + 残り行数 × 行送り / Line-count mode: first-line size plus leading for the remaining lines */
        var lineCount = parseFloat(heightSettings.inputText) || 1;
        if (lineCount < 1) lineCount = 1;
        try {
            var selectedText = frameContext.selectedText;
            var referenceFrame = frameContext.isInsertionPoint
                ? getInsertionPointTextFrame(selectedText)
                : selectedText.parentTextFrames[0];
            if (!referenceFrame) throw new Error("No parent text frame");

            var referenceStory = referenceFrame.parentStory;
            var insertionIndex = frameContext.isInsertionPoint ? selectedText.index : selectedText.characters[0].index;
            var referenceCharacter = (insertionIndex < referenceStory.characters.length)
                ? referenceStory.characters[insertionIndex]
                : referenceStory.characters[referenceStory.characters.length - 1];

            var referencePointSize = referenceCharacter.pointSize;
            var referenceLeading   = referenceCharacter.leading;
            if (referenceLeading === Leading.AUTO) {
                referenceLeading = referencePointSize * (referenceCharacter.autoLeading / 100);
            }
            frameHeight = referencePointSize + Math.max(0, lineCount - 1) * referenceLeading;
        } catch (e) {
            frameHeight = FALLBACK_POINT_SIZE + Math.max(0, lineCount - 1) * FALLBACK_LEADING;
        }
    } else {
        /* サイズ指定モード: mm 入力をポイントへ変換 / Size mode: convert the millimeter input to points */
        var heightInMillimeters = parseFloat(heightSettings.inputText) || parseFloat(DEFAULT_HEIGHT_IN_MM);
        frameHeight = heightInMillimeters * MM_TO_POINTS;
    }
    return frameHeight;
}

/**
 * フレームの幅を求める
 * @param {Object} frameContext - 選択の情報
 * @param {string} widthMode - "text"（選択したテキスト）| "column"（カラム幅）| "parentFrame"（親フレーム）| "margin"（ページのマージン）
 * @returns {number} 幅（読み取れないときは選択テキストの幅）
 */
function resolveFrameWidth(frameContext, widthMode) {
    var frameWidth = frameContext.selectionWidth;
    var selectedText = frameContext.selectedText;
    if (widthMode === "column") {
        try {
            var columnSourceFrame = selectedText.parentTextFrames[0];
            var columnWidth = columnSourceFrame.textFramePreferences.textColumnFixedWidth;
            if (columnWidth <= 0) {
                var columnFrameBounds = columnSourceFrame.geometricBounds;
                var textFrameWidth = columnFrameBounds[3] - columnFrameBounds[1];
                var columnCount    = columnSourceFrame.textFramePreferences.textColumnCount;
                var columnGutter   = columnSourceFrame.textFramePreferences.textColumnGutter;
                var insetLeft      = columnSourceFrame.textFramePreferences.insetSpacing[1];
                var insetRight     = columnSourceFrame.textFramePreferences.insetSpacing[3];
                columnWidth = (textFrameWidth - insetLeft - insetRight - columnGutter * (columnCount - 1)) / columnCount;
            }
            frameWidth = columnWidth;
        } catch (e) {}
    } else if (widthMode === "parentFrame") {
        try {
            var parentFrameBounds = selectedText.parentTextFrames[0].geometricBounds;
            frameWidth = parentFrameBounds[3] - parentFrameBounds[1];
        } catch (e) {}
    } else if (widthMode === "margin") {
        try {
            var marginPage = resolveDestinationPage(frameContext);
            if (marginPage) {
                var marginPageBounds = marginPage.bounds;
                var pageMargins = marginPage.marginPreferences;
                frameWidth = (marginPageBounds[3] - marginPageBounds[1]) - pageMargins.left - pageMargins.right;
            }
        } catch (e) {}
    }
    return frameWidth;
}

/**
 * ページに置くフレームの左上を求める（テキストを選択していればその左上、それ以外はマージンの左上）
 * @param {Object} frameContext - 選択の情報（hasTextBounds / selectionBounds）
 * @param {Page} destinationPage - 置くページ
 * @returns {number[]} [上, 左]
 */
function resolveFrameTopLeft(frameContext, destinationPage) {
    if (frameContext.hasTextBounds) {
        return [frameContext.selectionBounds[0], frameContext.selectionBounds[1]];
    }
    /* 挿入ポイント・未選択時はマージン左上を基準にする。見開きの左ページは marginPreferences.left が内側（右）なので、物理的な左のマージンを使う
       Anchor to the top-left margin for insertion points and empty selections; on a left-hand page marginPreferences.left is the inside (right) margin, so use the physical left one */
    var pageMargins = destinationPage.marginPreferences;
    var destinationBounds = destinationPage.bounds;
    return [destinationBounds[0] + pageMargins.top, destinationBounds[1] + getPhysicalSideMargins(destinationPage)[0]];
}

/**
 * ページの物理的な左右のマージンを返す（見開きの左ページは marginPreferences の left が内側＝右になる）
 * @param {Page} targetPage - ページ
 * @returns {number[]} [左, 右]
 */
function getPhysicalSideMargins(targetPage) {
    var pageMargins = targetPage.marginPreferences;
    var isLeftHand = false;
    try { isLeftHand = (targetPage.side === PageSideOptions.LEFT_HAND); } catch (e) {}
    return isLeftHand ? [pageMargins.right, pageMargins.left] : [pageMargins.left, pageMargins.right];
}

// =========================================
// 縮小図 / Frame thumbnail
// =========================================

var THUMBNAIL_UI_DARK = isDarkUI();
var THUMBNAIL_COLORS = {
    background:  THUMBNAIL_UI_DARK ? [0.16, 0.16, 0.16, 1] : [0.90, 0.90, 0.90, 1], /* 地 / background */
    page:        [1, 1, 1, 1],                                                     /* ページ / page */
    pageFrame:   THUMBNAIL_UI_DARK ? [0.55, 0.55, 0.55, 1] : [0.50, 0.50, 0.50, 1], /* ページの枠 / page edge */
    margin:      [0.85, 0.30, 0.75, 1],                                            /* マージン / margin guides */
    column:      [0.62, 0.55, 0.88, 1],                                            /* 段のガイド / column guides */
    parentFrame: [0.45, 0.70, 0.90, 1],                                            /* 親フレーム / parent text frame */
    selection:   [1.00, 0.90, 0.40, 1],                                            /* 選択したテキスト / selected text */
    newFrame:    [0.40, 0.62, 1.00, 0.35],                                         /* 作成するフレームの塗り / new frame fill */
    accent:      THUMBNAIL_UI_DARK ? [0.40, 0.65, 1.00, 1] : [0.10, 0.40, 0.85, 1]  /* 作成するフレームの枠 / new frame edge */
};

// 縮小図（再利用パーツ） / Thumbnail canvas (reusable)

var thumbnailFontCache = {}; /* 文字サイズごとの書体 / fonts per size */

/**
 * 縮小図を自作描画する描画域（group）を追加する
 * @param {Window|Panel|Group} parent - 追加先
 * @param {number[]} canvasSize - [幅, 高さ]（px）。fillWidth のときの幅は最小幅
 * @param {Function} drawFn - 描くたびに drawFn(canvasGraphics, canvasWidth, canvasHeight) で呼ぶ関数
 * @param {boolean} [fillWidth] - true なら親の幅いっぱいに伸ばす（ダイアログの幅は広げない）
 * @returns {Group} 描画域
 */
function addThumbnailCanvas(parent, canvasSize, drawFn, fillWidth) {
    var thumbnailCanvas = parent.add("group");
    thumbnailCanvas.preferredSize = [canvasSize[0], canvasSize[1]];
    thumbnailCanvas.minimumSize = [canvasSize[0], canvasSize[1]];
    thumbnailCanvas.maximumSize = [fillWidth ? 10000 : canvasSize[0], canvasSize[1]];
    if (fillWidth) thumbnailCanvas.alignment = ["fill", "top"];
    thumbnailCanvas.onDraw = function () {
        var drawnSize = thumbnailCanvas.size;
        drawFn(thumbnailCanvas.graphics, drawnSize.width, drawnSize.height);
    };
    return thumbnailCanvas;
}

/**
 * 縮小図を描き直す（group には notify() が無いので、隠して再表示する）
 * @param {Group} thumbnailCanvas - addThumbnailCanvas() の戻り値
 * @returns {void}
 */
function redrawThumbnailCanvas(thumbnailCanvas) {
    thumbnailCanvas.hide();
    thumbnailCanvas.show();
}

/**
 * 縮小図に矩形を塗る（rectPath の前に newPath を呼ばないとパスが重なって線画になる）
 * @param {ScriptUIGraphics} canvasGraphics - 描画先
 * @param {number} left - 左（px）
 * @param {number} top - 上（px）
 * @param {number} width - 幅（px）
 * @param {number} height - 高さ（px）
 * @param {number[]} color - RGBA
 * @returns {void}
 */
function fillThumbnailRect(canvasGraphics, left, top, width, height, color) {
    canvasGraphics.newPath();
    canvasGraphics.rectPath(left, top, width, height);
    canvasGraphics.fillPath(canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, color));
}

/**
 * 縮小図に矩形の枠を描く（1px の線が内側に収まるよう 0.5px 内に寄せる）
 * @param {ScriptUIGraphics} canvasGraphics - 描画先
 * @param {number} left - 左（px）
 * @param {number} top - 上（px）
 * @param {number} width - 幅（px）
 * @param {number} height - 高さ（px）
 * @param {number[]} color - RGBA
 * @returns {void}
 */
function strokeThumbnailRect(canvasGraphics, left, top, width, height, color) {
    canvasGraphics.newPath();
    canvasGraphics.rectPath(left + 0.5, top + 0.5, Math.max(width - 1, 0), Math.max(height - 1, 0));
    canvasGraphics.strokePath(canvasGraphics.newPen(canvasGraphics.PenType.SOLID_COLOR, color, 1));
}

/**
 * 縮小図の文字の書体を返す（作れない環境ではコントロールの書体を使う）
 * @param {ScriptUIGraphics} canvasGraphics - 描画先
 * @param {number} fontSize - 文字サイズ（px。InDesign では無視される）
 * @returns {ScriptUIFont} 書体
 */
function getThumbnailFont(canvasGraphics, fontSize) {
    if (thumbnailFontCache[fontSize]) return thumbnailFontCache[fontSize];
    try {
        thumbnailFontCache[fontSize] = ScriptUI.newFont(canvasGraphics.font.name, "REGULAR", fontSize);
    } catch (e) {
        thumbnailFontCache[fontSize] = canvasGraphics.font;
    }
    return thumbnailFontCache[fontSize];
}

/**
 * 文字列の幅と高さを測る（measureString は配列か {width, height} で返る）
 * @param {ScriptUIGraphics} canvasGraphics - 描画先
 * @param {string} text - 文字列
 * @param {ScriptUIFont} font - 書体
 * @returns {number[]} [幅, 高さ]（px）
 */
function measureThumbnailText(canvasGraphics, text, font) {
    var measured = canvasGraphics.measureString(text, font);
    if (measured.width !== undefined) return [measured.width, measured.height];
    return [measured[0], measured[1]];
}

// 縮小図（再利用パーツ）ここまで / End of the reusable thumbnail canvas

/**
 * インライン（アンカー付き）で挿入したときの、フレームの左上の目安を求める（選択位置の行頭＝親フレームの段の左端）
 * @param {Object} frameContext - 選択の情報
 * @param {TextFrame} parentFrame - 親テキストフレーム
 * @returns {number[]|null} [上, 左]。求められない場合は null
 */
function estimateInlineFrameTopLeft(frameContext, parentFrame) {
    try {
        var selectedText = frameContext.selectedText;
        var anchorTop, anchorX;
        if (frameContext.hasTextBounds) {
            anchorTop = frameContext.selectionBounds[0];
            anchorX = frameContext.selectionBounds[1];
        } else {
            anchorTop = selectedText.baseline - selectedText.pointSize;
            anchorX = selectedText.horizontalOffset;
        }
        var frameBounds = parentFrame.geometricBounds;
        var framePreferences = parentFrame.textFramePreferences;
        var columnCount = Math.max(1, framePreferences.textColumnCount);
        var columnGutter = framePreferences.textColumnGutter;
        var contentLeft = frameBounds[1] + framePreferences.insetSpacing[1];
        var contentWidth = (frameBounds[3] - frameBounds[1]) - framePreferences.insetSpacing[1] - framePreferences.insetSpacing[3];
        var columnWidth = (contentWidth - columnGutter * (columnCount - 1)) / columnCount;
        var columnIndex = Math.floor((anchorX - contentLeft + columnGutter / 2) / (columnWidth + columnGutter));
        columnIndex = Math.max(0, Math.min(columnCount - 1, columnIndex));
        return [anchorTop, contentLeft + columnIndex * (columnWidth + columnGutter)];
    } catch (e) {
        return null;
    }
}

/**
 * 縮小図で描く内容を集める（ページ・マージン・段・親フレーム・選択テキスト・作成するフレーム。座標はすべてスプレッド座標）
 * @param {Object} frameContext - 選択の情報
 * @param {boolean} useInlinePlacement - インラインで挿入するか
 * @param {number} frameWidth - 作成するフレームの幅
 * @param {number} frameHeight - 作成するフレームの高さ
 * @returns {Object|null} 描く内容。ページを読めないときは null
 */
function buildFrameThumbnail(frameContext, useInlinePlacement, frameWidth, frameHeight) {
    var destinationPage = null;
    try { destinationPage = resolveDestinationPage(frameContext); } catch (e) {}
    if (!destinationPage) return null;

    var pageMargins = destinationPage.marginPreferences;
    var thumbnailModel = {
        pageBounds: destinationPage.bounds,
        sideMargins: getPhysicalSideMargins(destinationPage),
        topMargin: pageMargins.top,
        bottomMargin: pageMargins.bottom,
        pageColumnCount: Math.max(1, pageMargins.columnCount),
        pageColumnGutter: pageMargins.columnGutter,
        parentFrame: null,
        selectionBounds: frameContext.hasTextBounds ? frameContext.selectionBounds : null,
        newFrameBounds: null
    };

    var parentFrame = null;
    if (!frameContext.hasNoSelection) {
        try {
            parentFrame = frameContext.isInsertionPoint
                ? getInsertionPointTextFrame(frameContext.selectedText)
                : frameContext.selectedText.parentTextFrames[0];
        } catch (e) {}
    }
    if (parentFrame) {
        var parentPreferences = parentFrame.textFramePreferences;
        thumbnailModel.parentFrame = {
            bounds: parentFrame.geometricBounds,
            columnCount: Math.max(1, parentPreferences.textColumnCount),
            columnGutter: parentPreferences.textColumnGutter,
            insetLeft: parentPreferences.insetSpacing[1],
            insetRight: parentPreferences.insetSpacing[3]
        };
    }

    var frameTopLeft = null;
    if (useInlinePlacement) {
        if (parentFrame) frameTopLeft = estimateInlineFrameTopLeft(frameContext, parentFrame);
    } else {
        frameTopLeft = resolveFrameTopLeft(frameContext, destinationPage);
    }
    if (frameTopLeft) {
        thumbnailModel.newFrameBounds = [frameTopLeft[0], frameTopLeft[1], frameTopLeft[0] + frameHeight, frameTopLeft[1] + frameWidth];
    }
    return thumbnailModel;
}

/**
 * 作成するフレームを、ページ・マージン・段・親フレーム・選択テキストと重ねて縮小して描く（ページの縦横比のまま）
 * @param {ScriptUIGraphics} canvasGraphics - 描画先
 * @param {number} canvasWidth - 描画域の幅（px）
 * @param {number} canvasHeight - 描画域の高さ（px）
 * @param {Object|null} thumbnailModel - buildFrameThumbnail() の戻り値
 * @returns {void}
 */
function drawFrameThumbnail(canvasGraphics, canvasWidth, canvasHeight, thumbnailModel) {
    fillThumbnailRect(canvasGraphics, 0, 0, canvasWidth, canvasHeight, THUMBNAIL_COLORS.background);
    if (!thumbnailModel) return;

    var pageBounds = thumbnailModel.pageBounds;
    var pageWidth = pageBounds[3] - pageBounds[1];
    var pageHeight = pageBounds[2] - pageBounds[0];
    if (!(pageWidth > 0) || !(pageHeight > 0)) return;
    var pixelsPerUnit = Math.min((canvasWidth - THUMBNAIL_PADDING * 2) / pageWidth, (canvasHeight - THUMBNAIL_PADDING * 2) / pageHeight);
    if (!(pixelsPerUnit > 0)) return;
    var originLeft = (canvasWidth - pageWidth * pixelsPerUnit) / 2;
    var originTop = (canvasHeight - pageHeight * pixelsPerUnit) / 2;

    /**
     * スプレッド座標の矩形 [上, 左, 下, 右] を描画域の [左, 上, 幅, 高さ]（px）にする
     * @param {number[]} bounds - [上, 左, 下, 右]
     * @returns {number[]} [左, 上, 幅, 高さ]
     */
    function toCanvasRect(bounds) {
        var rectLeft = Math.round(originLeft + (bounds[1] - pageBounds[1]) * pixelsPerUnit);
        var rectTop = Math.round(originTop + (bounds[0] - pageBounds[0]) * pixelsPerUnit);
        var rectRight = Math.round(originLeft + (bounds[3] - pageBounds[1]) * pixelsPerUnit);
        var rectBottom = Math.round(originTop + (bounds[2] - pageBounds[0]) * pixelsPerUnit);
        return [rectLeft, rectTop, Math.max(1, rectRight - rectLeft), Math.max(1, rectBottom - rectTop)];
    }

    /**
     * 縦の区切り線（1px 幅の矩形）を引く
     * @param {number} unitX - スプレッド座標の X
     * @param {number} top - 上（スプレッド座標）
     * @param {number} bottom - 下（スプレッド座標）
     * @param {number[]} color - RGBA
     * @returns {void}
     */
    function drawVerticalGuide(unitX, top, bottom, color) {
        var guideRect = toCanvasRect([top, unitX, bottom, unitX]);
        fillThumbnailRect(canvasGraphics, guideRect[0], guideRect[1], 1, guideRect[3], color);
    }

    var pageRect = toCanvasRect(pageBounds);
    fillThumbnailRect(canvasGraphics, pageRect[0], pageRect[1], pageRect[2], pageRect[3], THUMBNAIL_COLORS.page);

    /* 選択したテキスト / selected text */
    if (thumbnailModel.selectionBounds) {
        var selectionRect = toCanvasRect(thumbnailModel.selectionBounds);
        fillThumbnailRect(canvasGraphics, selectionRect[0], selectionRect[1], selectionRect[2], selectionRect[3], THUMBNAIL_COLORS.selection);
    }

    /* マージンと段のガイド / margin and column guides */
    var marginBounds = [
        pageBounds[0] + thumbnailModel.topMargin,
        pageBounds[1] + thumbnailModel.sideMargins[0],
        pageBounds[2] - thumbnailModel.bottomMargin,
        pageBounds[3] - thumbnailModel.sideMargins[1]
    ];
    var pageColumnWidth = ((marginBounds[3] - marginBounds[1]) - thumbnailModel.pageColumnGutter * (thumbnailModel.pageColumnCount - 1)) / thumbnailModel.pageColumnCount;
    for (var pageColumnIndex = 1; pageColumnIndex < thumbnailModel.pageColumnCount; pageColumnIndex++) {
        var gutterLeft = marginBounds[1] + pageColumnIndex * pageColumnWidth + (pageColumnIndex - 1) * thumbnailModel.pageColumnGutter;
        drawVerticalGuide(gutterLeft, marginBounds[0], marginBounds[2], THUMBNAIL_COLORS.column);
        drawVerticalGuide(gutterLeft + thumbnailModel.pageColumnGutter, marginBounds[0], marginBounds[2], THUMBNAIL_COLORS.column);
    }
    var marginRect = toCanvasRect(marginBounds);
    strokeThumbnailRect(canvasGraphics, marginRect[0], marginRect[1], marginRect[2], marginRect[3], THUMBNAIL_COLORS.margin);

    /* 親フレームとその段 / parent frame and its columns */
    var parentModel = thumbnailModel.parentFrame;
    if (parentModel) {
        var parentRect = toCanvasRect(parentModel.bounds);
        strokeThumbnailRect(canvasGraphics, parentRect[0], parentRect[1], parentRect[2], parentRect[3], THUMBNAIL_COLORS.parentFrame);
        var contentLeft = parentModel.bounds[1] + parentModel.insetLeft;
        var contentWidth = (parentModel.bounds[3] - parentModel.bounds[1]) - parentModel.insetLeft - parentModel.insetRight;
        var frameColumnWidth = (contentWidth - parentModel.columnGutter * (parentModel.columnCount - 1)) / parentModel.columnCount;
        for (var frameColumnIndex = 1; frameColumnIndex < parentModel.columnCount; frameColumnIndex++) {
            var frameGutterLeft = contentLeft + frameColumnIndex * frameColumnWidth + (frameColumnIndex - 1) * parentModel.columnGutter;
            drawVerticalGuide(frameGutterLeft, parentModel.bounds[0], parentModel.bounds[2], THUMBNAIL_COLORS.parentFrame);
            drawVerticalGuide(frameGutterLeft + parentModel.columnGutter, parentModel.bounds[0], parentModel.bounds[2], THUMBNAIL_COLORS.parentFrame);
        }
    }

    strokeThumbnailRect(canvasGraphics, pageRect[0], pageRect[1], pageRect[2], pageRect[3], THUMBNAIL_COLORS.pageFrame);

    /* 作成するフレーム（ページからはみ出す分も描く）/ the new frame (drawn even where it leaves the page) */
    if (thumbnailModel.newFrameBounds) {
        var newFrameRect = toCanvasRect(thumbnailModel.newFrameBounds);
        fillThumbnailRect(canvasGraphics, newFrameRect[0], newFrameRect[1], Math.max(2, newFrameRect[2]), Math.max(2, newFrameRect[3]), THUMBNAIL_COLORS.newFrame);
        strokeThumbnailRect(canvasGraphics, newFrameRect[0], newFrameRect[1], Math.max(2, newFrameRect[2]), Math.max(2, newFrameRect[3]), THUMBNAIL_COLORS.accent);
    }
}

// =========================================
// メイン処理 / Main
// =========================================

(function () {

    if (app.documents.length === 0) {
        alert(getLabel("alert.noDocument"));
        return;
    }

    var selectedText     = null;
    var isInsertionPoint = false;
    var hasNoSelection   = false;

    if (app.selection.length === 0) {
        hasNoSelection = true;
    } else if (app.selection.length !== 1) {
        alert(getLabel("alert.selectTextBeforeRun"));
        return;
    } else {
        selectedText = app.selection[0];
        if (selectedText.constructor && selectedText.constructor.name === "InsertionPoint") {
            isInsertionPoint = true;
        } else if (!isTextSelection(selectedText)) {
            alert(getLabel("alert.selectText"));
            return;
        }
    }

    var activeDoc = app.activeDocument;

    /* 選択テキストの外接矩形（挿入ポイント・未選択時は取得しない）/ Bounds of the selection (skipped for insertion points and empty selections) */
    var selectionBounds = null;
    var hasTextBounds   = false;
    if (!isInsertionPoint && !hasNoSelection) {
        selectionBounds = getTextSelectionBounds(selectedText);
        if (!selectionBounds) {
            alert(getLabel("alert.boundsError"));
            return;
        }
        hasTextBounds = true;
    }

    var selectionWidth  = hasTextBounds ? (selectionBounds[3] - selectionBounds[1]) : 0;
    var selectionHeight = hasTextBounds ? (selectionBounds[2] - selectionBounds[0]) : 0;

    /* 大きさ・位置の計算と縮小図に渡す選択の情報 / Selection info for the size, position and thumbnail */
    var frameContext = {
        selectedText: selectedText,
        isInsertionPoint: isInsertionPoint,
        hasNoSelection: hasNoSelection,
        hasTextBounds: hasTextBounds,
        selectionBounds: selectionBounds,
        selectionWidth: selectionWidth,
        selectionHeight: selectionHeight
    };

    /* オブジェクトスタイル一覧 / Object style list */
    var objectStyleNames = [];
    for (var objectStyleIndex = 0; objectStyleIndex < activeDoc.objectStyles.length; objectStyleIndex++) {
        objectStyleNames.push(activeDoc.objectStyles[objectStyleIndex].name);
    }

    /* 段落スタイル一覧と既定選択位置 / Paragraph style list and the default selection */
    var paragraphStyleNames = [];
    var defaultParaStyleIndex = 0;
    for (var paraStyleIndex = 0; paraStyleIndex < activeDoc.paragraphStyles.length; paraStyleIndex++) {
        var paragraphStyleName = activeDoc.paragraphStyles[paraStyleIndex].name;
        paragraphStyleNames.push(paragraphStyleName);
        if (paragraphStyleName === DEFAULT_PARA_STYLE_NAME || paragraphStyleName.indexOf(DEFAULT_PARA_STYLE_HINT) !== -1) {
            defaultParaStyleIndex = paraStyleIndex;
        }
    }

    /* 回り込みの選択肢 / Text wrap options */
    var wrapOptionLabels = [
        getLabel("wrap.none"),
        getLabel("wrap.boundingBox"),
        getLabel("wrap.contour"),
        getLabel("wrap.jumpObject"),
        getLabel("wrap.nextColumn")
    ];
    var wrapOptionModes = [
        TextWrapModes.NONE,
        TextWrapModes.BOUNDING_BOX_TEXT_WRAP,
        TextWrapModes.CONTOUR,
        TextWrapModes.JUMP_OBJECT_TEXT_WRAP,
        TextWrapModes.NEXT_COLUMN_TEXT_WRAP
    ];

    /* 「なし」オブジェクトスタイルの位置 / Index of the "None" object style */
    var noneObjectStyleIndex = 0;
    for (var i = 0; i < objectStyleNames.length; i++) {
        if (objectStyleNames[i] === NONE_OBJECT_STYLE_NAMES[0] || objectStyleNames[i] === NONE_OBJECT_STYLE_NAMES[1]) {
            noneObjectStyleIndex = i;
            break;
        }
    }

    // ---------------------------------------
    // ダイアログ / Dialog
    // ---------------------------------------
    var dialogTitle = (isInsertionPoint || hasNoSelection)
        ? getLabel("dialog.titleNoSelection")
        : getLabel("dialog.title");

    var createFrameDialog = new Window("dialog", dialogTitle);
    setupWindow(createFrameDialog);

    /* 配置方法パネル / Placement panel */
    var placementPanel = createFrameDialog.add("panel", undefined, getLabel("panel.method"));
    setupPanel(placementPanel, 6);
    placementPanel.alignChildren = ["left", "top"];

    var graphicFrameRadio = placementPanel.add("radiobutton", undefined, getLabel("radio.graphicFrame"));
    var inlineFrameRadio  = placementPanel.add("radiobutton", undefined, getLabel("radio.inlineFrame"));
    if (isInsertionPoint || hasNoSelection) {
        graphicFrameRadio.value = true;
        /* 未選択時は挿入位置がないためインラインを無効化 / Inline needs an insertion point, so disable it when nothing is selected */
        if (hasNoSelection) inlineFrameRadio.enabled = false;
    } else {
        inlineFrameRadio.value = true;
    }

    /* 2カラムレイアウト / Two-column layout */
    var mainColumnsRow = createFrameDialog.add("group");
    setupRow(mainColumnsRow, "fill", COLUMN_SPACING);
    mainColumnsRow.alignChildren = ["fill", "top"];

    var leftColumn = mainColumnsRow.add("group");
    leftColumn.orientation = "column";
    leftColumn.alignChildren = ["fill", "top"];
    leftColumn.spacing = PANEL_SPACING;

    var frameSizePanel = leftColumn.add("panel", undefined, getLabel("panel.frameSize"));
    setupPanel(frameSizePanel, 8);

    /* 幅パネル / Width panel */
    var widthPanel = frameSizePanel.add("panel", undefined, getLabel("panel.width"));
    setupPanel(widthPanel, 6);
    widthPanel.alignChildren = ["left", "top"];

    var widthFromTextRadio        = widthPanel.add("radiobutton", undefined, getLabel("radio.widthText"));
    var widthFromColumnRadio      = widthPanel.add("radiobutton", undefined, getLabel("radio.widthColumn"));
    var widthFromParentFrameRadio = widthPanel.add("radiobutton", undefined, getLabel("radio.widthFrame"));
    var widthFromMarginRadio      = widthPanel.add("radiobutton", undefined, getLabel("radio.widthMargin"));

    if (isInsertionPoint || hasNoSelection) {
        widthFromMarginRadio.value = true;
        widthFromTextRadio.enabled = false;
        if (hasNoSelection) {
            widthFromColumnRadio.enabled = false;
            widthFromParentFrameRadio.enabled = false;
        }
    } else {
        widthFromColumnRadio.value = true;
    }

    /* 高さパネル（テキスト外接矩形が使えないときのみ）/ Height panel (only when text bounds are unavailable) */
    var heightInput      = null;
    var heightLinesRadio = null;
    var heightSizeRadio  = null;
    if (!hasTextBounds) {
        var heightPanel = frameSizePanel.add("panel", undefined, getLabel("panel.height"));
        setupPanel(heightPanel, 6);
        heightPanel.alignChildren = ["left", "top"];

        heightLinesRadio = heightPanel.add("radiobutton", undefined, getLabel("radio.heightLines"));
        heightLinesRadio.helpTip = getLabel("tooltip.heightLines");
        heightSizeRadio = heightPanel.add("radiobutton", undefined, getLabel("radio.heightSize"));

        var heightInputRow = heightPanel.add("group");
        setupRow(heightInputRow, "left", 6);

        /* ∧∨と入力欄は隙間0で突き合わせる。下限は行数か mm かで切り替える
           butt the stepper against the field; the minimum follows lines or mm */
        var heightStepperGroup = heightInputRow.add("group");
        heightStepperGroup.orientation = "row";
        heightStepperGroup.alignChildren = ["left", "center"];
        heightStepperGroup.spacing = 0;
        heightStepperGroup.margins = 0;
        var heightStepOptions = { step: 1, min: hasNoSelection ? MIN_HEIGHT_IN_MM : MIN_HEIGHT_IN_LINES,
            onStep: function () { updateThumbnail(); } };
        var heightStepper = addStepper(heightStepperGroup, function () { return heightInput; }, heightStepOptions);
        heightInput = heightStepperGroup.add("edittext", undefined, hasNoSelection ? DEFAULT_HEIGHT_IN_MM : DEFAULT_HEIGHT_IN_LINES);
        heightInput.characters = HEIGHT_INPUT_CHARACTERS;
        bindSteppedArrowKeys(heightInput, heightStepper);
        if (!hasNoSelection) heightInput.helpTip = getLabel("tooltip.heightLines");

        var heightUnitLabel = heightInputRow.add("statictext", undefined,
            hasNoSelection ? getLabel("unit.mm") : getLabel("unit.lines"));

        /* 未選択時は行送りを参照できないため行数モードを無効化 / Without a selection there is no leading to read, so disable line-count mode */
        if (hasNoSelection) {
            heightSizeRadio.value = true;
            heightLinesRadio.enabled = false;
        } else {
            heightLinesRadio.value = true;
        }

        heightLinesRadio.onClick = function () {
            heightInput.text = DEFAULT_HEIGHT_IN_LINES;
            heightStepOptions.min = MIN_HEIGHT_IN_LINES;
            heightUnitLabel.text = getLabel("unit.lines");
            updateThumbnail();
        };
        heightSizeRadio.onClick = function () {
            heightInput.text = DEFAULT_HEIGHT_IN_MM;
            heightStepOptions.min = MIN_HEIGHT_IN_MM;
            heightUnitLabel.text = getLabel("unit.mm");
            updateThumbnail();
        };
        heightInput.onChanging = function () { updateThumbnail(); };
        heightInput.onChange = function () { updateThumbnail(); };
    }

    /* 右カラム / Right column */
    var rightColumn = mainColumnsRow.add("group");
    rightColumn.orientation = "column";
    rightColumn.alignChildren = ["fill", "top"];
    rightColumn.spacing = PANEL_SPACING;

    var textSettingsPanel = rightColumn.add("panel", undefined, getLabel("panel.textSettings"));
    setupPanel(textSettingsPanel, 6);

    var paraStyleLabel    = textSettingsPanel.add("statictext", undefined, getLabel("field.paraStyle"));
    var paraStyleDropdown = textSettingsPanel.add("dropdownlist", undefined, paragraphStyleNames);
    paraStyleDropdown.selection = defaultParaStyleIndex;

    var autoLeadingCheckbox = textSettingsPanel.add("checkbox", undefined, getLabel("checkbox.autoLeading"));
    autoLeadingCheckbox.value = true;

    var objectSettingsPanel = rightColumn.add("panel", undefined, getLabel("panel.objectSettings"));
    setupPanel(objectSettingsPanel, 6);

    objectSettingsPanel.add("statictext", undefined, getLabel("field.objStyle"));
    var objectStyleDropdown = objectSettingsPanel.add("dropdownlist", undefined, objectStyleNames);
    objectStyleDropdown.selection = noneObjectStyleIndex;

    var wrapLabel    = objectSettingsPanel.add("statictext", undefined, getLabel("field.wrap"));
    var wrapDropdown = objectSettingsPanel.add("dropdownlist", undefined, wrapOptionLabels);
    wrapDropdown.selection = 0;

    /**
     * 現在の選択状態に合わせてコントロールの有効／無効を切り替える
     * @returns {void}
     */
    function updateDialogState() {
        var isInlinePlacement = inlineFrameRadio.value;
        var isNoneObjectStyle = (objectStyleDropdown.selection.index === noneObjectStyleIndex);

        /* グラフィックフレームでは挿入行の段落スタイルを使わない / The inserted-line paragraph style only applies to inline placement */
        paraStyleLabel.enabled      = isInlinePlacement;
        paraStyleDropdown.enabled   = isInlinePlacement;
        autoLeadingCheckbox.enabled = isInlinePlacement;

        var disableWidthFromText        = !hasTextBounds;
        var disableWidthFromColumn      = hasNoSelection;
        var disableWidthFromParentFrame = isInlinePlacement || hasNoSelection;
        var disableWidthFromMargin      = isInlinePlacement;

        widthFromTextRadio.enabled        = !disableWidthFromText;
        widthFromColumnRadio.enabled      = !disableWidthFromColumn;
        widthFromParentFrameRadio.enabled = !disableWidthFromParentFrame;
        widthFromMarginRadio.enabled      = !disableWidthFromMargin;

        /* 選択中の項目が無効になったら、有効な項目へ移す / Move the selection to an enabled option when the current one is disabled */
        if ((widthFromTextRadio.value && disableWidthFromText) ||
            (widthFromColumnRadio.value && disableWidthFromColumn) ||
            (widthFromParentFrameRadio.value && disableWidthFromParentFrame) ||
            (widthFromMarginRadio.value && disableWidthFromMargin)) {
            if (!disableWidthFromText) {
                widthFromTextRadio.value = true;
            } else if (!disableWidthFromColumn) {
                widthFromColumnRadio.value = true;
            } else if (!disableWidthFromParentFrame) {
                widthFromParentFrameRadio.value = true;
            } else if (!disableWidthFromMargin) {
                widthFromMarginRadio.value = true;
            }
        }

        /* 回り込みはページ配置かつオブジェクトスタイルが「なし」のときだけ有効 / Text wrap applies only to page placement with the "None" object style */
        wrapLabel.enabled    = !isInlinePlacement && isNoneObjectStyle;
        wrapDropdown.enabled = !isInlinePlacement && isNoneObjectStyle;

        /* 幅の選択が移ることがあるので描き直す / the width option may have moved, so redraw */
        updateThumbnail();
    }

    /**
     * 幅の選択から、resolveFrameWidth() に渡す幅の決め方を返す
     * @returns {string} "column" | "parentFrame" | "margin" | "text"
     */
    function readWidthMode() {
        if (widthFromColumnRadio.value) return "column";
        if (widthFromParentFrameRadio.value) return "parentFrame";
        if (widthFromMarginRadio.value) return "margin";
        return "text";
    }

    /**
     * 高さの欄から、resolveFrameHeight() に渡す指定を返す
     * @returns {{useLines: boolean, inputText: string}|null} 高さの欄が無いときは null
     */
    function readHeightSettings() {
        if (!(heightLinesRadio && heightSizeRadio)) return null;
        return { useLines: heightLinesRadio.value, inputText: heightInput.text };
    }

    /* 作成するフレームの縮小図（ダイアログの幅いっぱい）/ Thumbnail of the new frame (full dialog width) */
    var thumbnailModel = null;
    var thumbnailCanvas = addThumbnailCanvas(createFrameDialog, THUMBNAIL_SIZE, function (canvasGraphics, canvasWidth, canvasHeight) {
        drawFrameThumbnail(canvasGraphics, canvasWidth, canvasHeight, thumbnailModel);
    }, true);
    thumbnailCanvas.helpTip = getLabel("tooltip.thumbnail");

    /**
     * 今の設定で作成するフレームを求め直し、縮小図を描き直す（描画域を作る前に呼ばれたら何もしない）
     * @returns {void}
     */
    function updateThumbnail() {
        if (!thumbnailCanvas) return;
        thumbnailModel = buildFrameThumbnail(frameContext, inlineFrameRadio.value,
            resolveFrameWidth(frameContext, readWidthMode()),
            resolveFrameHeight(frameContext, readHeightSettings()));
        redrawThumbnailCanvas(thumbnailCanvas);
    }

    updateDialogState();
    graphicFrameRadio.onClick     = updateDialogState;
    inlineFrameRadio.onClick      = updateDialogState;
    objectStyleDropdown.onChange  = updateDialogState;
    widthFromTextRadio.onClick        = updateThumbnail;
    widthFromColumnRadio.onClick      = updateThumbnail;
    widthFromParentFrameRadio.onClick = updateThumbnail;
    widthFromMarginRadio.onClick      = updateThumbnail;

    var buttonRow = addButtonRow(createFrameDialog);
    var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
    var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
    alignRightOnlyButtonRow(buttonRow);

    addVersionFooter(createFrameDialog);
    if (createFrameDialog.show() !== 1) return;

    // ---------------------------------------
    // 入力値の確定 / Resolve settings
    // ---------------------------------------
    var useInlinePlacement    = inlineFrameRadio.value;
    var selectedObjStyleIndex = objectStyleDropdown.selection.index;
    var selectedWrapMode      = wrapOptionModes[wrapDropdown.selection.index];
    var selectedParaStyleIdx  = paraStyleDropdown.selection.index;
    var useAutoLeading        = autoLeadingCheckbox.value;

    /* フレームの高さと幅（縮小図と同じ計算）/ Frame height and width (same computation as the thumbnail) */
    var frameHeight = resolveFrameHeight(frameContext, readHeightSettings());
    var frameWidth  = resolveFrameWidth(frameContext, readWidthMode());

    // ---------------------------------------
    // フレーム作成 / Frame creation
    // ---------------------------------------

    /**
     * インライン（アンカー付き）でフレームを挿入する
     * @returns {void}
     */
    function createInlineFrame() {
        var anchorFrame = getInsertionPointTextFrame(selectedText);
        if (!anchorFrame) {
            alert(getLabel("alert.parentFrameError"));
            return;
        }

        var anchorStory = anchorFrame.parentStory;
        var charIndex = isInsertionPoint ? selectedText.index : selectedText.characters[0].index;

        /* 元のテキストの段落スタイルを控える / Remember the original paragraph style */
        var originalParaStyle = null;
        var originalParagraph = null;
        if (!isInsertionPoint) {
            originalParaStyle = selectedText.characters[0].appliedParagraphStyle;
            originalParagraph = selectedText.characters[0].paragraphs[0];
        }

        /* 直前が改行でなければ改行を挿入 / Insert a return unless the previous character already is one */
        var needsLeadingReturn = (charIndex > 0) && (anchorStory.characters[charIndex - 1].contents !== "\r");
        if (needsLeadingReturn) {
            anchorStory.insertionPoints[charIndex].contents = "\r";
            charIndex = charIndex + 1;
        }

        var anchorInsertionPoint = anchorStory.insertionPoints[charIndex];
        var anchoredRectangle = anchorInsertionPoint.rectangles.add();
        anchoredRectangle.geometricBounds = [0, 0, frameHeight, frameWidth];
        anchoredRectangle.contentType = ContentType.GRAPHIC_TYPE;
        anchoredRectangle.anchoredObjectSettings.anchoredPosition = AnchorPosition.ANCHORED;
        anchoredRectangle.appliedObjectStyle = activeDoc.objectStyles[selectedObjStyleIndex];

        /* フレーム挿入で文字が 1 つ増えるため、その次の位置に改行を入れる / The inline frame adds one character, so the return goes after it */
        anchorStory.insertionPoints[charIndex + 1].contents = "\r";

        var anchorParagraph = anchorInsertionPoint.paragraphs[0];
        anchorParagraph.appliedParagraphStyle = activeDoc.paragraphStyles[selectedParaStyleIdx];

        if (useAutoLeading) {
            anchorParagraph.autoLeading = 100;
            anchorParagraph.leading = Leading.AUTO;
        }

        if (originalParagraph && originalParaStyle) {
            try {
                originalParagraph.appliedParagraphStyle = originalParaStyle;
            } catch (e) {}
        }
    }

    /**
     * ページ上にグラフィックフレームを作成する
     * @returns {void}
     */
    function createGraphicFrameOnPage() {
        var destinationPage = resolveDestinationPage(frameContext);

        if (!destinationPage) {
            alert(getLabel("alert.parentPageError"));
            return;
        }

        var frameTopLeft = resolveFrameTopLeft(frameContext, destinationPage);
        var frameTop  = frameTopLeft[0];
        var frameLeft = frameTopLeft[1];

        var graphicRectangle = destinationPage.rectangles.add();
        graphicRectangle.geometricBounds = [frameTop, frameLeft, frameTop + frameHeight, frameLeft + frameWidth];
        graphicRectangle.contentType = ContentType.GRAPHIC_TYPE;
        graphicRectangle.appliedObjectStyle = activeDoc.objectStyles[selectedObjStyleIndex];

        /* 回り込みはオブジェクトスタイルが「なし」のときだけ設定 / Apply text wrap only with the "None" object style */
        if (selectedObjStyleIndex === noneObjectStyleIndex) {
            graphicRectangle.textWrapPreferences.textWrapMode = selectedWrapMode;
        }
    }

    /* 一括で取り消せるように doScript でまとめて実行 / Run through doScript so the whole run is a single undo step */
    app.doScript(function () {
        if (useInlinePlacement) {
            createInlineFrame();
        } else {
            createGraphicFrameOnPage();
        }
    }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, getLabel("undo.createFrame"));

})();
