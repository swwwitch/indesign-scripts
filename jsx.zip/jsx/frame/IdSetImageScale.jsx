#target indesign
#targetengine "IdSetImageScale"

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdSetImageScale
Name=画像の縮尺率を変更してフレームを合わせる
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.4.6
Release-Date=2026-09-26
Description-BEGIN
選択したフレーム内の画像の縮尺率を、パレットで数値・幅・高さ・PPI・プリセット・マージン幅・親フレームの段幅から指定して変更し、フレームを画像に合わせます。

Changes the scale of the image in each selected frame, set from a palette by value, width, height, PPI, preset, margin width or parent column width, and fits the frame to the image.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択したフレーム内の画像の縮尺率を、パレットで数値・幅・高さ・PPI・プリセット・マージン幅・親フレームの段幅から指定して変更し、フレームを画像に合わせます。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdSetImageScale.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n91c6a628b7ed

### Overview

Changes the scale of the image in each selected frame, set from a palette by value, width, height, PPI, preset, margin width or parent column width, and fits the frame to the image.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdSetImageScale.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdSetImageScale";              /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.4.6";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-09-26";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "画像の縮尺率を変更してフレームを合わせる"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdSetImageScale.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdSetImageScale.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n91c6a628b7ed"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/frame/IdSetImageScale.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // 基本設定 / Settings
    // =========================================
    var DEFAULT_SCALE_PERCENT = 10;                        /* 縮尺率の初期値（現在値が混在のとき）（%） / default scale when current values differ (%) */
    var SCALE_STEPS   = [-10, 10, -5, 5, -1, 1];           /* 増減ボタンの量（2列で −／＋ の対に並ぶ順） / step buttons, in −/+ pairs */
    var SCALE_PRESETS = [10, 15, 20, 25, 30, 35, 40, 50, 100, 200, 300];   /* プリセットの縮尺率（%） / preset scales (%) */

    /* 幅に合わせるときの基準 / Width references for fitting */
    var FIT_MODE = {
        margin:    "margin",      /* ページのマージン幅 / page margin width */
        textFrame: "textFrame",   /* 親テキストフレームの段幅 / column width of the parent text frame */
        width:     "width",       /* 幅の欄に入力した幅 / width typed in the Width field */
        height:    "height",      /* 高さの欄に入力した高さ / height typed in the Height field */
        ppi:       "ppi"          /* PPI の欄に入力した有効 PPI / effective PPI typed in the PPI field */
    };

    /* 幅・高さで指定するときに比べる、縮尺率 100% のときの寸法 / natural size used by the Width / Height fields */
    var NATURAL_LENGTH_KEY = {
        width:  "naturalWidthPt",
        height: "naturalHeightPt"
    };

    var POINTS_PER_MM = 72 / 25.4;   /* 1mm あたりの pt / points per millimeter */
    var FIELD_STEP_MIN = 0.1;        /* ∧∨・↑↓キーで下げられる下限（縮尺率・幅・高さ・PPI は 0 より大きい値のみ有効） / lowest value the steppers reach */

    var DEFAULT_ANCHOR_INDEX = 0;    /* 基準点の初期値（0..8 を行優先。0=左上, 4=中央, 8=右下）/ default reference point, row-major 0..8 */

    /* キーボードショートカットの初期値（機能 ID → 「修飾キー+キー」）/ default shortcuts: action ID → "modifiers+key" */
    var DEFAULT_SHORTCUTS = {
        "preset:100": "option+1",
        "fit:margin": "option+0"
    };
    /* 管理画面で選べる修飾キー。修飾キーなしは入力欄への文字入力とぶつかるので選べない / selectable modifiers (none would clash with typing) */
    var SHORTCUT_MODIFIERS = ["option", "control", "control+option"];
    var SHORTCUT_KEYS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");   /* 管理画面で選べるキー / selectable keys */

    /* InDesign には任意の値を残す環境設定 API が無いので、設定ファイルに key=value で書き出す
       / InDesign has no scriptable preference store, so settings go to a key=value file */
    var PREFS_FILE_NAME      = "IdSetImageScale-prefs.txt";
    var PREF_SHORTCUT_PREFIX = "shortcut.";

    // =========================================
    // レイアウト / Layout
    // =========================================
    var SCALE_FIELD_CHARS      = 5;    /* 縮尺率欄の文字数 / scale field width in characters */
    var LENGTH_FIELD_CHARS     = 7;    /* 幅・高さの欄の文字数（小数の mm が入る）/ width & height fields in characters (fit decimal mm) */
    var ROW_LABEL_WIDTH        = 96;   /* 行ラベルの幅 / row label width */
    var COMPACT_BUTTON_WIDTH   = 44;   /* 小さいボタンの幅（増減・プリセット） / compact button width */
    var COMPACT_BUTTON_HEIGHT  = 20;   /* 小さいボタンの高さ / compact button height */
    var COMPACT_FONT_REDUCTION = 2;    /* 小さいボタンの文字サイズの縮小量（pt） / font size reduction for compact buttons */
    var INFO_TEXT_CHARS        = 12;   /* ピクセル寸法の表示幅（文字数）。更新で値が長くなっても切れないように / width of the pixel size text */
    var INFO_BOTTOM_GAP        = 10;   /* ピクセル寸法の下に足す余白（ボタン類との区切り） / extra gap below the pixel size row */
    var COMPACT_BUTTON_SPACING = 4;    /* 小さいボタンの間隔 / gap between compact buttons */
    var STEPS_PER_ROW          = 2;    /* 増減ボタンの1行の個数 / step buttons per row */
    var ANCHOR_WIDGET_SIZE     = 66;   /* 9軸ウィジェット全体の大きさ / overall size of the 9-axis widget */
    var ANCHOR_CELL_SIZE       = 9;    /* 9軸の□1個のサイズ / size of one anchor square */
    var ANCHOR_CELL_GAP        = 7.5;  /* 9軸の□どうしの間隔 / gap between anchor squares */
    var PRESETS_PER_ROW        = 1;    /* プリセットボタンの1行の個数 / preset buttons per row */
    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    var COLUMN_PANEL_MARGINS   = [10, 16, 10, 10];   /* カラムのパネル余白 [左,上,右,下] / column panel margins */
    var ANCHOR_PANEL_MARGINS   = [4, 10, 4, 0];      /* 基準点パネルの余白 [左,上,右,下]。9軸自体に余白があるので詰める / anchor panel margins; the widget has its own padding */
    var SHORTCUT_LABEL_WIDTH   = 80;   /* 管理画面の機能名の幅 / action label width in the Manage dialog */
    var ROW_ITEM_SPACING       = 10;   /* 項目名の行・管理画面の行の中の要素間隔 / spacing inside labeled rows and shortcut rows */

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
        "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と異なる単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); }).helpTip = getLabel(upTooltip);
        makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); }).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) return;
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    // =========================================
    // ラベル定義 / Labels
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // バージョン表示（再利用パーツ） / Version footer (reusable)

    var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
    var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
    var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
    var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
    var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
    var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

    /* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
       9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
       / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
         nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
    var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
    var VERSION_FOOTER_GLYPHS = {
        "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
        "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
        "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
        "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
        "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
        "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
        "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
        "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
        "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
        "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
        "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
        "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
        "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
        "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
        "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
        "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
        "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
        "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
        "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
        "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
        "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
        "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
        "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
        "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
        "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
        "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
        "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
        "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
        "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
        "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
        "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
        "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
        "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
        "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
        "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
        "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
        "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
        "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
        "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
        "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
        "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
        "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
        "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
        "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
        "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
        "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
        "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
        "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
        "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
        "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
        "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
        "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
        "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
        "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
        "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
        "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
        "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
        "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
        "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
        ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
        "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
        "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
        "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
        " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
    };

    /**
     * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
     * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
     * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
     * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
     * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
     */
    function addVersionFooter(targetWindow) {
        if (targetWindow.versionFooter) return null;

        /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
        var lastChild = targetWindow.children[targetWindow.children.length - 1];
        if (lastChild && lastChild.type === "group") {
            var rowMargins = lastChild.margins;
            lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
        }
        var windowMargins = targetWindow.margins;
        targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

        var footerGroup = targetWindow.add("group");
        footerGroup.orientation = "row";
        footerGroup.alignment = ["fill", "bottom"];
        footerGroup.alignChildren = ["left", "center"];
        footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

        /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
           左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
           / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
             or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
        var versionText = String(SCRIPT_VERSION);
        var leftCandidates = [versionText];
        if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
        var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
        versionCanvas.alignment = ["fill", "center"];
        bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
        var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
        brandCanvas.alignment = ["right", "center"];
        brandCanvas.maximumSize = brandCanvas.preferredSize;
        targetWindow.versionFooter = footerGroup;
        return versionCanvas;
    }

    /**
     * 文字列のすべての文字に字形があるかを返す
     * @param {string} dotText - 文字列
     * @returns {boolean} すべてあれば true
     */
    function hasVersionFooterGlyphs(dotText) {
        for (var i = 0; i < dotText.length; i++) {
            if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
        }
        return dotText.length > 0;
    }

    /**
     * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
     * @param {Group} parentGroup - 足す先
     * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
     * @returns {Group} 描くグループ
     */
    function addVersionFooterCanvas(parentGroup, dotTexts) {
        var dotCanvas = parentGroup.add("group");
        var shortestText = dotTexts[dotTexts.length - 1];
        dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
        dotCanvas.helpTip = dotTexts[0];
        dotCanvas.onDraw = function () {
            var availableWidth = this.size ? this.size.width : 0;
            var drawText = shortestText;
            for (var i = 0; i < dotTexts.length; i++) {
                if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                    drawText = dotTexts[i];
                    break;
                }
            }
            drawVersionFooterDots(this.graphics, drawText);
        };
        return dotCanvas;
    }

    /**
     * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
     * @param {string} versionText - 文字列
     * @returns {number} 幅（ドット）
     */
    function measureVersionFooterDots(versionText) {
        var dotCount = 0;
        for (var i = 0; i < versionText.length; i++) {
            var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
            if (!glyphRows) continue;
            if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
            dotCount += glyphRows[0].length;
        }
        return dotCount;
    }

    /**
     * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
     * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
     * @param {string} versionText - 文字列
     * @returns {void}
     */
    function drawVersionFooterDots(canvasGraphics, versionText) {
        var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
        var dotSize = VERSION_FOOTER_PIXEL_SIZE;
        var cursorDots = 0;
        canvasGraphics.newPath();
        for (var i = 0; i < versionText.length; i++) {
            var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
            if (!glyphRows) continue;
            if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
            for (var row = 0; row < glyphRows.length; row++) {
                var rowText = glyphRows[row];
                var runStart = -1;
                for (var col = 0; col <= rowText.length; col++) {
                    var isDot = col < rowText.length && rowText.charAt(col) === "#";
                    if (isDot && runStart < 0) runStart = col;
                    if (!isDot && runStart >= 0) {
                        canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                        runStart = -1;
                    }
                }
            }
            cursorDots += glyphRows[0].length;
        }
        canvasGraphics.fillPath(footerBrush);
    }

    // -----------------------------------------
    // このスクリプトについて / About this script
    // -----------------------------------------
    /* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
       この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
       Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
       and keeps its own labels and layout values so the part works on its own */

    var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
    var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
    /* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
       The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
    var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
    var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
    var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

    var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
    var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
    var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
    var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
    var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
    var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
    var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
    /* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
    var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
    var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
    var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
    var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

    var VERSION_INFO_LABELS = {
        dialog: {
            title: { ja: "このスクリプトについて", en: "About This Script" }
        },
        panel: {
            generalInfo: { ja: "基本情報", en: "General" },
            links: { ja: "リンク", en: "Links" }
        },
        fieldLabel: {
            scriptName: { ja: "スクリプト名", en: "Script Name" },
            scriptFeature: { ja: "機能", en: "Feature" },
            scriptVersion: { ja: "バージョン", en: "Version" }
        },
        button: {
            openReadme: { ja: "README", en: "README" },
            openSourceCode: { ja: "ソースコード", en: "Source Code" },
            openArticle: { ja: "記事（note）", en: "Article (note)" },
            revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
            revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
            close: { ja: "閉じる", en: "Close" }
        },
        tooltip: {
            versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
            copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
        },
        alert: {
            copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
        }
    };

    /**
     * VERSION_INFO_LABELS の文言を今の言語で返す
     * @param {Object} labelEntry - { ja, en }
     * @returns {string} 文言
     */
    function getVersionInfoLabel(labelEntry) {
        return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
    }

    /**
     * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
     * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
     * @returns {string} 値
     */
    function getVersionInfoValue(variableKey) {
        var infoValue;
        if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
        else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
        else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
        else if (variableKey === "readme") {
            if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
            else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
        }
        else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
        else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
        return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
    }

    /**
     * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
     * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
     * @returns {void}
     */
    function bindVersionInfoClick(versionCanvas) {
        versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
        /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
           Open on mouseup so the release does not land on the footer after the dialog closes */
        versionCanvas.addEventListener("mouseup", function () {
            showVersionInfoDialog(versionCanvas.window.type === "palette");
        });
    }

    /**
     * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
     * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
     * @returns {void}
     */
    function showVersionInfoDialog(isFromPalette) {
        var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
        infoDialog.orientation = "column";
        infoDialog.alignChildren = "fill";
        infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
        infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

        var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
        /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
        /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
        if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
            addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
        }
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
        alignVersionInfoLabels(infoPanel);

        /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
        var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
        var linkButtonRow = linksPanel.add("group");
        linkButtonRow.orientation = "row";
        linkButtonRow.alignment = ["left", "center"];
        linkButtonRow.alignChildren = ["left", "center"];
        linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

        /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
        var buttonRow = infoDialog.add("group");
        buttonRow.orientation = "row";
        buttonRow.alignment = ["fill", "bottom"];
        buttonRow.alignChildren = ["left", "center"];
        buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
        buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
        var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
        var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
        if (VERSION_INFO_SCRIPT_FILE.exists) {
            revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
            revealButton.onClick = function () {
                revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
                infoDialog.close();
            };
        } else {
            revealButton.enabled = false;
        }
        /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
        var buttonSpacer = buttonRow.add("group");
        buttonSpacer.alignment = ["fill", "fill"];
        buttonSpacer.minimumSize.width = 0;
        var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
        closeButton.alignment = ["right", "center"];
        /* return でも esc でも閉じる / Close with both Return and Esc */
        infoDialog.defaultElement = closeButton;
        infoDialog.cancelElement = closeButton;
        infoDialog.onShow = function () {
            pinVersionInfoCopyButton(infoPanel);
        };
        infoDialog.show();
    }

    /**
     * 「このスクリプトについて」のダイアログにパネルを足す
     * @param {Window} infoDialog - 足す先のダイアログ
     * @param {Object} titleEntry - パネル名の文言 { ja, en }
     * @returns {Panel} パネル
     */
    function addVersionInfoPanel(infoDialog, titleEntry) {
        var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
        infoPanel.orientation = "column";
        infoPanel.alignChildren = ["fill", "top"];
        infoPanel.alignment = "fill";
        infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
        infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
        return infoPanel;
    }

    /**
     * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
     * @param {Panel} infoPanel - 足す先のパネル
     * @param {Object} labelEntry - 項目名の文言 { ja, en }
     * @param {string} valueText - 表示する値
     * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
     * @returns {StaticText} 値の statictext
     */
    function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
        var infoRow = infoPanel.add("group");
        infoRow.orientation = "row";
        infoRow.alignment = ["fill", "center"];
        infoRow.alignChildren = ["left", "center"];
        infoRow.spacing = VERSION_INFO_ROW_SPACING;
        /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
        var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
        rowLabel.justify = "right";
        var valueLabel = infoRow.add("statictext", undefined, valueText);
        if (copyFromPalette === null) return valueLabel;
        /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
           A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
        var copySpacer = infoRow.add("group");
        copySpacer.alignment = ["fill", "fill"];
        copySpacer.minimumSize.width = 0;
        infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
        return valueLabel;
    }

    /**
     * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
     * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
     * @param {Panel} infoPanel - ［基本情報］パネル
     * @returns {void}
     */
    function pinVersionInfoCopyButton(infoPanel) {
        var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
        for (var i = 0; i < infoPanel.children.length; i++) {
            var infoRow = infoPanel.children[i];
            if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
            infoRow.size = [innerWidth, infoRow.size.height];
            infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
        }
    }

    /**
     * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
     * @param {Panel} infoPanel - 対象のパネル
     * @returns {void}
     */
    function alignVersionInfoLabels(infoPanel) {
        var rowLabels = [];
        var labelWidth = 0;
        for (var i = 0; i < infoPanel.children.length; i++) {
            var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
            rowLabels.push(rowLabel);
            labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
        }
        for (var j = 0; j < rowLabels.length; j++) {
            rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
        }
    }

    /**
     * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
     * @param {Window} infoDialog - ボタンを置くダイアログ
     * @param {Group} buttonGroup - 足す先のグループ
     * @param {Object} labelEntry - ボタンの文言 { ja, en }
     * @param {string} targetUrl - 開く URL（空ならディム表示）
     * @returns {void}
     */
    function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
        var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
        if (!targetUrl) {
            linkButton.enabled = false;
            return;
        }
        linkButton.helpTip = targetUrl;
        linkButton.onClick = function () {
            openVersionInfoUrl(targetUrl);
            infoDialog.close();
        };
    }

    /**
     * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
     * @param {Group} infoRow - 足す先の行
     * @param {StaticText} valueLabel - コピーする値の statictext
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
     * @returns {Group} ボタンとして使う group
     */
    function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
        var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
        var copyButton = infoRow.add("group");
        copyButton.preferredSize = [buttonSize, buttonSize];
        copyButton.minimumSize = [buttonSize, buttonSize];
        copyButton.maximumSize = [buttonSize, buttonSize];
        copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
        copyButton.isPressed = false;
        copyButton.isCopied = false;

        copyButton.onDraw = function () {
            var buttonGraphics = copyButton.graphics;
            var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
            buttonGraphics.newPath();
            buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
            buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
            buttonGraphics.newPath();
            buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
            buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
            if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
            else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
        };

        /**
         * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
         * @param {boolean} isPressed - 押下中なら true
         * @param {boolean} isCopied - コピー済みなら true
         * @returns {void}
         */
        function repaint(isPressed, isCopied) {
            if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
            copyButton.isPressed = isPressed;
            copyButton.isCopied = isCopied;
            copyButton.hide();
            copyButton.show();
        }
        copyButton.addEventListener("mousedown", function () { repaint(true, false); });
        copyButton.addEventListener("mouseup", function () {
            if (!copyButton.isPressed) return;
            var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
            repaint(false, hasCopied);
            if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
        });
        /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
        copyButton.addEventListener("mouseout", function () { repaint(false, false); });
        return copyButton;
    }

    /**
     * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
     * @param {ScriptUIGraphics} buttonGraphics - 描画先
     * @param {number} buttonSize - ボタンの一辺
     * @returns {void}
     */
    function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
        var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
        var sheetSize = 9;
        var offset = 3;
        var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
        var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
        var backLeft = frontLeft - offset;
        var backTop = frontTop - offset;
        /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
        buttonGraphics.newPath();
        buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
        buttonGraphics.lineTo(backLeft, backTop + sheetSize);
        buttonGraphics.lineTo(backLeft, backTop);
        buttonGraphics.lineTo(backLeft + sheetSize, backTop);
        buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
        buttonGraphics.strokePath(iconPen);
        buttonGraphics.newPath();
        buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
        buttonGraphics.strokePath(iconPen);
    }

    /**
     * コピーしたあとのチェックマークを描く
     * @param {ScriptUIGraphics} buttonGraphics - 描画先
     * @param {number} buttonSize - ボタンの一辺
     * @returns {void}
     */
    function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
        var center = buttonSize / 2;
        buttonGraphics.newPath();
        buttonGraphics.moveTo(center - 4.5, center);
        buttonGraphics.lineTo(center - 1.5, center + 3);
        buttonGraphics.lineTo(center + 4.5, center - 3.5);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
    }

    /**
     * 文字列をクリップボードにコピーする。
     * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
     * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
     * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
     * @param {string} copyText - コピーする文字列
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
     * @returns {boolean} コピーの操作まで進めたら true
     */
    function copyVersionInfoText(copyText, isFromPalette) {
        try {
            if (VERSION_INFO_IS_INDESIGN) {
                if (File.fs === "Windows") {
                    app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
                } else {
                    app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
                }
                return true;
            }
            var copyScript = buildVersionInfoCopyScript(copyText);
            if (!isFromPalette) return eval(copyScript) === true;
            var copyMessage = new BridgeTalk();
            copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
            copyMessage.body = copyScript;
            copyMessage.send();
            return true;
        } catch (e) {
            return false;
        }
    }

    /**
     * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
     * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
     * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
     * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
     * @param {string} copyText - コピーする文字列
     * @returns {string} 実行すると true / false を返すスクリプト
     */
    function buildVersionInfoCopyScript(copyText) {
        return [
            "(function (copyText) {",
            "    var usingTempDoc = (app.documents.length === 0);",
            "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
            "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
            "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
            "    var tempLayer = null;",
            "    var hasCopied = false;",
            "    try {",
            "        tempLayer = targetDoc.layers.add();",
            "        var tempFrame = tempLayer.textFrames.add();",
            "        tempFrame.contents = copyText;",
            "        app.redraw();",
            "        app.executeMenuCommand('deselectall');",
            "        tempFrame.selected = true;",
            "        app.redraw();",
            "        app.executeMenuCommand('copy');",
            "        app.redraw();",
            "        hasCopied = true;",
            "    } catch (e) { }",
            "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
            "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
            "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
            "    targetDoc.selection = null;",
            "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
            "    app.redraw();",
            "    return hasCopied;",
            "})(" + quoteVersionInfoString(copyText) + ");"
        ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
    }

    /**
     * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
     * @param {string} sourceText - 文字列
     * @returns {string} "…" の形のリテラル
     */
    function quoteVersionInfoString(sourceText) {
        return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
    }

    /**
     * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
     * @param {File} scriptFile - 表示するファイル
     * @returns {void}
     */
    function revealVersionInfoScriptFile(scriptFile) {
        /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
        var hasRevealApp = (File.fs === "Macintosh")
            && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
        /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
        if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
        /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
        scriptFile.parent.execute();
    }

    /**
     * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
     * @param {string} targetPath - 絶対パス
     * @returns {boolean} 書き出せたら true
     */
    function writeVersionInfoRevealPath(targetPath) {
        var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
        pathFile.encoding = "UTF-8";
        pathFile.lineFeed = "Unix";
        if (!pathFile.open("w")) return false;
        var hasWritten = pathFile.write(targetPath);
        pathFile.close();
        return hasWritten;
    }

    /**
     * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
     * @param {string} targetUrl - 開く URL
     * @returns {void}
     */
    function openVersionInfoUrl(targetUrl) {
        var isMac = (File.fs === "Macintosh");
        var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
        shortcutFile.encoding = "UTF-8";
        shortcutFile.open("w");
        if (isMac) {
            var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
            shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
                + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
        } else {
            shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
        }
        shortcutFile.close();
        shortcutFile.execute();
    }

    // バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

    var LABELS = {
        palette: {
            title: { ja: "画像の縮尺率とフレームの合わせ", en: "Scale Images and Fit Frames" }
        },
        manageDialog: {
            title: { ja: "管理：キーボードショートカット", en: "Manage: Keyboard Shortcuts" }
        },
        field: {
            scale:        { ja: "縮尺率", en: "Scale" },
            width:        { ja: "幅", en: "Width" },
            height:       { ja: "高さ", en: "Height" },
            ppi:          { ja: "PPI", en: "PPI" },
            pixelSize:    { ja: "ピクセル寸法", en: "Pixel size" },
            step:         { ja: "増減", en: "Adjust" },
            preset:       { ja: "プリセット", en: "Presets" },
            fitWidth:     { ja: "幅に合わせる", en: "Fit width" },
            anchor:       { ja: "基準点", en: "Reference point" }
        },
        value: {
            mixed:    { ja: "混在", en: "Mixed" },
            perFrame: { ja: "個別", en: "Varies" },
            none:     { ja: "—", en: "—" },
            noModifier: { ja: "なし", en: "None" }
        },
        checkbox: {
            roundToInteger: { ja: "縮尺率を整数に丸める", en: "Round scale to whole numbers" }
        },
        button: {
            fitMargin:    { ja: "マージン幅", en: "Margins" },
            fitTextFrame: { ja: "親フレーム", en: "Parent Frame" },
            manage:       { ja: "管理", en: "Manage" },
            cancel:       { ja: "キャンセル", en: "Cancel" },
            ok:           { ja: "OK", en: "OK" }
        },
        tooltip: {
            manage: { ja: "キーボードショートカットを設定する管理画面を表示します。", en: "Opens the window for setting keyboard shortcuts." },
            shortcutModifier: { ja: "修飾キー。「なし」でショートカットを外します。", en: "Modifier keys. Choose None to remove the shortcut." },
            shortcutKey: { ja: "組み合わせるキー", en: "Key to combine with the modifiers" },
            scale: {
                ja: "画像の縦横の縮尺率。適用後、フレームを画像のサイズに合わせます。\n↑↓で1、shift+↑↓で10ずつ増減します。",
                en: "Horizontal and vertical scale of the image. Frames are then fitted to the image.\nUse Up/Down to change by 1, or shift+Up/Down by 10."
            },
            currentScale: {
                ja: "選択中の画像の今の縮尺率（水平／垂直）。値が画像ごとに異なる場合は「混在」と表示します。",
                en: "Scale of the selected images (horizontal / vertical). Shows \"Mixed\" when the images differ."
            },
            actualPpi: {
                ja: "画像そのものの解像度（リンクパネルの「実際の PPI」）。縦横が異なる場合は「水平 × 垂直」、画像ごとに異なる場合は「混在」と表示します。PDF にはありません。",
                en: "Resolution of the image file itself (Actual PPI in the Links panel). Shows \"horizontal × vertical\" when they differ, or \"Mixed\" when the images differ. Not available for PDF."
            },
            effectivePpi: {
                ja: "縮尺率を反映した解像度（リンクパネルの「有効 PPI」、水平方向）。縮尺率を変えると更新します。\n入力すると、その PPI になる縮尺率をフレームごとに求めます。［縮尺率を整数に丸める］がオンなら、入力した PPI を下回らないよう縮尺率を切り捨てます。\n↑↓で1、shift+↑↓で10ずつ増減します。PDF にはありません。",
                en: "Resolution after scaling (Effective PPI in the Links panel, horizontal). Updates as the scale changes.\nType a PPI to scale each image to that resolution. With Round scale to whole numbers on, the scale is rounded down so the PPI never falls below the value.\nUse Up/Down to change by 1, or shift+Up/Down by 10. Not available for PDF."
            },
            pixelSize: {
                ja: "画像の幅 × 高さ（px）。縮尺率を変えても変わりません。画像ごとに異なる場合は「混在」と表示します。PDF にはありません。",
                en: "Width × height of the image in pixels. Does not change with the scale. Shows \"Mixed\" when the images differ. Not available for PDF."
            },
            step:   { ja: "縮尺率の入力欄の値を増減します。", en: "Changes the value in the Scale field." },
            preset: { ja: "縮尺率の入力欄にこの値を入れます。", en: "Sets this value in the Scale field." },
            width: {
                ja: "画像の幅（mm）。縮尺率を変えると更新します。\n入力すると、画像がその幅になる縮尺率をフレームごとに求めます。［縮尺率を整数に丸める］がオンなら、はみ出さないよう切り捨てます。\n↑↓で1mm、shift+↑↓で10mmずつ増減します。",
                en: "Width of the image in mm. Updates as the scale changes.\nType a width to scale each image to that width. With Round scale to whole numbers on, the scale is rounded down so the image never overflows.\nUse Up/Down to change by 1 mm, or shift+Up/Down by 10 mm."
            },
            height: {
                ja: "画像の高さ（mm）。縮尺率を変えると更新します。\n入力すると、画像がその高さになる縮尺率をフレームごとに求めます。［縮尺率を整数に丸める］がオンなら、はみ出さないよう切り捨てます。\n↑↓で1mm、shift+↑↓で10mmずつ増減します。",
                en: "Height of the image in mm. Updates as the scale changes.\nType a height to scale each image to that height. With Round scale to whole numbers on, the scale is rounded down so the image never overflows.\nUse Up/Down to change by 1 mm, or shift+Up/Down by 10 mm."
            },
            roundToInteger: {
                ja: "オンにすると、適用する縮尺率を整数にします。入力した値は四捨五入、［マージン幅］［親フレーム］ははみ出さないよう切り捨て、増減の ±5・±10 はその倍数へ寄せます。\nオフにすると丸めません。入力した値や増減の結果をそのまま使い、［マージン幅］［親フレーム］では幅にぴったりの縮尺率にします。",
                en: "When on, the applied scale is a whole number: typed values are rounded, Margins / Parent Frame round down so the image never overflows, and the ±5 / ±10 steps snap to multiples.\nWhen off, nothing is rounded: typed and stepped values are used as is, and Margins / Parent Frame use the exact scale that fits the width."
            },
            anchor: {
                ja: "縮尺を変えたあと、フレームのこの位置が元の場所に残るように配置します。\nアンカー付きのフレームは位置を動かしません。［マージン幅］では、左右の位置は左マージンが優先されます。",
                en: "After scaling, the frame is placed so this point stays where it was.\nAnchored frames are not moved. With Margins, the horizontal position follows the left margin."
            },
            fitMargin: {
                ja: "画像の幅がページのマージン幅に収まる縮尺率をフレームごとに求め、フレームの左端を左マージンにそろえます。\nアンカー付きのフレームは位置を動かしません。",
                en: "Scales each image to fit the page margin width, and moves the frame's left edge to the left margin.\nAnchored frames are not moved."
            },
            fitTextFrame: {
                ja: "テキストにアンカーされた画像を、親テキストフレームの段幅（インセットと段落のインデントを除く）に収まる縮尺率にします。\nアンカーされていないフレームは変更しません。",
                en: "Scales each anchored image to fit the column width of its text frame (excluding insets and paragraph indents).\nFrames that are not anchored are left unchanged."
            },
            /* ステップボタン用 / for the stepper */
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
        },
        alert: {
            duplicateShortcut: {
                ja: "同じショートカットが複数の機能に割り当てられています：",
                en: "The same shortcut is assigned to more than one action:"
            },
            noDocument:    { ja: "ドキュメントが開かれていません。", en: "No document is open." },
            noTargetFrame: {
                ja: "選択範囲に対象のフレームがありません。\n画像（またはPDF）を1点だけ配置した長方形フレームを選択してください。",
                en: "No applicable frames in the selection.\nSelect rectangle frames that each contain a single image (or PDF)."
            }
        }
    };

    // =========================================
    // パレット / Palette
    // =========================================

    /**
     * 縮尺率を増減する
     * 丸めるときは ±1 を整数に、±5・±10 をその倍数へ寄せる（下限 1）。丸めないときは増減量をそのまま足す（0 以下になるなら据え置き）
     * @param {number} value 現在の値
     * @param {number} delta 増減量
     * @param {boolean} roundToInteger 整数に丸めるか
     * @returns {number} 増減後の値
     */
    function stepScaleValue(value, delta, roundToInteger) {
        if (!roundToInteger) {
            /* 小数の足し算の誤差を表示前に落とす / drop float noise from the addition */
            var exactValue = Number(formatNumber(value + delta));
            return (exactValue > 0) ? exactValue : value;
        }
        var stepSize = Math.abs(delta);
        var nextValue = (stepSize === 1)
            ? Math.round(value + delta)
            : (delta > 0 ? Math.ceil((value + 1) / stepSize) : Math.floor((value - 1) / stepSize)) * stepSize;
        return Math.max(nextValue, 1);
    }

    /**
     * 行ラベル（右揃え・固定幅）を追加する
     * @param {Group} rowGroup 追加先の行
     * @param {object} labelSet ja / en を持つラベルオブジェクト
     * @returns {StaticText} 追加したラベル
     */
    function addRowLabel(rowGroup, labelSet) {
        var rowLabel = rowGroup.add("statictext", undefined, labelText(labelSet));
        rowLabel.preferredSize.width = ROW_LABEL_WIDTH;
        rowLabel.justify = "right";
        return rowLabel;
    }

    /**
     * 行グループを追加する（ラベル付き）
     * @param {Container} parent 追加先
     * @param {object} labelSet ja / en を持つラベルオブジェクト
     * @returns {Group} 追加した行
     */
    function addLabeledRow(parent, labelSet) {
        var rowGroup = parent.add("group");
        setupRow(rowGroup, "fill", ROW_ITEM_SPACING);
        addRowLabel(rowGroup, labelSet);
        return rowGroup;
    }

    /**
     * 適用後の有効 PPI（水平方向・整数）を表示用の文字列にする
     * @param {Array} scaleTargets 対象の配列
     * @param {object|null} scaleSpec { fitMode, scalePercent, targetLengthPt, targetPpi, roundToInteger, anchorIndex }
     * @returns {string} 全フレーム共通なら数値、異なれば「個別」、PPI を持つ画像が無ければ ""
     */
    function describeEffectivePpi(scaleTargets, scaleSpec) {
        if (scaleSpec === null) return "";
        return describeCommonValue(scaleTargets, function (scaleTarget) {
            var scalePercent = resolveScalePercent(scaleTarget, scaleSpec);
            if (scalePercent === null || scaleTarget.actualPpi === null) return null;
            return Math.round(scaleTarget.actualPpi * 100 / scalePercent);
        });
    }

    /**
     * 幅・高さの入力行（ラベル＋入力欄＋mm）を追加する
     * @param {Container} parent 追加先
     * @param {object} labelSet 項目名のラベル
     * @param {object} tooltipSet ツールチップのラベル
     * @param {object} stepOptions ∧∨の増減の設定（addStepper() に渡す）
     * @returns {EditText} 追加した入力欄
     */
    function addLengthRow(parent, labelSet, tooltipSet, stepOptions) {
        var lengthRowGroup = addLabeledRow(parent, labelSet);
        var lengthInput = addStepperInput(lengthRowGroup, LENGTH_FIELD_CHARS, stepOptions);
        lengthInput.helpTip = getLabel(tooltipSet);
        lengthRowGroup.add("statictext", undefined, "mm");
        return lengthInput;
    }

    /**
     * 9軸の□を描くパスを作る（rectPath の前に newPath しないとパスが累積する）
     * @param {ScriptUIGraphics} graphics 描画先
     * @param {number} x 左端
     * @param {number} y 上端
     * @param {number} size 一辺
     * @returns {void}
     */
    function squarePath(graphics, x, y, size) {
        graphics.newPath();
        graphics.rectPath(x, y, size, size);
    }

    /* 中央(4)を除く外周の□どうしをつなぐケイ線の組み合わせ / Pairs of outer squares (center 4 excluded) joined by rules */
    var ANCHOR_CONNECTIONS = [[0, 1], [1, 2], [6, 7], [7, 8], [0, 3], [3, 6], [2, 5], [5, 8]];

    /**
     * 9軸ウィジェットを描画する（外周の□をケイ線でつなぐ・中央は独立。選択中の□だけ塗る）
     * @param {Button} anchorWidget 対象のウィジェット（selectedAnchorIndex を持つ）
     * @returns {void}
     */
    function drawAnchorWidget(anchorWidget) {
        var graphics = anchorWidget.graphics;
        var lightUI = !isDarkUI();
        var lineColor = lightUI ? [0.6, 0.6, 0.6, 1] : [0.55, 0.55, 0.55, 1];
        var selectedFill = lightUI ? [0.4, 0.4, 0.4, 1] : [0.8, 0.8, 0.8, 1];
        var linePen = graphics.newPen(graphics.PenType.SOLID_COLOR, lineColor, 1);

        var cellStep = ANCHOR_CELL_SIZE + ANCHOR_CELL_GAP;
        var gridSize = ANCHOR_CELL_SIZE * 3 + ANCHOR_CELL_GAP * 2;
        var originX = Math.round((anchorWidget.size[0] - gridSize) / 2);
        var originY = Math.round((anchorWidget.size[1] - gridSize) / 2);
        var cellPositions = [];
        for (var cellIndex = 0; cellIndex < 9; cellIndex++) {
            cellPositions.push([originX + (cellIndex % 3) * cellStep, originY + Math.floor(cellIndex / 3) * cellStep]);
        }

        for (var i = 0; i < ANCHOR_CONNECTIONS.length; i++) {
            var cellA = cellPositions[ANCHOR_CONNECTIONS[i][0]];
            var cellB = cellPositions[ANCHOR_CONNECTIONS[i][1]];
            graphics.newPath();
            if (ANCHOR_CONNECTIONS[i][1] - ANCHOR_CONNECTIONS[i][0] === 1) {
                /* 横方向：右隣の□へ / Horizontal: to the square on the right */
                graphics.moveTo(cellA[0] + ANCHOR_CELL_SIZE, cellA[1] + ANCHOR_CELL_SIZE / 2);
                graphics.lineTo(cellB[0], cellB[1] + ANCHOR_CELL_SIZE / 2);
            } else {
                /* 縦方向：下の□へ / Vertical: to the square below */
                graphics.moveTo(cellA[0] + ANCHOR_CELL_SIZE / 2, cellA[1] + ANCHOR_CELL_SIZE);
                graphics.lineTo(cellB[0] + ANCHOR_CELL_SIZE / 2, cellB[1]);
            }
            graphics.strokePath(linePen);
        }

        for (var j = 0; j < cellPositions.length; j++) {
            /* 枠を上に描くので塗りを先に行う / Fill first so the border draws on top */
            if (j === anchorWidget.selectedAnchorIndex) {
                squarePath(graphics, cellPositions[j][0], cellPositions[j][1], ANCHOR_CELL_SIZE);
                graphics.fillPath(graphics.newBrush(graphics.BrushType.SOLID_COLOR, selectedFill));
            }
            squarePath(graphics, cellPositions[j][0], cellPositions[j][1], ANCHOR_CELL_SIZE);
            graphics.strokePath(linePen);
        }
    }

    /**
     * 9軸（3×3）の基準点ウィジェットを追加する（button を onDraw で描き、クリックしたセルを選ぶ）
     * @param {Container} parent 追加先
     * @param {function} onAnchorChange 基準点が変わったときに呼ぶ処理
     * @returns {Button} 追加したウィジェット（selectedAnchorIndex に 0..8）
     */
    function addAnchorWidget(parent, onAnchorChange) {
        var anchorWidget = parent.add("button", undefined, "");
        anchorWidget.alignment = ["center", "top"];
        anchorWidget.minimumSize = anchorWidget.preferredSize = anchorWidget.maximumSize = [ANCHOR_WIDGET_SIZE, ANCHOR_WIDGET_SIZE];
        anchorWidget.helpTip = getLabel(LABELS.tooltip.anchor);
        anchorWidget.selectedAnchorIndex = DEFAULT_ANCHOR_INDEX;
        anchorWidget.onDraw = function () { drawAnchorWidget(this); };
        /* クリック座標（コントロール基準）を 3 分割してセルを決める / Hit-test the clicked cell by splitting the control into thirds */
        anchorWidget.addEventListener("mousedown", function (event) {
            var col = Math.min(2, Math.max(0, Math.floor(event.clientX / (anchorWidget.size[0] / 3))));
            var row = Math.min(2, Math.max(0, Math.floor(event.clientY / (anchorWidget.size[1] / 3))));
            var nextIndex = row * 3 + col;
            if (nextIndex === anchorWidget.selectedAnchorIndex) return;
            anchorWidget.selectedAnchorIndex = nextIndex;
            anchorWidget.notify("onDraw");
            onAnchorChange();
        });
        return anchorWidget;
    }

    /**
     * ボタン類のカラムになるパネルを追加する
     * @param {Group} parent 追加先のカラム
     * @param {object} labelSet パネル見出しのラベル
     * @returns {Panel} 追加したパネル
     */
    function addColumnPanel(parent, labelSet) {
        var columnPanel = parent.add("panel", undefined, getLabel(labelSet));
        setupPanel(columnPanel, COMPACT_BUTTON_SPACING);
        columnPanel.margins = COLUMN_PANEL_MARGINS; /* ボタンを詰めて並べるので余白を狭くする / tighter margins for the compact buttons */
        return columnPanel;
    }

    /**
     * ボタン類の2カラム（左：縦に積むカラム／右：パネルを直接置くカラム）を追加する
     * @param {Window} parent 追加先
     * @returns {{columnsGroup: Group, leftColumnGroup: Group}} 2カラムの行と左のカラム（右は columnsGroup に直接足す）
     */
    function addButtonColumns(parent) {
        var columnsGroup = parent.add("group");
        setupRow(columnsGroup, "fill", COLUMN_SPACING);
        columnsGroup.alignChildren = ["fill", "top"];
        var leftColumnGroup = columnsGroup.add("group");
        leftColumnGroup.orientation = "column";
        leftColumnGroup.alignChildren = ["fill", "top"];
        leftColumnGroup.spacing = COLUMN_SPACING;
        return { columnsGroup: columnsGroup, leftColumnGroup: leftColumnGroup };
    }

    /**
     * ボタンをひとまわり小さくする（文字サイズと高さを詰める）
     * @param {Button} targetButton 対象のボタン
     * @param {number} [buttonWidth] 幅。省略時は文字に合わせる
     * @returns {void}
     */
    function makeCompactButton(targetButton, buttonWidth) {
        var baseFont = targetButton.graphics.font;
        targetButton.graphics.font = ScriptUI.newFont(baseFont.name, "REGULAR", baseFont.size - COMPACT_FONT_REDUCTION);
        targetButton.preferredSize.height = COMPACT_BUTTON_HEIGHT;
        if (buttonWidth) targetButton.preferredSize.width = buttonWidth;
    }

    /**
     * 値ボタンを並べる（行ごとに perRow 個）
     * @param {Panel} parent 追加先（カラムのパネル）
     * @param {Array} buttonValues ボタンに割り当てる値
     * @param {function} formatValue 値からボタン名を作る処理
     * @param {string} tooltipText ボタンの helpTip
     * @param {function} onValueClick 押されたときに値を受け取る処理
     * @param {number} perRow 1行の個数
     * @returns {void}
     */
    function addValueButtons(parent, buttonValues, formatValue, tooltipText, onValueClick, perRow) {
        var buttonColumnGroup = parent.add("group");
        buttonColumnGroup.orientation = "column";
        /* パネルの中で左右中央に置く / center horizontally in the panel */
        buttonColumnGroup.alignment = ["center", "top"];
        buttonColumnGroup.alignChildren = ["center", "center"];
        buttonColumnGroup.spacing = COMPACT_BUTTON_SPACING;

        var buttonRowGroup = null;
        for (var i = 0; i < buttonValues.length; i++) {
            if (i % perRow === 0) {
                buttonRowGroup = buttonColumnGroup.add("group");
                buttonRowGroup.orientation = "row";
                buttonRowGroup.spacing = COMPACT_BUTTON_SPACING;
            }
            var valueButton = buttonRowGroup.add("button", undefined, formatValue(buttonValues[i]));
            makeCompactButton(valueButton, COMPACT_BUTTON_WIDTH);
            valueButton.helpTip = tooltipText;
            valueButton.buttonValue = buttonValues[i];
            valueButton.onClick = function () { onValueClick(this.buttonValue); };
        }
    }

    /**
     * 行に∧∨と入力欄を隙間なく並べて追加する（↑↓キーも∧∨と同じ処理で増減する）
     * @param {Group} rowGroup 追加先の行
     * @param {number} fieldChars 入力欄の文字数
     * @param {object} stepOptions addStepper() に渡す step / min / onStep など
     * @returns {EditText} 追加した入力欄
     */
    function addStepperInput(rowGroup, fieldChars, stepOptions) {
        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = rowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, stepOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, "");
        numberInput.characters = fieldChars;
        bindSteppedArrowKeys(numberInput, stepperGroup);
        return numberInput;
    }

    /**
     * 数値を表示用に丸める（小数第2位まで）
     * @param {number} value 縮尺率（%）や幅（mm）
     * @returns {string} 表示用の文字列
     */
    function formatNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    /**
     * 画像の PPI を表示用の文字列にする
     * @param {Array} scaleTargets collectScaleTargets() の戻り値
     * @param {string} ppiProperty "actualPpi" または "effectivePpi"
     * @returns {string} 例："300"、"300 × 350"、"混在"。PPI を持つ画像が無ければ "—"
     */
    function describePpi(scaleTargets, ppiProperty) {
        var ppiText = null;
        for (var i = 0; i < scaleTargets.length; i++) {
            var placedGraphic = scaleTargets[i].graphic;
            /* PDF は PPI を持たない / PDF has no PPI */
            if (!placedGraphic.isValid || placedGraphic.reflect.name !== "Image") continue;
            var ppiPair = placedGraphic[ppiProperty];
            var horizontalPpi = Math.round(ppiPair[0]);
            var verticalPpi = Math.round(ppiPair[1]);
            var itemText = (horizontalPpi === verticalPpi) ? String(horizontalPpi) : horizontalPpi + " \u00D7 " + verticalPpi;
            if (ppiText !== null && itemText !== ppiText) return getLabel(LABELS.value.mixed);
            ppiText = itemText;
        }
        return (ppiText === null) ? getLabel(LABELS.value.none) : ppiText;
    }

    /**
     * 画像の基準点をペーストボードの座標（pt）で返す（回転していても画像の角を追う）
     * @param {Graphic} placedGraphic 対象の画像
     * @param {AnchorPoint} anchorPoint 基準点
     * @returns {Array} [x, y]（pt）
     */
    function resolveGraphicCorner(placedGraphic, anchorPoint) {
        return placedGraphic.resolve(
            [anchorPoint, BoundingBoxLimits.GEOMETRIC_PATH_BOUNDS, CoordinateSpaces.INNER_COORDINATES],
            CoordinateSpaces.PASTEBOARD_COORDINATES
        )[0];
    }

    /**
     * 2点間の距離を返す
     * @param {Array} startPoint [x, y]
     * @param {Array} endPoint [x, y]
     * @returns {number} 距離
     */
    function getDistance(startPoint, endPoint) {
        var dx = endPoint[0] - startPoint[0];
        var dy = endPoint[1] - startPoint[1];
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * 画像のピクセル寸法を表示用の文字列にする（表示サイズ pt × 有効 PPI ÷ 72）
     * @param {Array} scaleTargets collectScaleTargets() の戻り値
     * @returns {string} 例："3000 × 2000 px"、"混在"。画像が無ければ "—"
     */
    function describePixelSize(scaleTargets) {
        var sizeText = null;
        for (var i = 0; i < scaleTargets.length; i++) {
            var placedGraphic = scaleTargets[i].graphic;
            /* PDF はピクセルを持たない / PDF has no pixels */
            if (!placedGraphic.isValid || placedGraphic.reflect.name !== "Image") continue;
            var topLeft = resolveGraphicCorner(placedGraphic, AnchorPoint.TOP_LEFT_ANCHOR);
            var topRight = resolveGraphicCorner(placedGraphic, AnchorPoint.TOP_RIGHT_ANCHOR);
            var bottomLeft = resolveGraphicCorner(placedGraphic, AnchorPoint.BOTTOM_LEFT_ANCHOR);
            var effectivePpi = placedGraphic.effectivePpi;
            var pixelWidth = Math.round(getDistance(topLeft, topRight) / 72 * effectivePpi[0]);
            var pixelHeight = Math.round(getDistance(topLeft, bottomLeft) / 72 * effectivePpi[1]);
            var itemText = pixelWidth + " \u00D7 " + pixelHeight + " px";
            if (sizeText !== null && itemText !== sizeText) return getLabel(LABELS.value.mixed);
            sizeText = itemText;
        }
        return (sizeText === null) ? getLabel(LABELS.value.none) : sizeText;
    }

    /**
     * 現在の縮尺率を表示用の文字列にする
     * @param {object|null} currentScale { horizontal, vertical }。画像ごとに異なる場合は null
     * @returns {string} 例："25%"、"25% / 30%"、"混在"
     */
    function describeCurrentScale(currentScale) {
        if (currentScale === null) return getLabel(LABELS.value.mixed);
        var horizontalText = formatNumber(currentScale.horizontal) + "%";
        if (currentScale.horizontal === currentScale.vertical) return horizontalText;
        return horizontalText + " / " + formatNumber(currentScale.vertical) + "%";
    }

    /**
     * 入力欄の縮尺率を読む
     * @param {EditText} scaleInput 縮尺率の入力欄
     * @returns {number|null} 0 より大きい数値。無効なら null
     */
    function readScalePercent(scaleInput) {
        var value = Number(scaleInput.text);
        return (value > 0) ? value : null;
    }

    /**
     * 対象ごとの値をまとめて表示用の文字列にする
     * @param {Array} scaleTargets 対象の配列
     * @param {function} getItemValue 対象から数値（求められなければ null）を返す処理
     * @returns {string} 全フレーム共通なら数値、異なれば「個別」、1つも無ければ ""
     */
    function describeCommonValue(scaleTargets, getItemValue) {
        var commonText = null;
        for (var i = 0; i < scaleTargets.length; i++) {
            var itemValue = getItemValue(scaleTargets[i]);
            if (itemValue === null) continue;
            var itemText = formatNumber(itemValue);
            if (commonText !== null && itemText !== commonText) return getLabel(LABELS.value.perFrame);
            commonText = itemText;
        }
        return (commonText === null) ? "" : commonText;
    }

    /**
     * 幅に合わせたときの縮尺率を表示用の文字列にする
     * @param {Array} scaleTargets 対象の配列
     * @param {object} scaleSpec { fitMode, scalePercent, targetLengthPt, targetPpi, roundToInteger, anchorIndex }
     * @returns {string} 全フレーム共通なら数値、異なれば「個別」
     */
    function describeFitPercent(scaleTargets, scaleSpec) {
        return describeCommonValue(scaleTargets, function (scaleTarget) {
            return resolveScalePercent(scaleTarget, scaleSpec);
        });
    }

    /**
     * 適用後の画像の幅または高さ（mm）を表示用の文字列にする
     * @param {Array} scaleTargets 対象の配列
     * @param {object|null} scaleSpec { fitMode, scalePercent, targetLengthPt, targetPpi, roundToInteger, anchorIndex }
     * @param {string} lengthMode FIT_MODE.width または FIT_MODE.height
     * @returns {string} 全フレーム共通なら数値、異なれば「個別」
     */
    function describeLength(scaleTargets, scaleSpec, lengthMode) {
        if (scaleSpec === null) return "";
        var naturalKey = NATURAL_LENGTH_KEY[lengthMode];
        return describeCommonValue(scaleTargets, function (scaleTarget) {
            var scalePercent = resolveScalePercent(scaleTarget, scaleSpec);
            if (scalePercent === null || scaleTarget[naturalKey] === null) return null;
            return scaleTarget[naturalKey] * scalePercent / 100 / POINTS_PER_MM;
        });
    }

    /**
     * 読み込んだ対象を見分けるキーを返す（ドキュメント名＋フレームの ID）
     * @param {object} selectionState readSelectionState() の戻り値
     * @returns {string} 対象が同じなら同じ文字列
     */
    function getSelectionKey(selectionState) {
        var scaleTargets = selectionState.scaleTargets;
        if (scaleTargets.length === 0) return "";
        var frameIds = [];
        for (var i = 0; i < scaleTargets.length; i++) {
            /* 削除されたフレームは ID を読めない / deleted frames have no readable ID */
            frameIds.push(scaleTargets[i].frame.isValid ? scaleTargets[i].frame.id : "-");
        }
        return selectionState.targetDocument.name + ":" + frameIds.join(",");
    }

    /**
     * いずれかのフレームで幅に合わせられるか
     * @param {Array} scaleTargets 対象の配列
     * @param {string} fitMode FIT_MODE の値
     * @returns {boolean} 合わせられるフレームがあれば true
     */
    function canFitAny(scaleTargets, fitMode) {
        for (var i = 0; i < scaleTargets.length; i++) {
            if (scaleTargets[i].fitPercents[fitMode] !== null) return true;
        }
        return false;
    }

    /**
     * ショートカットを割り当てられる機能の一覧を返す（増減・幅に合わせる・プリセット）
     * @returns {Array} { id, kind, value, labelText, groupLabel } の配列
     */
    function getShortcutActions() {
        var shortcutActions = [];

        /**
         * 機能を一覧に加える
         * @param {string} kind "step"／"fit"／"preset"
         * @param {number|string} value 増減量・FIT_MODE の値・縮尺率
         * @param {string} labelString 管理画面に出す機能名
         * @param {object} groupLabel 所属するパネルのラベル
         * @returns {void}
         */
        function addAction(kind, value, labelString, groupLabel) {
            shortcutActions.push({ id: kind + ":" + value, kind: kind, value: value, labelText: labelString, groupLabel: groupLabel });
        }
        for (var i = 0; i < SCALE_STEPS.length; i++) {
            addAction("step", SCALE_STEPS[i], (SCALE_STEPS[i] > 0 ? "+" : "\u2212") + Math.abs(SCALE_STEPS[i]), LABELS.field.step);
        }
        addAction("fit", FIT_MODE.margin, getLabel(LABELS.button.fitMargin), LABELS.field.fitWidth);
        addAction("fit", FIT_MODE.textFrame, getLabel(LABELS.button.fitTextFrame), LABELS.field.fitWidth);
        for (var j = 0; j < SCALE_PRESETS.length; j++) {
            addAction("preset", SCALE_PRESETS[j], SCALE_PRESETS[j] + "%", LABELS.field.preset);
        }
        return shortcutActions;
    }

    /**
     * 設定ファイルを返す
     * @returns {File} 設定ファイル
     */
    function getPrefsFile() {
        return File(Folder.userData.fsName + "/" + PREFS_FILE_NAME);
    }

    /**
     * ショートカットの割り当てを読み出す。記録の無い機能は初期値にする
     * @returns {Object<string, string>} 機能 ID → 「修飾キー+キー」（未割り当ては ""）
     */
    function loadShortcuts() {
        var shortcuts = {};
        for (var actionId in DEFAULT_SHORTCUTS) {
            if (DEFAULT_SHORTCUTS.hasOwnProperty(actionId)) shortcuts[actionId] = DEFAULT_SHORTCUTS[actionId];
        }

        var prefsFile = getPrefsFile();
        prefsFile.encoding = "UTF-8";
        if (!prefsFile.exists || !prefsFile.open("r")) return shortcuts;
        var lines = prefsFile.read().split("\n");
        prefsFile.close();

        for (var i = 0; i < lines.length; i++) {
            var separatorIndex = lines[i].indexOf("=");
            if (separatorIndex < 0 || lines[i].indexOf(PREF_SHORTCUT_PREFIX) !== 0) continue;
            shortcuts[lines[i].substring(PREF_SHORTCUT_PREFIX.length, separatorIndex)] = lines[i].substring(separatorIndex + 1);
        }
        return shortcuts;
    }

    /**
     * ショートカットの割り当てを設定ファイルに書き出す（未割り当ても "" で残し、初期値に戻らないようにする）
     * @param {Object<string, string>} shortcuts 機能 ID → 「修飾キー+キー」
     * @returns {void}
     */
    function saveShortcuts(shortcuts) {
        var shortcutActions = getShortcutActions();
        var lines = [];
        for (var i = 0; i < shortcutActions.length; i++) {
            lines.push(PREF_SHORTCUT_PREFIX + shortcutActions[i].id + "=" + (shortcuts[shortcutActions[i].id] || ""));
        }

        /* 保存できなくてもこのセッションでは使えるので、書き出せたかどうかは見ない / A failed save still works for this session */
        var prefsFile = getPrefsFile();
        prefsFile.encoding = "UTF-8";
        if (!prefsFile.open("w")) return;
        prefsFile.write(lines.join("\n"));
        prefsFile.close();
    }

    /**
     * 押されたキーを「修飾キー+キー」の文字列にする
     * @param {KeyboardEvent} event keydown のイベント
     * @returns {string} 例："option+1"。修飾キーが無ければ ""
     */
    function getPressedShortcut(event) {
        var keyboardState = ScriptUI.environment.keyboardState;
        var modifiers = [];
        if (keyboardState.ctrlKey) modifiers.push("control");
        if (keyboardState.altKey) modifiers.push("option");
        if (modifiers.length === 0 || !event.keyName) return "";
        return modifiers.join("+") + "+" + String(event.keyName).toUpperCase();
    }

    /**
     * 押されたキーに割り当てた機能を探す
     * @param {Object<string, string>} shortcuts 機能 ID → 「修飾キー+キー」
     * @param {string} pressedShortcut getPressedShortcut() の戻り値
     * @returns {object|null} getShortcutActions() の要素。割り当てが無ければ null
     */
    function findShortcutAction(shortcuts, pressedShortcut) {
        if (pressedShortcut === "") return null;
        var shortcutActions = getShortcutActions();
        for (var i = 0; i < shortcutActions.length; i++) {
            if (shortcuts[shortcutActions[i].id] === pressedShortcut) return shortcutActions[i];
        }
        return null;
    }

    /**
     * 管理画面の1行（機能名・修飾キー・キー）を追加する
     * @param {Panel} parent 追加先のパネル
     * @param {object} shortcutAction getShortcutActions() の要素
     * @param {string} shortcut 今の割り当て（未割り当ては ""）
     * @returns {{modifierList: DropDownList, keyList: DropDownList}} 追加した選択欄
     */
    function addShortcutRow(parent, shortcutAction, shortcut) {
        var rowGroup = parent.add("group");
        setupRow(rowGroup, "fill", ROW_ITEM_SPACING);
        var actionLabel = rowGroup.add("statictext", undefined, shortcutAction.labelText);
        actionLabel.preferredSize.width = SHORTCUT_LABEL_WIDTH;
        actionLabel.justify = "right";

        var modifierList = rowGroup.add("dropdownlist", undefined, [getLabel(LABELS.value.noModifier)].concat(SHORTCUT_MODIFIERS));
        modifierList.helpTip = getLabel(LABELS.tooltip.shortcutModifier);
        var keyList = rowGroup.add("dropdownlist", undefined, SHORTCUT_KEYS);
        keyList.helpTip = getLabel(LABELS.tooltip.shortcutKey);

        /* 「修飾キー+キー」を分ける（キーは最後の + の後）/ the key follows the last "+" */
        var separatorIndex = shortcut.lastIndexOf("+");
        var modifierIndex = -1;
        var keyIndex = -1;
        if (separatorIndex > 0) {
            var modifierText = shortcut.substring(0, separatorIndex);
            var keyText = shortcut.substring(separatorIndex + 1);
            for (var i = 0; i < SHORTCUT_MODIFIERS.length; i++) {
                if (SHORTCUT_MODIFIERS[i] === modifierText) modifierIndex = i;
            }
            for (var j = 0; j < SHORTCUT_KEYS.length; j++) {
                if (SHORTCUT_KEYS[j] === keyText) keyIndex = j;
            }
        }
        var isAssigned = (modifierIndex >= 0 && keyIndex >= 0);
        modifierList.selection = isAssigned ? modifierIndex + 1 : 0;
        keyList.selection = isAssigned ? keyIndex : 0;
        keyList.enabled = isAssigned;
        modifierList.onChange = function () { keyList.enabled = (modifierList.selection.index > 0); };

        return { modifierList: modifierList, keyList: keyList };
    }

    /**
     * キーボードショートカットを設定する管理画面を表示する
     * @param {Object<string, string>} shortcuts 今の割り当て（機能 ID → 「修飾キー+キー」）
     * @returns {Object<string, string>|null} OK なら新しい割り当て、キャンセルなら null
     */
    function showManageDialog(shortcuts) {
        var shortcutActions = getShortcutActions();

        var manageDialog = new Window("dialog", getLabel(LABELS.manageDialog.title));
        setupWindow(manageDialog);

        /* パレットと同じ並び（左：増減＋幅に合わせる／右：プリセット）/ Same layout as the palette */
        var buttonColumns = addButtonColumns(manageDialog);
        var groupPanels = {};
        groupPanels.step = addColumnPanel(buttonColumns.leftColumnGroup, LABELS.field.step);
        groupPanels.fit = addColumnPanel(buttonColumns.leftColumnGroup, LABELS.field.fitWidth);
        groupPanels.preset = addColumnPanel(buttonColumns.columnsGroup, LABELS.field.preset);

        var shortcutRows = [];
        for (var i = 0; i < shortcutActions.length; i++) {
            shortcutRows.push(addShortcutRow(groupPanels[shortcutActions[i].kind], shortcutActions[i], shortcuts[shortcutActions[i].id] || ""));
        }

        var buttonRow = addButtonRow(manageDialog);
        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.cancel), { name: "cancel" });
        var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.ok), { name: "ok" });
        alignRightOnlyButtonRow(buttonRow);

        var nextShortcuts = null;

        /**
         * 選択欄から割り当てを読む
         * @returns {Object<string, string>} 機能 ID → 「修飾キー+キー」
         */
        function readShortcutRows() {
            var readShortcuts = {};
            for (var k = 0; k < shortcutActions.length; k++) {
                var modifierIndex = shortcutRows[k].modifierList.selection.index;
                readShortcuts[shortcutActions[k].id] = (modifierIndex > 0)
                    ? SHORTCUT_MODIFIERS[modifierIndex - 1] + "+" + shortcutRows[k].keyList.selection.text
                    : "";
            }
            return readShortcuts;
        }

        /* 同じキーの重複があれば閉じずに知らせる / Keep the dialog open on duplicates */
        btnOK.onClick = function () {
            var readShortcuts = readShortcutRows();
            var ownerLabels = {};
            var duplicateLines = [];
            for (var k = 0; k < shortcutActions.length; k++) {
                var shortcut = readShortcuts[shortcutActions[k].id];
                if (shortcut === "") continue;
                var actionName = getLabel(shortcutActions[k].groupLabel) + " " + shortcutActions[k].labelText;
                if (ownerLabels.hasOwnProperty(shortcut)) {
                    duplicateLines.push(shortcut + "\uFF1A" + ownerLabels[shortcut] + " / " + actionName);
                } else {
                    ownerLabels[shortcut] = actionName;
                }
            }
            if (duplicateLines.length > 0) {
                alert(getLabel(LABELS.alert.duplicateShortcut) + "\n" + duplicateLines.join("\n"));
                return;
            }
            nextShortcuts = readShortcuts;
            manageDialog.close(1);
        };

        manageDialog.show();
        return nextShortcuts;
    }

    /**
     * 縮尺率を入力するパレットを表示する（変更はその場でドキュメントに反映）
     * InDesign はモーダルダイアログの表示中にドキュメントを変更できない（Error 30486）ため、パレットにしている
     * @param {object} initialState readSelectionState() の戻り値
     * @returns {void}
     */
    function showScalePalette(initialState) {
        var selectionState = initialState;

        var scalePalette = new Window("palette", getLabel(LABELS.palette.title));
        setupWindow(scalePalette);

        /* 縮尺率：今の値 → ［入力欄］% / Scale: current → [input] % */
        var scaleRowGroup = addLabeledRow(scalePalette, LABELS.field.scale);
        var currentScaleText = scaleRowGroup.add("statictext", undefined, "");
        currentScaleText.helpTip = getLabel(LABELS.tooltip.currentScale);
        scaleRowGroup.add("statictext", undefined, "\u2192");
        /* 丸めるときは∧∨・↑↓キーの結果も整数（下限1）にそろえる / snap to whole numbers (min 1) while rounding is on */
        var scaleInput = addStepperInput(scaleRowGroup, SCALE_FIELD_CHARS, {
            step: 1, min: FIELD_STEP_MIN,
            onStep: function () {
                if (roundCheckbox.value) scaleInput.text = String(Math.max(1, Math.round(Number(scaleInput.text))));
                activeFitMode = null;
                refreshPreview();
            }
        });
        scaleInput.helpTip = getLabel(LABELS.tooltip.scale);
        scaleRowGroup.add("statictext", undefined, "%");

        var widthInput = addLengthRow(scalePalette, LABELS.field.width, LABELS.tooltip.width, createTargetStepOptions(FIT_MODE.width));
        var heightInput = addLengthRow(scalePalette, LABELS.field.height, LABELS.tooltip.height, createTargetStepOptions(FIT_MODE.height));

        /* PPI：元の PPI → ［有効 PPI の入力欄］/ PPI: actual → [effective PPI field] */
        var ppiRowGroup = addLabeledRow(scalePalette, LABELS.field.ppi);
        var actualPpiText = ppiRowGroup.add("statictext", undefined, "");
        actualPpiText.helpTip = getLabel(LABELS.tooltip.actualPpi);
        ppiRowGroup.add("statictext", undefined, "\u2192");
        var ppiInput = addStepperInput(ppiRowGroup, SCALE_FIELD_CHARS, createTargetStepOptions(FIT_MODE.ppi));
        ppiInput.helpTip = getLabel(LABELS.tooltip.effectivePpi);

        var pixelSizeRowGroup = addLabeledRow(scalePalette, LABELS.field.pixelSize);
        pixelSizeRowGroup.margins = [0, 0, 0, INFO_BOTTOM_GAP];
        var pixelSizeText = pixelSizeRowGroup.add("statictext", undefined, "");
        pixelSizeText.characters = INFO_TEXT_CHARS;
        pixelSizeText.alignment = ["fill", "center"];   /* 「3000 × 2000 px」でも切れないよう行の残り幅まで伸ばす / stretch to the row width */
        pixelSizeText.helpTip = getLabel(LABELS.tooltip.pixelSize);

        /* ボタン類は2カラム（左：増減＋幅に合わせる／右：プリセット）/ Two columns: steps + fit width, presets */
        var buttonColumns = addButtonColumns(scalePalette);
        var stepPanel = addColumnPanel(buttonColumns.leftColumnGroup, LABELS.field.step);
        var fitPanel = addColumnPanel(buttonColumns.leftColumnGroup, LABELS.field.fitWidth);
        var anchorPanel = addColumnPanel(buttonColumns.leftColumnGroup, LABELS.field.anchor);
        anchorPanel.margins = ANCHOR_PANEL_MARGINS;
        var presetPanel = addColumnPanel(buttonColumns.columnsGroup, LABELS.field.preset);

        var btnFitMargin = fitPanel.add("button", undefined, getLabel(LABELS.button.fitMargin));
        var btnFitTextFrame = fitPanel.add("button", undefined, getLabel(LABELS.button.fitTextFrame));
        makeCompactButton(btnFitMargin);
        makeCompactButton(btnFitTextFrame);
        /* パネル幅まで伸ばさず、文字に合わせた幅で中央に置く / natural width, centered (not filled) */
        btnFitMargin.alignment = ["center", "top"];
        btnFitTextFrame.alignment = ["center", "top"];
        btnFitMargin.helpTip = getLabel(LABELS.tooltip.fitMargin);
        btnFitTextFrame.helpTip = getLabel(LABELS.tooltip.fitTextFrame);

        /* パレットの一番下（左：丸め／右：管理）/ At the bottom: rounding on the left, Manage on the right */
        var buttonRow = addButtonRow(scalePalette);
        var roundCheckbox = buttonRow.leftGroup.add("checkbox", undefined, getLabel(LABELS.checkbox.roundToInteger));
        roundCheckbox.value = true;
        roundCheckbox.helpTip = getLabel(LABELS.tooltip.roundToInteger);

        var btnManage = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.manage));
        btnManage.helpTip = getLabel(LABELS.tooltip.manage);
        alignRightOnlyButtonRow(buttonRow);
        btnManage.onClick = function () {
            var nextShortcuts = showManageDialog(shortcuts);
            if (nextShortcuts === null) return;
            shortcuts = nextShortcuts;
            saveShortcuts(shortcuts);
        };

        var shortcuts = loadShortcuts();
        var scalePreview = null;
        var isChangingDocument = false;   /* 変更・取り消しの最中は選択の変更イベントを無視する / ignore selection events while applying or undoing */
        var anchorWidget = addAnchorWidget(anchorPanel, function () { refreshPreview(); });
        var activeFitMode = null;   /* 幅に合わせるボタン・幅の欄を使った状態。縮尺率を入れ直すと解除 / set by fit buttons or the Width field, cleared by typing a scale */

        /**
         * 文字列の幅ぴったりに表示し、行を詰め直す（ラベルと矢印の間に空きを作らない）
         * @param {StaticText} textControl 対象の表示
         * @param {string} displayText 表示する文字列
         * @returns {void}
         */
        function setTextFitWidth(textControl, displayText) {
            textControl.text = displayText;
            var measuredSize = textControl.graphics.measureString(displayText);
            var fitSize = [Math.ceil(measuredSize[0]), Math.ceil(measuredSize[1])];
            /* 一度配置されたあとは preferredSize だけでは幅が変わらない（0 のまま残る）ので size も入れる */
            /* After the first layout, preferredSize alone does not resize the control (it stays 0), so set size too */
            textControl.preferredSize = fitSize;
            textControl.size = fitSize;
            scalePalette.layout.layout(true);
        }

        /**
         * 読み込んだ選択状態をパレットの表示に反映する
         * @returns {void}
         */
        function loadSelectionState() {
            var scaleTargets = selectionState.scaleTargets;
            scalePreview = createScalePreview(selectionState.targetDocument, scaleTargets);
            activeFitMode = null;
            setTextFitWidth(currentScaleText, (scaleTargets.length > 0)
                ? describeCurrentScale(selectionState.currentScale)
                : getLabel(LABELS.value.none));
            setTextFitWidth(actualPpiText, describePpi(scaleTargets, "actualPpi"));
            pixelSizeText.text = describePixelSize(scaleTargets);
            scaleInput.text = String(selectionState.initialPercent);
            /* 表示前はチェックボックスを読めないので、丸めずに今の幅を出す / checkbox is unreadable before show; show the current width unrounded */
            var currentSpec = { fitMode: null, scalePercent: selectionState.initialPercent, roundToInteger: false };
            widthInput.text = describeLength(scaleTargets, currentSpec, FIT_MODE.width);
            heightInput.text = describeLength(scaleTargets, currentSpec, FIT_MODE.height);
            ppiInput.text = describeEffectivePpi(scaleTargets, currentSpec);
            btnFitMargin.enabled = canFitAny(scaleTargets, FIT_MODE.margin);
            btnFitTextFrame.enabled = canFitAny(scaleTargets, FIT_MODE.textFrame);
        }

        /**
         * 入力内容から適用内容を読む
         * @returns {object|null} { fitMode, scalePercent, targetLengthPt, targetPpi, roundToInteger, anchorIndex }。数値が無効なら null
         */
        function readScaleSpec() {
            var scaleSpec = {
                fitMode: activeFitMode,
                scalePercent: null,
                targetLengthPt: null,
                targetPpi: null,
                roundToInteger: roundCheckbox.value,
                anchorIndex: anchorWidget.selectedAnchorIndex
            };
            if (activeFitMode === FIT_MODE.width || activeFitMode === FIT_MODE.height) {
                /* 0 より大きい数値を読む処理は縮尺率と共通 / same positive-number check as the scale */
                var lengthMm = readScalePercent(activeFitMode === FIT_MODE.width ? widthInput : heightInput);
                if (lengthMm === null) return null;
                scaleSpec.targetLengthPt = lengthMm * POINTS_PER_MM;
            } else if (activeFitMode === FIT_MODE.ppi) {
                scaleSpec.targetPpi = readScalePercent(ppiInput);
                if (scaleSpec.targetPpi === null) return null;
            } else if (activeFitMode === null) {
                scaleSpec.scalePercent = readScalePercent(scaleInput);
                if (scaleSpec.scalePercent === null) return null;
            }
            return scaleSpec;
        }

        /**
         * 入力内容に合わせて、直前の変更を戻してから掛け直す
         * @returns {void}
         */
        function refreshPreview() {
            isChangingDocument = true;
            scalePreview.clear();
            var scaleSpec = readScaleSpec();
            if (scaleSpec !== null) scalePreview.apply(scaleSpec);
            isChangingDocument = false;
            /* 入力中の欄（幅・高さ・PPI）は書き換えない / leave the field being typed in alone */
            if (activeFitMode !== FIT_MODE.width) widthInput.text = describeLength(selectionState.scaleTargets, scaleSpec, FIT_MODE.width);
            if (activeFitMode !== FIT_MODE.height) heightInput.text = describeLength(selectionState.scaleTargets, scaleSpec, FIT_MODE.height);
            if (activeFitMode !== FIT_MODE.ppi) ppiInput.text = describeEffectivePpi(selectionState.scaleTargets, scaleSpec);
        }

        /**
         * 縮尺率の欄に値を入れて掛け直す
         * @param {number} scalePercent 縮尺率（%）
         * @returns {void}
         */
        function setScaleValue(scalePercent) {
            activeFitMode = null;
            scaleInput.text = String(scalePercent);
            refreshPreview();
        }

        /**
         * 縮尺率を増減して掛け直す（欄が空・無効なら今の縮尺率から）
         * @param {number} delta 増減量
         * @returns {void}
         */
        function stepScale(delta) {
            var value = Number(scaleInput.text);
            setScaleValue(stepScaleValue(isNaN(value) ? selectionState.initialPercent : value, delta, roundCheckbox.value));
        }

        /**
         * 幅に合わせる基準を選び、掛け直す
         * @param {string} fitMode FIT_MODE の値
         * @returns {void}
         */
        function selectFitMode(fitMode) {
            activeFitMode = fitMode;
            showFitPercent();
            refreshPreview();
        }

        /**
         * 幅に合わせているときの縮尺率を縮尺率の入力欄に表示する
         * @returns {void}
         */
        function showFitPercent() {
            var scaleSpec = readScaleSpec();
            scaleInput.text = (scaleSpec === null) ? "" : describeFitPercent(selectionState.scaleTargets, scaleSpec);
        }

        /* 幅に合わせている間は、丸め方を変えると欄の値も変わる / In fit mode the shown value follows the rounding */
        roundCheckbox.onClick = function () {
            if (activeFitMode !== null) showFitPercent();
            refreshPreview();
        };

        /**
         * 幅・高さ・PPI の欄の入力から縮尺率を求めて掛け直す
         * @param {string} targetMode FIT_MODE.width／height／ppi
         * @returns {void}
         */
        function applyTargetInput(targetMode) {
            activeFitMode = targetMode;
            showFitPercent();
            refreshPreview();
        }

        /**
         * 幅・高さ・PPI の欄の∧∨・↑↓キーの設定を作る（増減後に縮尺率を求めて掛け直す）
         * @param {string} targetMode FIT_MODE.width／height／ppi
         * @returns {object} addStepper() に渡す設定
         */
        function createTargetStepOptions(targetMode) {
            return {
                step: 1, min: FIELD_STEP_MIN,
                onStep: function () { applyTargetInput(targetMode); }
            };
        }

        /**
         * 幅・高さ・PPI の欄に入力の処理を付ける
         * @param {EditText} targetInput 対象の欄
         * @param {string} targetMode FIT_MODE.width／height／ppi
         * @returns {void}
         */
        function bindTargetInput(targetInput, targetMode) {
            targetInput.onChanging = function () { applyTargetInput(targetMode); };
        }

        bindTargetInput(widthInput, FIT_MODE.width);
        bindTargetInput(heightInput, FIT_MODE.height);
        bindTargetInput(ppiInput, FIT_MODE.ppi);

        btnFitMargin.onClick = function () { selectFitMode(FIT_MODE.margin); };
        btnFitTextFrame.onClick = function () { selectFitMode(FIT_MODE.textFrame); };

        addValueButtons(stepPanel, SCALE_STEPS,
            function (delta) { return (delta > 0 ? "+" : "\u2212") + Math.abs(delta); },
            getLabel(LABELS.tooltip.step),
            stepScale,
            STEPS_PER_ROW);
        addValueButtons(presetPanel, SCALE_PRESETS,
            function (presetPercent) { return presetPercent + "%"; },
            getLabel(LABELS.tooltip.preset),
            setScaleValue,
            PRESETS_PER_ROW);

        scaleInput.onChanging = function () {
            activeFitMode = null;
            refreshPreview();
        };

        /* 管理画面で割り当てたショートカット（欄に「¡」などが入らないよう既定の入力は止める） */
        /* Shortcuts set in the Manage dialog (suppress the typed character such as "¡") */
        scalePalette.addEventListener("keydown", function (event) {
            var shortcutAction = findShortcutAction(shortcuts, getPressedShortcut(event));
            if (shortcutAction === null) return;
            event.preventDefault();
            if (shortcutAction.kind === "step") {
                stepScale(shortcutAction.value);
            } else if (shortcutAction.kind === "fit") {
                /* ボタンが使えない選択では何もしない / skip when the fit button is disabled */
                if (!canFitAny(selectionState.scaleTargets, shortcutAction.value)) return;
                selectFitMode(shortcutAction.value);
            } else {
                setScaleValue(shortcutAction.value);
            }
        });

        /* 選択が変わったら自動で読み込み直す（対象が同じなら何もしない。警告も出さない） */
        /* Follow selection changes (skip when the targets are unchanged; no warnings) */
        var selectionListener = app.addEventListener("afterSelectionChanged", function () {
            if (isChangingDocument) return;
            var nextState = readSelectionState();
            if (getSelectionKey(nextState) === getSelectionKey(selectionState)) return;
            scalePreview.keep();   /* ここまでの変更は残す / keep the changes so far */
            selectionState = nextState;
            loadSelectionState();
        });

        /* 閉じても変更は残す（元に戻すのは Cmd+Z）/ Closing keeps the changes (undo with Cmd+Z) */
        scalePalette.onClose = function () {
            selectionListener.remove();
            $.global.idSetImageScalePalette = null;
        };

        scalePalette.onShow = function () { scaleInput.active = true; };

        loadSelectionState();

        /* パレットは show() から即座に戻るので、参照を $.global に残す / Keep a reference: palettes return from show() at once */
        $.global.idSetImageScalePalette = scalePalette;
        addVersionFooter(scalePalette);
        scalePalette.show();
    }

    // =========================================
    // 処理 / Processing
    // =========================================

    /**
     * 縮尺変更の対象になる画像を返す（長方形フレームに画像または PDF が1点だけ入っている場合）
     * @param {PageItem} pageItem 選択中のオブジェクト
     * @returns {Graphic|null} 対象の画像。対象外なら null
     */
    function getScalableGraphic(pageItem) {
        if (pageItem.reflect.name !== "Rectangle" || pageItem.allGraphics.length !== 1) return null;
        var placedGraphic = pageItem.allGraphics[0];
        var graphicType = placedGraphic.constructor.name;
        return (graphicType === "Image" || graphicType === "PDF") ? placedGraphic : null;
    }

    /**
     * フレームがテキストにアンカーされているか（親が文字なら、インライン・行の上・カスタムのいずれか）
     * @param {PageItem} pageItem 判定するオブジェクト
     * @returns {boolean} アンカー付きなら true
     */
    function isAnchoredFrame(pageItem) {
        return pageItem.parent.constructor.name === "Character";
    }

    /**
     * ページの左右マージンの X 座標を返す（見開きの左ページは内側・外側を入れ替える）
     * @param {Page} targetPage 対象ページ
     * @returns {object} { left, right }
     */
    function getMarginEdges(targetPage) {
        var pageBounds = targetPage.bounds;
        var marginPrefs = targetPage.marginPreferences;
        var isLeftHand = (targetPage.side === PageSideOptions.LEFT_HAND);
        return {
            left:  pageBounds[1] + (isLeftHand ? marginPrefs.right : marginPrefs.left),
            right: pageBounds[3] - (isLeftHand ? marginPrefs.left : marginPrefs.right)
        };
    }

    /**
     * テキストフレームの左右インセットの合計を返す
     * @param {TextFrame} textFrame 対象のテキストフレーム
     * @returns {number} 左右インセットの合計
     */
    function getHorizontalInsets(textFrame) {
        var insetSpacing = textFrame.textFramePreferences.insetSpacing;
        return (insetSpacing instanceof Array) ? insetSpacing[1] + insetSpacing[3] : insetSpacing * 2;
    }

    /**
     * アンカー付きフレームが入る段の幅を返す（インセット・段間・段落の左右インデントを除く）
     * @param {PageItem} graphicFrame 対象のフレーム
     * @returns {number|null} 段の幅。アンカーされていない・親が見つからない場合は null
     */
    function getParentColumnWidth(graphicFrame) {
        if (!isAnchoredFrame(graphicFrame)) return null;
        var anchorCharacter = graphicFrame.parent;
        var parentTextFrames = anchorCharacter.parentTextFrames;
        if (parentTextFrames.length === 0) return null;   /* オーバーセット / overset */

        var textFrame = parentTextFrames[0];
        var framePrefs = textFrame.textFramePreferences;
        var frameBounds = textFrame.geometricBounds;
        var innerWidth = frameBounds[3] - frameBounds[1] - getHorizontalInsets(textFrame);
        var columnCount = framePrefs.textColumnCount;
        var columnWidth = (innerWidth - framePrefs.textColumnGutter * (columnCount - 1)) / columnCount;

        var anchorParagraph = anchorCharacter.paragraphs[0];
        return columnWidth - anchorParagraph.leftIndent - anchorParagraph.rightIndent;
    }

    /**
     * 指定の幅にぴったり合う縮尺率を返す（整数への丸めは適用時に行う）
     * @param {Graphic} placedGraphic 対象の画像
     * @param {number|null} targetWidth 収めたい幅
     * @returns {number|null} 縮尺率（%）。求められなければ null
     */
    function getFitPercent(placedGraphic, targetWidth) {
        if (targetWidth === null || targetWidth <= 0) return null;
        var graphicBounds = placedGraphic.geometricBounds;
        var graphicWidth = graphicBounds[3] - graphicBounds[1];
        if (graphicWidth <= 0) return null;
        /* 幅は水平の縮尺率に比例する / width is proportional to horizontalScale */
        return placedGraphic.horizontalScale * targetWidth / graphicWidth;
    }

    /**
     * 縮尺率 100% のときの画像の幅・高さ（pt）を返す（回転していても画像の辺に沿って測る）
     * @param {Graphic} placedGraphic 対象の画像
     * @returns {object} { width, height }（pt）。求められない値は null
     */
    function getNaturalSize(placedGraphic) {
        var horizontalScale = placedGraphic.horizontalScale;
        var verticalScale = placedGraphic.verticalScale;
        var topLeft = resolveGraphicCorner(placedGraphic, AnchorPoint.TOP_LEFT_ANCHOR);
        return {
            width: (horizontalScale > 0)
                ? getDistance(topLeft, resolveGraphicCorner(placedGraphic, AnchorPoint.TOP_RIGHT_ANCHOR)) / horizontalScale * 100
                : null,
            height: (verticalScale > 0)
                ? getDistance(topLeft, resolveGraphicCorner(placedGraphic, AnchorPoint.BOTTOM_LEFT_ANCHOR)) / verticalScale * 100
                : null
        };
    }

    /**
     * 縮尺変更の対象を1件作る（幅に合わせるときの縮尺率は変更前の状態で求めておく）
     * @param {PageItem} graphicFrame 対象のフレーム
     * @param {Graphic} placedGraphic フレーム内の画像
     * @returns {object} { frame, graphic, naturalWidthPt, naturalHeightPt, actualPpi, marginLeft, fitPercents }
     */
    function createScaleTarget(graphicFrame, placedGraphic) {
        var targetPage = graphicFrame.parentPage;
        var marginEdges = targetPage ? getMarginEdges(targetPage) : null;
        var naturalSize = getNaturalSize(placedGraphic);
        return {
            frame: graphicFrame,
            graphic: placedGraphic,
            naturalWidthPt: naturalSize.width,
            naturalHeightPt: naturalSize.height,
            /* PDF は PPI を持たない / PDF has no PPI */
            actualPpi: (placedGraphic.reflect.name === "Image") ? placedGraphic.actualPpi[0] : null,
            /* アンカー付きは位置を動かさない / anchored frames are not moved */
            marginLeft: (marginEdges && !isAnchoredFrame(graphicFrame)) ? marginEdges.left : null,
            fitPercents: {
                margin:    getFitPercent(placedGraphic, marginEdges ? marginEdges.right - marginEdges.left : null),
                textFrame: getFitPercent(placedGraphic, getParentColumnWidth(graphicFrame))
            }
        };
    }

    /**
     * 選択範囲から縮尺変更の対象を集める
     * @param {Array} selectedItems 選択中のオブジェクト
     * @returns {Array} createScaleTarget() の戻り値の配列
     */
    function collectScaleTargets(selectedItems) {
        var scaleTargets = [];
        for (var i = 0; i < selectedItems.length; i++) {
            var placedGraphic = getScalableGraphic(selectedItems[i]);
            if (placedGraphic) scaleTargets.push(createScaleTarget(selectedItems[i], placedGraphic));
        }
        return scaleTargets;
    }

    /**
     * 対象の画像に共通する現在の縮尺率を返す
     * @param {Array} scaleTargets collectScaleTargets() の戻り値
     * @returns {object|null} { horizontal, vertical }。画像ごとに異なる場合は null
     */
    function getCommonScale(scaleTargets) {
        var firstGraphic = scaleTargets[0].graphic;
        var commonScale = { horizontal: firstGraphic.horizontalScale, vertical: firstGraphic.verticalScale };
        for (var i = 1; i < scaleTargets.length; i++) {
            var placedGraphic = scaleTargets[i].graphic;
            if (placedGraphic.horizontalScale !== commonScale.horizontal || placedGraphic.verticalScale !== commonScale.vertical) return null;
        }
        return commonScale;
    }

    /**
     * 対象ごとに適用する縮尺率を決める（整数に丸めるときは、入力値は四捨五入、幅に合わせるときははみ出さないよう切り捨て）
     * @param {object} scaleTarget createScaleTarget() の戻り値
     * @param {object} scaleSpec { fitMode, scalePercent, targetLengthPt, targetPpi, roundToInteger, anchorIndex }
     * @returns {number|null} 縮尺率（%）。求められなければ null
     */
    function resolveScalePercent(scaleTarget, scaleSpec) {
        var scalePercent;
        var naturalKey = NATURAL_LENGTH_KEY[scaleSpec.fitMode];
        if (naturalKey) {
            var naturalLength = scaleTarget[naturalKey];
            scalePercent = (naturalLength > 0) ? scaleSpec.targetLengthPt / naturalLength * 100 : null;
        } else if (scaleSpec.fitMode === FIT_MODE.ppi) {
            /* 有効 PPI ＝ 元の PPI ÷ 縮尺率。PPI を上げるほど縮尺率は小さくなる / effective PPI = actual PPI / scale */
            scalePercent = (scaleTarget.actualPpi > 0) ? scaleTarget.actualPpi / scaleSpec.targetPpi * 100 : null;
        } else {
            scalePercent = scaleSpec.fitMode ? scaleTarget.fitPercents[scaleSpec.fitMode] : scaleSpec.scalePercent;
        }
        if (scalePercent === null) return null;
        if (scaleSpec.roundToInteger) {
            /* 浮動小数の誤差で 1 下がらないよう少し足す / nudge so float error does not drop a whole percent */
            scalePercent = scaleSpec.fitMode ? Math.floor(scalePercent + 1e-6) : Math.round(scalePercent);
        }
        return (scalePercent > 0) ? scalePercent : null;
    }

    /**
     * 境界の基準点の座標を返す
     * @param {Array} bounds geometricBounds [上, 左, 下, 右]
     * @param {number} anchorIndex 基準点（0..8 を行優先）
     * @returns {Array} [x, y]
     */
    function getAnchorPosition(bounds, anchorIndex) {
        var col = anchorIndex % 3;
        var row = Math.floor(anchorIndex / 3);
        return [
            bounds[1] + (bounds[3] - bounds[1]) * col / 2,
            bounds[0] + (bounds[2] - bounds[0]) * row / 2
        ];
    }

    /**
     * 画像を縮尺変更し、フレームを画像に合わせる（基準点の位置を保つ。マージン幅のときは左端を左マージンへ）
     * @param {Array} scaleTargets collectScaleTargets() の戻り値
     * @param {object} scaleSpec { fitMode, scalePercent, targetLengthPt, targetPpi, roundToInteger, anchorIndex }
     * @returns {void}
     */
    function scaleGraphicsAndFitFrames(scaleTargets, scaleSpec) {
        for (var i = 0; i < scaleTargets.length; i++) {
            var scaleTarget = scaleTargets[i];
            if (!scaleTarget.frame.isValid) continue;   /* パレット表示中に削除された / deleted while the palette is open */
            var scalePercent = resolveScalePercent(scaleTarget, scaleSpec);
            if (scalePercent === null) continue;   /* 幅に合わせられないフレームは変えない / skip frames that cannot fit */

            /* 基準点の位置を控えてから変形し、あとで同じ位置へ戻す（アンカー付きは動かせない）/ keep the reference point in place (not for anchored frames) */
            var canMove = !isAnchoredFrame(scaleTarget.frame);
            var anchorBefore = canMove ? getAnchorPosition(scaleTarget.frame.geometricBounds, scaleSpec.anchorIndex) : null;

            scaleTarget.graphic.horizontalScale = scalePercent;
            scaleTarget.graphic.verticalScale = scalePercent;
            scaleTarget.frame.fit(FitOptions.FRAME_TO_CONTENT);

            if (canMove) {
                var anchorAfter = getAnchorPosition(scaleTarget.frame.geometricBounds, scaleSpec.anchorIndex);
                scaleTarget.frame.move(undefined, [anchorBefore[0] - anchorAfter[0], anchorBefore[1] - anchorAfter[1]]);
            }

            if (scaleSpec.fitMode === FIT_MODE.margin && scaleTarget.marginLeft !== null) {
                var dx = scaleTarget.marginLeft - scaleTarget.frame.geometricBounds[1];
                scaleTarget.frame.move(undefined, [dx, 0]);
            }
        }
    }

    /**
     * 縮尺変更を 1 段の取り消しとして適用する
     * @param {Array} scaleTargets collectScaleTargets() の戻り値
     * @param {object} scaleSpec { fitMode, scalePercent, targetLengthPt, targetPpi, roundToInteger, anchorIndex }
     * @param {string} undoName 取り消しの名前
     * @returns {void}
     */
    function applyScaleAsOneUndo(scaleTargets, scaleSpec, undoName) {
        app.doScript(
            function () { scaleGraphicsAndFitFrames(scaleTargets, scaleSpec); },
            ScriptLanguage.JAVASCRIPT,
            undefined,
            UndoModes.ENTIRE_SCRIPT,
            undoName
        );
    }

    /**
     * 変更の適用・取り消し・確定を受け持つオブジェクトを作る
     * 変更は常に 1 段の取り消しにまとめ、掛け直すときは直前の 1 段を戻してから適用する
     * @param {Document|null} targetDocument 対象ドキュメント
     * @param {Array} scaleTargets collectScaleTargets() の戻り値
     * @returns {object} apply(scaleSpec)・clear()・keep() を持つオブジェクト
     */
    function createScalePreview(targetDocument, scaleTargets) {
        var previewUndoName = getLabel(LABELS.palette.title);
        var isApplied = false;
        return {
            apply: function (scaleSpec) {
                if (scaleTargets.length === 0 || !targetDocument.isValid) return;
                applyScaleAsOneUndo(scaleTargets, scaleSpec, previewUndoName);
                isApplied = true;
            },
            clear: function () {
                /* 直前の取り消しが自分の変更のときだけ戻す。ドキュメントが閉じられたり別の操作が挟まったりしたら戻さない */
                /* Undo only when the last step is ours; skip when the document was closed or another step intervened */
                if (isApplied && targetDocument.isValid && targetDocument.undoName === previewUndoName) targetDocument.undo();
                isApplied = false;
            },
            keep: function () {
                isApplied = false;
            }
        };
    }

    // =========================================
    // メイン / Main
    // =========================================

    /**
     * 現在の選択から対象と初期値を読み込む
     * @returns {object} { targetDocument, scaleTargets, currentScale, initialPercent, alertLabel }。対象が無いときは alertLabel に理由
     */
    function readSelectionState() {
        var selectionState = {
            targetDocument: null,
            scaleTargets: [],
            currentScale: null,
            initialPercent: DEFAULT_SCALE_PERCENT,
            alertLabel: null
        };
        if (app.documents.length === 0) {
            selectionState.alertLabel = LABELS.alert.noDocument;
            return selectionState;
        }
        selectionState.targetDocument = app.activeDocument;
        var selectedItems = selectionState.targetDocument.selection;
        /* 未選択は警告せず、空のまま開く（選択すると読み込む） / No selection: open empty without a warning */
        if (selectedItems.length === 0) return selectionState;
        selectionState.scaleTargets = collectScaleTargets(selectedItems);
        if (selectionState.scaleTargets.length === 0) {
            selectionState.alertLabel = LABELS.alert.noTargetFrame;
            return selectionState;
        }
        /* 縦横がそろった共通の縮尺率があれば初期値に使う / Start from the common scale when uniform */
        var currentScale = getCommonScale(selectionState.scaleTargets);
        selectionState.currentScale = currentScale;
        if (currentScale !== null && currentScale.horizontal === currentScale.vertical) {
            selectionState.initialPercent = Number(formatNumber(currentScale.horizontal));
        }
        return selectionState;
    }

    /* 前回のパレットが開いていれば閉じる（変更は残る） / Close a palette left open (its changes are kept) */
    if ($.global.idSetImageScalePalette) $.global.idSetImageScalePalette.close();

    /* 対象が無ければパレットを出さずに終える / Skip the palette when nothing applies */
    var initialState = readSelectionState();
    if (initialState.alertLabel) {
        alert(getLabel(initialState.alertLabel));
        return;
    }

    showScalePalette(initialState);

})();
