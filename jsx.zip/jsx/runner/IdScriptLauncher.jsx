#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdScriptLauncher
Name=スクリプトをキーワードで絞り込んで実行
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.3.4
Release-Date=2026-08-26
Description-BEGIN
指定したフォルダー内の .jsx / .js / .jsxbin をキーワードで絞り込み、選んだスクリプトをその場で実行するランチャーです。
フォルダーとファイル名を左右のリストに分けて表示し、絞り込んだ結果によく出てくる語をワンクリックのボタンとして自動で並べます。

A launcher that filters .jsx / .js / .jsxbin files in a chosen folder by keyword and runs the selected script on the spot.
Folders and file names are shown in two side-by-side lists, and words that appear often in the filtered results become one-click buttons automatically.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

指定したフォルダー内の .jsx / .js / .jsxbin をキーワードで絞り込み、選んだスクリプトをその場で実行するランチャーです。
フォルダーとファイル名を左右のリストに分けて表示し、絞り込んだ結果によく出てくる語をワンクリックのボタンとして自動で並べます。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdScriptLauncher.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n86fe7e6251ec

### Overview

A launcher that filters .jsx / .js / .jsxbin files in a chosen folder by keyword and runs the selected script on the spot.
Folders and file names are shown in two side-by-side lists, and words that appear often in the filtered results become one-click buttons automatically.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdScriptLauncher.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdScriptLauncher";             /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.3.4";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-08-26";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "スクリプトをキーワードで絞り込んで実行"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdScriptLauncher.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdScriptLauncher.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n86fe7e6251ec"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/runner/IdScriptLauncher.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

/**
 * @discussion 参考 / Reference
 * 「Finderで表示」の仕組み（Automatorアプリとの連携）
 * 自分用メモ (@mute_racoon3631)「真の「Finderで表示」をイラレでも」
 * https://note.com/mute_racoon3631/n/n9e0e08f5d5f7
 */

(function () {

    // =========================================
    // ユーザー設定 / User Settings
    // =========================================

    /* 一覧に載せる拡張子 / Script file extensions to list */
    var SCRIPT_EXT_RE = /\.(jsx|js|jsxbin)$/i;

    /* スクリプト名から自動で作るキーワードボタンの条件 / Rules for the auto keyword buttons */
    var KEYWORD_MIN_WORD_LENGTH    = 3;      /* ボタンにする語の最小文字数 / minimum word length */
    var KEYWORD_PRESET_MIN_COUNT   = 4;      /* ボタンにする最小出現ファイル数 / minimum number of files */
    var KEYWORD_PRESET_MAX_BUTTONS = 10;     /* ボタンの最大個数 / maximum number of buttons */
    var KEYWORD_PRESET_LIMIT       = 40;     /* 環境設定で指定できる上限 / ceiling for the preferences dialog */
    var KEYWORD_PRESETS_PER_ROW    = 5;      /* 1行に並べる個数 / buttons per row */

    /* ボタンにしない語。件数は多いが検索の役に立たない接続語 / Words never turned into buttons */
    var KEYWORD_STOP_WORDS = ["and", "the", "for", "with", "from", "into", "その他"];

    /* 出現ファイル数が足りなくても常に出す語。小文字・KEYWORD_MIN_WORD_LENGTH以上で書く
       / Words always offered as buttons, regardless of how many files match */
    var KEYWORD_PINNED_WORDS = ["font"];

    /* Finder表示に使うAutomatorアプリと、パスを受け渡す一時ファイル / Automator app used to reveal a file */
    /* 一時ファイル名はアプリ内のAppleScriptが読む固定名。アプリを旧名 IllustratorRevealLink.app から
       改名した名残で綴りが揃っていないが、アプリ側を直すまでここは変えない
       / The temp file name is hard-coded in the app; leave it until the app itself is updated */
    var REVEAL_APP_PATH  = "/Applications/RevealInFinder.app";
    var REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";

    /* 「サブディレクトリを含む」の初期状態 / Initial state of the subfolder checkbox */
    var INCLUDE_SUBFOLDERS_DEFAULT = false;

    /* 「フルパス」の初期状態。OFFではホームフォルダーを ~ に略す / Initial state of the full path checkbox */
    var SHOW_FULL_PATH_DEFAULT = false;

    /* 「検索条件を記憶」の初期状態 / Initial state of the remember checkbox */
    var REMEMBER_SETTINGS_DEFAULT = true;

    /* サブディレクトリOFF時に残す階層の深さ（対象フォルダー直下のフォルダーまで） / Folder depth kept when subfolders are excluded */
    var NESTED_FOLDER_DEPTH_LIMIT = 1;

    // =========================================
    // 設定の保存 / Stored settings
    // =========================================

    /* InDesignには任意の値を残す環境設定APIが無いので、設定ファイルに key=value で書き出す
       / InDesign has no scriptable preference store, so settings go to a key=value file */
    var PREFS_FILE_NAME      = "IdScriptLauncher-prefs.txt";
    var PREF_KEY_FOLDER      = "targetFolder";
    var PREF_KEY_MIN_COUNT   = "keywordMinCount";
    var PREF_KEY_MAX_BUTTONS = "keywordMaxButtons";

    /**
     * 設定ファイルを返す
     * @returns {File} 設定ファイル
     */
    function getPrefsFile() {
        return File(Folder.userData.fsName + "/" + PREFS_FILE_NAME);
    }

    /**
     * 設定ファイルを読み出す
     * @returns {object} キーと文字列値の対応。読めなければ空のオブジェクト
     */
    function loadPrefs() {
        var raw = readTextFile(getPrefsFile());
        if (!raw) return {};

        var prefs = {};
        var lines = String(raw).split("\n");
        for (var i = 0; i < lines.length; i++) {
            /* 値にも = が入りうるので最初の = だけで区切る / Split on the first = only */
            var separatorIndex = lines[i].indexOf("=");
            if (separatorIndex > 0) prefs[lines[i].substring(0, separatorIndex)] = trimWhitespace(lines[i].substring(separatorIndex + 1));
        }
        return prefs;
    }

    /**
     * 設定ファイルを書き出す
     * @param {object} prefs - キーと値の対応
     * @returns {void}
     */
    function savePrefs(prefs) {
        var lines = [];
        for (var key in prefs) {
            if (prefs.hasOwnProperty(key)) lines.push(key + "=" + prefs[key]);
        }

        /* 保存できなくても操作は続けられるので、書き出せたかどうかは見ない / A failed save must not break the run */
        writeTextFile(getPrefsFile(), lines.join("\n"));
    }

    /**
     * 前回使った対象フォルダーを読み出す
     * @returns {Folder|null} 実在するフォルダー。記録がなければ null
     */
    function readSavedScriptFolder() {
        var savedPath = trimWhitespace(loadPrefs()[PREF_KEY_FOLDER] || "");
        if (!savedPath) return null;

        var savedFolder = new Folder(savedPath);
        return savedFolder.exists ? savedFolder : null;
    }

    /**
     * 対象フォルダーを次回起動用に記録する
     * @param {Folder} targetFolder - 記録するフォルダー
     * @returns {void}
     */
    function saveScriptFolder(targetFolder) {
        /* 他のキーを消さないよう、読み出した内容に足してから書き戻す / Merge into the existing file */
        var prefs = loadPrefs();
        prefs[PREF_KEY_FOLDER] = targetFolder.fsName;
        savePrefs(prefs);
    }

    /**
     * 記録済みのキーワード設定を読み出す
     * @returns {{minCount: number, maxButtons: number}} 記録がなければユーザー設定の初期値
     */
    function readKeywordSettings() {
        /* 記録が無いキーは undefined になり、parsePositiveInt が初期値へ落とす / Missing keys fall back */
        var prefs = loadPrefs();

        return {
            minCount: parsePositiveInt(prefs[PREF_KEY_MIN_COUNT], KEYWORD_PRESET_MIN_COUNT),
            maxButtons: parsePositiveInt(prefs[PREF_KEY_MAX_BUTTONS], KEYWORD_PRESET_MAX_BUTTONS, KEYWORD_PRESET_LIMIT)
        };
    }

    /**
     * キーワード設定を記録する
     * @param {number} minCount - 出現数
     * @param {number} maxButtons - キーワード数
     * @returns {void}
     */
    function saveKeywordSettings(minCount, maxButtons) {
        var prefs = loadPrefs();
        prefs[PREF_KEY_MIN_COUNT] = minCount;
        prefs[PREF_KEY_MAX_BUTTONS] = maxButtons;
        savePrefs(prefs);
    }

    // =========================================
    // セッションの記憶 / Session state
    // =========================================

    /* スクリプトは実行のたびに初期化され、グローバル変数は次の実行まで残らない。そのため一時ファイルに
       置き、このセッションを表すidを一緒に書いておく。InDesignを起動し直すとidが変わり、前回の記録は使われない
       / Globals do not survive between runs, so the state lives in a temp file tagged with a session id */
    var SESSION_FILE_NAME = "IdScriptLauncher.session.txt";

    /* InDesignが起動中だけ作る作業用データベース。名前にプロセスidが入るので、起動し直すと変わる
       / A working database that only exists while InDesign runs; its name carries the process id */
    var SESSION_TEMP_DB_MASK = "DBTmp*";
    var RECOVERY_FOLDER_NAME = "InDesign Recovery";

    /* 上のファイルが見つからないとき用。起動のたびに書き直されるので、その時刻をidにする
       / Fallback: this file is rewritten at every launch, so its time can serve as the id */
    var SESSION_MARKER_FILE_NAME = "PluginLoadStartup_Data";

    /* 1回の実行の中でidは変わらないので、調べるのは最初の1回だけにする / Look it up once per run */
    var isSessionIdChecked = false;
    var cachedSessionId = null;

    /**
     * 一時フォルダー内のファイルを返す
     * @param {string} fileName - ファイル名
     * @returns {File} 一時フォルダー内のファイル
     */
    function temporaryFile(fileName) {
        return new File(Folder.temp.fsName + "/" + fileName);
    }

    /**
     * フォルダーの中身を取り出す
     * @param {Folder} folder - 対象のフォルダー
     * @param {string} [mask] - 名前のマスク。省略時はすべて
     * @returns {Array} 見つかった項目。読めなければ空の配列
     */
    function folderEntries(folder, mask) {
        try {
            /* getFiles は読めないと null を返す / getFiles returns null when it fails */
            var entries = (mask === undefined) ? folder.getFiles() : folder.getFiles(mask);
            return entries ? entries : [];
        } catch (e) {
            return [];
        }
    }

    /**
     * 使用中のInDesignのキャッシュフォルダーを集める
     * @returns {Array<Folder>} 言語ごとのフォルダー。見つからなければ空の配列
     */
    function findCacheFolders() {
        /* Folder.userData は ~/Library/Application Support を指す / userData is Application Support on macOS */
        var cacheRoot = new Folder(Folder.userData.parent.fsName + "/Caches/Adobe InDesign");
        if (!cacheRoot.exists) return [];

        /* フォルダー名はビルドによって変わる（Version 21.0-J）ので、メジャーバージョンで始まるものをまとめて見る
           / The folder name differs between builds */
        var versionFolders = folderEntries(cacheRoot, "Version " + parseInt(app.version, 10) + "*");
        var localeFolders = [];

        for (var i = 0; i < versionFolders.length; i++) {
            if (!(versionFolders[i] instanceof Folder)) continue;

            var entries = folderEntries(versionFolders[i]);
            for (var j = 0; j < entries.length; j++) {
                if (entries[j] instanceof Folder) localeFolders.push(entries[j]);
            }
        }
        return localeFolders;
    }

    /**
     * このセッションのidを調べる
     * @returns {string|null} 起動のたびに変わるid。見つからなければ null
     */
    function lookUpSessionId() {
        var localeFolders = findCacheFolders();
        var newestTempDb = null;
        var newestStamp = null;

        for (var i = 0; i < localeFolders.length; i++) {
            /* 落ちたセッションの置き土産が残っていることがあるので、いちばん新しいものを選ぶ
               / A crashed session can leave one behind, so take the newest */
            var tempDbFiles = folderEntries(new Folder(localeFolders[i].fsName + "/" + RECOVERY_FOLDER_NAME), SESSION_TEMP_DB_MASK);
            for (var j = 0; j < tempDbFiles.length; j++) {
                if (!newestTempDb || tempDbFiles[j].modified > newestTempDb.modified) newestTempDb = tempDbFiles[j];
            }

            var marker = new File(localeFolders[i].fsName + "/" + SESSION_MARKER_FILE_NAME);
            if (!marker.exists) continue;

            var stamp = marker.modified || marker.created;
            if (stamp && (!newestStamp || stamp > newestStamp)) newestStamp = stamp;
        }

        /* 名前は起動中ずっと変わらないので、そのままidにできる / The name stays the same for the whole session */
        if (newestTempDb) return newestTempDb.name;
        return newestStamp ? String(newestStamp.getTime()) : null;
    }

    /**
     * このセッションのidを返す
     * @returns {string|null} セッションのid。調べられなかったときは null
     */
    function readSessionId() {
        if (!isSessionIdChecked) {
            isSessionIdChecked = true;
            cachedSessionId = lookUpSessionId();
        }
        return cachedSessionId;
    }

    /**
     * 記録ファイルを「項目名 → 値」の形で読み出す
     * @returns {Object|null} 読み出した項目。ファイルが無ければ null
     */
    function readSessionFields() {
        var savedText = readTextFile(temporaryFile(SESSION_FILE_NAME));
        if (!savedText) return null;

        var savedLines = savedText.split(/\r\n|\r|\n/);
        var savedFields = {};
        for (var i = 0; i < savedLines.length; i++) {
            var separatorIndex = savedLines[i].indexOf("\t");
            if (separatorIndex === -1) continue;
            savedFields[savedLines[i].substring(0, separatorIndex)] = savedLines[i].substring(separatorIndex + 1);
        }
        return savedFields;
    }

    /**
     * このセッションで前回閉じたときの状態を読み出す
     * @returns {{remember: boolean, targetFolder: string|null, keyword: string, includeSubfolders: boolean, showFullPath: boolean, folderPath: string|null, fileName: string|null}} 記録がなければユーザー設定の初期値
     */
    function readSessionState() {
        var defaultState = {
            remember: REMEMBER_SETTINGS_DEFAULT,
            targetFolder: null,
            keyword: "",
            includeSubfolders: INCLUDE_SUBFOLDERS_DEFAULT,
            showFullPath: SHOW_FULL_PATH_DEFAULT,
            folderPath: null,
            fileName: null
        };

        var sessionId = readSessionId();
        if (!sessionId) return defaultState;

        /* 前回のInDesignが残した記録は使わない / Ignore what an earlier InDesign left behind */
        var savedFields = readSessionFields();
        if (!savedFields || savedFields.session !== sessionId) return defaultState;

        return {
            /* 「記憶しない」で閉じたあとは初期値だけが書いてあるので、そのまま読めばよい / Defaults were stored */
            remember: (savedFields.remember === undefined) ? REMEMBER_SETTINGS_DEFAULT : savedFields.remember === "1",
            targetFolder: (savedFields.targetFolder === undefined) ? null : savedFields.targetFolder,
            keyword: (savedFields.keyword === undefined) ? "" : savedFields.keyword,
            includeSubfolders: (savedFields.includeSubfolders === undefined) ? INCLUDE_SUBFOLDERS_DEFAULT : savedFields.includeSubfolders === "1",
            showFullPath: (savedFields.showFullPath === undefined) ? SHOW_FULL_PATH_DEFAULT : savedFields.showFullPath === "1",

            /* 「すべて」を選んでいたときは記録しない。空文字はルート直下を指すので区別する / An empty value means the root */
            folderPath: (savedFields.folderPath === undefined) ? null : savedFields.folderPath,
            fileName: (savedFields.fileName === undefined) ? null : savedFields.fileName
        };
    }

    /**
     * このセッションの記憶を書き換える
     * @param {Object} changes - 書き換える項目だけを持つオブジェクト
     * @returns {void}
     */
    function saveSessionState(changes) {
        var sessionId = readSessionId();
        if (!sessionId) return;

        var sessionState = readSessionState();
        for (var key in changes) {
            if (changes.hasOwnProperty(key)) sessionState[key] = changes[key];
        }

        var savedFields = {
            session: sessionId,
            remember: sessionState.remember ? "1" : "0",
            targetFolder: sessionState.targetFolder,
            keyword: sessionState.keyword,
            includeSubfolders: sessionState.includeSubfolders ? "1" : "0",
            showFullPath: sessionState.showFullPath ? "1" : "0",
            folderPath: sessionState.folderPath,
            fileName: sessionState.fileName
        };

        var savedLines = [];
        for (var fieldName in savedFields) {
            /* null の項目は行ごと書かない。読み出すときに「記録なし」と区別できるようにする / Skip empty fields */
            if (!savedFields.hasOwnProperty(fieldName)) continue;
            if (savedFields[fieldName] === null) continue;

            /* 改行やタブが混じると行の形が壊れるので、その項目はあきらめる / Would break the line format */
            var fieldValue = String(savedFields[fieldName]);
            if (/[\t\r\n]/.test(fieldValue)) continue;

            savedLines.push(fieldName + "\t" + fieldValue);
        }
        writeTextFile(temporaryFile(SESSION_FILE_NAME), savedLines.join("\n"));
    }

    // =========================================
    // テキストファイルの読み書き / Text files
    // =========================================

    /**
     * テキストファイルを読み込む
     * @param {File} textFile - 読み込むファイル
     * @returns {string} 中身。読めなければ空文字
     */
    function readTextFile(textFile) {
        if (!textFile.exists) return "";
        try {
            textFile.encoding = "UTF-8";
            if (!textFile.open("r")) return "";
            return textFile.read();
        } catch (e) {
            return "";
        } finally {
            try { textFile.close(); } catch (e) {}
        }
    }

    /**
     * テキストファイルへ書き出す
     * @param {File} textFile - 書き出すファイル
     * @param {string} text - 書き出す内容
     * @returns {boolean} 書き出せたら true
     */
    function writeTextFile(textFile, text) {
        try {
            textFile.encoding = "UTF-8";
            textFile.lineFeed = "Unix";
            if (!textFile.open("w")) return false;

            textFile.write(text);
            return true;
        } catch (e) {
            return false;
        } finally {
            try { textFile.close(); } catch (e) {}
        }
    }

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    /* 密なパネル・行の間隔 / Spacing for dense panels and rows */
    var DENSE_SPACING      = 8;              /* パネル内を詰めるときの間隔 / dense panel spacing */
    var LIST_LABEL_SPACING = 4;              /* 見出しとリストの間隔 / gap under a list caption */

    /* リストと入力欄の寸法 / List and field sizes */
    var FOLDER_LIST_SIZE  = [165, 360];      /* フォルダーリストの寸法 [幅,高さ] / folder list size */
    var SCRIPT_LIST_SIZE  = [280, 360];      /* ファイル名リストの寸法 [幅,高さ]。ダイアログ幅＝キーワード欄の長さを決める / script list size */

    /* ボタンの寸法と余白 / Button sizes and margins */
    var BUTTON_HEIGHT           = 28;        /* ボタンの高さ / button height */
    var FOLDER_BUTTON_WIDTH     = 120;       /* フォルダー変更ボタンの幅 / change folder button width */
    var DIALOG_BUTTON_WIDTH     = 92;        /* 実行・キャンセルの幅 / dialog button width */
    var SETTINGS_BUTTON_WIDTH   = 100;       /* 環境設定ボタンの幅 / preferences button width */

    /* 環境設定ダイアログ / Preferences dialog */
    var SETTINGS_LABEL_WIDTH = 100;          /* 項目名の幅 / field label width */
    var SETTINGS_INPUT_WIDTH = 60;           /* 数値入力欄の幅 / number field width */
    var FOLDER_PATH_WIDTH    = 360;          /* 対象フォルダーのパス表示の幅 / target folder path width */
    var CHECKBOX_TOP_MARGIN     = 10;        /* リスト下のチェックボックスの上余白 / top margin above a checkbox under a list */
    var REMEMBER_ROW_TOP_MARGIN = 5;         /* 「検索条件を記憶」の上余白 / top margin above the remember checkbox */

    /* キーワードボタンは小ぶりにする / Keyword preset buttons are smaller */
    var PRESET_BUTTON_HEIGHT  = 22;          /* キーワードボタンの高さ / preset button height */
    var PRESET_BUTTON_PADDING = 16;          /* 文字幅に足す左右の余白 / horizontal padding */
    var PRESET_CHAR_WIDTH     = 7;           /* 実測できない環境用の1文字概算幅 / fallback char width */

    /* キーワード欄のクリアボタン（自前描画） / Clear button next to the keyword field (custom drawn) */
    var CLEAR_BUTTON_SIZE    = 20;           /* クリアボタンの一辺 / clear button size */
    var CLEAR_CIRCLE_INSET   = 2;            /* 円と外周の間隔 / inset of the circle */
    var CLEAR_GLYPH_INSET    = 6;            /* ×と外周の間隔 / inset of the × glyph */
    var CLEAR_STROKE_WIDTH   = 1.5;          /* 円と×の線幅 / stroke width */

    /**
     * 見出し付きのリスト用カラムを作る
     * @param {Group} parent - 追加先のグループ
     * @param {string} captionText - リストの見出し
     * @returns {Group} 見出しを追加済みのカラムグループ
     */
    function addListColumn(parent, captionText) {
        var column = parent.add("group");
        column.orientation = "column";
        column.alignChildren = ["fill", "top"];
        column.spacing = LIST_LABEL_SPACING;
        column.add("statictext", undefined, captionText);
        return column;
    }

    /**
     * ボタンの寸法をそろえる
     * @param {Button} button - 対象ボタン
     * @param {number} width - ボタンの幅
     * @returns {void}
     */
    function applyButtonSize(button, width) {
        button.preferredSize = [width, BUTTON_HEIGHT];
        button.minimumSize = [width, BUTTON_HEIGHT];
    }

    /**
     * キーワードボタンの寸法を文字幅に合わせて詰める
     * @param {Button} button - 対象ボタン
     * @returns {void}
     */
    function applyPresetButtonSize(button) {
        /* 実測できればそれを使い、駄目なら文字数から概算する / Measure if possible, else estimate */
        var textWidth = String(button.text).length * PRESET_CHAR_WIDTH;
        try {
            var measured = button.graphics.measureString(button.text);
            var measuredWidth = (measured.width !== undefined) ? measured.width : measured[0];
            /* 環境によっては値が取れずNaNになる。その場合は概算のままにする / Keep the estimate if unusable */
            if (!isNaN(measuredWidth) && measuredWidth > 0) textWidth = measuredWidth;
        } catch (e) {}

        var buttonWidth = Math.ceil(textWidth) + PRESET_BUTTON_PADDING;
        button.preferredSize = [buttonWidth, PRESET_BUTTON_HEIGHT];
        button.minimumSize = [buttonWidth, PRESET_BUTTON_HEIGHT];
    }

    /**
     * クリアボタンの丸と×を描く
     * @param {Button} button - 対象ボタン
     * @returns {void}
     */
    function drawClearButton(button) {
        var graphics = button.graphics;
        var size = button.size[0];
        var useLightUI = !isDarkUI();

        /* 主役ではないので、通常時も少し薄めに描く。押している間は濃くして手応えを出す / Slightly muted, darker while pressed */
        var glyphColor = useLightUI ? [0.45, 0.45, 0.45, 1] : [0.72, 0.72, 0.72, 1];
        if (button.pressed) glyphColor = useLightUI ? [0.20, 0.20, 0.20, 1] : [0.95, 0.95, 0.95, 1];

        /* キーワードが空のときは無効にしてあるので、さらに淡くする / Dim further while disabled */
        if (button.enabled === false) glyphColor = useLightUI ? [0.78, 0.78, 0.78, 1] : [0.42, 0.42, 0.42, 1];

        /* 前回の描画を消すため、まず親と同じ色で塗りつぶす。InDesignでは背景ブラシが取れないので何もしない / No-op in InDesign */
        try {
            graphics.newPath();
            graphics.rectPath(0, 0, size, size);
            graphics.fillPath(graphics.backgroundColor);
        } catch (e) {}

        var pen = graphics.newPen(graphics.PenType.SOLID_COLOR, glyphColor, CLEAR_STROKE_WIDTH);
        var circleSize = size - CLEAR_CIRCLE_INSET * 2;
        graphics.newPath();
        graphics.ellipsePath(CLEAR_CIRCLE_INSET, CLEAR_CIRCLE_INSET, circleSize, circleSize);
        graphics.strokePath(pen);

        var glyphStart = CLEAR_GLYPH_INSET;
        var glyphEnd = size - CLEAR_GLYPH_INSET;
        graphics.newPath();
        graphics.moveTo(glyphStart, glyphStart);
        graphics.lineTo(glyphEnd, glyphEnd);
        graphics.strokePath(pen);
        graphics.newPath();
        graphics.moveTo(glyphEnd, glyphStart);
        graphics.lineTo(glyphStart, glyphEnd);
        graphics.strokePath(pen);
    }

    /**
     * キーワードを消すクリアボタンを作る
     * @param {Group} parent - 追加先のグループ
     * @returns {Button} 丸に×を自前描画したボタン
     */
    function addClearButton(parent) {
        var button = parent.add("button", undefined, "");
        button.helpTip = getLabel(LABELS.button.clearKeyword);
        button.alignment = ["right", "center"];
        button.preferredSize = [CLEAR_BUTTON_SIZE, CLEAR_BUTTON_SIZE];
        button.minimumSize = [CLEAR_BUTTON_SIZE, CLEAR_BUTTON_SIZE];
        button.maximumSize = [CLEAR_BUTTON_SIZE, CLEAR_BUTTON_SIZE];
        button.pressed = false;

        /* 実際の状態は呼び出し側が入力欄に合わせる / The caller syncs this with the field */
        button.enabled = false;

        button.onDraw = function () {
            drawClearButton(this);
        };
        button.addEventListener("mousedown", function () {
            this.pressed = true;
            this.notify("onDraw");
        });
        button.addEventListener("mouseup", function () {
            this.pressed = false;
            this.notify("onDraw");
        });
        /* ボタンの外でマウスを離したときも押下表示を戻す / Reset the pressed look on mouseout */
        button.addEventListener("mouseout", function () {
            if (!this.pressed) return;
            this.pressed = false;
            this.notify("onDraw");
        });

        return button;
    }

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 }, /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 }, /* 歯 / H */
        "p": { unit: "pc", amount: 1 }     /* パイカ / pica */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と異なる単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); }).helpTip = getLabel(upTooltip);
        makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); }).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) return;
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^([A-Za-z]+|%|°)/.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    // =========================================
    // ラベル定義 / Labels
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // バージョン表示（再利用パーツ） / Version footer (reusable)

    var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
    var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
    var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
    var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
    var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
    var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

    /* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
       9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
       / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
         nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
    var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
    var VERSION_FOOTER_GLYPHS = {
        "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
        "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
        "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
        "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
        "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
        "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
        "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
        "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
        "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
        "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
        "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
        "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
        "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
        "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
        "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
        "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
        "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
        "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
        "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
        "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
        "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
        "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
        "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
        "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
        "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
        "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
        "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
        "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
        "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
        "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
        "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
        "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
        "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
        "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
        "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
        "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
        "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
        "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
        "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
        "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
        "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
        "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
        "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
        "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
        "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
        "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
        "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
        "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
        "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
        "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
        "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
        "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
        "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
        "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
        "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
        "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
        "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
        "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
        "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
        ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
        "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
        "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
        "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
        " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
    };

    /**
     * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
     * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
     * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
     * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
     * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
     */
    function addVersionFooter(targetWindow) {
        if (targetWindow.versionFooter) return null;

        /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
        var lastChild = targetWindow.children[targetWindow.children.length - 1];
        if (lastChild && lastChild.type === "group") {
            var rowMargins = lastChild.margins;
            lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
        }
        var windowMargins = targetWindow.margins;
        targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

        var footerGroup = targetWindow.add("group");
        footerGroup.orientation = "row";
        footerGroup.alignment = ["fill", "bottom"];
        footerGroup.alignChildren = ["left", "center"];
        footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

        /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
           左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
           / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
             or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
        var versionText = String(SCRIPT_VERSION);
        var leftCandidates = [versionText];
        if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
        var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
        versionCanvas.alignment = ["fill", "center"];
        bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
        var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
        brandCanvas.alignment = ["right", "center"];
        brandCanvas.maximumSize = brandCanvas.preferredSize;
        targetWindow.versionFooter = footerGroup;
        return versionCanvas;
    }

    /**
     * 文字列のすべての文字に字形があるかを返す
     * @param {string} dotText - 文字列
     * @returns {boolean} すべてあれば true
     */
    function hasVersionFooterGlyphs(dotText) {
        for (var i = 0; i < dotText.length; i++) {
            if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
        }
        return dotText.length > 0;
    }

    /**
     * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
     * @param {Group} parentGroup - 足す先
     * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
     * @returns {Group} 描くグループ
     */
    function addVersionFooterCanvas(parentGroup, dotTexts) {
        var dotCanvas = parentGroup.add("group");
        var shortestText = dotTexts[dotTexts.length - 1];
        dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
        dotCanvas.helpTip = dotTexts[0];
        dotCanvas.onDraw = function () {
            var availableWidth = this.size ? this.size.width : 0;
            var drawText = shortestText;
            for (var i = 0; i < dotTexts.length; i++) {
                if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                    drawText = dotTexts[i];
                    break;
                }
            }
            drawVersionFooterDots(this.graphics, drawText);
        };
        return dotCanvas;
    }

    /**
     * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
     * @param {string} versionText - 文字列
     * @returns {number} 幅（ドット）
     */
    function measureVersionFooterDots(versionText) {
        var dotCount = 0;
        for (var i = 0; i < versionText.length; i++) {
            var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
            if (!glyphRows) continue;
            if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
            dotCount += glyphRows[0].length;
        }
        return dotCount;
    }

    /**
     * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
     * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
     * @param {string} versionText - 文字列
     * @returns {void}
     */
    function drawVersionFooterDots(canvasGraphics, versionText) {
        var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
        var dotSize = VERSION_FOOTER_PIXEL_SIZE;
        var cursorDots = 0;
        canvasGraphics.newPath();
        for (var i = 0; i < versionText.length; i++) {
            var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
            if (!glyphRows) continue;
            if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
            for (var row = 0; row < glyphRows.length; row++) {
                var rowText = glyphRows[row];
                var runStart = -1;
                for (var col = 0; col <= rowText.length; col++) {
                    var isDot = col < rowText.length && rowText.charAt(col) === "#";
                    if (isDot && runStart < 0) runStart = col;
                    if (!isDot && runStart >= 0) {
                        canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                        runStart = -1;
                    }
                }
            }
            cursorDots += glyphRows[0].length;
        }
        canvasGraphics.fillPath(footerBrush);
    }

    // -----------------------------------------
    // このスクリプトについて / About this script
    // -----------------------------------------
    /* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
       この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
       Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
       and keeps its own labels and layout values so the part works on its own */

    var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
    var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
    /* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
       The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
    var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
    var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
    var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

    var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
    var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
    var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
    var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
    var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
    var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
    var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
    /* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
    var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
    var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
    var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
    var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

    var VERSION_INFO_LABELS = {
        dialog: {
            title: { ja: "このスクリプトについて", en: "About This Script" }
        },
        panel: {
            generalInfo: { ja: "基本情報", en: "General" },
            links: { ja: "リンク", en: "Links" }
        },
        fieldLabel: {
            scriptName: { ja: "スクリプト名", en: "Script Name" },
            scriptFeature: { ja: "機能", en: "Feature" },
            scriptVersion: { ja: "バージョン", en: "Version" }
        },
        button: {
            openReadme: { ja: "README", en: "README" },
            openSourceCode: { ja: "ソースコード", en: "Source Code" },
            openArticle: { ja: "記事（note）", en: "Article (note)" },
            revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
            revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
            close: { ja: "閉じる", en: "Close" }
        },
        tooltip: {
            versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
            copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
        },
        alert: {
            copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
        }
    };

    /**
     * VERSION_INFO_LABELS の文言を今の言語で返す
     * @param {Object} labelEntry - { ja, en }
     * @returns {string} 文言
     */
    function getVersionInfoLabel(labelEntry) {
        return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
    }

    /**
     * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
     * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
     * @returns {string} 値
     */
    function getVersionInfoValue(variableKey) {
        var infoValue;
        if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
        else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
        else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
        else if (variableKey === "readme") {
            if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
            else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
        }
        else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
        else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
        return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
    }

    /**
     * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
     * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
     * @returns {void}
     */
    function bindVersionInfoClick(versionCanvas) {
        versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
        /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
           Open on mouseup so the release does not land on the footer after the dialog closes */
        versionCanvas.addEventListener("mouseup", function () {
            showVersionInfoDialog(versionCanvas.window.type === "palette");
        });
    }

    /**
     * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
     * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
     * @returns {void}
     */
    function showVersionInfoDialog(isFromPalette) {
        var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
        infoDialog.orientation = "column";
        infoDialog.alignChildren = "fill";
        infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
        infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

        var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
        /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
        /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
        if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
            addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
        }
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
        alignVersionInfoLabels(infoPanel);

        /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
        var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
        var linkButtonRow = linksPanel.add("group");
        linkButtonRow.orientation = "row";
        linkButtonRow.alignment = ["left", "center"];
        linkButtonRow.alignChildren = ["left", "center"];
        linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

        /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
        var buttonRow = infoDialog.add("group");
        buttonRow.orientation = "row";
        buttonRow.alignment = ["fill", "bottom"];
        buttonRow.alignChildren = ["left", "center"];
        buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
        buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
        var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
        var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
        if (VERSION_INFO_SCRIPT_FILE.exists) {
            revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
            revealButton.onClick = function () {
                revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
                infoDialog.close();
            };
        } else {
            revealButton.enabled = false;
        }
        /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
        var buttonSpacer = buttonRow.add("group");
        buttonSpacer.alignment = ["fill", "fill"];
        buttonSpacer.minimumSize.width = 0;
        var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
        closeButton.alignment = ["right", "center"];
        /* return でも esc でも閉じる / Close with both Return and Esc */
        infoDialog.defaultElement = closeButton;
        infoDialog.cancelElement = closeButton;
        infoDialog.onShow = function () {
            pinVersionInfoCopyButton(infoPanel);
        };
        infoDialog.show();
    }

    /**
     * 「このスクリプトについて」のダイアログにパネルを足す
     * @param {Window} infoDialog - 足す先のダイアログ
     * @param {Object} titleEntry - パネル名の文言 { ja, en }
     * @returns {Panel} パネル
     */
    function addVersionInfoPanel(infoDialog, titleEntry) {
        var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
        infoPanel.orientation = "column";
        infoPanel.alignChildren = ["fill", "top"];
        infoPanel.alignment = "fill";
        infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
        infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
        return infoPanel;
    }

    /**
     * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
     * @param {Panel} infoPanel - 足す先のパネル
     * @param {Object} labelEntry - 項目名の文言 { ja, en }
     * @param {string} valueText - 表示する値
     * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
     * @returns {StaticText} 値の statictext
     */
    function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
        var infoRow = infoPanel.add("group");
        infoRow.orientation = "row";
        infoRow.alignment = ["fill", "center"];
        infoRow.alignChildren = ["left", "center"];
        infoRow.spacing = VERSION_INFO_ROW_SPACING;
        /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
        var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
        rowLabel.justify = "right";
        var valueLabel = infoRow.add("statictext", undefined, valueText);
        if (copyFromPalette === null) return valueLabel;
        /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
           A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
        var copySpacer = infoRow.add("group");
        copySpacer.alignment = ["fill", "fill"];
        copySpacer.minimumSize.width = 0;
        infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
        return valueLabel;
    }

    /**
     * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
     * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
     * @param {Panel} infoPanel - ［基本情報］パネル
     * @returns {void}
     */
    function pinVersionInfoCopyButton(infoPanel) {
        var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
        for (var i = 0; i < infoPanel.children.length; i++) {
            var infoRow = infoPanel.children[i];
            if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
            infoRow.size = [innerWidth, infoRow.size.height];
            infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
        }
    }

    /**
     * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
     * @param {Panel} infoPanel - 対象のパネル
     * @returns {void}
     */
    function alignVersionInfoLabels(infoPanel) {
        var rowLabels = [];
        var labelWidth = 0;
        for (var i = 0; i < infoPanel.children.length; i++) {
            var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
            rowLabels.push(rowLabel);
            labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
        }
        for (var j = 0; j < rowLabels.length; j++) {
            rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
        }
    }

    /**
     * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
     * @param {Window} infoDialog - ボタンを置くダイアログ
     * @param {Group} buttonGroup - 足す先のグループ
     * @param {Object} labelEntry - ボタンの文言 { ja, en }
     * @param {string} targetUrl - 開く URL（空ならディム表示）
     * @returns {void}
     */
    function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
        var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
        if (!targetUrl) {
            linkButton.enabled = false;
            return;
        }
        linkButton.helpTip = targetUrl;
        linkButton.onClick = function () {
            openVersionInfoUrl(targetUrl);
            infoDialog.close();
        };
    }

    /**
     * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
     * @param {Group} infoRow - 足す先の行
     * @param {StaticText} valueLabel - コピーする値の statictext
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
     * @returns {Group} ボタンとして使う group
     */
    function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
        var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
        var copyButton = infoRow.add("group");
        copyButton.preferredSize = [buttonSize, buttonSize];
        copyButton.minimumSize = [buttonSize, buttonSize];
        copyButton.maximumSize = [buttonSize, buttonSize];
        copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
        copyButton.isPressed = false;
        copyButton.isCopied = false;

        copyButton.onDraw = function () {
            var buttonGraphics = copyButton.graphics;
            var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
            buttonGraphics.newPath();
            buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
            buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
            buttonGraphics.newPath();
            buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
            buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
            if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
            else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
        };

        /**
         * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
         * @param {boolean} isPressed - 押下中なら true
         * @param {boolean} isCopied - コピー済みなら true
         * @returns {void}
         */
        function repaint(isPressed, isCopied) {
            if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
            copyButton.isPressed = isPressed;
            copyButton.isCopied = isCopied;
            copyButton.hide();
            copyButton.show();
        }
        copyButton.addEventListener("mousedown", function () { repaint(true, false); });
        copyButton.addEventListener("mouseup", function () {
            if (!copyButton.isPressed) return;
            var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
            repaint(false, hasCopied);
            if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
        });
        /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
        copyButton.addEventListener("mouseout", function () { repaint(false, false); });
        return copyButton;
    }

    /**
     * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
     * @param {ScriptUIGraphics} buttonGraphics - 描画先
     * @param {number} buttonSize - ボタンの一辺
     * @returns {void}
     */
    function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
        var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
        var sheetSize = 9;
        var offset = 3;
        var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
        var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
        var backLeft = frontLeft - offset;
        var backTop = frontTop - offset;
        /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
        buttonGraphics.newPath();
        buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
        buttonGraphics.lineTo(backLeft, backTop + sheetSize);
        buttonGraphics.lineTo(backLeft, backTop);
        buttonGraphics.lineTo(backLeft + sheetSize, backTop);
        buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
        buttonGraphics.strokePath(iconPen);
        buttonGraphics.newPath();
        buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
        buttonGraphics.strokePath(iconPen);
    }

    /**
     * コピーしたあとのチェックマークを描く
     * @param {ScriptUIGraphics} buttonGraphics - 描画先
     * @param {number} buttonSize - ボタンの一辺
     * @returns {void}
     */
    function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
        var center = buttonSize / 2;
        buttonGraphics.newPath();
        buttonGraphics.moveTo(center - 4.5, center);
        buttonGraphics.lineTo(center - 1.5, center + 3);
        buttonGraphics.lineTo(center + 4.5, center - 3.5);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
    }

    /**
     * 文字列をクリップボードにコピーする。
     * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
     * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
     * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
     * @param {string} copyText - コピーする文字列
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
     * @returns {boolean} コピーの操作まで進めたら true
     */
    function copyVersionInfoText(copyText, isFromPalette) {
        try {
            if (VERSION_INFO_IS_INDESIGN) {
                if (File.fs === "Windows") {
                    app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
                } else {
                    app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
                }
                return true;
            }
            var copyScript = buildVersionInfoCopyScript(copyText);
            if (!isFromPalette) return eval(copyScript) === true;
            var copyMessage = new BridgeTalk();
            copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
            copyMessage.body = copyScript;
            copyMessage.send();
            return true;
        } catch (e) {
            return false;
        }
    }

    /**
     * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
     * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
     * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
     * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
     * @param {string} copyText - コピーする文字列
     * @returns {string} 実行すると true / false を返すスクリプト
     */
    function buildVersionInfoCopyScript(copyText) {
        return [
            "(function (copyText) {",
            "    var usingTempDoc = (app.documents.length === 0);",
            "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
            "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
            "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
            "    var tempLayer = null;",
            "    var hasCopied = false;",
            "    try {",
            "        tempLayer = targetDoc.layers.add();",
            "        var tempFrame = tempLayer.textFrames.add();",
            "        tempFrame.contents = copyText;",
            "        app.redraw();",
            "        app.executeMenuCommand('deselectall');",
            "        tempFrame.selected = true;",
            "        app.redraw();",
            "        app.executeMenuCommand('copy');",
            "        app.redraw();",
            "        hasCopied = true;",
            "    } catch (e) { }",
            "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
            "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
            "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
            "    targetDoc.selection = null;",
            "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
            "    app.redraw();",
            "    return hasCopied;",
            "})(" + quoteVersionInfoString(copyText) + ");"
        ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
    }

    /**
     * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
     * @param {string} sourceText - 文字列
     * @returns {string} "…" の形のリテラル
     */
    function quoteVersionInfoString(sourceText) {
        return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
    }

    /**
     * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
     * @param {File} scriptFile - 表示するファイル
     * @returns {void}
     */
    function revealVersionInfoScriptFile(scriptFile) {
        /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
        var hasRevealApp = (File.fs === "Macintosh")
            && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
        /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
        if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
        /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
        scriptFile.parent.execute();
    }

    /**
     * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
     * @param {string} targetPath - 絶対パス
     * @returns {boolean} 書き出せたら true
     */
    function writeVersionInfoRevealPath(targetPath) {
        var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
        pathFile.encoding = "UTF-8";
        pathFile.lineFeed = "Unix";
        if (!pathFile.open("w")) return false;
        var hasWritten = pathFile.write(targetPath);
        pathFile.close();
        return hasWritten;
    }

    /**
     * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
     * @param {string} targetUrl - 開く URL
     * @returns {void}
     */
    function openVersionInfoUrl(targetUrl) {
        var isMac = (File.fs === "Macintosh");
        var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
        shortcutFile.encoding = "UTF-8";
        shortcutFile.open("w");
        if (isMac) {
            var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
            shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
                + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
        } else {
            shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
        }
        shortcutFile.close();
        shortcutFile.execute();
    }

    // バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

    // ファイルビューアで表示（再利用パーツ） / Show in file viewer (reusable)

    /**
     * Path Finder（起動中のとき）か Finder で、フォルダーを開くかファイルを選択して表示する。
     * 補助アプリ /Applications/OpenInFileViewer.app に一時ファイルでパスを渡して起動する。
     * 補助アプリは illustrator-scripts の helpers/OpenInFileViewer.applescript から作る
     * @param {File|Folder} targetItem - 開くフォルダーか、選択して表示するファイル
     * @returns {boolean} 補助アプリを起動できたら true。無い・起動できない・macOS 以外のときは false
     */
    function openInFileViewer(targetItem) {
        /* 定数は巻き上げで未定義にならないよう関数内に置く / Kept local so hoisting never leaves them undefined */
        var viewerAppPath = "/Applications/OpenInFileViewer.app";
        var pathFilePath = "/tmp/open_in_file_viewer_path.txt";

        if ($.os.indexOf("Mac") === -1) return false;
        /* .app は実体がディレクトリなので Folder でも確かめる / An .app is a directory, so check it as a Folder too */
        if (!new Folder(viewerAppPath).exists && !new File(viewerAppPath).exists) return false;

        var pathFile = new File(pathFilePath);
        var written = false;
        try {
            pathFile.encoding = "UTF-8";
            pathFile.lineFeed = "Unix";
            if (pathFile.open("w")) {
                /* fsName で ~ ではなく絶対パスを渡す / fsName gives the absolute POSIX path */
                written = pathFile.write(targetItem.fsName);
            }
        } catch (e) {
        } finally {
            try { pathFile.close(); } catch (closeError) {}
        }
        return written && new File(viewerAppPath).execute();
    }

    // ファイルビューアで表示（再利用パーツ）ここまで / End of the reusable file viewer

    var LABELS = {
        dialog: {
            title:           { ja: "スクリプトランチャー", en: "Script Launcher" },
            selectFolder:    { ja: "検索対象のスクリプトフォルダーを選択してください", en: "Select the script folder to search" },
            preferences:     { ja: "環境設定", en: "Preferences" }
        },
        panel: {
            keyword:        { ja: "絞り込み（%1件）", en: "Filter (%1)" },
            scriptFolder:   { ja: "対象フォルダー", en: "Target Folder" },
            keywordButtons: { ja: "キーワードボタン", en: "Keyword Buttons" }
        },
        listCaption: {
            folder:   { ja: "フォルダー", en: "Folder" },
            fileName: { ja: "ファイル名", en: "File Name" }
        },
        folderRow: {
            allFolders: { ja: "（すべて）", en: "(All)" },
            rootFolder: { ja: "（ルート）", en: "(Root)" }
        },
        fieldLabel: {
            keyword:    { ja: "キーワード", en: "Keyword" },
            minCount:   { ja: "出現数", en: "Occurrences" },
            maxButtons: { ja: "キーワード数", en: "Keywords" }
        },
        checkbox: {
            includeSubfolders: { ja: "サブディレクトリを含む", en: "Include subdirectories" },
            showFullPath:      { ja: "フルパス", en: "Full path" },
            rememberSettings:  { ja: "検索条件を記憶", en: "Remember the search" }
        },
        tooltip: {
            rememberSettings: { ja: "InDesignを終了するまでのあいだ引き継ぎます", en: "Carried over until InDesign quits" },
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
        },
        button: {
            changeFolder:    { ja: "フォルダー変更", en: "Change Folder" },
            clearKeyword:    { ja: "キーワードをクリア", en: "Clear keyword" },
            preferences:     { ja: "環境設定", en: "Preferences" },
            cancel:          { ja: "キャンセル", en: "Cancel" },
            run:             { ja: "実行", en: "Run" },
            ok:              { ja: "OK", en: "OK" }
        },
        alert: {
            noScripts: {
                ja: "対象フォルダー内に .jsx / .js / .jsxbin ファイルが見つかりませんでした。",
                en: "No .jsx / .js / .jsxbin files were found in the target folder."
            },
            missingScript: {
                ja: "選択したスクリプトが見つかりません。",
                en: "The selected script could not be found."
            },
            runFailed: {
                ja: "スクリプトの実行中にエラーが発生しました。\n\n%1\n\nエラー: %2",
                en: "An error occurred while running the script.\n\n%1\n\nError: %2"
            },
            errorLine: {
                ja: "\n行: %1",
                en: "\nLine: %1"
            }
        }
    };

    // =========================================
    // スクリプトの収集と検索キー / Script collection and search keys
    // =========================================

    /**
     * スクリプト1件分の情報
     * @typedef {object} ScriptEntry
     * @property {File} file - スクリプトファイル
     * @property {string} fileName - デコード済みのファイル名
     * @property {string} localizedFileName - OSの表示名
     * @property {string} relativePath - 対象フォルダーからの相対パス
     * @property {string} folderPath - 相対パスのフォルダー部分
     * @property {number} folderDepth - 対象フォルダーからの階層の深さ
     * @property {string} searchText - 検索対象を連結した文字列
     * @property {string} normalizedSearchText - 正規化済みの検索キー
     * @property {Array<string>} nameWords - ファイル名から取り出した語（キーワードボタン用）
     */

    /**
     * 前後の空白を取り除く
     * @param {string} value - 対象の文字列
     * @returns {string} 前後の空白を除いた文字列
     */
    function trimWhitespace(value) {
        return String(value).replace(/^\s+|\s+$/g, "");
    }

    /* 半角カナを全角カタカナへ置き換える並び。U+FF61 から順に対応する / Half-width kana in code point order */
    var KANA_HALFWIDTH_START = 0xFF61;
    var KANA_HALFWIDTH_TABLE = "。「」、・ヲァィゥェォャュョッーアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン";
    var KANA_HALFWIDTH_END   = KANA_HALFWIDTH_START + KANA_HALFWIDTH_TABLE.length - 1;

    /**
     * カタカナを濁点・半濁点・小書きのない基音へ寄せる
     * 変換表は持たず、Unicodeの並び方から計算する
     * @param {number} code - カタカナのコードポイント
     * @returns {number} 基音のコードポイント。カタカナ以外はそのまま返す
     */
    function foldKatakana(code) {
        /* ヴ と ヷヸヹヺ は並びから外れるので個別に扱う / These sit outside the regular rows */
        if (code === 0x30F4) return 0x30A6;
        if (code >= 0x30F7 && code <= 0x30FA) return code - 8;

        /* カ〜ヂ、ツ〜ド は「清音・濁音」の2つ並び。ッ を挟んで並びが一度切れる / Pairs, broken by ッ */
        if (code >= 0x30AB && code <= 0x30C2 && (code - 0x30AB) % 2 === 1) code -= 1;
        else if (code >= 0x30C4 && code <= 0x30C9 && (code - 0x30C4) % 2 === 1) code -= 1;

        /* ハ〜ポ は「清音・濁音・半濁音」の3つ並び / The ha row runs in threes */
        else if (code >= 0x30CF && code <= 0x30DD) code -= (code - 0x30CF) % 3;

        /* 小書きは対応する大書きの1つ手前にある / Each small kana sits right before its large form */
        if (code === 0x30A1 || code === 0x30A3 || code === 0x30A5 || code === 0x30A7 || code === 0x30A9 ||
            code === 0x30C3 || code === 0x30E3 || code === 0x30E5 || code === 0x30E7 || code === 0x30EE) {
            code += 1;
        }
        return code;
    }

    /**
     * 比較用の検索キーへ変換する
     * 大文字小文字・全角半角・かなの種類・濁点や小書きの違いを無視して一致させる
     * @param {string} value - 変換前の文字列
     * @returns {string} 正規化した文字列
     */
    function normalizeSearchKey(value) {
        var source = String(value).toLowerCase();
        var normalized = "";

        for (var i = 0; i < source.length; i++) {
            var currentChar = source.charAt(i);
            if (/\s/.test(currentChar)) continue;

            var code = source.charCodeAt(i);

            /* 単独の濁点・半濁点は落とす。濁りは基音へ寄せるので不要 / Standalone voiced marks are dropped */
            if (code === 0x3099 || code === 0x309A || code === 0x309B || code === 0x309C ||
                code === 0xFF9E || code === 0xFF9F) continue;

            /* 全角の英数記号は半角へ / Full-width ASCII to half-width */
            if (code >= 0xFF01 && code <= 0xFF5E) {
                normalized += String.fromCharCode(code - 0xFEE0).toLowerCase();
                continue;
            }

            /* 半角カナは全角カタカナへ / Half-width kana to full-width katakana */
            if (code >= KANA_HALFWIDTH_START && code <= KANA_HALFWIDTH_END) {
                code = KANA_HALFWIDTH_TABLE.charCodeAt(code - KANA_HALFWIDTH_START);
            }

            /* ひらがなはカタカナへ寄せる / Hiragana to katakana */
            if (code >= 0x3041 && code <= 0x3096) code += 0x60;

            normalized += String.fromCharCode(foldKatakana(code));
        }
        return normalized;
    }

    /**
     * 入力文字列を空白区切りの検索語に分解する
     * @param {string} value - キーワード欄の文字列
     * @returns {Array<string>} 正規化した検索語。空の語は含まない
     */
    function splitSearchTerms(value) {
        var rawTerms = String(value).split(/\s+/);
        var searchTerms = [];
        for (var i = 0; i < rawTerms.length; i++) {
            var term = normalizeSearchKey(rawTerms[i]);
            if (term !== "") searchTerms.push(term);
        }
        return searchTerms;
    }

    /**
     * 検索語をすべて含むかどうかを判定する（AND検索）
     * @param {string} searchTarget - 正規化済みの検索対象
     * @param {Array<string>} searchTerms - 正規化済みの検索語
     * @returns {boolean} すべて含むなら true
     */
    function matchesSearchTerms(searchTarget, searchTerms) {
        for (var i = 0; i < searchTerms.length; i++) {
            if (searchTarget.indexOf(searchTerms[i]) === -1) return false;
        }
        return true;
    }

    /**
     * 初回起動時に開くフォルダーを返す
     * @returns {Folder} InDesignのスクリプトフォルダー。取得できなければ書類フォルダー
     */
    function getDefaultScriptFolder() {
        try {
            var scriptsFolder = app.scriptPreferences.scriptsFolder;

            /* 環境によって Folder と文字列のどちらも返りうる / Either a Folder or a path string */
            if (!(scriptsFolder instanceof Folder)) scriptsFolder = new Folder(String(scriptsFolder));
            if (scriptsFolder.exists) return scriptsFolder;
        } catch (e) {}
        return Folder.myDocuments;
    }

    /**
     * 対象フォルダーを選ばせる
     * @param {Folder|null} currentFolder - 初期表示に使うフォルダー
     * @returns {Folder|null} 選ばれたフォルダー。取り消し時は null
     */
    function chooseScriptFolder(currentFolder) {
        var startFolder = currentFolder && currentFolder.exists ? currentFolder : getDefaultScriptFolder();
        return startFolder.selectDlg(getLabel(LABELS.dialog.selectFolder));
    }

    /**
     * 対象フォルダーのパスを表示用に整える
     * @param {Folder} targetFolder - 表示するフォルダー
     * @param {boolean} showFullPath - true でフルパス、false でホームフォルダーを ~ に略す
     * @returns {string} 表示用のパス文字列
     */
    function formatFolderPath(targetFolder, showFullPath) {
        var fullPath = targetFolder.fsName;
        if (showFullPath) return fullPath;

        var homePath = Folder("~").fsName;
        if (homePath && fullPath.indexOf(homePath) === 0) {
            /* 区切りの手前で切れているか確かめる。/Users/tak が /Users/takano に一致しないように */
            var rest = fullPath.substring(homePath.length);
            if (rest === "" || rest.charAt(0) === "/" || rest.charAt(0) === "\\") return "~" + rest;
        }
        return fullPath;
    }

    /**
     * decodeURI に失敗しても元の文字列を返す
     * @param {string} value - デコードする文字列
     * @returns {string} デコード結果。失敗時は元の文字列
     */
    function decodeSafely(value) {
        try {
            return decodeURI(value);
        } catch (e) {
            return value;
        }
    }

    /**
     * フォルダーを再帰的にたどってスクリプトを集める
     * @param {Folder} targetFolder - 走査するフォルダー
     * @param {Array<ScriptEntry>} collected - 収集結果の追加先
     * @param {Folder} rootFolder - 相対パスの基準になる対象フォルダー
     * @returns {void}
     */
    function collectScriptFiles(targetFolder, collected, rootFolder) {
        var entries;
        try {
            entries = targetFolder.getFiles();
        } catch (e) {
            return;
        }

        for (var i = 0; i < entries.length; i++) {
            var entry = entries[i];

            if (entry instanceof Folder) {
                /* エイリアスは循環の元になるのでたどらない / Aliases can loop back into an ancestor */
                if (!entry.alias && !/^\./.test(entry.name)) collectScriptFiles(entry, collected, rootFolder);
                continue;
            }

            if (!(entry instanceof File) || !SCRIPT_EXT_RE.test(entry.name)) continue;

            /* 対象フォルダー内にこのランチャー自身がある場合は一覧に載せない / Skip this launcher itself */
            if (File($.fileName).fsName === entry.fsName) continue;

            var relativePath = entry.fsName;
            var rootPath = rootFolder.fsName;
            if (relativePath.indexOf(rootPath) === 0) {
                relativePath = relativePath.substring(rootPath.length).replace(/^[\\\/]+/, "");
            }

            var decodedFileName = decodeSafely(entry.name);
            var localizedFileName = entry.displayName || decodedFileName;
            var decodedRelativePath = decodeSafely(relativePath);

            /* リストは左右2本なので、フォルダー部分とファイル名を分けて持つ / Split folder and file name for the two lists */
            var decodedFolderPath = decodedRelativePath.replace(/[\\\/][^\\\/]*$/, "");
            if (decodedFolderPath === decodedRelativePath) decodedFolderPath = "";

            /* 対象フォルダーからの階層の深さ。直下は0、table/backup は2 / Depth below the root folder */
            var folderDepth = (decodedFolderPath === "") ? 0 : decodedFolderPath.split(/[\\\/]/).length;

            collected.push({
                file: entry,
                fileName: decodedFileName,
                localizedFileName: localizedFileName,
                relativePath: decodedRelativePath,
                folderPath: decodedFolderPath,
                folderDepth: folderDepth,
                searchText: decodedRelativePath + " " + localizedFileName
            });
        }
    }

    /**
     * 相対パス順にスクリプトを並べ替える
     * @param {Array<ScriptEntry>} scriptEntries - 並べ替える配列（破壊的に変更する）
     * @returns {void}
     */
    function sortScriptEntries(scriptEntries) {
        scriptEntries.sort(function (entryA, entryB) {
            var pathA = entryA.relativePath.toLowerCase();
            var pathB = entryB.relativePath.toLowerCase();
            return pathA < pathB ? -1 : (pathA > pathB ? 1 : 0);
        });
    }

    /**
     * 入力文字列を1以上の整数として読み取る
     * @param {string} value - 入力文字列
     * @param {number} fallbackValue - 数値として読めないときに返す値
     * @param {number} [maxValue] - 上限。超えた場合はこの値に丸める
     * @returns {number} 1以上の整数
     */
    function parsePositiveInt(value, fallbackValue, maxValue) {
        var parsed = parseInt(trimWhitespace(value), 10);
        if (isNaN(parsed) || parsed < 1) return fallbackValue;
        if (typeof maxValue === "number" && parsed > maxValue) return maxValue;
        return parsed;
    }

    /**
     * ボタンにしない語かどうかを判定する
     * @param {string} word - 小文字化した語
     * @returns {boolean} 除外語なら true
     */
    function isStopWord(word) {
        for (var i = 0; i < KEYWORD_STOP_WORDS.length; i++) {
            if (KEYWORD_STOP_WORDS[i] === word) return true;
        }
        return false;
    }

    /**
     * ファイル名を単語に分解する（キャメルケース・ハイフン・アンダースコア区切り）
     * @param {string} fileName - 拡張子付きのファイル名
     * @returns {Array<string>} 小文字化した単語の配列
     */
    function extractNameWords(fileName) {
        var baseName = String(fileName).replace(/\.[^.]+$/, "");

        /* 区切り文字と数字を空白にし、続けてキャメルケースの境目を空ける / Split separators, then camel case */
        var separated = baseName.replace(/[-_\s\d]+/g, " ");
        separated = separated.replace(/([a-z])([A-Z])/g, "$1 $2");
        separated = separated.replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2");

        var words = [];
        var parts = separated.split(" ");
        for (var i = 0; i < parts.length; i++) {
            var word = parts[i].toLowerCase();
            /* 英字だけの語に限る。日本語名や記号混じりはボタンにしない / ASCII words only */
            if (!/^[a-z]+$/.test(word)) continue;
            if (word.length < KEYWORD_MIN_WORD_LENGTH) continue;
            if (isStopWord(word)) continue;
            words.push(word);
        }
        return words;
    }

    /**
     * 常に出す語かどうかを判定する
     * @param {string} word - 小文字化した語
     * @returns {boolean} 常設の語なら true
     */
    function isPinnedWord(word) {
        for (var i = 0; i < KEYWORD_PINNED_WORDS.length; i++) {
            if (KEYWORD_PINNED_WORDS[i] === word) return true;
        }
        return false;
    }

    /**
     * すでに入力済みの検索語で覆われている語かどうかを判定する
     * @param {string} word - 判定する語
     * @param {Array<string>} searchTerms - 正規化済みの検索語
     * @returns {boolean} いずれかの検索語を含むなら true
     */
    function isCoveredByTerms(word, searchTerms) {
        for (var i = 0; i < searchTerms.length; i++) {
            if (word.indexOf(searchTerms[i]) !== -1) return true;
        }
        return false;
    }

    /**
     * スクリプト名によく出てくる語を求める
     * @param {Array<ScriptEntry>} scriptEntries - 集計対象のスクリプト
     * @param {number} minCount - ボタンにする最小出現ファイル数
     * @param {number} maxButtons - 返す語の最大個数
     * @param {Array<string>} searchTerms - 入力済みの検索語。これを含む語は除く
     * @returns {Array<string>} 常設の語、続いて出現ファイル数の多い順に並べた語
     */
    function collectFrequentWords(scriptEntries, minCount, maxButtons, searchTerms) {
        var wordCounts = {};
        for (var i = 0; i < scriptEntries.length; i++) {
            var words = scriptEntries[i].nameWords;

            /* 同じ語が1つのファイル名に複数あっても1件と数える / Count each file once per word */
            var seenWords = {};
            for (var j = 0; j < words.length; j++) {
                var wordKey = "#" + words[j];
                if (seenWords[wordKey]) continue;
                seenWords[wordKey] = true;
                wordCounts[wordKey] = (wordCounts[wordKey] || 0) + 1;
            }
        }

        var frequentWords = [];
        for (var countKey in wordCounts) {
            if (!wordCounts.hasOwnProperty(countKey)) continue;

            /* 入力済みの語をボタンにしても絞り込めないので外す / A word the query already covers is a no-op */
            var word = countKey.substring(1);
            if (isCoveredByTerms(word, searchTerms)) continue;

            /* 常設の語は件数を問わず先頭に置くので、ここでは数えない / Pinned words are placed first instead */
            if (isPinnedWord(word)) continue;
            if (wordCounts[countKey] < minCount) continue;
            frequentWords.push({ word: word, count: wordCounts[countKey] });
        }

        frequentWords.sort(function (wordA, wordB) {
            if (wordA.count !== wordB.count) return wordB.count - wordA.count;
            return wordA.word < wordB.word ? -1 : (wordA.word > wordB.word ? 1 : 0);
        });

        /* 常設の語を先に並べる。絞り込み結果に1件も無い語は押しても空振りなので出さない
           / Pinned words come first, unless nothing in the current result matches them */
        var presetWords = [];
        for (var p = 0; p < KEYWORD_PINNED_WORDS.length && presetWords.length < maxButtons; p++) {
            var pinnedWord = KEYWORD_PINNED_WORDS[p];
            if (!wordCounts["#" + pinnedWord]) continue;
            if (isCoveredByTerms(pinnedWord, searchTerms)) continue;
            presetWords.push(pinnedWord);
        }

        for (var k = 0; k < frequentWords.length && presetWords.length < maxButtons; k++) {
            presetWords.push(frequentWords[k].word);
        }
        return presetWords;
    }

    /**
     * 語の先頭を大文字にする（ボタン表示用）
     * @param {string} word - 小文字の語
     * @returns {string} 先頭だけ大文字にした語
     */
    function capitalizeWord(word) {
        return word.charAt(0).toUpperCase() + word.substring(1);
    }

    // =========================================
    // ダイアログ / Dialog
    // =========================================

    /**
     * キーワードボタン置き場の高さを固定する（絞り込みのたびにダイアログが伸縮しないようにする）
     * @param {Group} container - ボタン行を入れるグループ
     * @param {number} maxButtons - 並べうるボタンの最大個数
     * @returns {void}
     */
    function reserveKeywordPresetHeight(container, maxButtons) {
        var rowCount = Math.ceil(maxButtons / KEYWORD_PRESETS_PER_ROW);
        var height = rowCount * PRESET_BUTTON_HEIGHT + (rowCount - 1) * DENSE_SPACING;
        container.preferredSize.height = height;
        container.minimumSize.height = height;
    }

    /**
     * 項目名付きの数値入力欄（∧∨付き、1以上の整数）を1行追加する
     * @param {Window} parent - 追加先のウィンドウ
     * @param {{ja: string, en: string}} labelSet - 項目名のラベル定義
     * @param {number} value - 初期値
     * @param {number} [maxValue] - 上限。省略時は上限なし
     * @returns {EditText} 追加した数値入力欄
     */
    function addNumberField(parent, labelSet, value, maxValue) {
        var input = addSteppedField(parent, {
            label: labelText(labelSet),
            labelWidth: SETTINGS_LABEL_WIDTH,
            text: String(value),
            step: 1, min: 1, max: maxValue, integer: true
        });
        input.preferredSize.width = SETTINGS_INPUT_WIDTH;
        return input;
    }

    /**
     * 環境設定（キーワードボタンの出現条件）を編集するダイアログを表示する
     * @param {Folder} targetFolder - 現在の対象フォルダー
     * @param {number} minCount - 現在の出現数
     * @param {number} maxButtons - 現在のキーワード数
     * @param {boolean} remembersSettings - 「フルパス」の状態を覚えるかどうか
     * @returns {{folder: Folder, minCount: number, maxButtons: number}|null} 入力された値。取り消し時は null
     */
    function showPreferencesDialog(targetFolder, minCount, maxButtons, remembersSettings) {
        var settingsDialog = new Window("dialog", getLabel(LABELS.dialog.preferences));
        setupWindow(settingsDialog, DENSE_SPACING);

        var selectedFolder = targetFolder;
        var folderUI = buildScriptFolderPanel(settingsDialog, selectedFolder, remembersSettings);
        folderUI.changeButton.onClick = function () {
            var pickedFolder = chooseScriptFolder(selectedFolder);
            if (!pickedFolder) return;
            selectedFolder = pickedFolder;
            folderUI.refreshPath(selectedFolder);
        };

        var keywordButtonPanel = settingsDialog.add("panel", undefined, getLabel(LABELS.panel.keywordButtons));
        setupPanel(keywordButtonPanel, DENSE_SPACING);
        var minCountInput = addNumberField(keywordButtonPanel, LABELS.fieldLabel.minCount, minCount);
        var maxButtonsInput = addNumberField(keywordButtonPanel, LABELS.fieldLabel.maxButtons, maxButtons, KEYWORD_PRESET_LIMIT);

        var buttonRow = addButtonRow(settingsDialog);
        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.cancel), { name: "cancel" });
        var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.ok), { name: "ok" });
        applyButtonSize(btnCancel, DIALOG_BUTTON_WIDTH);
        applyButtonSize(btnOK, DIALOG_BUTTON_WIDTH);
        alignRightOnlyButtonRow(buttonRow);

        minCountInput.active = true;
        if (settingsDialog.show() !== 1) return null;

        return {
            folder: selectedFolder,
            minCount: parsePositiveInt(minCountInput.text, minCount),
            maxButtons: parsePositiveInt(maxButtonsInput.text, maxButtons, KEYWORD_PRESET_LIMIT)
        };
    }

    /**
     * 対象フォルダーのスクリプトを集め、検索キーまで用意する
     * @param {Folder} targetFolder - 検索対象のフォルダー
     * @returns {Array<ScriptEntry>} 相対パス順に並べ、検索キーを付けたスクリプト
     */
    function loadScriptEntries(targetFolder) {
        var scriptEntries = [];
        collectScriptFiles(targetFolder, scriptEntries, targetFolder);
        sortScriptEntries(scriptEntries);

        /* 検索キーは起動時に一度だけ作ってキャッシュし、入力のたびの再計算を避ける / Cache search keys once */
        for (var i = 0; i < scriptEntries.length; i++) {
            scriptEntries[i].normalizedSearchText = normalizeSearchKey(scriptEntries[i].searchText);
            scriptEntries[i].nameWords = extractNameWords(scriptEntries[i].fileName);
        }
        return scriptEntries;
    }

    /**
     * 絞り込みパネルを組み立てる
     * @param {Window} parent - 追加先のウィンドウ
     * @param {string} initialKeyword - 最初に表示するキーワード
     * @param {boolean} remembersSettings - 「検索条件を記憶」の初期状態
     * @returns {{panel: Panel, input: EditText, clearButton: Button, presetContainer: Group, rememberCheckbox: Checkbox}} パネルの部品
     */
    function buildKeywordPanel(parent, initialKeyword, remembersSettings) {
        var panel = parent.add("panel", undefined, getLabel(LABELS.panel.keyword, [0]));
        setupPanel(panel, DENSE_SPACING);

        var row = panel.add("group");
        setupRow(row, "fill", DENSE_SPACING);
        row.add("statictext", undefined, labelText(LABELS.fieldLabel.keyword));

        var input = row.add("edittext", undefined, initialKeyword);
        input.alignment = ["fill", "center"];

        var clearButton = addClearButton(row);

        /* ボタンは絞り込みのたびに作り直すので、置き場だけ先に用意する / Reserve the area for the preset buttons */
        var presetContainer = panel.add("group");
        presetContainer.orientation = "column";
        presetContainer.alignChildren = ["left", "top"];
        presetContainer.alignment = ["fill", "top"];
        presetContainer.spacing = DENSE_SPACING;

        var rememberRow = panel.add("group");
        setupRow(rememberRow, "left", 0);
        rememberRow.margins = [0, REMEMBER_ROW_TOP_MARGIN, 0, 0];

        var rememberCheckbox = rememberRow.add("checkbox", undefined, getLabel(LABELS.checkbox.rememberSettings));
        rememberCheckbox.helpTip = getLabel(LABELS.tooltip.rememberSettings);
        rememberCheckbox.value = remembersSettings;

        return {
            panel: panel,
            input: input,
            clearButton: clearButton,
            presetContainer: presetContainer,
            rememberCheckbox: rememberCheckbox
        };
    }

    /**
     * 対象フォルダーパネルを組み立てる
     * @param {Window} parent - 追加先のウィンドウ
     * @param {Folder} targetFolder - 最初に表示するフォルダー
     * @param {boolean} remembersSettings - 「フルパス」の状態を覚えるかどうか
     * @returns {{changeButton: Button, refreshPath: function(Folder): void}} 変更ボタンと表示更新関数
     */
    function buildScriptFolderPanel(parent, targetFolder, remembersSettings) {
        var currentFolder = targetFolder;
        var showFullPath = readSessionState().showFullPath;

        var panel = parent.add("panel", undefined, getLabel(LABELS.panel.scriptFolder));
        setupPanel(panel, DENSE_SPACING);

        var row = panel.add("group");
        setupRow(row, "fill", DENSE_SPACING);

        /* 入力欄に見せないよう statictext で表示し、長いパスは中央を省略する / Plain text, truncated in the middle */
        var pathText = row.add("statictext", undefined, formatFolderPath(currentFolder, showFullPath), { truncate: "middle" });
        pathText.preferredSize.width = FOLDER_PATH_WIDTH;

        var changeButton = row.add("button", undefined, getLabel(LABELS.button.changeFolder));
        changeButton.alignment = ["right", "center"];
        applyButtonSize(changeButton, FOLDER_BUTTON_WIDTH);

        var fullPathCheckbox = panel.add("checkbox", undefined, getLabel(LABELS.checkbox.showFullPath));
        fullPathCheckbox.alignment = "left";
        fullPathCheckbox.value = showFullPath;

        /**
         * パス表示を今のフォルダーと「フルパス」の状態に合わせる
         * @param {Folder} [folder] - 新しいフォルダー。省略時は表示だけ更新する
         * @returns {void}
         */
        function refreshPath(folder) {
            if (folder) currentFolder = folder;
            pathText.text = formatFolderPath(currentFolder, fullPathCheckbox.value);
        }

        fullPathCheckbox.onClick = function () {
            /* 表示の切り替えはセッション中だけ覚えておく / Remember the toggle for this session */
            if (remembersSettings) saveSessionState({ showFullPath: fullPathCheckbox.value });
            refreshPath();
        };
        return { changeButton: changeButton, refreshPath: refreshPath };
    }

    /**
     * 左右2本のリストを組み立てる
     * @param {Window} parent - 追加先のウィンドウ
     * @param {boolean} includeSubfolders - 「サブディレクトリを含む」の初期状態
     * @returns {{folderListBox: ListBox, subfoldersCheckbox: Checkbox, scriptListBox: ListBox}} リスト部品
     */
    function buildListColumns(parent, includeSubfolders) {
        /* 左でフォルダーを選び、右にそのフォルダー内のファイル名だけを並べる / Folder on the left, file names on the right */
        var row = parent.add("group");
        setupRow(row, "fill", COLUMN_SPACING);
        row.alignChildren = ["fill", "fill"];

        var folderColumn = addListColumn(row, getLabel(LABELS.listCaption.folder));
        var folderListBox = folderColumn.add("listbox", undefined, [], { multiselect: false });
        folderListBox.preferredSize = FOLDER_LIST_SIZE;

        var checkboxRow = folderColumn.add("group");
        setupRow(checkboxRow, "left", 0);
        checkboxRow.margins = [0, CHECKBOX_TOP_MARGIN, 0, 0];
        var subfoldersCheckbox = checkboxRow.add("checkbox", undefined, getLabel(LABELS.checkbox.includeSubfolders));
        subfoldersCheckbox.value = includeSubfolders;

        var scriptColumn = addListColumn(row, getLabel(LABELS.listCaption.fileName));
        var scriptListBox = scriptColumn.add("listbox", undefined, [], { multiselect: false });
        scriptListBox.preferredSize = SCRIPT_LIST_SIZE;

        return { folderListBox: folderListBox, subfoldersCheckbox: subfoldersCheckbox, scriptListBox: scriptListBox };
    }

    /**
     * ダイアログ下部のボタン列を組み立てる
     * @param {Window} parent - 追加先のウィンドウ
     * @returns {{settings: Button, cancel: Button, run: Button}} 3つのボタン
     */
    function buildDialogButtons(parent) {
        /* 左に［環境設定］、右に［キャンセル］［実行］ / Preferences on the left, Cancel and Run on the right */
        var buttonRow = addButtonRow(parent);
        var btnPreferences = buttonRow.leftGroup.add("button", undefined, getLabel(LABELS.button.preferences));
        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.cancel), { name: "cancel" });
        var btnRun = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.run), { name: "ok" });
        btnRun.enabled = false;
        alignRightOnlyButtonRow(buttonRow);

        applyButtonSize(btnPreferences, SETTINGS_BUTTON_WIDTH);
        applyButtonSize(btnCancel, DIALOG_BUTTON_WIDTH);
        applyButtonSize(btnRun, DIALOG_BUTTON_WIDTH);

        return { settings: btnPreferences, cancel: btnCancel, run: btnRun };
    }

    /**
     * ランチャーのダイアログを表示する
     * @param {Folder} targetFolder - 検索対象のフォルダー
     * @returns {{action: string, file: File|null, folder: Folder|null}} 操作結果（"run" / "changeFolder" / "cancel"）
     */
    function showLauncherDialog(targetFolder) {
        var scriptEntries = loadScriptEntries(targetFolder);
        if (scriptEntries.length === 0) {
            alert(getLabel(LABELS.alert.noScripts), getLabel(LABELS.dialog.title));
            return { action: "changeFolder", file: null, folder: null };
        }

        /* 同じセッション中に開き直したときは、前回の絞り込みから再開する / Resume the previous search within the session */
        var sessionState = readSessionState();

        /* 対象フォルダーが変わっていれば、フォルダーとファイルの選択は引き継がない
           / Those two are relative to the folder they were stored for */
        if (sessionState.targetFolder !== targetFolder.fsName) {
            sessionState.folderPath = null;
            sessionState.fileName = null;
        }

        var launcherDialog = new Window("dialog", getLabel(LABELS.dialog.title));
        setupWindow(launcherDialog);

        /* 検索欄を最初の操作部品にして、起動時のフォーカスを安定させる / Keep the keyword field first */
        var keywordUI = buildKeywordPanel(launcherDialog, sessionState.keyword, sessionState.remember);
        var keywordPanel = keywordUI.panel;
        var keywordInput = keywordUI.input;
        var keywordClearButton = keywordUI.clearButton;
        var keywordPresetContainer = keywordUI.presetContainer;
        var rememberCheckbox = keywordUI.rememberCheckbox;

        /* 絞り込み結果によく出る語をワンクリックで入れる / One-click presets from the filtered results */
        var storedSettings = readKeywordSettings();
        var presetMinCount = storedSettings.minCount;
        var presetMaxButtons = storedSettings.maxButtons;
        var keywordPresetRows = [];
        var currentPresetWords = null;
        var isDialogShown = false;
        reserveKeywordPresetHeight(keywordPresetContainer, presetMaxButtons);

        var listUI = buildListColumns(launcherDialog, sessionState.includeSubfolders);
        var folderListBox = listUI.folderListBox;
        var includeSubfoldersCheckbox = listUI.subfoldersCheckbox;
        var scriptListBox = listUI.scriptListBox;

        var dialogButtons = buildDialogButtons(launcherDialog);
        var btnPreferences = dialogButtons.settings;
        var btnCancel = dialogButtons.cancel;
        var btnRun = dialogButtons.run;

        var filteredScripts = [];
        var listedScripts = [];
        var dialogResult = { action: "cancel", file: null, folder: null };

        /* 組み直し中の選択変更でファイル名リストが何度も再構築されるのを防ぐ / Suppress cascaded rebuilds */
        var isRebuildingFolderList = false;

        /* 前回の選択は最初の組み立てでだけ使う。以降は通常どおり先頭を選ぶ / Used only while building the lists for the first time */
        var restoringFolderPath = sessionState.folderPath;
        var restoringFileName = sessionState.fileName;

        /* 記録は1回だけ。閉じ方によっては二重に呼ばれる / Guards against being called twice */
        var isSessionSaved = false;

        /**
         * 絞り込み結果に合わせてキーワードボタンを作り直す
         * @param {Array<ScriptEntry>} entries - 集計対象のスクリプト（現在の絞り込み結果）
         * @param {Array<string>} searchTerms - 入力済みの検索語。これを含む語はボタンにしない
         * @returns {void}
         */
        function refreshKeywordPresetButtons(entries, searchTerms) {
            var presetWords = collectFrequentWords(entries, presetMinCount, presetMaxButtons, searchTerms);

            /* 顔ぶれが変わらないなら作り直さない。1打鍵ごとの再構築を避ける / Skip the rebuild when nothing changed */
            var presetWordsKey = presetWords.join(" ");
            if (presetWordsKey === currentPresetWords) return;
            currentPresetWords = presetWordsKey;

            for (var i = 0; i < keywordPresetRows.length; i++) {
                keywordPresetContainer.remove(keywordPresetRows[i]);
            }
            keywordPresetRows = [];

            var presetRow = null;
            for (var j = 0; j < presetWords.length; j++) {
                if (j % KEYWORD_PRESETS_PER_ROW === 0) {
                    presetRow = keywordPresetContainer.add("group");
                    setupRow(presetRow, "left", DENSE_SPACING);
                    keywordPresetRows.push(presetRow);
                }
                var presetButton = presetRow.add("button", undefined, capitalizeWord(presetWords[j]));
                applyPresetButtonSize(presetButton);
                presetButton.onClick = makeKeywordPresetHandler(presetWords[j]);
            }

            /* 置き場の高さは固定してあるので、ここだけ組み直せばダイアログは動かない / Fixed height keeps the dialog still */
            if (isDialogShown) keywordPresetContainer.layout.layout(true);
        }

        /**
         * プリセットボタン用の onClick ハンドラーを作る
         * @param {string} presetKeyword - ボタンに割り当てるキーワード
         * @returns {function(): void} 通常クリックで置き換え、option+クリックで追加するハンドラー
         */
        function makeKeywordPresetHandler(presetKeyword) {
            return function () {
                /* option+クリックは空白を挟んで語を足し、AND検索で絞り込む / Option-click appends the word */
                var currentText = trimWhitespace(keywordInput.text);
                var isAppend = ScriptUI.environment.keyboardState.altKey && currentText !== "";
                keywordInput.text = isAppend ? currentText + " " + presetKeyword : presetKeyword;
                lastNormalizedQuery = splitSearchTerms(keywordInput.text).join(" ");

                /* 押されたボタンは組み直しで消える。先にフォーカスを入力欄へ移しておく */
                keywordInput.active = true;
                updateClearButtonState();
                refreshFolderList();
            };
        }

        /**
         * 選択中フォルダーの相対パスを返す
         * @returns {string|null} 相対パス。「すべて」選択時と未選択時は null
         */
        function selectedFolderPath() {
            if (!folderListBox.selection) return null;
            var folderPath = folderListBox.selection.folderPath;
            return (folderPath === undefined) ? null : folderPath;
        }

        /**
         * キーワードとサブディレクトリ設定で絞り込み、左のフォルダーリストを組み直す
         * @returns {void}
         */
        function refreshFolderList() {
            var searchTerms = splitSearchTerms(keywordInput.text);

            /* 最初の組み立てだけは前回のセッションで選んでいたフォルダーを狙う / Aim at the remembered folder on the first pass */
            var previousFolderPath = selectedFolderPath();
            if (previousFolderPath === null) previousFolderPath = restoringFolderPath;
            restoringFolderPath = null;
            var depthLimit = includeSubfoldersCheckbox.value ? null : NESTED_FOLDER_DEPTH_LIMIT;
            isRebuildingFolderList = true;
            filteredScripts = [];

            var seenFolderPaths = {};
            var folderPaths = [];
            for (var i = 0; i < scriptEntries.length; i++) {
                var searchTarget = scriptEntries[i].normalizedSearchText;
                if (!matchesSearchTerms(searchTarget, searchTerms)) continue;
                if (depthLimit !== null && scriptEntries[i].folderDepth > depthLimit) continue;

                filteredScripts.push(scriptEntries[i]);

                /* ハッシュのキー衝突を避けるため接頭辞を付けて既出判定する / Prefix the key to avoid collisions */
                var folderKey = "#" + scriptEntries[i].folderPath;
                if (!seenFolderPaths[folderKey]) {
                    seenFolderPaths[folderKey] = true;
                    folderPaths.push(scriptEntries[i].folderPath);
                }
            }
            folderPaths.sort();
            refreshKeywordPresetButtons(filteredScripts, searchTerms);

            folderListBox.removeAll();
            folderListBox.add("item", getLabel(LABELS.folderRow.allFolders));
            for (var j = 0; j < folderPaths.length; j++) {
                var folderItem = folderListBox.add("item", folderPaths[j] === "" ? getLabel(LABELS.folderRow.rootFolder) : folderPaths[j]);
                folderItem.folderPath = folderPaths[j];
            }

            /* 絞り込み前に選んでいたフォルダーが残っていれば選択を引き継ぐ / Keep the previous folder selection */
            folderListBox.selection = 0;
            if (previousFolderPath !== null) {
                for (var k = 1; k < folderListBox.items.length; k++) {
                    if (folderListBox.items[k].folderPath === previousFolderPath) {
                        folderListBox.selection = k;
                        break;
                    }
                }
            }

            isRebuildingFolderList = false;
            refreshScriptList();
        }

        /**
         * ファイル名リストから指定した名前の位置を探す
         * @param {string|null} fileName - 探すファイル名
         * @returns {number} 見つかった位置。見つからなければ 0（先頭）
         */
        function findScriptIndex(fileName) {
            if (!fileName) return 0;
            for (var i = 0; i < scriptListBox.items.length; i++) {
                if (scriptListBox.items[i].text === fileName) return i;
            }
            return 0;
        }

        /**
         * 選択中フォルダーに合わせて右のファイル名リストを組み直す
         * @returns {void}
         */
        function refreshScriptList() {
            var folderPath = selectedFolderPath();
            scriptListBox.removeAll();
            listedScripts = [];

            for (var i = 0; i < filteredScripts.length; i++) {
                if (folderPath !== null && filteredScripts[i].folderPath !== folderPath) continue;
                listedScripts.push(filteredScripts[i]);
                var scriptItem = scriptListBox.add("item", filteredScripts[i].fileName);
                scriptItem.scriptIndex = listedScripts.length - 1;
            }

            /* 件数はパネルのタイトルに出す / Show the match count in the panel title */
            keywordPanel.text = getLabel(LABELS.panel.keyword, [listedScripts.length]);

            /* 最初の組み立てだけは前回のセッションで選んでいたファイルを狙う / Aim at the remembered file on the first pass */
            var selectionIndex = findScriptIndex(restoringFileName);
            restoringFileName = null;

            if (scriptListBox.items.length > 0) {
                scriptListBox.selection = selectionIndex;
                btnRun.enabled = true;
            } else {
                btnRun.enabled = false;
            }
        }

        /**
         * 右のリストで選択中のスクリプトを返す
         * @returns {ScriptEntry|null} 選択中のスクリプト。未選択なら null
         */
        function selectedScriptEntry() {
            if (!scriptListBox.selection) return null;
            var selectedIndex = scriptListBox.selection.scriptIndex;
            if (selectedIndex === undefined) return null;
            return listedScripts[selectedIndex] || null;
        }

        /**
         * 今の絞り込みと選択を控える
         * 閉じたあとでは部品の値を読めないことがあるので、記録はここでまとめて行う
         * @returns {void}
         */
        function saveLauncherSession() {
            if (isSessionSaved) return;
            isSessionSaved = true;

            var savedState = { remember: rememberCheckbox.value };
            if (rememberCheckbox.value) {
                var chosenScript = selectedScriptEntry();

                /* 対象フォルダーも控える。別のフォルダーで開いたときに選択を引き継がないため
                   / The selections below only make sense against this folder */
                savedState.targetFolder = targetFolder.fsName;
                savedState.keyword = keywordInput.text;
                savedState.includeSubfolders = includeSubfoldersCheckbox.value;
                savedState.folderPath = selectedFolderPath();
                savedState.fileName = chosenScript ? chosenScript.fileName : null;
            } else {
                /* OFFのときは初期値を書き、次に開いたときは何も引き継がない / Store the defaults instead */
                savedState.targetFolder = null;
                savedState.keyword = "";
                savedState.includeSubfolders = INCLUDE_SUBFOLDERS_DEFAULT;
                savedState.showFullPath = SHOW_FULL_PATH_DEFAULT;
                savedState.folderPath = null;
                savedState.fileName = null;
            }
            saveSessionState(savedState);
        }

        /**
         * 今の絞り込みと選択を控えてからダイアログを閉じる
         * @param {number} [closeCode] - close() に渡す値
         * @returns {void}
         */
        function closeLauncher(closeCode) {
            saveLauncherSession();

            if (closeCode === undefined) launcherDialog.close();
            else launcherDialog.close(closeCode);
        }

        /**
         * 選択中のスクリプトを実行対象に確定してダイアログを閉じる
         * @returns {void}
         */
        function runSelectedScript() {
            var selectedScript = selectedScriptEntry();
            if (!selectedScript) return;
            dialogResult.action = "run";
            dialogResult.file = selectedScript.file;
            closeLauncher(1);
        }

        /**
         * 左のリストで選択中のフォルダーをFinderで開く（ダイアログは開いたまま）
         * 「すべて」と「ルート」は対象フォルダーそのものを開く
         * @returns {void}
         */
        function openSelectedFolder() {
            var folderPath = selectedFolderPath();
            var folderToOpen = targetFolder;

            /* パス文字列を組み立てず、そのフォルダーにあるスクリプトの親を使う / Use a real Folder object */
            if (folderPath) {
                for (var i = 0; i < filteredScripts.length; i++) {
                    if (filteredScripts[i].folderPath === folderPath) {
                        folderToOpen = filteredScripts[i].file.parent;
                        break;
                    }
                }
            }
            if (!openInFileViewer(folderToOpen)) folderToOpen.execute();
        }

        /**
         * 選択中のスクリプトをFinderで表示する（ダイアログは開いたまま）
         * @returns {void}
         */
        function revealSelectedScript() {
            var selectedScript = selectedScriptEntry();
            if (selectedScript) revealScriptFile(selectedScript.file);
        }

        /* 検索キーは作成済みなので入力時は比較だけを行う。onChangingで即時反映し、onChangeでIME確定も拾う */
        var lastNormalizedQuery = null;

        /**
         * キーワードが変わったときだけリストを組み直す
         * @returns {void}
         */
        function refreshListIfQueryChanged() {
            var normalizedQuery = splitSearchTerms(keywordInput.text).join(" ");
            if (normalizedQuery === lastNormalizedQuery) return;
            lastNormalizedQuery = normalizedQuery;
            refreshFolderList();
        }

        /**
         * キーワードの有無に合わせてクリアボタンのディム表示を切り替える
         * @returns {void}
         */
        function updateClearButtonState() {
            var hasKeyword = trimWhitespace(keywordInput.text) !== "";
            if (keywordClearButton.enabled === hasKeyword) return;
            keywordClearButton.enabled = hasKeyword;
            keywordClearButton.notify("onDraw");
        }

        /**
         * キーワードが変わったときの処理をまとめる
         * @returns {void}
         */
        function handleKeywordChanged() {
            updateClearButtonState();
            refreshListIfQueryChanged();
        }

        keywordInput.onChanging = handleKeywordChanged;
        keywordInput.onChange = handleKeywordChanged;
        keywordClearButton.onClick = function () {
            keywordInput.text = "";
            /* 続けて打ち直せるよう、フォーカスは入力欄へ戻す / Put the focus back in the field */
            keywordInput.active = true;
            handleKeywordChanged();
        };
        btnPreferences.onClick = function () {
            var settings = showPreferencesDialog(targetFolder, presetMinCount, presetMaxButtons, rememberCheckbox.value);
            if (!settings) return;
            presetMinCount = settings.minCount;
            presetMaxButtons = settings.maxButtons;
            saveKeywordSettings(presetMinCount, presetMaxButtons);

            /* フォルダーが変わったら一覧を作り直すため、ダイアログを開き直す / Reopen the dialog to rescan */
            if (settings.folder.fsName !== targetFolder.fsName) {
                dialogResult.action = "changeFolder";
                dialogResult.folder = settings.folder;
                closeLauncher(2);
                return;
            }

            /* 置き場の高さが変わるので、ダイアログ全体を組み直す / The reserved height changes, so re-layout the dialog */
            reserveKeywordPresetHeight(keywordPresetContainer, presetMaxButtons);
            currentPresetWords = null;
            refreshFolderList();
            launcherDialog.layout.layout(true);
        };
        includeSubfoldersCheckbox.onClick = refreshFolderList;
        folderListBox.onChange = function () {
            if (isRebuildingFolderList) return;
            refreshScriptList();
        };
        scriptListBox.onChange = function () {
            btnRun.enabled = !!scriptListBox.selection;
        };
        folderListBox.onDoubleClick = openSelectedFolder;
        scriptListBox.onDoubleClick = function () {
            /* option+ダブルクリックは実行せずFinderで場所を開く / Option-double-click reveals instead of running */
            if (ScriptUI.environment.keyboardState.altKey) {
                revealSelectedScript();
                return;
            }
            runSelectedScript();
        };
        btnRun.onClick = runSelectedScript;
        btnCancel.onClick = function () {
            dialogResult.action = "cancel";
            closeLauncher();
        };
        keywordInput.addEventListener("keydown", function (event) {
            if (event.keyName === "Down" && scriptListBox.items.length > 0) {
                scriptListBox.active = true;
                if (!scriptListBox.selection) scriptListBox.selection = 0;
                event.preventDefault();
            } else if (event.keyName === "Enter" || event.keyName === "Return") {
                /* 絞り込みは onChanging / onChange で済んでいる。ここで組み直すと選択が先頭へ戻る */
                runSelectedScript();
                event.preventDefault();
                if (event.stopPropagation) event.stopPropagation();
            }
        });

        scriptListBox.addEventListener("keydown", function (event) {
            if (event.keyName === "Enter" || event.keyName === "Return") {
                runSelectedScript();
                event.preventDefault();
                if (event.stopPropagation) event.stopPropagation();
            }
        });

        /* テンキーEnterを含め、ダイアログ内のどこにフォーカスがあっても実行する / Enter runs from anywhere */
        launcherDialog.addEventListener("keydown", function (event) {
            /* ボタンにフォーカスがあるときは、そのボタン自身の動作に任せる */
            if (event.target && event.target.type === "button") return;
            if (event.keyName === "Enter" || event.keyName === "Return") {
                runSelectedScript();
                event.preventDefault();
            }
        });

        /* セッションを見分けられない環境では覚えようがないので、操作させない / Nothing to remember without a session id */
        rememberCheckbox.enabled = !!readSessionId();

        /* ボタン以外の方法で閉じられても記録を残す / Cover any other way of dismissing the dialog */
        launcherDialog.onClose = function () {
            saveLauncherSession();
            return true;
        };

        refreshFolderList();
        lastNormalizedQuery = splitSearchTerms(keywordInput.text).join(" ");
        updateClearButtonState();

        /* 検索欄を先頭の操作部品にしたうえで、表示時にも明示的にフォーカスする / Focus the keyword field on show */
        keywordInput.active = true;
        launcherDialog.onShow = function () {
            keywordInput.active = true;
            keywordInput.selection = [0, 0];
        };

        isDialogShown = true;
        addVersionFooter(launcherDialog);
        launcherDialog.show();
        return dialogResult;
    }

    // =========================================
    // 実行 / Run
    // =========================================

    /**
     * Finder表示用のAutomatorアプリを探す
     * .app は実体がフォルダーなので File.exists が false を返す環境がある。Folder でも確認する
     * @returns {File|null} 実在するアプリ。無ければ null
     */
    function findRevealApp() {
        if ($.os.indexOf("Macintosh") === -1) return null;
        if (!new Folder(REVEAL_APP_PATH).exists && !new File(REVEAL_APP_PATH).exists) return null;
        return new File(REVEAL_APP_PATH);
    }

    /**
     * Finder表示用アプリに渡すパスを一時ファイルへ書き出す
     * @param {File} scriptFile - 対象のスクリプトファイル
     * @returns {boolean} 書き出せたら true
     */
    function writeRevealPath(scriptFile) {
        /* fsName で ~ ではなく絶対パスを渡す / fsName gives the absolute POSIX path */
        return writeTextFile(new File(REVEAL_PATH_FILE), scriptFile.fsName);
    }

    /**
     * スクリプトの場所をFinderで開く
     * @param {File} scriptFile - 対象のスクリプトファイル
     * @returns {void}
     */
    function revealScriptFile(scriptFile) {
        /* 補助アプリがあれば Path Finder（起動中のとき）か Finder で選択表示する / Prefer the file viewer helper */
        if (openInFileViewer(scriptFile)) return;

        /* アプリが無い環境では囲みフォルダーを開くだけにとどめる / Fall back to the enclosing folder */
        var revealApp = findRevealApp();
        if (!revealApp) {
            scriptFile.parent.execute();
            return;
        }

        /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
        if (writeRevealPath(scriptFile) && revealApp.execute()) return;

        /* 起動できなかった場合も何も起きないままにはしない / Never end up doing nothing */
        scriptFile.parent.execute();
    }

    /**
     * 選ばれたスクリプトを実行する
     * @param {File} scriptFile - 実行するスクリプトファイル
     * @returns {void}
     */
    function runScriptFile(scriptFile) {
        if (!scriptFile || !scriptFile.exists) {
            alert(getLabel(LABELS.alert.missingScript), getLabel(LABELS.dialog.title));
            return;
        }

        try {
            /* 実行されるスクリプト側で取り消し単位を管理するため、doScript でラップしない
               / The launched script manages its own undo grouping, so no doScript wrapper here */
            $.evalFile(scriptFile);
        } catch (e) {
            /* 投げられるのは Error とは限らず、message を持たない値のこともある。
               ここで落ちると本当の失敗理由が隠れるので、どんな形でも文字列にして出す
               / The thrown value is not always an Error; never let this handler fail */
            var detail = (e && e.message) ? e.message : String(e);
            var message = getLabel(LABELS.alert.runFailed, [scriptFile.fsName, detail]);
            if (e && e.line) message += getLabel(LABELS.alert.errorLine, [e.line]);
            alert(message, getLabel(LABELS.dialog.title));
        }
    }

    /**
     * 対象フォルダーの確認からスクリプト実行までを進める
     * @returns {void}
     */
    function main() {
        var scriptFolder = readSavedScriptFolder();

        while (true) {
            if (!scriptFolder || !scriptFolder.exists) {
                scriptFolder = chooseScriptFolder(scriptFolder);
                if (!scriptFolder) return;
                saveScriptFolder(scriptFolder);
            }

            var launcherResult = showLauncherDialog(scriptFolder);

            if (launcherResult.action === "changeFolder") {
                /* 環境設定で選び直した場合はそのフォルダーを使い、見つからなかった場合だけ選ばせる */
                var changedFolder = launcherResult.folder || chooseScriptFolder(scriptFolder);

                /* 選び直しを取り消したら終了する。対象が空のまま繰り返すと抜けられなくなる */
                if (!changedFolder) return;
                scriptFolder = changedFolder;
                saveScriptFolder(scriptFolder);
                continue;
            }

            if (launcherResult.action === "run") runScriptFile(launcherResult.file);
            break;
        }
    }

    main();

})();
