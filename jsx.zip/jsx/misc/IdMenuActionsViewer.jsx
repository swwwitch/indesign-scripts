#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdMenuActionsViewer
Name=メニューアクションを調べて実行コードをコピー
Author=Peter Kahrel
Target-App=InDesign
Version=1.0.30
Release-Date=2026-09-25
Description-BEGIN
InDesign のメニューアクションを一覧し、カテゴリ・エリア・名前・ID で絞り込んで調べます。
選択したアクションのキーストリング（$ID/…）と実行コード（app.menuActions.itemByID(…).invoke();）をコピーできます。
Peter Kahrel 氏の menu_actions.jsx をもとに改変しています。

Lists InDesign menu actions and lets you filter them by category, area, name, and ID.
You can copy the key strings ($ID/…) and the invoke code (app.menuActions.itemByID(…).invoke();) of the selected action.
Based on menu_actions.jsx by Peter Kahrel.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

InDesign のメニューアクションを一覧し、カテゴリ・エリア・名前・ID で絞り込んで調べます。
選択したアクションのキーストリング（$ID/…）と実行コード（app.menuActions.itemByID(…).invoke();）をコピーできます。
Peter Kahrel 氏の menu_actions.jsx をもとに改変しています。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdMenuActionsViewer.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n5038c9d2cc85

### Overview

Lists InDesign menu actions and lets you filter them by category, area, name, and ID.
You can copy the key strings ($ID/…) and the invoke code (app.menuActions.itemByID(…).invoke();) of the selected action.
Based on menu_actions.jsx by Peter Kahrel.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdMenuActionsViewer.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdMenuActionsViewer";          /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.30";                      /* バージョン / version */
var SCRIPT_AUTHOR   = "Peter Kahrel";                 /* 作者 / author */
var SCRIPT_MODIFIED = "Masahiro Takano (@swwwitch)";  /* 改変 / modified by */
var SCRIPT_RELEASED = "2026-09-25";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "メニューアクションを調べて実行コードをコピー"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdMenuActionsViewer.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdMenuActionsViewer.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n5038c9d2cc85"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/misc/IdMenuActionsViewer.jsx"; /* 最新版のソース / latest source */

/**
 * @author Peter Kahrel（原作 menu_actions.jsx / original author）
 * @discussion https://creativepro.com/menu_actions/
 * http://kasyan.ho.com.ua/open_menu_item.html
 */

/*
 * Original script: menu_actions.jsx by Peter Kahrel
 * https://creativepro.com/menu_actions/
 *
 * Modifications Copyright (c) 2026 Masahiro Takano (@swwwitch)
 * Permission from Peter Kahrel is being requested. The MIT license below
 * applies to the modifications only, once permission is granted.
 * http://opensource.org/licenses/mit-license.php
 */

(function () {

    // =========================================
    // 基本設定 / Settings
    // =========================================

    /* フォント名・スタイル名などのノイズを隠す / Hide fonts, style names and other noise */
    var HIDE_NOISE = true;

    /* フォント名・スタイル名が並ぶ ID の範囲 / ID range occupied by font and style names */
    var NOISE_ID_MIN = 57603;
    var NOISE_ID_MAX = 61066;

    /* 名前末尾の「 (xyz:)」を取り除く / Strip the occasional " (xyz:)" code */
    var CODE_SUFFIX_PATTERN = / \([a-z]+?:\)/;

    /* ファイル名（最近使用したファイル・スクリプト）/ File names (recent files, scripts) */
    var FILE_NAME_PATTERN = /\.(?:indd|jsx?(?:bin)?)$/i;

    /* 文字・数字を1つも含まない名前（「(」「)」だけなど）の判定用 / Names without any letter or digit */
    var MEANINGFUL_CHAR_PATTERN = /[0-9A-Za-z\u3040-\u30FF\u3400-\u9FFF\uFF10-\uFF19\uFF21-\uFF5A]/;

    /* ［ウィンドウ］メニューに並ぶドキュメントのウィンドウ名（「名称未設定-1 @ 239%」）/ Document window names */
    var WINDOW_NAME_PATTERN = /@\s*[\d.]+%/;

    /* 除外するエリア（英語版の名称）/ Areas to exclude (English names) */
    var NOISE_AREA_PATTERN = /^(?:Text Selection|Menu:Insert)/i;

    /* エリア名の階層の区切り（「パネルメニュー:スウォッチ」）/ Separator of area levels */
    var AREA_LEVEL_SEPARATOR = ":";

    /* メニュー関連のカテゴリ（「編集メニュー」「Panel Menus」など）/ Menu-related categories */
    var MENU_CATEGORY_PATTERN = /メニュー|Menu/;

    /* 並び順ラジオボタンの順（リストの列順にそろえる）/ Sort radio order (matches the list columns) */
    var SORT_KEYS = ["name", "area"];
    var DEFAULT_SORT_INDEX = 1;

    // =========================================
    // レイアウト / Layout
    // =========================================
    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    var LIST_SIZE             = [560, 520];      /* リストの寸法 [幅,高さ] / list size */
    var COLUMN_WIDTHS         = [280, 260];      /* 列幅（名前・エリア）/ column widths (name, area) */
    var NAME_COLUMN_MAX_CHARS = 20;              /* 1列目に出す名前の最大文字数 / max characters shown in the name column */
    var FILTER_FIELD_WIDTH    = 300;             /* エリア・名前・ID の欄の幅 / width of the area and name/ID fields */
    var ROW_LABEL_WIDTH       = 130;             /* 行ラベルの幅 / row label width */
    var COPY_BUTTON_WIDTH     = 70;              /* ［コピー］ボタンの幅 / width of the Copy buttons */
    var PROGRESS_BAR_WIDTH    = 320;             /* 進行状況バーの幅 / progress bar width */
    var PROGRESS_STEP         = 250;             /* 進行状況を更新する間隔（件）/ items between progress updates */

    // =========================================
    // ラベル定義 / Labels
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // バージョン表示（再利用パーツ） / Version footer (reusable)

    var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
    var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
    var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
    var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
    var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
    var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

    /* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
       9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
       / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
         nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
    var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
    var VERSION_FOOTER_GLYPHS = {
        "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
        "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
        "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
        "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
        "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
        "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
        "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
        "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
        "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
        "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
        "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
        "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
        "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
        "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
        "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
        "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
        "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
        "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
        "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
        "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
        "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
        "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
        "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
        "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
        "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
        "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
        "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
        "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
        "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
        "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
        "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
        "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
        "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
        "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
        "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
        "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
        "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
        "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
        "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
        "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
        "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
        "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
        "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
        "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
        "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
        "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
        "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
        "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
        "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
        "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
        "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
        "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
        "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
        "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
        "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
        "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
        "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
        "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
        "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
        ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
        "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
        "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
        "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
        " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
    };

    /**
     * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
     * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
     * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
     * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
     * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
     */
    function addVersionFooter(targetWindow) {
        if (targetWindow.versionFooter) return null;

        /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
        var lastChild = targetWindow.children[targetWindow.children.length - 1];
        if (lastChild && lastChild.type === "group") {
            var rowMargins = lastChild.margins;
            lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
        }
        var windowMargins = targetWindow.margins;
        targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

        var footerGroup = targetWindow.add("group");
        footerGroup.orientation = "row";
        footerGroup.alignment = ["fill", "bottom"];
        footerGroup.alignChildren = ["left", "center"];
        footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

        /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
           左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
           / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
             or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
        var versionText = String(SCRIPT_VERSION);
        var leftCandidates = [versionText];
        if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
        var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
        versionCanvas.alignment = ["fill", "center"];
        bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
        var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
        brandCanvas.alignment = ["right", "center"];
        brandCanvas.maximumSize = brandCanvas.preferredSize;
        targetWindow.versionFooter = footerGroup;
        return versionCanvas;
    }

    /**
     * 文字列のすべての文字に字形があるかを返す
     * @param {string} dotText - 文字列
     * @returns {boolean} すべてあれば true
     */
    function hasVersionFooterGlyphs(dotText) {
        for (var i = 0; i < dotText.length; i++) {
            if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
        }
        return dotText.length > 0;
    }

    /**
     * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
     * @param {Group} parentGroup - 足す先
     * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
     * @returns {Group} 描くグループ
     */
    function addVersionFooterCanvas(parentGroup, dotTexts) {
        var dotCanvas = parentGroup.add("group");
        var shortestText = dotTexts[dotTexts.length - 1];
        dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
        dotCanvas.helpTip = dotTexts[0];
        dotCanvas.onDraw = function () {
            var availableWidth = this.size ? this.size.width : 0;
            var drawText = shortestText;
            for (var i = 0; i < dotTexts.length; i++) {
                if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                    drawText = dotTexts[i];
                    break;
                }
            }
            drawVersionFooterDots(this.graphics, drawText);
        };
        return dotCanvas;
    }

    /**
     * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
     * @param {string} versionText - 文字列
     * @returns {number} 幅（ドット）
     */
    function measureVersionFooterDots(versionText) {
        var dotCount = 0;
        for (var i = 0; i < versionText.length; i++) {
            var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
            if (!glyphRows) continue;
            if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
            dotCount += glyphRows[0].length;
        }
        return dotCount;
    }

    /**
     * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
     * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
     * @param {string} versionText - 文字列
     * @returns {void}
     */
    function drawVersionFooterDots(canvasGraphics, versionText) {
        var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
        var dotSize = VERSION_FOOTER_PIXEL_SIZE;
        var cursorDots = 0;
        canvasGraphics.newPath();
        for (var i = 0; i < versionText.length; i++) {
            var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
            if (!glyphRows) continue;
            if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
            for (var row = 0; row < glyphRows.length; row++) {
                var rowText = glyphRows[row];
                var runStart = -1;
                for (var col = 0; col <= rowText.length; col++) {
                    var isDot = col < rowText.length && rowText.charAt(col) === "#";
                    if (isDot && runStart < 0) runStart = col;
                    if (!isDot && runStart >= 0) {
                        canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                        runStart = -1;
                    }
                }
            }
            cursorDots += glyphRows[0].length;
        }
        canvasGraphics.fillPath(footerBrush);
    }

    // -----------------------------------------
    // このスクリプトについて / About this script
    // -----------------------------------------
    /* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
       この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
       Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
       and keeps its own labels and layout values so the part works on its own */

    var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
    var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
    /* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
       The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
    var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
    var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
    var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

    var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
    var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
    var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
    var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
    var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
    var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
    var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
    /* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
    var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
    var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
    var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
    var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

    var VERSION_INFO_LABELS = {
        dialog: {
            title: { ja: "このスクリプトについて", en: "About This Script" }
        },
        panel: {
            generalInfo: { ja: "基本情報", en: "General" },
            links: { ja: "リンク", en: "Links" }
        },
        fieldLabel: {
            scriptName: { ja: "スクリプト名", en: "Script Name" },
            scriptFeature: { ja: "機能", en: "Feature" },
            scriptVersion: { ja: "バージョン", en: "Version" }
        },
        button: {
            openReadme: { ja: "README", en: "README" },
            openSourceCode: { ja: "ソースコード", en: "Source Code" },
            openArticle: { ja: "記事（note）", en: "Article (note)" },
            revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
            revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
            close: { ja: "閉じる", en: "Close" }
        },
        tooltip: {
            versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
            copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
        },
        alert: {
            copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
        }
    };

    /**
     * VERSION_INFO_LABELS の文言を今の言語で返す
     * @param {Object} labelEntry - { ja, en }
     * @returns {string} 文言
     */
    function getVersionInfoLabel(labelEntry) {
        return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
    }

    /**
     * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
     * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
     * @returns {string} 値
     */
    function getVersionInfoValue(variableKey) {
        var infoValue;
        if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
        else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
        else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
        else if (variableKey === "readme") {
            if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
            else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
        }
        else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
        else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
        return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
    }

    /**
     * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
     * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
     * @returns {void}
     */
    function bindVersionInfoClick(versionCanvas) {
        versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
        /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
           Open on mouseup so the release does not land on the footer after the dialog closes */
        versionCanvas.addEventListener("mouseup", function () {
            showVersionInfoDialog(versionCanvas.window.type === "palette");
        });
    }

    /**
     * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
     * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
     * @returns {void}
     */
    function showVersionInfoDialog(isFromPalette) {
        var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
        infoDialog.orientation = "column";
        infoDialog.alignChildren = "fill";
        infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
        infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

        var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
        /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
        /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
        if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
            addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
        }
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
        alignVersionInfoLabels(infoPanel);

        /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
        var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
        var linkButtonRow = linksPanel.add("group");
        linkButtonRow.orientation = "row";
        linkButtonRow.alignment = ["left", "center"];
        linkButtonRow.alignChildren = ["left", "center"];
        linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

        /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
        var buttonRow = infoDialog.add("group");
        buttonRow.orientation = "row";
        buttonRow.alignment = ["fill", "bottom"];
        buttonRow.alignChildren = ["left", "center"];
        buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
        buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
        var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
        var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
        if (VERSION_INFO_SCRIPT_FILE.exists) {
            revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
            revealButton.onClick = function () {
                revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
                infoDialog.close();
            };
        } else {
            revealButton.enabled = false;
        }
        /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
        var buttonSpacer = buttonRow.add("group");
        buttonSpacer.alignment = ["fill", "fill"];
        buttonSpacer.minimumSize.width = 0;
        var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
        closeButton.alignment = ["right", "center"];
        /* return でも esc でも閉じる / Close with both Return and Esc */
        infoDialog.defaultElement = closeButton;
        infoDialog.cancelElement = closeButton;
        infoDialog.onShow = function () {
            pinVersionInfoCopyButton(infoPanel);
        };
        infoDialog.show();
    }

    /**
     * 「このスクリプトについて」のダイアログにパネルを足す
     * @param {Window} infoDialog - 足す先のダイアログ
     * @param {Object} titleEntry - パネル名の文言 { ja, en }
     * @returns {Panel} パネル
     */
    function addVersionInfoPanel(infoDialog, titleEntry) {
        var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
        infoPanel.orientation = "column";
        infoPanel.alignChildren = ["fill", "top"];
        infoPanel.alignment = "fill";
        infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
        infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
        return infoPanel;
    }

    /**
     * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
     * @param {Panel} infoPanel - 足す先のパネル
     * @param {Object} labelEntry - 項目名の文言 { ja, en }
     * @param {string} valueText - 表示する値
     * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
     * @returns {StaticText} 値の statictext
     */
    function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
        var infoRow = infoPanel.add("group");
        infoRow.orientation = "row";
        infoRow.alignment = ["fill", "center"];
        infoRow.alignChildren = ["left", "center"];
        infoRow.spacing = VERSION_INFO_ROW_SPACING;
        /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
        var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
        rowLabel.justify = "right";
        var valueLabel = infoRow.add("statictext", undefined, valueText);
        if (copyFromPalette === null) return valueLabel;
        /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
           A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
        var copySpacer = infoRow.add("group");
        copySpacer.alignment = ["fill", "fill"];
        copySpacer.minimumSize.width = 0;
        infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
        return valueLabel;
    }

    /**
     * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
     * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
     * @param {Panel} infoPanel - ［基本情報］パネル
     * @returns {void}
     */
    function pinVersionInfoCopyButton(infoPanel) {
        var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
        for (var i = 0; i < infoPanel.children.length; i++) {
            var infoRow = infoPanel.children[i];
            if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
            infoRow.size = [innerWidth, infoRow.size.height];
            infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
        }
    }

    /**
     * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
     * @param {Panel} infoPanel - 対象のパネル
     * @returns {void}
     */
    function alignVersionInfoLabels(infoPanel) {
        var rowLabels = [];
        var labelWidth = 0;
        for (var i = 0; i < infoPanel.children.length; i++) {
            var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
            rowLabels.push(rowLabel);
            labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
        }
        for (var j = 0; j < rowLabels.length; j++) {
            rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
        }
    }

    /**
     * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
     * @param {Window} infoDialog - ボタンを置くダイアログ
     * @param {Group} buttonGroup - 足す先のグループ
     * @param {Object} labelEntry - ボタンの文言 { ja, en }
     * @param {string} targetUrl - 開く URL（空ならディム表示）
     * @returns {void}
     */
    function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
        var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
        if (!targetUrl) {
            linkButton.enabled = false;
            return;
        }
        linkButton.helpTip = targetUrl;
        linkButton.onClick = function () {
            openVersionInfoUrl(targetUrl);
            infoDialog.close();
        };
    }

    /**
     * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
     * @param {Group} infoRow - 足す先の行
     * @param {StaticText} valueLabel - コピーする値の statictext
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
     * @returns {Group} ボタンとして使う group
     */
    function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
        var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
        var copyButton = infoRow.add("group");
        copyButton.preferredSize = [buttonSize, buttonSize];
        copyButton.minimumSize = [buttonSize, buttonSize];
        copyButton.maximumSize = [buttonSize, buttonSize];
        copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
        copyButton.isPressed = false;
        copyButton.isCopied = false;

        copyButton.onDraw = function () {
            var buttonGraphics = copyButton.graphics;
            var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
            buttonGraphics.newPath();
            buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
            buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
            buttonGraphics.newPath();
            buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
            buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
            if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
            else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
        };

        /**
         * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
         * @param {boolean} isPressed - 押下中なら true
         * @param {boolean} isCopied - コピー済みなら true
         * @returns {void}
         */
        function repaint(isPressed, isCopied) {
            if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
            copyButton.isPressed = isPressed;
            copyButton.isCopied = isCopied;
            copyButton.hide();
            copyButton.show();
        }
        copyButton.addEventListener("mousedown", function () { repaint(true, false); });
        copyButton.addEventListener("mouseup", function () {
            if (!copyButton.isPressed) return;
            var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
            repaint(false, hasCopied);
            if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
        });
        /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
        copyButton.addEventListener("mouseout", function () { repaint(false, false); });
        return copyButton;
    }

    /**
     * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
     * @param {ScriptUIGraphics} buttonGraphics - 描画先
     * @param {number} buttonSize - ボタンの一辺
     * @returns {void}
     */
    function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
        var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
        var sheetSize = 9;
        var offset = 3;
        var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
        var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
        var backLeft = frontLeft - offset;
        var backTop = frontTop - offset;
        /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
        buttonGraphics.newPath();
        buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
        buttonGraphics.lineTo(backLeft, backTop + sheetSize);
        buttonGraphics.lineTo(backLeft, backTop);
        buttonGraphics.lineTo(backLeft + sheetSize, backTop);
        buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
        buttonGraphics.strokePath(iconPen);
        buttonGraphics.newPath();
        buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
        buttonGraphics.strokePath(iconPen);
    }

    /**
     * コピーしたあとのチェックマークを描く
     * @param {ScriptUIGraphics} buttonGraphics - 描画先
     * @param {number} buttonSize - ボタンの一辺
     * @returns {void}
     */
    function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
        var center = buttonSize / 2;
        buttonGraphics.newPath();
        buttonGraphics.moveTo(center - 4.5, center);
        buttonGraphics.lineTo(center - 1.5, center + 3);
        buttonGraphics.lineTo(center + 4.5, center - 3.5);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
    }

    /**
     * 文字列をクリップボードにコピーする。
     * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
     * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
     * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
     * @param {string} copyText - コピーする文字列
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
     * @returns {boolean} コピーの操作まで進めたら true
     */
    function copyVersionInfoText(copyText, isFromPalette) {
        try {
            if (VERSION_INFO_IS_INDESIGN) {
                if (File.fs === "Windows") {
                    app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
                } else {
                    app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
                }
                return true;
            }
            var copyScript = buildVersionInfoCopyScript(copyText);
            if (!isFromPalette) return eval(copyScript) === true;
            var copyMessage = new BridgeTalk();
            copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
            copyMessage.body = copyScript;
            copyMessage.send();
            return true;
        } catch (e) {
            return false;
        }
    }

    /**
     * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
     * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
     * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
     * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
     * @param {string} copyText - コピーする文字列
     * @returns {string} 実行すると true / false を返すスクリプト
     */
    function buildVersionInfoCopyScript(copyText) {
        return [
            "(function (copyText) {",
            "    var usingTempDoc = (app.documents.length === 0);",
            "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
            "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
            "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
            "    var tempLayer = null;",
            "    var hasCopied = false;",
            "    try {",
            "        tempLayer = targetDoc.layers.add();",
            "        var tempFrame = tempLayer.textFrames.add();",
            "        tempFrame.contents = copyText;",
            "        app.redraw();",
            "        app.executeMenuCommand('deselectall');",
            "        tempFrame.selected = true;",
            "        app.redraw();",
            "        app.executeMenuCommand('copy');",
            "        app.redraw();",
            "        hasCopied = true;",
            "    } catch (e) { }",
            "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
            "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
            "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
            "    targetDoc.selection = null;",
            "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
            "    app.redraw();",
            "    return hasCopied;",
            "})(" + quoteVersionInfoString(copyText) + ");"
        ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
    }

    /**
     * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
     * @param {string} sourceText - 文字列
     * @returns {string} "…" の形のリテラル
     */
    function quoteVersionInfoString(sourceText) {
        return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
    }

    /**
     * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
     * @param {File} scriptFile - 表示するファイル
     * @returns {void}
     */
    function revealVersionInfoScriptFile(scriptFile) {
        /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
        var hasRevealApp = (File.fs === "Macintosh")
            && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
        /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
        if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
        /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
        scriptFile.parent.execute();
    }

    /**
     * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
     * @param {string} targetPath - 絶対パス
     * @returns {boolean} 書き出せたら true
     */
    function writeVersionInfoRevealPath(targetPath) {
        var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
        pathFile.encoding = "UTF-8";
        pathFile.lineFeed = "Unix";
        if (!pathFile.open("w")) return false;
        var hasWritten = pathFile.write(targetPath);
        pathFile.close();
        return hasWritten;
    }

    /**
     * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
     * @param {string} targetUrl - 開く URL
     * @returns {void}
     */
    function openVersionInfoUrl(targetUrl) {
        var isMac = (File.fs === "Macintosh");
        var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
        shortcutFile.encoding = "UTF-8";
        shortcutFile.open("w");
        if (isMac) {
            var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
            shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
                + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
        } else {
            shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
        }
        shortcutFile.close();
        shortcutFile.execute();
    }

    // バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

    var LABELS = {
        dialog: {
            title: { ja: "メニューアクション", en: "Menu Actions" }
        },
        fieldLabel: {
            name:       { ja: "名前", en: "Name" },
            nameOrId:   { ja: "名前・ID", en: "Name / ID" },
            area:       { ja: "エリア", en: "Area" },
            category:   { ja: "カテゴリ", en: "Category" },
            sortOrder:  { ja: "並び順", en: "Sort by" },
            keyStrings: { ja: "キーストリング", en: "Key strings" },
            invokeCode: { ja: "実行コード", en: "Invoke code" }
        },
        dropdown: {
            allAreas: { ja: "［すべて］", en: "[All]" },
            allCategories: { ja: "［すべて］", en: "[All]" }
        },
        button: {
            copy:  { ja: "コピー", en: "Copy" },
            close: { ja: "閉じる", en: "Close" }
        },
        tooltip: {
            category: {
                ja: "エリア名の「:」より前の部分（編集メニュー、パネルメニューなど）で絞り込みます。エリアの候補も絞られます。",
                en: "Filters by the part of the area name before \":\" (Edit Menu, Panel Menus, etc.). The area choices are narrowed as well."
            },
            nameOrId: {
                ja: "名前に含まれる文字で絞り込みます（大文字小文字を区別しません）。正規表現も使えます。数字だけを入れると、その ID のアクションも対象にします。入力するたびに絞り込みます。",
                en: "Filters by text contained in the name (case-insensitive). Regular expressions are allowed. Digits only also match the action with that ID. The list is filtered as you type."
            },
            copyKeyStrings: {
                ja: "選択したアクション名に対応するキーストリング（$ID/…）をクリップボードにコピーします。複数ある場合は「 | 」で区切ります。",
                en: "Copies the key strings ($ID/…) for the selected action name to the clipboard. Multiple key strings are separated by \" | \"."
            },
            copyInvokeCode: {
                ja: "選択したアクションを実行するコード（app.menuActions.itemByID(…).invoke();）をクリップボードにコピーします。",
                en: "Copies the code that invokes the selected action (app.menuActions.itemByID(…).invoke();) to the clipboard."
            }
        },
        message: {
            noKeyStrings: { ja: "（見つかりません）", en: "(not found)" }
        },
        alert: {
            copyFailed: { ja: "クリップボードにコピーできませんでした。", en: "Could not copy to the clipboard." }
        },
        progress: {
            loading:  { ja: "メニューアクションを読み込み中…", en: "Loading menu actions…" },
            building: { ja: "リストを作成中…", en: "Building the list…" }
        },
        counter: {
            itemUnit: { ja: "件", en: " items" }
        }
    };

    // =========================================
    // データ / Data
    // =========================================

    /**
     * @typedef {Object} ActionEntry
     * @property {string} name - 表示用の名前（コード接尾辞を除いたもの）
     * @property {string} area - エリア
     * @property {number} id - アクション ID
     */

    /**
     * 一覧に出さないアクションか判定する
     * @param {string} actionName - アクション名
     * @param {string} areaName - エリア名
     * @param {number} actionId - アクション ID
     * @returns {boolean} 除外するなら true
     */
    function isNoiseAction(actionName, areaName, actionId) {
        if (!HIDE_NOISE) {
            return false;
        }
        return (actionId >= NOISE_ID_MIN && actionId <= NOISE_ID_MAX)
            || !MEANINGFUL_CHAR_PATTERN.test(actionName)
            || WINDOW_NAME_PATTERN.test(actionName)
            || FILE_NAME_PATTERN.test(actionName)
            || NOISE_AREA_PATTERN.test(areaName);
    }

    /**
     * メニューアクションを収集する
     * 1件ずつプロパティを読むと遅いので、everyItem() で列ごとにまとめて取る
     * @param {Object} progressWindow - createProgressWindow() の戻り値
     * @returns {ActionEntry[]} アクションの一覧
     */
    function collectActions(progressWindow) {
        var allItems = app.menuActions.everyItem();
        var actionNames = allItems.name;
        progressWindow.update(1);
        var areaNames = allItems.area;
        progressWindow.update(2);
        var actionIds = allItems.id;
        progressWindow.update(3);

        var entries = [];
        for (var i = 0; i < actionIds.length; i++) {
            if (isNoiseAction(actionNames[i], areaNames[i], actionIds[i])) {
                continue;
            }
            entries.push({
                name: actionNames[i].replace(CODE_SUFFIX_PATTERN, ""),
                area: areaNames[i],
                id: actionIds[i]
            });
        }
        return entries;
    }

    /**
     * エリア名の一覧を重複なく昇順で返す
     * @param {ActionEntry[]} entries - アクションの一覧
     * @returns {string[]} エリア名の一覧
     */
    function collectAreaNames(entries) {
        var seen = {};
        var areaNames = [];
        for (var i = 0; i < entries.length; i++) {
            if (!seen[entries[i].area]) {
                seen[entries[i].area] = true;
                areaNames.push(entries[i].area);
            }
        }
        return areaNames.sort();
    }

    /* 並べ替えキーの区切り（どの文字より前に並ぶ）/ Sort key separator (sorts before any character) */
    var SORT_KEY_SEPARATOR = "\u0001";

    /**
     * ID を桁そろえした文字列にする（文字列の並べ替えで数値順になるように）
     * @param {number} actionId - アクション ID
     * @returns {string} 10桁にゼロ埋めした ID
     */
    function padActionId(actionId) {
        return ("0000000000" + actionId).slice(-10);
    }

    /**
     * 並べ替え用の文字列キーを作る（同順位は名前・ID で決める）
     * @param {ActionEntry} actionEntry - 対象のアクション
     * @param {string} sortKey - "name" / "area"
     * @returns {string} 並べ替えキー
     */
    function buildSortKey(actionEntry, sortKey) {
        var paddedId = padActionId(actionEntry.id);
        var nameKey = actionEntry.name + SORT_KEY_SEPARATOR + paddedId;
        return (sortKey === "area") ? actionEntry.area + SORT_KEY_SEPARATOR + nameKey : nameKey;
    }

    /**
     * 指定したキーでアクションを並べ替える
     * 比較関数を渡すと ExtendScript では数秒かかるため、文字列キーを組み込みの sort() で並べる
     * @param {ActionEntry[]} entries - 並べ替えるアクションの一覧（直接並べ替える）
     * @param {string} sortKey - "name" / "area"
     * @returns {void}
     */
    function sortActions(entries, sortKey) {
        var sortKeys = [];
        for (var i = 0; i < entries.length; i++) {
            sortKeys.push(buildSortKey(entries[i], sortKey) + SORT_KEY_SEPARATOR + i);
        }
        sortKeys.sort();

        var sortedEntries = [];
        for (var j = 0; j < sortKeys.length; j++) {
            var originalIndex = Number(sortKeys[j].substring(sortKeys[j].lastIndexOf(SORT_KEY_SEPARATOR) + 1));
            sortedEntries.push(entries[originalIndex]);
        }
        for (var k = 0; k < sortedEntries.length; k++) {
            entries[k] = sortedEntries[k];
        }
    }

    /**
     * 名前の検索文字列から照合用の正規表現を作る（正規表現として不正なら文字どおりに探す）
     * @param {string} searchText - 検索文字列
     * @returns {RegExp|null} 正規表現。空欄なら null
     */
    function buildNamePattern(searchText) {
        if (searchText === "") {
            return null;
        }
        /* 入力途中の不正な正規表現は例外になる / Incomplete regex input throws */
        try {
            return new RegExp(searchText, "i");
        } catch (e) {
            return new RegExp(searchText.replace(/[\\^$.*+?()[\]{}|\/]/g, "\\$&"), "i");
        }
    }

    /**
     * エリア名からカテゴリ（「:」より前の部分）を取り出す
     * @param {string} areaName - エリア名
     * @returns {string} カテゴリ名
     */
    function getCategoryName(areaName) {
        return areaName.split(AREA_LEVEL_SEPARATOR)[0];
    }

    /**
     * エリア名の一覧からカテゴリ名を重複なく昇順で返す
     * @param {string[]} areaNames - エリア名の一覧
     * @returns {string[]} カテゴリ名の一覧
     */
    function collectCategoryNames(areaNames) {
        var seen = {};
        var categoryNames = [];
        for (var i = 0; i < areaNames.length; i++) {
            var categoryName = getCategoryName(areaNames[i]);
            if (!seen[categoryName]) {
                seen[categoryName] = true;
                categoryNames.push(categoryName);
            }
        }
        return categoryNames.sort();
    }

    /**
     * 指定したカテゴリに属するエリア名だけを返す
     * @param {string[]} areaNames - エリア名の一覧
     * @param {string|null} categoryName - カテゴリ名。null ならすべて
     * @returns {string[]} 条件に合うエリア名
     */
    function filterAreaNames(areaNames, categoryName) {
        var matched = [];
        for (var i = 0; i < areaNames.length; i++) {
            if (categoryName === null || getCategoryName(areaNames[i]) === categoryName) {
                matched.push(areaNames[i]);
            }
        }
        return matched;
    }

    /**
     * 名前・ID、カテゴリ、エリアの条件で絞り込む
     * @param {ActionEntry[]} entries - アクションの一覧
     * @param {string} searchText - 名前の検索文字列（数字だけなら ID とも照合する）
     * @param {string|null} categoryName - カテゴリ名。null ならすべて
     * @param {string|null} areaName - エリア名。null ならすべて
     * @returns {ActionEntry[]} 条件に合うアクション
     */
    function filterActions(entries, searchText, categoryName, areaName) {
        var trimmedText = searchText.replace(/^\s+|\s+$/g, "");
        var namePattern = buildNamePattern(trimmedText);
        var idText = /^\d+$/.test(trimmedText) ? trimmedText : null;
        var matched = [];
        for (var i = 0; i < entries.length; i++) {
            var matchesId = (idText !== null && String(entries[i].id) === idText);
            if (namePattern && !matchesId && !namePattern.test(entries[i].name)) {
                continue;
            }
            if (areaName !== null && entries[i].area !== areaName) {
                continue;
            }
            if (categoryName !== null && getCategoryName(entries[i].area) !== categoryName) {
                continue;
            }
            matched.push(entries[i]);
        }
        return matched;
    }

    /**
     * 数値を3桁区切りの文字列にする
     * @param {number} value - 数値
     * @returns {string} 3桁区切りの文字列
     */
    function formatThousands(value) {
        return String(value).replace(/(\d)(?=(\d\d\d)+$)/g, "$1,");
    }

    /**
     * 件数入りのダイアログタイトルを作る
     * @param {number} itemCount - 表示中の件数
     * @returns {string} ダイアログタイトル
     */
    function buildDialogTitle(itemCount) {
        var countText = formatThousands(itemCount) + getLabel(LABELS.counter.itemUnit);
        return getLabel(LABELS.dialog.title) + " " + SCRIPT_VERSION
            + (uiLang === "ja" ? "（" + countText + "）" : " (" + countText + ")");
    }

    /**
     * 1列目に出す名前を切り詰める
     * Mac の ScriptUI は1列目の幅を中身の最も長い文字列まで広げ、columnWidths を無視するため
     * @param {string} actionName - アクション名
     * @returns {string} 長い場合は末尾を「…」にした名前
     */
    function truncateForNameColumn(actionName) {
        return (actionName.length > NAME_COLUMN_MAX_CHARS)
            ? actionName.substring(0, NAME_COLUMN_MAX_CHARS - 1) + "…"
            : actionName;
    }

    /**
     * アクションを実行するコードを作る
     * @param {ActionEntry} actionEntry - 対象のアクション
     * @returns {string} app.menuActions.itemByID(…).invoke(); 形式のコード
     */
    function buildInvokeCode(actionEntry) {
        return "app.menuActions.itemByID(" + actionEntry.id + ").invoke();";
    }

    // =========================================
    // 進行状況 / Progress
    // =========================================

    /**
     * 進行状況バーの小さなパレットを表示する
     * @param {Object} messageSet - 表示する文言
     * @param {number} maxValue - バーの最大値
     * @returns {{update: function(number): void, reset: function(Object, number): void, close: function(): void}} 操作用の関数（close は2回呼んでもよい）
     */
    function createProgressWindow(messageSet, maxValue) {
        var progressPalette = new Window("palette", getLabel(LABELS.dialog.title));
        setupWindow(progressPalette);

        var messageText = progressPalette.add("statictext", undefined, getLabel(messageSet));
        var progressBar = progressPalette.add("progressbar", undefined, 0, maxValue);
        progressBar.preferredSize.width = PROGRESS_BAR_WIDTH;

        progressPalette.show();
        progressPalette.update();
        var isClosed = false;

        return {
            update: function (value) {
                progressBar.value = value;
                progressPalette.update();
            },
            reset: function (nextMessageSet, nextMaxValue) {
                messageText.text = getLabel(nextMessageSet);
                progressBar.maxvalue = nextMaxValue;
                progressBar.value = 0;
                progressPalette.update();
            },
            close: function () {
                if (!isClosed) {
                    isClosed = true;
                    progressPalette.close();
                }
            }
        };
    }

    // =========================================
    // ダイアログ部品 / Dialog parts
    // =========================================

    /**
     * ラベルと入力部品を1行に並べる
     * @param {Group} parent - 追加先
     * @param {Object} labelSet - 行ラベル
     * @returns {Group} 行グループ（入力部品はここへ追加する）
     */
    function addFieldRow(parent, labelSet) {
        var rowGroup = parent.add("group");
        setupRow(rowGroup, ["fill", "top"]);
        var rowLabel = rowGroup.add("statictext", undefined, labelText(labelSet));
        /* 幅を固定しないと右揃えが効かない / Right alignment needs a fixed width */
        rowLabel.minimumSize.width = ROW_LABEL_WIDTH;
        rowLabel.preferredSize.width = ROW_LABEL_WIDTH;
        rowLabel.justify = "right";
        return rowGroup;
    }

    /**
     * 名前・エリアの2列のリストを作る（ID は実行コードの欄で確認する）
     * @param {Group} parent - 追加先
     * @returns {ListBox} アクション一覧
     */
    function buildActionList(parent) {
        var actionList = parent.add("listbox", [0, 0, LIST_SIZE[0], LIST_SIZE[1]], "", {
            multiselect: false,
            numberOfColumns: 2,
            showHeaders: true,
            columnTitles: [
                getLabel(LABELS.fieldLabel.name),
                getLabel(LABELS.fieldLabel.area)
            ],
            columnWidths: COLUMN_WIDTHS
        });
        actionList.preferredSize = LIST_SIZE;
        return actionList;
    }

    /**
     * エリアのドロップダウンの項目を入れ替える（先頭は［すべて］）
     * @param {DropDownList} areaDropdown - エリアのドロップダウン
     * @param {string[]} areaNames - 並べるエリア名
     * @returns {void}
     */
    function fillAreaDropdown(areaDropdown, areaNames) {
        areaDropdown.removeAll();
        areaDropdown.add("item", getLabel(LABELS.dropdown.allAreas));
        for (var i = 0; i < areaNames.length; i++) {
            areaDropdown.add("item", areaNames[i]);
        }
        areaDropdown.selection = 0;
    }

    /**
     * カテゴリのドロップダウンを作る（［すべて］→ メニュー関連 → 区切り線 → それ以外）
     * @param {DropDownList} categoryDropdown - カテゴリのドロップダウン
     * @param {string[]} categoryNames - カテゴリ名の一覧（昇順）
     * @returns {void}
     */
    function fillCategoryDropdown(categoryDropdown, categoryNames) {
        var menuCategories = [];
        var otherCategories = [];
        for (var i = 0; i < categoryNames.length; i++) {
            if (MENU_CATEGORY_PATTERN.test(categoryNames[i])) {
                menuCategories.push(categoryNames[i]);
            } else {
                otherCategories.push(categoryNames[i]);
            }
        }
        categoryDropdown.add("item", getLabel(LABELS.dropdown.allCategories));
        for (var j = 0; j < menuCategories.length; j++) {
            categoryDropdown.add("item", menuCategories[j]);
        }
        if (menuCategories.length > 0 && otherCategories.length > 0) {
            categoryDropdown.add("separator");
        }
        for (var k = 0; k < otherCategories.length; k++) {
            categoryDropdown.add("item", otherCategories[k]);
        }
    }

    /**
     * リスト上の絞り込み条件（カテゴリ・エリア・名前と ID・並び順）の行を作る
     * @param {Group} parent - 追加先
     * @param {string[]} areaNames - エリア名の一覧
     * @returns {{categoryDropdown: DropDownList, areaDropdown: DropDownList, searchInput: EditText, sortRadios: RadioButton[]}} 作成した部品
     */
    function buildFilterRows(parent, areaNames) {
        var categoryDropdown = addFieldRow(parent, LABELS.fieldLabel.category).add("dropdownlist", undefined, []);
        fillCategoryDropdown(categoryDropdown, collectCategoryNames(areaNames));
        categoryDropdown.preferredSize.width = FILTER_FIELD_WIDTH;
        categoryDropdown.helpTip = getLabel(LABELS.tooltip.category);
        categoryDropdown.selection = 0;

        var areaDropdown = addFieldRow(parent, LABELS.fieldLabel.area).add("dropdownlist", undefined, []);
        areaDropdown.preferredSize.width = FILTER_FIELD_WIDTH;
        fillAreaDropdown(areaDropdown, areaNames);

        var searchInput = addFieldRow(parent, LABELS.fieldLabel.nameOrId).add("edittext", undefined, "");
        searchInput.preferredSize.width = FILTER_FIELD_WIDTH;
        searchInput.helpTip = getLabel(LABELS.tooltip.nameOrId);
        searchInput.active = true;

        /* 並び順の項目名は列名と同じ。同じ行グループに入れて排他にする / Reuse column names; same parent keeps them exclusive */
        var sortRowGroup = addFieldRow(parent, LABELS.fieldLabel.sortOrder);
        var sortRadios = [];
        for (var j = 0; j < SORT_KEYS.length; j++) {
            sortRadios.push(sortRowGroup.add("radiobutton", undefined, getLabel(LABELS.fieldLabel[SORT_KEYS[j]])));
        }
        sortRadios[DEFAULT_SORT_INDEX].value = true;

        return {
            categoryDropdown: categoryDropdown,
            areaDropdown: areaDropdown,
            searchInput: searchInput,
            sortRadios: sortRadios
        };
    }

    /**
     * リスト下の1行（ラベル・読み取り専用の欄・［コピー］ボタン）を作る
     * @param {Group} parent - 追加先
     * @param {Object} labelSet - 行ラベル
     * @param {Object} tooltipSet - ［コピー］ボタンのツールチップ
     * @returns {{valueField: EditText, btnCopy: Button}} 作成した部品
     */
    function addDetailRow(parent, labelSet, tooltipSet) {
        var rowGroup = addFieldRow(parent, labelSet);

        /* コピーできるよう読み取り専用の欄に出す / Read-only field so the text can be copied */
        var valueField = rowGroup.add("edittext", undefined, "", { readonly: true });
        valueField.alignment = ["fill", "center"];

        /* 余った幅を吸わないよう幅を固定 / Fix the width so it does not absorb spare space */
        var btnCopy = rowGroup.add("button", undefined, getLabel(LABELS.button.copy));
        btnCopy.alignment = ["right", "center"];
        btnCopy.minimumSize.width = COPY_BUTTON_WIDTH;
        btnCopy.preferredSize.width = COPY_BUTTON_WIDTH;
        btnCopy.maximumSize.width = COPY_BUTTON_WIDTH;
        btnCopy.helpTip = getLabel(tooltipSet);

        return { valueField: valueField, btnCopy: btnCopy };
    }

    /**
     * ボタン行（右に［閉じる］）を作る。［閉じる］はデフォルトボタン兼キャンセルボタン
     * @param {Window} dialogWindow - 追加先のダイアログ
     * @returns {Button} ［閉じる］ボタン
     */
    function addCloseButtonRow(dialogWindow) {
        var buttonRow = addButtonRow(dialogWindow);
        var btnClose = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.close), { name: "ok" });
        alignRightOnlyButtonRow(buttonRow);
        dialogWindow.defaultElement = btnClose;
        dialogWindow.cancelElement = btnClose;
        return btnClose;
    }

    // =========================================
    // 表示 / Display
    // =========================================

    /**
     * アクションのキーストリングを1行にまとめる
     * @param {ActionEntry} actionEntry - 対象のアクション
     * @returns {string} 「 | 」区切りのキーストリング。なければ空文字
     */
    function buildKeyStringsText(actionEntry) {
        return app.findKeyStrings(actionEntry.name).join(" | ");
    }

    /**
     * 文字列をクリップボードにコピーする（Mac は AppleScript、Windows は VBScript 経由）
     * @param {string} copyText - コピーする文字列
     * @returns {void}
     */
    function copyToClipboard(copyText) {
        var isMac = (File.fs === "Macintosh");
        var scriptSource = isMac
            ? 'set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"'
            : 'CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"';
        /* スクリプト実行の許可がないと失敗する / Fails without permission to run scripts */
        try {
            app.doScript(scriptSource, isMac ? ScriptLanguage.APPLESCRIPT_LANGUAGE : ScriptLanguage.VISUAL_BASIC);
        } catch (e) {
            alert(getLabel(LABELS.alert.copyFailed) + "\n" + e.message);
        }
    }

    /**
     * メインダイアログを作って表示する
     * @param {ActionEntry[]} allActions - すべてのアクション
     * @param {Object} progressWindow - createProgressWindow() の戻り値（最初の一覧作成後に閉じる）
     * @returns {void}
     */
    function showMainDialog(allActions, progressWindow) {
        var visibleActions = [];
        var lastSearchText = "";

        var mainDialog = new Window("dialog", getLabel(LABELS.dialog.title));
        setupWindow(mainDialog);

        /* 上から絞り込み条件・リスト・詳細行 / Filters, list and detail rows from top to bottom */
        var allAreaNames = collectAreaNames(allActions);
        var filterControls = buildFilterRows(mainDialog, allAreaNames);
        var actionList = buildActionList(mainDialog);
        var keyStringsRow = addDetailRow(mainDialog, LABELS.fieldLabel.keyStrings, LABELS.tooltip.copyKeyStrings);
        var invokeCodeRow = addDetailRow(mainDialog, LABELS.fieldLabel.invokeCode, LABELS.tooltip.copyInvokeCode);
        addCloseButtonRow(mainDialog);

        /**
         * 一覧で選択中のアクションを返す
         * @returns {ActionEntry|null} 選択中のアクション。なければ null
         */
        function getSelectedAction() {
            return actionList.selection ? visibleActions[actionList.selection.index] : null;
        }

        /**
         * 選択中のアクションのキーストリングと実行コードを詳細欄に出し、［コピー］の有効／無効を切り替える
         * @returns {void}
         */
        function updateDetailRows() {
            var selectedAction = getSelectedAction();
            var keyStringsText = selectedAction ? buildKeyStringsText(selectedAction) : "";
            if (selectedAction && keyStringsText === "") {
                keyStringsRow.valueField.text = getLabel(LABELS.message.noKeyStrings);
            } else {
                keyStringsRow.valueField.text = keyStringsText;
            }
            invokeCodeRow.valueField.text = selectedAction ? buildInvokeCode(selectedAction) : "";
            keyStringsRow.btnCopy.enabled = (keyStringsText !== "");
            invokeCodeRow.btnCopy.enabled = (selectedAction !== null);
        }

        /**
         * ドロップダウンの選択を返す（先頭の［すべて］なら null）
         * @param {DropDownList} dropdown - 対象のドロップダウン
         * @returns {string|null} 選択中の項目名
         */
        function getDropdownFilterValue(dropdown) {
            return (dropdown.selection.index === 0) ? null : dropdown.selection.text;
        }

        /**
         * カテゴリを変えたら、エリアの候補を絞り直して一覧を作り直す
         * @returns {void}
         */
        function handleCategoryChange() {
            /* 項目の入れ替えで onChange が走らないよう外しておく / Detach so refilling does not fire onChange */
            filterControls.areaDropdown.onChange = null;
            fillAreaDropdown(filterControls.areaDropdown,
                filterAreaNames(allAreaNames, getDropdownFilterValue(filterControls.categoryDropdown)));
            filterControls.areaDropdown.onChange = handleFilterChange;
            refreshList(null);
        }

        /**
         * 選択中の並び順のキーを返す
         * @returns {string} "name" / "area"
         */
        function getSelectedSortKey() {
            for (var i = 0; i < filterControls.sortRadios.length; i++) {
                if (filterControls.sortRadios[i].value) {
                    return SORT_KEYS[i];
                }
            }
            return SORT_KEYS[DEFAULT_SORT_INDEX];
        }

        /**
         * 絞り込み・並べ替えの結果で一覧を作り直す
         * @param {Object} [listProgress] - 進行状況の表示先（最初の作成時だけ渡す）
         * @returns {void}
         */
        function refreshList(listProgress) {
            lastSearchText = filterControls.searchInput.text;
            visibleActions = filterActions(allActions, filterControls.searchInput.text,
                getDropdownFilterValue(filterControls.categoryDropdown), getDropdownFilterValue(filterControls.areaDropdown));
            sortActions(visibleActions, getSelectedSortKey());

            if (listProgress) {
                listProgress.reset(LABELS.progress.building, visibleActions.length);
            }
            actionList.removeAll();
            for (var i = 0; i < visibleActions.length; i++) {
                var listItem = actionList.add("item", truncateForNameColumn(visibleActions[i].name));
                listItem.subItems[0].text = visibleActions[i].area;
                if (listProgress && i % PROGRESS_STEP === 0) {
                    listProgress.update(i);
                }
            }
            mainDialog.text = buildDialogTitle(visibleActions.length);
            /* 1件に絞れたら選択して詳細を出す / Select it when only one action is left */
            if (visibleActions.length === 1) {
                actionList.selection = 0;
            }
            updateDetailRows();
        }

        /**
         * 絞り込み条件の変更時に一覧を作り直す（進行状況は出さない）
         * @returns {void}
         */
        function handleFilterChange() {
            refreshList(null);
        }

        /**
         * 名前・ID 欄の文字が前回の絞り込みから変わっていれば一覧を作り直す
         * （onChanging と onChange の両方から呼ばれても1回で済ませる）
         * @returns {void}
         */
        function applySearchText() {
            if (filterControls.searchInput.text !== lastSearchText) {
                refreshList(null);
            }
        }

        /* 入力するたびに絞り込む（Enter は［閉じる］に使う）/ Filter as you type (Enter is for Close) */
        filterControls.searchInput.onChanging = applySearchText;
        filterControls.searchInput.onChange = applySearchText;
        filterControls.areaDropdown.onChange = handleFilterChange;
        filterControls.categoryDropdown.onChange = handleCategoryChange;
        for (var i = 0; i < filterControls.sortRadios.length; i++) {
            filterControls.sortRadios[i].onClick = handleFilterChange;
        }
        actionList.onChange = updateDetailRows;
        keyStringsRow.btnCopy.onClick = function () {
            copyToClipboard(buildKeyStringsText(getSelectedAction()));
        };
        invokeCodeRow.btnCopy.onClick = function () {
            copyToClipboard(buildInvokeCode(getSelectedAction()));
        };

        refreshList(progressWindow);
        progressWindow.close();
        addVersionFooter(mainDialog);
        mainDialog.show();
    }

    /* 読み込み3段階（名前・エリア・ID）/ Three loading steps (names, areas, IDs) */
    var loadingProgress = createProgressWindow(LABELS.progress.loading, 3);
    /* 途中で例外が起きても進行状況ウィンドウを残さない / Never leave the progress window open on error */
    try {
        showMainDialog(collectActions(loadingProgress), loadingProgress);
    } finally {
        loadingProgress.close();
    }

}());
