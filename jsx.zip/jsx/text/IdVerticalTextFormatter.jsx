#target indesign
#targetengine "IdVerticalTextFormatter"

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdVerticalTextFormatter
Name=縦組みの欧文回転・縦中横・数字の書き換えをまとめて適用
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.0.3
Release-Date=2026-11-01
Description-BEGIN
選択したテキストを縦組みにし、欧文回転・縦中横・数字の書き換え（全角・漢数字・和暦）・禁則・文字組みなどをまとめて適用します。
ダイアログボックスで項目を選び、変換の結果を一覧で確かめてから実行できます。

Turns the selected text vertical and applies vertical-text settings in one go: rotated Roman characters,
Tate-Chu-Yoko, number rewriting (full-width digits, kanji numerals, Japanese era years), kinsoku and mojikumi.
Choose the options in a dialog box and check the result list before running.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

選択したテキストを縦組みにし、欧文回転・縦中横・数字の書き換え（全角・漢数字・和暦）・禁則・文字組みなどをまとめて適用します。
ダイアログボックスで項目を選び、変換の結果を一覧で確かめてから実行できます。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdVerticalTextFormatter.md

### Overview

Turns the selected text vertical and applies vertical-text settings in one go: rotated Roman characters,
Tate-Chu-Yoko, number rewriting (full-width digits, kanji numerals, Japanese era years), kinsoku and mojikumi.
Choose the options in a dialog box and check the result list before running.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdVerticalTextFormatter.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdVerticalTextFormatter";      /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.3";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-11-01";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "縦組みの欧文回転・縦中横・数字の書き換えをまとめて適用"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA  = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdVerticalTextFormatter.md"; /* README（日本語） */
var SCRIPT_README_EN  = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdVerticalTextFormatter.md"; /* README (English) */
var SCRIPT_SOURCE_URL = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/text/IdVerticalTextFormatter.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

    // =========================================
    // 基本設定 / Settings
    // =========================================

    /* ダイアログの初期値（前回の値は SettingsStore に残る） / Dialog defaults (the last values are kept by SettingsStore) */
    var DEFAULT_SETTINGS = {
        rotateRoman: true,
        tcyNumbers: true,
        tcyDigits2: true,
        tcyDigits3: true,
        tcyDigits4: false,
        tcyExcludeAdjacent: true,
        tcyCapitals: false,
        tcyExclamation: false,
        tcyGlyphByLength: true,
        singleDigitFullwidth: false,
        longDigitsFullwidth: false,
        nonTcyDigitsFullwidth: false,
        japaneseEra: false,
        kanjiToArabic: false,
        kanji: false,
        kanjiMinDigits: 4,
        kanjiMaxDigits: 20,
        kanjiStyle: "digit",
        kanjiZeroRei: false,
        kanjiIchiSen: false,
        halfwidthAlnum: false,
        commaStyle: "touten",
        phoneHyphenStyle: "hyphen",
        colorCheck: false,
        areaAutoSize: true,
        areaHeightToSize: true,
        periodToNakaguro: true,
        symbolsFullwidth: true,
        quotesToChonchon: true,
        rangeToWave: true,
        exclamFullwidth: true,
        singleLetterFullwidth: false,
        shortCapsFullwidth: false,
        unitsKumimoji: false,
        proportionalFullwidthLatin: true,
        ichiNoTightening: true,
        rotateSkipLongLatin: false,
        rotateSkipMinChars: 5,
        shortWordFullwidth: false,
        shortWordMaxChars: 4,
        kinsokuName: "",        /* 禁則処理セットの名前（空文字は弱い禁則、TABLE_NONE は「なし」） / kinsoku set name ("" = soft kinsoku, TABLE_NONE = none) */
        mojikumiName: "",       /* 文字組みアキ量設定の名前（空文字は行末約物半角、TABLE_NONE は「なし」） / mojikumi set name ("" = line-end punctuation half-width) */
        leadingPercent: 175,
        dialogMode: "simple",   /* "simple" / "detail" / "wizard" */
        /* ウィザードでチェックしたやりたいこと（WIZARD_GOALS の key） / Goals checked in the wizard (keys of WIZARD_GOALS) */
        wizardGoals: { rotate: true, uprightWords: false, tcyNumbers: true, fullwidthDigits: false, kanji: false, era: false,
            tcyOthers: false, units: false, marks: true, paragraph: true, fitFrame: true, colorCheck: false }
    };

    /* ダイアログの真偽値の項目（設定のキーとコントロール名が同じ） / Boolean dialog options (setting key = control name) */
    var CHECKBOX_SETTING_KEYS = ["rotateRoman", "tcyNumbers", "tcyDigits2", "tcyDigits3", "tcyDigits4", "tcyExcludeAdjacent", "tcyCapitals",
        "tcyExclamation", "tcyGlyphByLength", "singleDigitFullwidth", "longDigitsFullwidth", "nonTcyDigitsFullwidth", "japaneseEra", "kanjiToArabic", "kanji", "kanjiZeroRei", "kanjiIchiSen", "halfwidthAlnum",
        "colorCheck", "areaAutoSize", "areaHeightToSize", "periodToNakaguro", "symbolsFullwidth", "quotesToChonchon", "rangeToWave", "exclamFullwidth", "singleLetterFullwidth",
        "shortCapsFullwidth", "unitsKumimoji", "proportionalFullwidthLatin", "ichiNoTightening", "rotateSkipLongLatin", "shortWordFullwidth"];

    /* 簡易モードで表示していなくてもオフにしない項目（常にかける） / Options kept on even when hidden in the simple mode (always applied) */
    var ALWAYS_APPLIED_KEYS = ["areaHeightToSize", "ichiNoTightening"];

    /* ウィザードのやりたいこと。チェックしたものの data を順に重ねる（チェックしていない項目はオフ、禁則・文字組み・行送りは変えない）。
       overriddenBy のやりたいことがオンのときは、チェックしていても使わない（ダイアログボックスでは無効にする）
       Wizard goals; the data of each checked goal is layered in order (unchecked options are off; kinsoku, mojikumi and leading stay).
       A goal is skipped (and dimmed in the dialog box) while its overriddenBy goal is on */
    var WIZARD_GOALS = [
        { key: "rotate", data: { rotateRoman: true, rotateSkipLongLatin: true } },
        { key: "uprightWords", data: { shortWordFullwidth: true, singleLetterFullwidth: true } },
        { key: "tcyNumbers", overriddenBy: "kanji", data: { tcyNumbers: true, tcyDigits2: true, tcyDigits3: true, tcyDigits4: false, tcyExcludeAdjacent: true, tcyGlyphByLength: true } },
        { key: "fullwidthDigits", overriddenBy: "kanji", data: { nonTcyDigitsFullwidth: true, singleDigitFullwidth: true } },
        { key: "kanji", data: { kanji: true, kanjiMinDigits: 1, kanjiMaxDigits: 20 } },
        { key: "era", data: { japaneseEra: true } },
        { key: "tcyOthers", data: { tcyCapitals: true, tcyExclamation: true, tcyGlyphByLength: true } },
        { key: "units", data: { unitsKumimoji: true } },
        { key: "marks", data: { commaStyle: "touten", periodToNakaguro: true, rangeToWave: true, symbolsFullwidth: true, quotesToChonchon: true,
            exclamFullwidth: true, phoneHyphenStyle: "hyphen" } },
        { key: "paragraph", data: { kinsokuName: "", mojikumiName: "", leadingPercent: 175, proportionalFullwidthLatin: true } },
        { key: "fitFrame", data: { areaAutoSize: true } },
        { key: "colorCheck", data: { colorCheck: true } }
    ];

    var MODE_SWITCH_RESULT = 3;   /* モードを切り替えて開き直すときの show() の戻り値 / show() result for reopening in another mode */

    /* 禁則処理セット・文字組みアキ量設定はドキュメントの一覧（組み込みも入っている）から名前で選ぶ。
       組み込みの並びは実測で、禁則は 強い禁則・弱い禁則・…、文字組みは 行末約物半角・… の順
       Kinsoku and mojikumi sets are chosen by name from the document's lists (built-ins included);
       measured built-in order: kinsoku Hard, Soft, ...; mojikumi starts with line-end punctuation half-width */
    var TABLE_NONE = "[none]";        /* 「なし」の設定値 / setting value for "None" */
    var KINSOKU_DEFAULT_INDEX = 1;    /* 既定の禁則（弱い禁則）の doc.kinsokuTables の位置 / position of the default (soft) kinsoku set */
    var MOJIKUMI_DEFAULT_INDEX = 0;   /* 既定の文字組み（行末約物半角）の doc.mojikumiTables の位置 / position of the default mojikumi set */
    var KERNING_METHOD_NONE = "$ID/None";   /* 自動カーニング「なし」（カーニング 0） / auto kerning "None" (kerning 0) */
    /* 桁区切りの選択肢 / Thousands separator choices */
    var COMMA_STYLES = ["touten", "remove", "keep"];
    /* 番号のハイフンの選択肢 / Phone hyphen choices */
    var PHONE_HYPHEN_STYLES = ["hyphen", "choon", "keep"];

    /* 組み込みのプリセット。書いていない項目は DEFAULT_SETTINGS の値
       Built-in presets; omitted items use DEFAULT_SETTINGS.
       よりどころ：モリサワ「数字を含んだ文章はどのように組めばいいの？」、東洋美術印刷「縦組みの基本！」、
       校正視点「縦書き数字の表記方法」（A：漢数字が原則、B：算用数字が原則） */
    var KANJI_ALL_DIGITS = { tcyNumbers: false, kanji: true, kanjiMinDigits: 1, kanjiMaxDigits: 20 };   /* すべて漢数字にする共通の値 / shared values for all-kanji presets */
    var BUILTIN_PRESETS = [
        /* 初期値のまま：2〜3桁を縦中横、字数に合わせた等幅字形、「、」「・」、混じった漢数字は算用数字に
           Defaults: 2–3 digit TCY, fixed-width forms, 、 and ・, stray kanji numerals to digits */
        { labelKey: "standard", data: { kanjiToArabic: true } },
        /* 校正視点 B：2桁は縦中横、1桁と3桁以上は1字ずつ縦に / Kousei B: TCY for 2 digits only, others upright one by one */
        { labelKey: "arabicTcy2", data: { tcyDigits3: false, singleDigitFullwidth: true, kanjiToArabic: true } },
        /* 東洋美術印刷・モリサワ：2〜3桁を縦中横（3桁は三分）、単位は組文字、短い略称は全角で縦・長い欧文は横（縦中横は数字だけ）
           Toyobijutsu / Morisawa: 2–3 digit TCY, unit squares, short abbreviations full-width upright, long Roman text sideways (TCY for numbers only) */
        {
            labelKey: "arabicMagazine",
            data: {
                singleDigitFullwidth: true, unitsKumimoji: true, kanjiToArabic: true,
                rotateSkipLongLatin: true, shortWordFullwidth: true
            }
        },
        /* 校正視点 A①：万・億・兆だけ（一般的な方法） / Kousei A-1: only 万・億・兆 (the common style) */
        { labelKey: "kanjiLargeUnits", data: mergeObjects(KANJI_ALL_DIGITS, { kanjiStyle: "largeUnits", commaStyle: "remove" }) },
        /* 校正視点 A②：十・百・千も入れる / Kousei A-2: every unit word */
        { labelKey: "kanjiPositional", data: mergeObjects(KANJI_ALL_DIGITS, { kanjiStyle: "positional", commaStyle: "remove" }) },
        /* 校正視点 A③：単位語なしで1字ずつ、3桁ごとに読点 / Kousei A-3: digit by digit with 、 every three digits */
        { labelKey: "kanjiDigitTouten", data: mergeObjects(KANJI_ALL_DIGITS, { kanjiStyle: "digit", commaStyle: "touten" }) },
        {
            labelKey: "rotateOnly",
            data: {
                tcyNumbers: false, tcyGlyphByLength: false, commaStyle: "keep", phoneHyphenStyle: "keep", periodToNakaguro: false,
                symbolsFullwidth: false, quotesToChonchon: false, rangeToWave: false, exclamFullwidth: false,
                proportionalFullwidthLatin: false
            }
        }
    ];

    /**
     * 2つのオブジェクトを重ねた新しいオブジェクトを返す（後ろが優先）
     * @param {Object} baseObject - 元の値
     * @param {Object} overrideObject - 上書きする値
     * @returns {Object} 重ねた値
     */
    function mergeObjects(baseObject, overrideObject) {
        var mergedObject = {};
        var key;
        for (key in baseObject) {
            if (baseObject.hasOwnProperty(key)) mergedObject[key] = baseObject[key];
        }
        for (key in overrideObject) {
            if (overrideObject.hasOwnProperty(key)) mergedObject[key] = overrideObject[key];
        }
        return mergedObject;
    }

    var PREVIEW_MAX_LINES = 300;   /* 確認の一覧に出す最大の行数 / max lines in the check list */

    /* 確認用の色分けの色（ColorCharactersByWidth から移植）。CMYK のスウォッチを作って塗る（ベースは［黒］）
       Check-coloring colors (ported from ColorCharactersByWidth); CMYK swatches are created (the base is [Black]) */
    var CHECK_FULL_WIDTH_CMYK  = [0, 100, 100, 0];   /* 全角 / full-width */
    var CHECK_HALF_WIDTH_CMYK  = [100, 40, 0, 0];    /* 半角 / half-width */
    var CHECK_GLYPH_WIDTH_CMYK = [80, 0, 100, 0];    /* 等幅字形 / fixed-width glyphs */

    /* 全角：０-９ Ａ-Ｚ ａ-ｚ ！？、半角：0-9 A-Z a-z !? / full-width and half-width alphanumerics, ! and ? */
    var FULL_WIDTH_PATTERN = /[０-９Ａ-Ｚａ-ｚ！？]/;
    var HALF_WIDTH_PATTERN = /[0-9A-Za-z!?]/;

    // =========================================
    // レイアウト / Layout
    // =========================================

    // UIレイアウト（再利用パーツ） / UI layout (reusable)

    /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
    var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
    var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
    var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
    var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
    var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
    var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

    /**
     * ウィンドウの共通設定
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
     * @returns {void}
     */
    function setupWindow(targetWindow, spacing) {
        targetWindow.orientation = "column";
        targetWindow.alignChildren = "fill";
        targetWindow.margins = WINDOW_MARGINS;
        targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
    }

    /**
     * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
     * @param {Panel} targetPanel - 対象のパネル
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupPanel(targetPanel, spacing) {
        targetPanel.orientation = "column";
        targetPanel.alignChildren = ["fill", "top"];
        targetPanel.alignment = "fill";
        targetPanel.margins = PANEL_MARGINS;
        targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * タブの共通設定
     * @param {Tab} targetTab - 対象のタブ
     * @param {number} [spacing] - 要素間隔（省略時は変えない）
     * @returns {void}
     */
    function setupTab(targetTab, spacing) {
        targetTab.orientation = "column";
        targetTab.alignChildren = "fill";
        targetTab.margins = TAB_MARGINS;
        if (typeof spacing === "number") targetTab.spacing = spacing;
    }

    /**
     * 横並びの行グループの共通設定（ボタン列など）。
     * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
     * @param {Group} rowGroup - 対象のグループ
     * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
     * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
     * @returns {void}
     */
    function setupRow(rowGroup, rowAlignment, spacing) {
        rowGroup.orientation = "row";
        rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
        rowGroup.alignChildren = ["left", "center"];
        rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
    }

    /**
     * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
     * @param {Button} targetButton - 対象のボタン
     * @param {number} trimPixels - 詰める量（px）
     * @returns {void}
     */
    function trimButtonHeight(targetButton, trimPixels) {
        /* レイアウト前は size が無い / size is not set until the layout runs */
        if (!targetButton.size) return;
        targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
    }

    // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

    var BUTTON_WIDTH        = 90;    /* OK／キャンセルの幅 / OK and Cancel width */
    var OPTION_INDENT       = 20;    /* 親のチェックボックスに従う項目の字下げ / indent for dependent options */
    var PREVIEW_LIST_SIZE   = [420, 320];   /* 「変換の確認」ダイアログボックスの一覧の大きさ / size of the list in the Conversion Check dialog box */
    var PROGRESS_WIDTH      = 300;   /* プログレスバーの幅 / progress bar width */
    var PRESET_ICON_SIZE    = [20, 18];   /* プリセットの保存・削除アイコンの大きさ / preset save and delete icon size */
    var PRESET_DROPDOWN_WIDTH = 150; /* プリセットのドロップダウンの幅（長い名前は選択中の表示だけ切れる） / preset dropdown width (long names are cut only in the closed menu) */
    var PRESET_NAME_CHARS   = 20;    /* プリセット名の入力欄の文字数 / preset name field width */
    var PARAGRAPH_LABEL_WIDTH = 60;  /* 段落のドロップダウンの項目名の幅（右揃え） / paragraph dropdown label width (right-aligned) */
    var PARAGRAPH_DROPDOWN_WIDTH = 200;   /* 禁則・文字組みのドロップダウンの幅（長い名前は選択中の表示だけ切れる） / kinsoku and mojikumi dropdown width */
    var PARAGRAPH_OPTION_TOP_MARGIN = 5;   /* 「文字・段落」のチェックボックスの上の余白 / gap above the checkboxes in Character and Paragraph */

    // UI の明暗（再利用パーツ） / UI theme (reusable)

    /**
     * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
     * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
     */
    function isDarkUI() {
        try {
            if (app.preferences && app.preferences.getRealPreference) {
                return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
            }
            return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
        } catch (e) {
            return false;
        }
    }

    // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

    // ステップボタン（再利用パーツ） / Stepper buttons (reusable)

    // -----------------------------------------
    // ステップボタンの寸法・増減量 / Stepper metrics and steps
    // -----------------------------------------
    var STEPPER_BUTTON_WIDTH   = 20;  /* ∧∨ボタンの幅 / button width */
    var STEPPER_BUTTON_HEIGHT  = 11;  /* ∧∨ボタン1つの高さ（2つ重ねた全体の高さは22） / button height (22 for the pair) */
    var STEPPER_CORNER_RADIUS  = 2;   /* 枠の角丸の半径（ScriptUIは円弧を描けないため短い線分で近似） / corner radius, approximated with segments */
    var STEPPER_FIELD_SPACING  = 3;   /* 項目名と∧∨の間隔 / spacing between the label and the stepper */
    var STEPPER_SIDE_MARGIN    = 3;   /* ∧∨の左に足す余白（右は入力欄に突き合わせる） / extra space left of the stepper */
    var STEPPER_SHIFT_MULTIPLE = 10;  /* shift＋クリックでそろえる倍数 / Shift-click snaps to multiples of this */
    var STEPPER_OPTION_STEP    = 0.1; /* option＋クリックの増減量 / Option-click step */

    /* 単位の換算は UnitValue に任せる（in / ft / yd / mm / cm / m / pt / pc / px ほか、単数形・複数形も可）。
       UnitValue に無い単位だけ、ここで UnitValue の単位に読み替える（値は「1単位＝何 unit か」）。
       「p」は「1p6」（1パイカ6ポイント）の形にも使う
       Units UnitValue lacks, mapped onto UnitValue units (how many of `unit` make one) */
    var STEPPER_UNIT_ALIASES = {
        "q": { unit: "mm", amount: 0.25 },    /* 級 / Q */
        "h": { unit: "mm", amount: 0.25 },    /* 歯 / H */
        "p": { unit: "pc", amount: 1 },       /* パイカ / pica */
        "ft/in": { unit: "ft", amount: 1 },   /* Illustrator の単位コード7の表示 / Illustrator unit code 7 */
        "c": { unit: "ci", amount: 1 },       /* シセロ（InDesign の表示） / ciceros as InDesign shows them */
        "ag": { unit: "in", amount: 1 / 14 }, /* アゲート / agates */
        "ap": { unit: "tpt", amount: 1 }      /* アメリカンポイント / American points */
    };

    // -----------------------------------------
    // ステップボタンの配色 / Stepper colors
    // -----------------------------------------
    var STEPPER_UI_DARK           = isDarkUI();
    /* UIの明るさは4段階あり、段階ごとに背景色が違う。どの段階でも背景に対する差で見せるよう、黒・白の半透明を重ねる。
       ダーク側は Illustrator 標準のスピナー（［グリッドに分割］）で実測、明るい側は最も明るい段階（背景 約0.94）から逆算
       UI brightness has four levels with different backgrounds, so colors are translucent overlays that follow the
       dialog background. Dark values are measured from Illustrator's own spinner; light values derived for the lightest level */
    var STEPPER_FILL_COLOR        = STEPPER_UI_DARK ? [0, 0, 0, 0.10]  : [1, 1, 1, 0.50];  /* 地 / background */
    var STEPPER_FRAME_COLOR       = STEPPER_UI_DARK ? [1, 1, 1, 0.07]  : [0, 0, 0, 0.10];  /* 枠線 / frame */
    var STEPPER_PRESSED_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 0.12]  : [0, 0, 0, 0.13];  /* 押下中 / pressed */
    var STEPPER_CHEVRON_COLOR     = STEPPER_UI_DARK ? [1, 1, 1, 1]     : [0, 0, 0, 0.70];  /* 山形の線 / chevron */
    var STEPPER_DIM_FILL_COLOR    = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [1, 1, 1, 0.30];  /* 無効時の地 / background when disabled */
    var STEPPER_DIM_FRAME_COLOR   = STEPPER_UI_DARK ? [1, 1, 1, 0.035] : [0, 0, 0, 0.05];  /* 無効時の枠線（ダークは地と同じで見せない） / frame when disabled */
    var STEPPER_DIM_CHEVRON_COLOR = STEPPER_UI_DARK ? [1, 1, 1, 0.20]  : [0, 0, 0, 0.25];  /* 無効時の山形 / chevron when disabled */

    // -----------------------------------------
    // 数値欄を作る（外から呼ぶ関数） / Public API
    // -----------------------------------------
    /**
     * 「項目名・∧∨・入力欄」をひと組にした数値欄を追加する。
     * ↑↓キーでも∧∨と同じように増減する。直接入力した値も、フォーカスが外れたときに
     * 整数化・下限・上限・単位（「20 mm」の形）へそろえ、数値でなければ直前の値に戻す。
     * 四則演算（+ - * / と括弧）を入れると、確定時に計算した値にする。欄と異なる単位で入れた値は欄の単位へ換算する（mm の欄に「1 in」→「25.4 mm」）
     * @param {Group|Panel} parent - 追加先
     * @param {Object} fieldOptions - label（コロン込みの項目名）/ labelWidth / text / characters /
     *     step / min / max / integer（true で整数のみ）/ unit / onStep
     * @returns {EditText} 入力欄（項目名は .fieldLabel、∧∨は .stepperGroup で参照できる）
     */
    function addSteppedField(parent, fieldOptions) {
        var fieldRowGroup = parent.add("group");
        fieldRowGroup.orientation = "row";
        fieldRowGroup.alignChildren = ["left", "center"];
        fieldRowGroup.spacing = STEPPER_FIELD_SPACING;

        var fieldLabel = fieldRowGroup.add("statictext", undefined, fieldOptions.label || "");
        if (fieldOptions.labelWidth) {
            fieldLabel.preferredSize.width = fieldOptions.labelWidth;
            fieldLabel.justify = "right";
        }

        /* ∧∨と入力欄は隙間0で突き合わせる / butt the stepper against the field */
        var stepperInputGroup = fieldRowGroup.add("group");
        stepperInputGroup.orientation = "row";
        stepperInputGroup.alignChildren = ["left", "center"];
        stepperInputGroup.spacing = 0;
        stepperInputGroup.margins = 0;

        var numberInput;
        var stepperGroup = addStepper(stepperInputGroup, function () { return numberInput; }, fieldOptions);
        numberInput = stepperInputGroup.add("edittext", undefined, fieldOptions.text || "");
        numberInput.characters = fieldOptions.characters || 6;
        numberInput.fieldLabel = fieldLabel;
        numberInput.stepperGroup = stepperGroup;

        /* ↑↓キーも∧∨と同じ処理で増減する（増減量・下限・上限・単位・修飾キーをそろえる） / arrow keys share the stepper's logic */
        bindSteppedArrowKeys(numberInput, stepperGroup);

        /* 直接入力をそろえる。計算式は計算し、数値でなければ直前の値に戻す / normalize typed values; evaluate arithmetic, revert non-numbers */
        numberInput.lastValidText = numberInput.text;
        numberInput.onChange = function () {
            var value = evaluateArithmetic(numberInput.text, fieldOptions.unit);
            if (isNaN(value)) {
                numberInput.text = numberInput.lastValidText;
                return;
            }
            writeSteppedValue(numberInput, value, fieldOptions);
        };
        return numberInput;
    }

    /**
     * 数値欄の有効／無効を、項目名・∧∨ごとまとめて切り替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setSteppedFieldEnabled(numberInput, isEnabled) {
        numberInput.enabled = isEnabled;
        numberInput.fieldLabel.enabled = isEnabled;
        numberInput.stepperGroup.enabled = isEnabled;
        /* ∧∨は自作描画なので、描き直してディム表示を切り替える / redraw the custom-drawn buttons to update the dimming */
        for (var i = 0; i < numberInput.stepperGroup.children.length; i++) {
            redrawStepperGroup(numberInput.stepperGroup.children[i]);
        }
    }

    /**
     * 数値欄の単位を差し替える（単位の設定やドロップダウンを切り替えたとき用）。
     * shouldConvert が true なら値を新しい単位へ換算し（10 mm → 28.35 pt）、false なら数値はそのままで単位だけ付け替える
     * @param {EditText} numberInput - addSteppedField() で作った入力欄、または bindSteppedArrowKeys() を呼んだ入力欄
     * @param {string} unit - 新しい単位（例 " pt"。単位なしは ""）
     * @param {boolean} [shouldConvert] - 値も換算するなら true
     * @returns {void}
     */
    function setSteppedFieldUnit(numberInput, unit, shouldConvert) {
        var stepOptions = numberInput.stepperGroup.stepOptions;
        var oldUnit = stepOptions.unit || "";
        var value = parseFloat(numberInput.text);
        stepOptions.unit = unit;
        if (isNaN(value)) return;
        if (shouldConvert) {
            var converted = evaluateArithmetic(String(value) + oldUnit, unit);
            if (!isNaN(converted)) value = converted;
        }
        numberInput.text = formatStepperNumber(value) + unit;
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 入力欄の値を増減する∧∨ボタンを、隙間なく縦に積んで追加する
     * @param {Group|Panel} parent - 追加先
     * @param {Function} getNumberInput - 対象の入力欄を返す関数（入力欄を∧∨より後に作れるよう、クリック時に引く）
     * @param {Object} stepOptions - step（増減量）/ min / max / integer / unit（例 " mm"）/ onStep(numberInput)
     * @returns {Group} ∧∨をまとめた group（.stepBy(direction) で同じ増減を呼べる）
     */
    function addStepper(parent, getNumberInput, stepOptions) {
        var stepperGroup = parent.add("group");
        stepperGroup.orientation = "column";
        stepperGroup.spacing = 0; /* 2つのボタンをつなげて1つの枠に見せる / join the buttons into one frame */
        stepperGroup.margins = [STEPPER_SIDE_MARGIN, 0, 0, 0]; /* 右は入力欄に突き合わせる / butt against the field on the right */
        stepperGroup.alignment = ["left", "center"];

        /**
         * 入力欄の値を増減する（shift を押しながらなら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ。下限・上限で止める）
         * @param {number} direction - 増やすなら 1、減らすなら -1
         * @returns {void}
         */
        function stepBy(direction) {
            var numberInput = getNumberInput();
            if (!isStepperEnabledInTree(numberInput)) return; /* 入力欄か親が無効の間は動かさない */
            var value = evaluateArithmetic(numberInput.text, stepOptions.unit); /* 確定前の計算式も計算してから増減 / evaluate an uncommitted expression first */
            if (isNaN(value)) value = parseFloat(numberInput.text); /* 計算できなければ従来どおり先頭の数値 / fall back to the leading number */
            if (isNaN(value)) value = 0;
            writeSteppedValue(numberInput, computeSteppedValue(value, direction, stepOptions), stepOptions);
            if (stepOptions.onStep) stepOptions.onStep(numberInput);
        }

        /* 整数の欄では option＋クリックの0.1刻みが効かないので、説明から外す / integer fields have no 0.1 step */
        var upTooltip = stepOptions.integer ? LABELS.tooltip.stepUpInteger : LABELS.tooltip.stepUp;
        var downTooltip = stepOptions.integer ? LABELS.tooltip.stepDownInteger : LABELS.tooltip.stepDown;
        makeStepperChevronButton(stepperGroup, "up", function () { stepBy(1); }).helpTip = getLabel(upTooltip);
        makeStepperChevronButton(stepperGroup, "down", function () { stepBy(-1); }).helpTip = getLabel(downTooltip);
        stepperGroup.stepBy = stepBy; /* ↑↓キーからも同じ処理で増減できるよう公開 / shared with the arrow keys */
        stepperGroup.stepOptions = stepOptions; /* 確定時の計算で欄の単位を引けるよう公開 / lets the commit-time evaluation find the unit */
        return stepperGroup;
    }

    /**
     * 入力欄の↑↓キーを、∧∨と同じ処理で増減させる。ほかのキーは素通し。
     * あわせて、確定時に計算式・単位付きの値を計算して書き戻す（各スクリプトの onChange より先に呼ばれるので、onChange は計算後の値を読む）
     * @param {EditText} numberInput - 対象の入力欄
     * @param {Group} stepperGroup - addStepper() で作った∧∨
     * @returns {void}
     */
    function bindSteppedArrowKeys(numberInput, stepperGroup) {
        numberInput.addEventListener("keydown", function (event) {
            if (event.keyName !== "Up" && event.keyName !== "Down") return;
            stepperGroup.stepBy(event.keyName === "Up" ? 1 : -1);
            event.preventDefault(); /* カーソル移動を止める / keep the caret from moving */
        });
        numberInput.addEventListener("change", function () {
            var fieldUnit = stepperGroup.stepOptions ? stepperGroup.stepOptions.unit : undefined;
            var value = evaluateArithmetic(numberInput.text, fieldUnit);
            if (isNaN(value)) return; /* 計算できなければ各スクリプトの処理に任せる / leave it to the script's own handler */
            /* 式か、換算で値が変わったときだけ書き戻す（ただの数値は書式を崩さない） / rewrite only expressions and converted values */
            var hasOperator = /[*\/()\u00D7\u00F7\uFF0A\uFF0F\uFF08\uFF09]|[\d.\uFF10-\uFF19][^\d.\uFF10-\uFF19]*[+\-\u2212\uFF0B\uFF0D]/.test(numberInput.text);
            if (!hasOperator && value === parseFloat(numberInput.text)) {
                /* 単位を省いて入れた数値には、欄の単位だけ付け足す（桁は丸めない） / append the field unit to a bare number */
                var trimmedText = numberInput.text.replace(/^\s+|\s+$/g, "");
                if (fieldUnit && /[\d.]$/.test(trimmedText)) numberInput.text = trimmedText + fieldUnit;
                return;
            }
            numberInput.text = formatStepperNumber(value) + (fieldUnit || "");
        });
        numberInput.stepperGroup = stepperGroup; /* setSteppedFieldUnit() から∧∨の設定を引けるようにする / lets setSteppedFieldUnit() find the options */
    }

    // -----------------------------------------
    // 値の計算 / Value helpers
    // -----------------------------------------
    /**
     * 押された修飾キーに応じて、1回分増減した値を返す
     * （shift なら STEPPER_SHIFT_MULTIPLE の倍数へ、option なら STEPPER_OPTION_STEP ずつ、それ以外は step の倍数へ（1.5→2、1.5→1）。
     * 整数の欄では option を無視して step の倍数へ）
     * @param {number} value - 元の値
     * @param {number} direction - 増やすなら 1、減らすなら -1
     * @param {Object} stepOptions - step（通常の増減量。省略時は 1）/ integer
     * @returns {number} 増減した値（下限・上限は未適用）
     */
    function computeSteppedValue(value, direction, stepOptions) {
        var keyState = ScriptUI.environment.keyboardState;
        if (keyState.shiftKey) return snapStepperToNextMultiple(value, STEPPER_SHIFT_MULTIPLE, direction);
        if (keyState.altKey && !stepOptions.integer) return value + direction * STEPPER_OPTION_STEP;
        return snapStepperToNextMultiple(value, stepOptions.step || 1, direction);
    }

    /**
     * 値を、指定した方向にある次の倍数へ移す（230→240、232→240、下げるときは 232→230、230→220）
     * @param {number} value - 元の値
     * @param {number} multiple - 倍数の単位（例 10）
     * @param {number} direction - 上げるなら 1、下げるなら -1
     * @returns {number} 移した値
     */
    function snapStepperToNextMultiple(value, multiple, direction) {
        /* 0.29 / 0.01 = 28.999… のような浮動小数の誤差で同じ値に戻らないよう、商を丸めてから切り捨て・切り上げる
           round the quotient first so float error (0.29 / 0.01 = 28.999…) does not step back to the same value */
        var quotient = Math.round(value / multiple * 1e6) / 1e6;
        if (direction > 0) return Math.round((Math.floor(quotient) + 1) * multiple * 1e6) / 1e6;
        return Math.round((Math.ceil(quotient) - 1) * multiple * 1e6) / 1e6;
    }

    /**
     * 値を下限・上限の範囲に収める
     * @param {number} value - 数値
     * @param {Object} rangeOptions - min / max（どちらも省略可）
     * @returns {number} 範囲に収めた値
     */
    function clampSteppedValue(value, rangeOptions) {
        if (rangeOptions.min !== undefined && value < rangeOptions.min) return rangeOptions.min;
        if (rangeOptions.max !== undefined && value > rangeOptions.max) return rangeOptions.max;
        return value;
    }

    /**
     * 入力欄の文字列を四則演算（+ - * / と括弧）として計算する。eval は使わない。
     * 数値の後ろの単位は UnitValue で欄の単位へ換算する（mm の欄に「1in」→ 25.4、「1p6」は1パイカ6ポイント）。単位のない数値は欄の単位とみなす。
     * 全角の数字・記号と × ÷ は半角に直す
     * @param {string} text - 入力欄の文字列
     * @param {string} [fieldUnit] - 欄の単位（例 " mm"。前後の空白は無視）
     * @returns {number} 欄の単位での計算結果（式として読めない・換算できない単位・0で割ったときは NaN）
     */
    function evaluateArithmetic(text, fieldUnit) {
        var source = String(text)
            .replace(/[！-～]/g, function (ch) { return String.fromCharCode(ch.charCodeAt(0) - 0xFEE0); })
            .replace(/×/g, "*")
            .replace(/÷/g, "/")
            .replace(/[−–—]/g, "-")
            .replace(/\s/g, "");
        if (source === "") return NaN;
        var fieldUnitKey = String(fieldUnit || "").replace(/^\s+|\s+$/g, "").toLowerCase();
        var fieldUnitValue = createStepperUnitValue(1, fieldUnitKey); /* 欄の単位の1単位（換算できない欄は null） / one field unit */
        var position = 0;

        /**
         * 加減算の並び（項 ± 項 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readSum() {
            var total = readProduct();
            while (position < source.length && (source.charAt(position) === "+" || source.charAt(position) === "-")) {
                var operator = source.charAt(position++);
                var operand = readProduct();
                total = (operator === "+") ? total + operand : total - operand;
            }
            return total;
        }

        /**
         * 乗除算の並び（因子 × 因子 …）を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readProduct() {
            var total = readFactor();
            while (position < source.length && (source.charAt(position) === "*" || source.charAt(position) === "/")) {
                var operator = source.charAt(position++);
                var operand = readFactor();
                if (operator === "/" && operand === 0) return NaN;
                total = (operator === "*") ? total * operand : total / operand;
            }
            return total;
        }

        /**
         * 符号付きの数値（単位付きなら欄の単位へ換算）か、括弧で囲んだ式を読む
         * @returns {number} 値（読めなければ NaN）
         */
        function readFactor() {
            var ch = source.charAt(position);
            if (ch === "+" || ch === "-") {
                position++;
                var signedValue = readFactor();
                return (ch === "-") ? -signedValue : signedValue;
            }
            if (ch === "(") {
                position++;
                var innerValue = readSum();
                if (source.charAt(position) !== ")") return NaN;
                position++;
                return innerValue;
            }
            var numberMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
            if (!numberMatch) return NaN;
            position += numberMatch[0].length;
            return readUnitSuffix(parseFloat(numberMatch[0]));
        }

        /**
         * 数値の直後の単位を読み、欄の単位へ換算する
         * @param {number} value - 単位の前の数値
         * @returns {number} 欄の単位での値（換算できない単位なら NaN）
         */
        function readUnitSuffix(value) {
            var unitMatch = /^(ft\/in|[A-Za-z]+|%|°)/i.exec(source.substring(position));
            if (!unitMatch) return value; /* 単位なしは欄の単位 / no unit means the field's unit */
            position += unitMatch[0].length;
            var unitKey = unitMatch[0].toLowerCase();
            if (unitKey === fieldUnitKey) return value;
            var typedValue = createStepperUnitValue(value, unitKey);
            if (!typedValue || !fieldUnitValue) return NaN; /* 知らない単位・単位のない欄 / unknown unit or unitless field */
            var points = typedValue.as("pt");
            /* 「1p6」＝1パイカ6ポイント / pica-point notation */
            if (unitKey === "p") {
                var pointMatch = /^(\d+\.?\d*|\.\d+)/.exec(source.substring(position));
                if (pointMatch) {
                    position += pointMatch[0].length;
                    points += parseFloat(pointMatch[0]);
                }
            }
            return points / fieldUnitValue.as("pt");
        }

        var result = readSum();
        if (position !== source.length || !isFinite(result)) return NaN; /* 読み残しがあれば式として不正 / leftovers mean a malformed expression */
        return result;
    }

    /**
     * 数値と単位から UnitValue を作る。Q・H・p は STEPPER_UNIT_ALIASES で UnitValue の単位に読み替える。
     * %（percent）は基準の長さが無いと換算できないので扱わない
     * @param {number} value - 数値
     * @param {string} unitKey - 単位（小文字。例 "mm"、"inches"、"q"）
     * @returns {UnitValue|null} UnitValue（UnitValue が知らない単位・空・% なら null）
     */
    function createStepperUnitValue(value, unitKey) {
        if (unitKey === "" || unitKey === "%") return null;
        var alias = STEPPER_UNIT_ALIASES[unitKey];
        var unitValue = alias ? new UnitValue(value * alias.amount, alias.unit) : new UnitValue(value, unitKey);
        if (unitValue.type === "?" || unitValue.type === "%") return null; /* 知らない単位は例外にならず "?" になる。"percent" も除く / unknown units become "?" */
        return unitValue;
    }

    /**
     * 値を整数化・下限・上限でそろえ、単位を付けて入力欄に書き込む（直前の正しい値としても控える）
     * @param {EditText} numberInput - 書き込む入力欄
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {void}
     */
    function writeSteppedValue(numberInput, value, valueOptions) {
        numberInput.text = formatSteppedValue(value, valueOptions);
        numberInput.lastValidText = numberInput.text;
    }

    /**
     * 値を整数化・下限・上限でそろえ、丸めて単位を付けた表示用の文字列にする。
     * 整数化してから下限で止めるので、「整数・下限1」の欄に 0.4 が入っても 1 になる
     * @param {number} value - 数値
     * @param {Object} valueOptions - integer / min / max / unit（どれも省略可）
     * @returns {string} 入力欄に入れる文字列（例 "20 mm"）
     */
    function formatSteppedValue(value, valueOptions) {
        if (valueOptions.integer) value = Math.round(value);
        return formatStepperNumber(clampSteppedValue(value, valueOptions)) + (valueOptions.unit || "");
    }

    /**
     * 小数第2位で丸めた数値を文字列で返す
     * @param {number} value - 数値
     * @returns {string} 表示用の数値文字列
     */
    function formatStepperNumber(value) {
        return String(Math.round(value * 100) / 100);
    }

    // -----------------------------------------
    // ∧∨ボタンの描画 / Drawing
    // -----------------------------------------
    /**
     * 山形（∧／∨）の極小ボタンを作成する。
     * 上下2つを隙間なく積んで1つの枠に見えるよう、枠線は外側の辺だけ描き（上ボタンは上側、下ボタンは下側）、
     * 継ぎ目に線は引かない
     * @param {Group|Panel} parent - 追加先
     * @param {string} direction - "up" または "down"
     * @param {Function} onClickFn - クリック時の処理
     * @returns {Group} ボタンとして使う group
     */
    function makeStepperChevronButton(parent, direction, onClickFn) {
        var buttonWidth = STEPPER_BUTTON_WIDTH;
        var buttonHeight = STEPPER_BUTTON_HEIGHT;
        var isUp = (direction === "up");
        var chevronBox = parent.add("group");
        chevronBox.margins = 0;
        chevronBox.spacing = 0;
        chevronBox.preferredSize = [buttonWidth, buttonHeight];
        chevronBox.minimumSize = [buttonWidth, buttonHeight];
        chevronBox.maximumSize = [buttonWidth, buttonHeight];
        chevronBox.isPressed = false;
        chevronBox.isStepperButton = true; /* redrawSteppersIn() の目印 / marker for redrawSteppersIn() */

        chevronBox.onDraw = function () {
            var boxGraphics = chevronBox.graphics;
            /* 自作描画は自動でディムにならないため、無効なら薄い色で描く。親の無効化は子の enabled に出ないので親も見る
               Custom drawing is not dimmed automatically; the parent's state does not reach the child's enabled */
            var isDimmed = !isStepperEnabledInTree(chevronBox);

            /* 枠線の内側の地（押下中は押下色） / background inside the frame, pressed color while pressed */
            var fillColor = isDimmed ? STEPPER_DIM_FILL_COLOR : (chevronBox.isPressed ? STEPPER_PRESSED_COLOR : STEPPER_FILL_COLOR);
            boxGraphics.newPath();
            boxGraphics.rectPath(1, isUp ? 1 : 0, buttonWidth - 2, buttonHeight - 1);
            boxGraphics.fillPath(boxGraphics.newBrush(boxGraphics.BrushType.SOLID_COLOR, fillColor));

            drawStepperFrame(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_FRAME_COLOR : STEPPER_FRAME_COLOR);
            drawStepperChevron(boxGraphics, buttonWidth, buttonHeight, isUp, isDimmed ? STEPPER_DIM_CHEVRON_COLOR : STEPPER_CHEVRON_COLOR);
        };

        /**
         * 押下状態を変えて描き直す
         * @param {boolean} isPressed - 押下中なら true
         * @returns {void}
         */
        function repaint(isPressed) {
            if (chevronBox.isPressed === isPressed) return;
            chevronBox.isPressed = isPressed;
            redrawStepperGroup(chevronBox);
        }
        chevronBox.addEventListener("mousedown", function () {
            if (!isStepperEnabledInTree(chevronBox)) return;
            repaint(true);
            if (onClickFn) onClickFn();
        });
        chevronBox.addEventListener("mouseup", function () { repaint(false); });
        /* 押したまま外へ出たときも押下色を残さない / reset when the pointer leaves while pressed */
        chevronBox.addEventListener("mouseout", function () { repaint(false); });
        return chevronBox;
    }

    /**
     * 外側の辺だけの枠を描く（角は丸める）。継ぎ目側は開けておき、上下2つで1つの枠に見せる。
     * ScriptUI は円弧を描けないため、角丸は短い線分で近似する
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - 上のボタンなら true（上側に枠を描く）
     * @param {number[]} frameColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperFrame(boxGraphics, boxWidth, boxHeight, isUp, frameColor) {
        var frameLeft = 0.5;
        var frameRight = boxWidth - 0.5;
        var outerY = isUp ? 0.5 : boxHeight - 0.5;
        var seamY = isUp ? boxHeight : 0;
        var towardSeam = isUp ? 1 : -1; /* 外側の辺から継ぎ目へ向かう向き / direction from the outer edge to the seam */
        var radius = STEPPER_CORNER_RADIUS;
        var arcSteps = 4; /* 角丸1つを何本の線分で近似するか / segments per corner */
        var angle, k;

        boxGraphics.newPath();
        boxGraphics.moveTo(frameLeft, seamY);
        /* 左の角丸 / left corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameLeft + radius - radius * Math.cos(angle), outerY + towardSeam * (radius - radius * Math.sin(angle)));
        }
        /* 右の角丸 / right corner */
        for (k = 0; k <= arcSteps; k++) {
            angle = (Math.PI / 2) * k / arcSteps;
            boxGraphics.lineTo(frameRight - radius + radius * Math.sin(angle), outerY + towardSeam * (radius - radius * Math.cos(angle)));
        }
        boxGraphics.lineTo(frameRight, seamY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, frameColor, 1));
    }

    /**
     * 山形（∧／∨）を描く。文字グリフの▲▼は上下で大きさやベースラインが揃わないため、線で描く
     * @param {ScriptUIGraphics} boxGraphics - 描画先
     * @param {number} boxWidth - ボタンの幅
     * @param {number} boxHeight - ボタンの高さ
     * @param {boolean} isUp - ∧なら true、∨なら false
     * @param {number[]} chevronColor - [r, g, b, a]
     * @returns {void}
     */
    function drawStepperChevron(boxGraphics, boxWidth, boxHeight, isUp, chevronColor) {
        var centerX = boxWidth / 2;
        var centerY = isUp ? boxHeight / 2 + 0.5 : boxHeight / 2 - 0.5; /* 継ぎ目から少し離す / nudged away from the seam */
        var halfWidth = 3.6; /* 山形の半幅（高さ1.8に対して開き約127°） / half width of the chevron */
        var tipOffsetY = isUp ? -1.8 : 1.8; /* 頂点の中心からのずれ（上向きは上、下向きは下） */
        boxGraphics.newPath();
        boxGraphics.moveTo(centerX - halfWidth, centerY - tipOffsetY);
        boxGraphics.lineTo(centerX, centerY + tipOffsetY);
        boxGraphics.lineTo(centerX + halfWidth, centerY - tipOffsetY);
        boxGraphics.strokePath(boxGraphics.newPen(boxGraphics.PenType.SOLID_COLOR, chevronColor, 1.2));
    }

    /**
     * コントロールと、その親をたどってすべて有効かを返す（親の無効化は子の enabled に出ない）
     * @param {Object} control - 対象のコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isStepperEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * コンテナ以下にある∧∨ボタンをすべて描き直す。行やパネルの enabled を切り替えたあとに呼ぶ
     * @param {Object} container - 行・グループ・パネルなど
     * @returns {void}
     */
    function redrawSteppersIn(container) {
        if (!container.children) return;
        for (var i = 0; i < container.children.length; i++) {
            var child = container.children[i];
            if (child.isStepperButton) redrawStepperGroup(child);
            else redrawSteppersIn(child);
        }
    }

    /**
     * group の onDraw を呼び直す。group には notify() が無いため、隠して再表示して描き直させる
     * @param {Group} targetGroup - 描き直す group
     * @returns {void}
     */
    function redrawStepperGroup(targetGroup) {
        targetGroup.hide();
        targetGroup.show();
    }

    // ステップボタン（再利用パーツ）ここまで / End of the reusable stepper

    // アイコンのボタン（再利用パーツ） / Icon buttons (reusable)

    var ICON_BUTTON_SIZE = [24, 22]; /* 既定の大きさ / default size */
    var ICON_BUTTON_UI_DARK = isDarkUI();
    var ICON_BUTTON_COLOR     = ICON_BUTTON_UI_DARK ? [1, 1, 1, 1]    : [0, 0, 0, 0.70]; /* 絵の色 / icon color */
    var ICON_BUTTON_DIM_COLOR = ICON_BUTTON_UI_DARK ? [1, 1, 1, 0.20] : [0, 0, 0, 0.25]; /* 無効時の色 / color when disabled */

    /**
     * onDraw で絵を描くアイコンのボタンを追加する。押すと onClick を呼ぶ（無効の間は押せず、薄く描く）
     * @param {Group} parent - 追加先
     * @param {number[]} iconSize - [幅, 高さ]
     * @param {Function} drawIcon - 絵を描く関数 (iconGraphics, iconWidth, iconHeight, iconColor)
     * @returns {Group} アイコン
     */
    function addIconButton(parent, iconSize, drawIcon) {
        var iconButton = parent.add("group");
        iconButton.preferredSize = iconSize;
        iconButton.minimumSize = iconSize;
        iconButton.maximumSize = iconSize;
        iconButton.onDraw = function () {
            var iconColor = isIconButtonEnabledInTree(iconButton) ? ICON_BUTTON_COLOR : ICON_BUTTON_DIM_COLOR;
            drawIcon(iconButton.graphics, iconSize[0], iconSize[1], iconColor);
        };
        iconButton.addEventListener("mousedown", function () {
            if (!isIconButtonEnabledInTree(iconButton)) return;
            if (typeof iconButton.onClick === "function") iconButton.onClick();
        });
        return iconButton;
    }

    /**
     * アイコンのボタンの有効／無効を切り替えて描き直す（変わらないときは描き直さない）
     * @param {Group} iconButton - addIconButton() で作ったアイコン
     * @param {boolean} isEnabled - 有効にするなら true
     * @returns {void}
     */
    function setIconButtonEnabled(iconButton, isEnabled) {
        if (iconButton.enabled === isEnabled) return;
        iconButton.enabled = isEnabled;
        /* group には notify() が無いため、隠して再表示して描き直させる / groups have no notify(), so hide and show to repaint */
        iconButton.hide();
        iconButton.show();
    }

    /**
     * コントロールと親がすべて有効かを判定する（親の無効化は子の enabled に出ないため、親もたどる）
     * @param {Object} control - 判定するコントロール
     * @returns {boolean} すべて有効なら true
     */
    function isIconButtonEnabledInTree(control) {
        for (var node = control; node; node = node.parent) {
            if (!node.enabled) return false;
        }
        return true;
    }

    /**
     * 絵の座標の長方形の並びを、縦横比を保って中央に置いて塗る（ScriptUI は多角形を塗れないため、斜めも長方形の並びで描く）
     * @param {ScriptUIGraphics} iconGraphics - 描画先
     * @param {number} iconWidth - アイコンの幅
     * @param {number} iconHeight - アイコンの高さ
     * @param {number[]} designSize - 絵の [幅, 高さ]
     * @param {number[][]} designRects - 長方形 [左, 上, 右, 下] の並び
     * @param {number[]} iconColor - [r, g, b, a]
     * @returns {void}
     */
    function fillIconButtonRects(iconGraphics, iconWidth, iconHeight, designSize, designRects, iconColor) {
        var iconScale = Math.min(iconWidth / designSize[0], iconHeight / designSize[1]);
        var originX = (iconWidth - designSize[0] * iconScale) / 2;
        var originY = (iconHeight - designSize[1] * iconScale) / 2;
        iconGraphics.newPath();
        for (var i = 0; i < designRects.length; i++) {
            var designRect = designRects[i];
            if (designRect[2] <= designRect[0] || designRect[3] <= designRect[1]) continue;
            iconGraphics.rectPath(originX + designRect[0] * iconScale, originY + designRect[1] * iconScale,
                (designRect[2] - designRect[0]) * iconScale, (designRect[3] - designRect[1]) * iconScale);
        }
        iconGraphics.fillPath(iconGraphics.newBrush(iconGraphics.BrushType.SOLID_COLOR, iconColor));
    }

    /**
     * 保存アイコン（トレイに下向きの矢印）を描く。1223×993 の絵。
     * 矢じりとトレイの V 字の切り欠きは細い長方形を並べ、トレイの四角い穴は塗らずに残す
     * @param {ScriptUIGraphics} iconGraphics - 描画先
     * @param {number} iconWidth - アイコンの幅
     * @param {number} iconHeight - アイコンの高さ
     * @param {number[]} iconColor - [r, g, b, a]
     * @returns {void}
     */
    function drawSaveIcon(iconGraphics, iconWidth, iconHeight, iconColor) {
        var designWidth = 1223;
        var trayHole = [78, 688, 230, 840]; /* トレイの四角い穴 [左, 上, 右, 下] / the tray's square hole */
        var sliceCount = 16;
        var designRects = [[535, 0, 688, 383]]; /* 矢印の軸 / arrow shaft */
        var k;

        /** 穴と重なる部分を除いて長方形を足す / add a rectangle minus the tray hole */
        function addTrayRect(left, top, right, bottom) {
            if (right <= trayHole[0] || left >= trayHole[2] || bottom <= trayHole[1] || top >= trayHole[3]) {
                designRects.push([left, top, right, bottom]);
                return;
            }
            designRects.push([left, top, right, trayHole[1]], [left, trayHole[3], right, bottom],
                [left, Math.max(top, trayHole[1]), trayHole[0], Math.min(bottom, trayHole[3])],
                [trayHole[2], Math.max(top, trayHole[1]), right, Math.min(bottom, trayHole[3])]);
        }

        /* 下向きの矢じり（上の付け根から先端へ細っていく）/ the downward head */
        for (k = 0; k < sliceCount; k++) {
            var headHalf = 251 * (1 - (k + 0.5) / sliceCount);
            var headTop = 383 + (703 - 383) * k / sliceCount;
            designRects.push([612 - headHalf, headTop, 612 + headHalf, headTop + (703 - 383) / sliceCount]);
        }
        /* トレイ：上辺に V 字の切り欠き（幅 458 から下へ細り、856 で閉じる）/ tray with a V notch along the top */
        for (k = 0; k < sliceCount; k++) {
            var notchTop = 612 + (856 - 612) * k / sliceCount;
            var notchBottom = notchTop + (856 - 612) / sliceCount;
            var notchHalf = 229 * (1 - (k + 0.5) / sliceCount);
            addTrayRect(0, notchTop, 612 - notchHalf, notchBottom);
            addTrayRect(612 + notchHalf, notchTop, designWidth, notchBottom);
        }
        addTrayRect(0, 856, designWidth, 993);
        fillIconButtonRects(iconGraphics, iconWidth, iconHeight, [designWidth, 993], designRects, iconColor);
    }

    /**
     * 削除アイコン（ゴミ箱）を描く。756×825 の絵
     * @param {ScriptUIGraphics} iconGraphics - 描画先
     * @param {number} iconWidth - アイコンの幅
     * @param {number} iconHeight - アイコンの高さ
     * @param {number[]} iconColor - [r, g, b, a]
     * @returns {void}
     */
    function drawTrashIcon(iconGraphics, iconWidth, iconHeight, iconColor) {
        fillIconButtonRects(iconGraphics, iconWidth, iconHeight, [756, 825], [
            [206, 0, 550, 70], [206, 70, 275, 137], [481, 70, 550, 137],     /* 取っ手 / handle */
            [0, 137, 756, 207],                                               /* ふた / lid */
            [69, 207, 138, 825], [618, 207, 688, 825], [138, 756, 618, 825], /* 本体 / body */
            [206, 275, 275, 687], [343, 275, 413, 687], [481, 275, 550, 687] /* 縦の線 / ribs */
        ], iconColor);
    }

    // アイコンのボタン（再利用パーツ）ここまで / End of the reusable icon buttons

    // =========================================
    // ローカライズ / Localization
    // =========================================

    // ローカライズ（再利用パーツ） / Localization (reusable)

    /**
     * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
     * @returns {string} "ja" または "en"
     */
    function getCurrentLang() {
        return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
    }

    var uiLang = getCurrentLang();

    /**
     * LABELS から今の UI 言語の文言を取り出す。
     * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
     * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
     * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
     */
    function getLabel(labelRef, placeholderValues) {
        var labelEntry = labelRef;
        if (typeof labelRef === "string") {
            var labelPathKeys = labelRef.split(".");
            labelEntry = LABELS;
            for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                labelEntry = labelEntry[labelPathKeys[i]];
            }
        }
        var labelString;
        if (typeof labelEntry === "string") labelString = labelEntry;
        else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
        else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
        else return (typeof labelRef === "string") ? labelRef : "";
        return fillLabelPlaceholders(String(labelString), placeholderValues);
    }

    /**
     * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {Object|Array} [placeholderValues] - getLabel と同じ
     * @returns {string} コロン付きの文言
     */
    function labelText(labelRef, placeholderValues) {
        return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
    }

    /**
     * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
     * @param {string|Object} labelRef - getLabel と同じ
     * @param {string|number} value - コロンのあとに続ける値
     * @returns {string} 項目名と値をつないだ文字列
     */
    function labelValueText(labelRef, value) {
        return labelText(labelRef) + " " + value;
    }

    /**
     * 文言の {name} や %1 に値を差し込む
     * @param {string} labelString - 文言
     * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
     * @returns {string} 差し込んだ文言
     */
    function fillLabelPlaceholders(labelString, placeholderValues) {
        if (placeholderValues == null) return labelString;
        if (placeholderValues instanceof Array) {
            /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
            for (var i = placeholderValues.length; i >= 1; i--) {
                labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
            }
            return labelString;
        }
        for (var placeholderKey in placeholderValues) {
            if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
            labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
        }
        return labelString;
    }

    // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

    var LABELS = {
        dialog: {
            title: { ja: "縦組みの整形", en: "Vertical Text Formatter" }
        },
        /* 確認用の色分けで作るスウォッチの名前 / Names of the swatches made for check coloring */
        swatch: {
            fullWidth: { ja: "確認用_全角", en: "Check_FullWidth" },
            halfWidth: { ja: "確認用_半角", en: "Check_HalfWidth" },
            glyphWidth: { ja: "確認用_等幅字形", en: "Check_FixedWidthGlyph" }
        },
        wizard: {
            rotate: {
                label: { ja: "英単語を回転して立てる", en: "Rotate Roman text upright" },
                tip: { ja: "欧文回転をかけて英字を立てます（5文字以上の欧文は回転せず横倒しのまま）", en: "Rotates Roman characters upright (runs of 5 or more characters stay sideways)" }
            },
            uprightWords: {
                label: { ja: "短い英単語と1文字の英字を正立させる", en: "Stand short words and single letters upright" },
                tip: { ja: "4文字以下の英単語と1文字の英字を全角にします（OK → ＯＫ）。［英単語を回転して立てる］と両方オンのときは、こちらが優先", en: "Makes words of 4 or fewer letters and single letters full-width (OK → ＯＫ); takes priority over Rotate Roman text upright" }
            },
            tcyNumbers: {
                label: { ja: "2〜3桁の数字を縦中横にする", en: "Tate-Chu-Yoko for 2–3 digit numbers" },
                tip: { ja: "2・3桁の数字を縦中横にし、字数に合わせた等幅字形にします（桁区切り・小数点の隣は除く）。漢数字にするときは使えません", en: "Tate-Chu-Yoko for 2 and 3 digit numbers with fixed-width forms by length (not next to separators); unavailable with kanji numerals" }
            },
            fullwidthDigits: {
                label: { ja: "縦中横にしない数字を全角で正立させる", en: "Stand other digits upright in full-width" },
                tip: { ja: "縦中横にしない数字（1桁・4桁以上・桁区切りの隣など）を全角にします。漢数字にするときは使えません", en: "Makes digits not in Tate-Chu-Yoko full-width (single digits, 4+ digits, next to separators); unavailable with kanji numerals" }
            },
            kanji: {
                label: { ja: "数字を漢数字にする", en: "Convert numbers to kanji" },
                tip: { ja: "すべての桁の数字を漢数字にします（書き方は詳細モードの設定）", en: "Converts numbers of any length to kanji numerals (style from the Detailed mode)" }
            },
            era: {
                label: { ja: "西暦を和暦にする", en: "Western years to Japanese eras" },
                tip: { ja: "「2026年」を「令和8年」にします", en: "Turns 2026年 into 令和8年" }
            },
            tcyOthers: {
                label: { ja: "略称と「!?」を縦中横にする", en: "Tate-Chu-Yoko for abbreviations and !?" },
                tip: { ja: "大文字2〜3字（NHK など）と「!?」「!!」を縦中横にします", en: "Tate-Chu-Yoko for 2–3 capitals (NHK etc.) and !? !!" }
            },
            units: {
                label: { ja: "単位を組文字にする", en: "Turn units into squares" },
                tip: { ja: "数字の直後の cm・kg・ml などを ㌢・㌕・㍉㍑ などにします", en: "Turns cm, kg, ml etc. after digits into ㌢ ㌕ ㍉㍑ etc." }
            },
            marks: {
                label: { ja: "記号を縦組み用にする", en: "Use vertical-friendly marks" },
                tip: { ja: "桁区切りを「、」、小数点を「・」、範囲を「〜」にし、記号・「!?」を全角、引用符を〝〟、番号のハイフンを「‐」にします", en: "Separators to 、, decimal points to ・, ranges to 〜, symbols and !? full-width, quotes to 〝〟, number hyphens to ‐" }
            },
            paragraph: {
                label: { ja: "段落を縦組み用に整える", en: "Set up paragraphs for vertical text" },
                tip: { ja: "弱い禁則・行末約物半角・行送り175%にし、全角英数字にプロポーショナルメトリクスをかけます", en: "Soft kinsoku, half-width line-end punctuation, 175% leading, proportional metrics for full-width alphanumerics" }
            },
            fitFrame: {
                label: { ja: "テキストフレームを文字に合わせる", en: "Fit text frames to the text" },
                tip: { ja: "処理のあと、テキストフレームを自動サイズ調整（幅のみ）にします（連結したテキストは除く）", en: "Turns on Auto-Sizing (width only) for text frames after processing (not threaded text)" }
            },
            colorCheck: {
                label: { ja: "処理のあとに色分けして確かめる", en: "Color characters afterwards to check" },
                tip: { ja: "全角を赤、半角を青、等幅字形を緑で塗ります（元の色には戻りません）", en: "Colors full-width red, half-width blue and fixed-width glyphs green (the original colors are not restored)" }
            }
        },
        panel: {
            wizard: { ja: "やりたいこと", en: "What to do" },
            rotateTcy: { ja: "欧文回転・縦中横", en: "Rotation and Tate-Chu-Yoko" },
            replace: { ja: "文字の変換", en: "Character Conversion" },
            numbers: { ja: "数字", en: "Numbers" },
            paragraph: { ja: "文字・段落", en: "Character and Paragraph" },
            colorCheck: { ja: "確認用の色分け", en: "Check Coloring" },
            preview: { ja: "変換の確認", en: "Conversion Check" }
        },
        checkbox: {
            rotateRoman: { ja: "縦組み中の欧文回転", en: "Rotate Roman characters" },
            rotateSkipLongLatin: { ja: "", en: "Skip Roman text of" },   /* 日本語は数値欄のあとの文言で読ませる / Japanese reads from the text after the field */
            shortWordFullwidth: { ja: "", en: "Full-width for words of" },   /* 日本語は数値欄のあとの文言で読ませる / Japanese reads from the text after the field */
            tcyNumbers: { ja: "数字を縦中横", en: "TCY numbers" },
            tcyDigits2: { ja: "2桁", en: "2 digits" },
            tcyDigits3: { ja: "3桁", en: "3 digits" },
            tcyDigits4: { ja: "4桁", en: "4 digits" },
            tcyGlyphByLength: { ja: "字数に合わせた等幅字形", en: "Fixed-width forms by length" },
            colorCheck: { ja: "処理のあとに文字を色分けする", en: "Color characters after processing" },
            areaAutoSize: { ja: "フレームを自動サイズ調整", en: "Auto-size frames" },
            areaHeightToSize: { ja: "高さを文字サイズの整数倍に", en: "Height to a multiple of the type size" },
            tcyExcludeAdjacent: { ja: "桁区切り・小数点の隣は除く", en: "Skip numbers next to separators" },
            tcyCapitals: { ja: "大文字の英字（2〜3字）を縦中横", en: "TCY 2–3 capitals" },
            tcyExclamation: { ja: "「!!」「!?」を縦中横", en: "TCY \"!!\" and \"!?\"" },
            halfwidthAlnum: { ja: "全角英数字を半角に", en: "Full-width alnum to half-width" },
            periodToNakaguro: { ja: "小数点「.」→「・」", en: "Decimal \".\" → \"・\"" },
            symbolsFullwidth: { ja: "記号を全角に", en: "Symbols to full-width" },
            quotesToChonchon: { ja: "引用符を〝〟に", en: "Quotes to 〝〟" },
            rangeToWave: { ja: "範囲の「-」「~」→「〜」", en: "Range \"-\" \"~\" → \"〜\"" },
            exclamFullwidth: { ja: "「!」「?」を全角に", en: "\"!\" \"?\" to full-width" },
            singleLetterFullwidth: { ja: "1文字の英字を全角に", en: "Single letters to full-width" },
            shortCapsFullwidth: { ja: "3文字以内の大文字の英単語を全角に", en: "Capitals of up to 3 letters to full-width" },
            proportionalFullwidthLatin: { ja: "全角英数字にプロポーショナルメトリクス", en: "Proportional metrics for full-width alphanumerics" },
            ichiNoTightening: { ja: "「一」を詰めない", en: "Do not tighten 一" },
            singleDigitFullwidth: { ja: "1桁の数字を全角に", en: "Single digits to full-width" },
            longDigitsFullwidth: { ja: "3桁以上の数字を全角に", en: "Numbers of 3+ digits to full-width" },
            nonTcyDigitsFullwidth: { ja: "縦中横以外の数字を全角に", en: "Non-TCY digits to full-width" },
            japaneseEra: { ja: "西暦を和暦に", en: "Western years to Japanese era" },
            kanjiToArabic: { ja: "漢数字を算用数字にそろえる", en: "Kanji numerals to Arabic digits" },
            kanjiZeroRei: { ja: "0を「零」に", en: "0 as 零" },
            kanjiIchiSen: { ja: "千を「一千」に", en: "千 as 一千" },
            unitsKumimoji: { ja: "単位を組文字に（cm → ㌢）", en: "Units to squares (cm → ㌢)" },
            kanji: { ja: "漢数字に変換", en: "Convert to kanji numerals" }
        },
        glyphShort: {
            half: { ja: "半角", en: "half" },
            third: { ja: "三分", en: "third" },
            quarter: { ja: "四分", en: "quarter" }
        },
        dropdown: {
            none: { ja: "なし", en: "None" },
            comma: [
                { ja: "「、」にする", en: "Use 、" },
                { ja: "取る", en: "Remove" },
                { ja: "そのまま", en: "Keep" }
            ],
            phoneHyphen: [
                { ja: "「‐」（ハイフン）", en: "‐ (hyphen)" },
                { ja: "「ー」（音引き）", en: "ー (long vowel mark)" },
                { ja: "そのまま", en: "Keep" }
            ]
        },
        radio: {
            modeSimple: { ja: "簡易", en: "Simple" },
            modeDetail: { ja: "詳細", en: "Detailed" },
            modeWizard: { ja: "ウィザード", en: "Wizard" },
            kanjiDigit: { ja: "二〇二六", en: "二〇二六" },
            kanjiPositional: { ja: "二千二十六", en: "二千二十六" },
            kanjiLargeUnits: { ja: "二万五〇〇〇", en: "二万五〇〇〇" }
        },
        fieldLabel: {
            digits: { ja: "桁数", en: "Digits" },
            rangeTo: { ja: "〜", en: "to" },
            rotateSkipSuffix: { ja: "文字以上の欧文は除く", en: "or more characters" },
            shortWordSuffix: { ja: "文字以下の英単語を全角に", en: "or fewer letters" },
            kinsoku: { ja: "禁則", en: "Kinsoku" },
            comma: { ja: "桁区切り", en: "Separators" },
            phoneHyphen: { ja: "番号のハイフン", en: "Number hyphens" },
            mojikumi: { ja: "文字組み", en: "Mojikumi" },
            leading: { ja: "行送り", en: "Leading" }
        },
        preview: {
            tcyMark: { ja: "［縦中横］", en: " [TCY]" },
            noRotateMark: { ja: "［回転なし］", en: " [not rotated]" },
            tcyGlyphMark: { ja: "［縦中横・{glyph}］", en: " [TCY, {glyph}]" },
            none: { ja: "（変換する文字はありません）", en: "(Nothing to convert)" }
        },
        button: {
            ok: { ja: "OK", en: "OK" },
            cancel: { ja: "キャンセル", en: "Cancel" },
            preview: { ja: "変換の確認...", en: "Conversion Check..." },
            close: { ja: "閉じる", en: "Close" }
        },
        preset: {
            label: { ja: "プリセット", en: "Preset" },
            placeholder: { ja: "---", en: "---" },
            name: { ja: "プリセット名", en: "Preset name" },
            saveTitle: { ja: "プリセットを保存", en: "Save Preset" },
            builtin: {
                standard: { ja: "標準", en: "Standard" },
                arabicTcy2: { ja: "算用数字・2桁だけ縦中横", en: "Arabic, TCY for 2 digits only" },
                arabicMagazine: { ja: "算用数字・2〜3桁縦中横（雑誌・広告）", en: "Arabic, TCY for 2–3 digits (magazines, ads)" },
                kanjiLargeUnits: { ja: "漢数字・万億兆（新聞・一般書）", en: "Kanji, 万・億・兆 only (newspapers, books)" },
                kanjiPositional: { ja: "漢数字・十百千（文芸）", en: "Kanji with 十・百・千 (literature)" },
                kanjiDigitTouten: { ja: "漢数字・1字ずつ＋読点", en: "Kanji digit by digit with 、" },
                rotateOnly: { ja: "欧文回転だけ", en: "Rotation only" }
            }
        },
        confirm: {
            presetOverwrite: { ja: "「{name}」を上書きしますか？", en: "Overwrite \"{name}\"?" },
            presetDelete: { ja: "「{name}」を削除しますか？", en: "Delete \"{name}\"?" }
        },
        progress: {
            title: { ja: "縦組みの整形", en: "Vertical Text Formatter" },
            rotate: { ja: "欧文回転を適用中...", en: "Rotating Roman characters..." },
            edit: { ja: "文字を変換中... {current}/{total}", en: "Converting text... {current}/{total}" },
            tcy: { ja: "縦中横を適用中... {current}/{total}", en: "Applying Tate-Chu-Yoko... {current}/{total}" }
        },
        alert: {
            noSelection: { ja: "テキストを選択してください。", en: "Select text first." },
            presetSaveFailed: { ja: "プリセットを保存できませんでした。", en: "Could not save the preset." },
            presetNameTaken: { ja: "組み込みのプリセットと同じ名前は使えません。", en: "That name is used by a built-in preset." },
            actionFailed: { ja: "縦組みの整形を適用できませんでした。", en: "Could not apply the vertical text settings." }
        },
        /* ステップボタン用（stepUp〜）と、項目の説明 / for the stepper (stepUp…) and option descriptions */
        tooltip: {
            leading: {
                ja: "行送りを、文字サイズに対する自動行送りの％で指定します（50〜500%）。行送りは常に「自動」になります",
                en: "Leading as an auto-leading percentage of the type size (50–500%)"
            },
            kinsoku: { ja: "段落の禁則処理セットを選びます（ドキュメントの禁則処理セット）", en: "Kinsoku set for the paragraphs (from the document)" },
            mojikumi: {
                ja: "段落の文字組みアキ量設定を選びます（行揃えは常に均等配置（最終行上揃え））",
                en: "Mojikumi set for the paragraphs (justification is always justified, last line top)"
            },
            modeSimple: {
                ja: "よく使う項目だけを表示して処理します。表示していない項目はオフにし、禁則・文字組みは変えません",
                en: "Shows and applies only the common options; hidden options are off and kinsoku / mojikumi stay unchanged"
            },
            modeDetail: { ja: "すべての項目を表示します", en: "Shows all options" },
            modeWizard: { ja: "やりたいことを選ぶだけで、詳細の項目をまとめて設定して処理します（詳細モードの設定は変わりません）。option キーを押しながらクリックすると、すべてオン（すべてオンのときは、クリックしたものだけオン）", en: "Choose what you want to do; the matching detailed options are set for you (the Detailed mode settings are kept). Option-click to turn all on (when all are on, only the clicked one stays on)" },
            preview: { ja: "今の設定で変わる箇所を、別のダイアログボックスで一覧にします", en: "Lists what the current settings change, in a separate dialog box" },
            preset: { ja: "組み込みのプリセットか、保存した設定を読み込みます。", en: "Loads a built-in preset or saved settings." },
            presetSave: { ja: "今の設定に名前を付けて保存します。", en: "Saves the current settings under a name." },
            presetDelete: { ja: "選んでいる保存したプリセットを削除します。", en: "Deletes the selected saved preset." },
            presetName: {
                ja: "保存する設定の名前です。同じ名前は上書きします。",
                en: "Name the settings are saved under. The same name is overwritten."
            },
            shortWordFullwidth: {
                ja: "指定した文字数以下の英単語（英字だけの並び）を全角にして正立させます（OK → ＯＫ）。文字数は［○文字以上の欧文は除く］の1つ下に連動します",
                en: "Makes words of at most this many letters full-width so they stand upright (OK → ＯＫ); linked to one below \"Skip Roman text of ... or more characters\""
            },
            rotateSkipLongLatin: {
                ja: "指定した文字数以上の欧文（スペースなどでつながった単語のまとまり）は回転せず、横倒しのままにします。［○文字以下の英単語を全角に］の文字数はこの1つ下に連動します",
                en: "Leaves Roman text of at least this many characters (words joined by spaces etc.) sideways"
            },
            tcyNumbers: { ja: "下で選んだ桁数の半角数字を縦中横にします", en: "Tate-Chu-Yoko for half-width numbers of the lengths checked below" },
            kanji: {
                ja: "桁数が範囲内の数字を漢数字にします。縦中横の桁数と重なるときは漢数字を優先します",
                en: "Converts numbers within the digit range to kanji numerals; this wins over Tate-Chu-Yoko"
            },
            tcyGlyphByLength: {
                ja: "縦中横の文字を、2字は等幅半角・3字は等幅三分・4字は等幅四分の字形にします",
                en: "Uses half-width forms for 2 characters, third-width for 3 and quarter-width for 4"
            },
            tcyExcludeAdjacent: {
                ja: "「3,000」の「000」や「12.5」の「12」を縦中横にしません",
                en: "Leaves \"000\" in \"3,000\" and \"12\" in \"12.5\" alone"
            },
            tcyCapitals: {
                ja: "「PDF」「OK」など、すべて大文字の2〜3字の英字を縦中横にします",
                en: "Tate-Chu-Yoko for all-capital words of 2–3 letters such as PDF"
            },
            tcyExclamation: {
                ja: "感嘆符・疑問符の2字の組を縦中横にします（全角は半角にそろえます）",
                en: "Tate-Chu-Yoko for pairs of ! and ? (full-width marks become half-width)"
            },
            halfwidthAlnum: {
                ja: "「２０」「ＰＤＦ」なども縦中横・欧文回転の対象にします",
                en: "Makes full-width digits and letters targets for Tate-Chu-Yoko and rotation"
            },
            areaHeightToSize: {
                ja: "テキストフレームの高さ（縦組みでは1行の長さ）を、文字サイズのいちばん近い整数倍にそろえます（フレーム内マージンは除いて測ります。回転したフレームは除く）。簡易モードでも常にかけます",
                en: "Sets the text frame height (the line length in vertical text) to the nearest whole multiple of the type size (inset excluded, rotated frames skipped); always applied, in Simple mode too"
            },
            areaAutoSize: {
                ja: "処理のあと、テキストフレーム設定の［自動サイズ調整］を「幅のみ」（右上基準）にし、枠を文字に合わせます（連結したテキストは対象外）",
                en: "After processing, sets Auto-Sizing in Text Frame Options to Width Only (top-right reference) so the frame fits the text (threaded text is skipped)"
            },
            colorCheck: {
                ja: "処理のあと、全角の英数字と「！？」を赤、半角を青、等幅字形の文字を緑、ほかを［黒］で塗ります（仕上がりの確認用。スウォッチを追加し、元の色には戻りません）",
                en: "After processing, colors full-width alphanumerics and ！？ red, half-width blue, fixed-width glyphs green and the rest in the base color (for checking; the original colors are not restored)"
            },
            comma: {
                ja: "桁区切りの「,」「，」の扱いです（「、」にする：3,000 → 3、000／取る：3,000 → 3000）",
                en: "How to handle thousands separators (Use 、: 3,000 → 3、000 / Remove: 3,000 → 3000)"
            },
            phoneHyphen: {
                ja: "電話番号・郵便番号（数字-数字-数字、3桁-4桁）のハイフンの扱いです。番号は範囲の「〜」・縦中横・漢数字の対象にしません",
                en: "Hyphens in phone and postal numbers; these numbers are never ranges, Tate-Chu-Yoko or kanji"
            },
            periodToNakaguro: { ja: "小数点の「.」「．」を「・」にします（12.5 → 12・5）", en: "Replaces decimal points \".\" \"．\" with \"・\"" },
            symbolsFullwidth: {
                ja: "半角の ( ) [ ] { } : ; / % & # @ * + = < > を全角にして正立させます",
                en: "Makes half-width ( ) [ ] { } : ; / % & # @ * + = < > full-width so they stand upright"
            },
            quotesToChonchon: { ja: "“ ” と \" \" をチョンチョン（〝 〟）にします", en: "Replaces “ ” and \" \" with 〝 〟" },
            rangeToWave: {
                ja: "数字の間の「-」「~」「－」「～」を「〜」にします（10-20 → 10〜20）",
                en: "Replaces - ~ between digits with 〜 (10-20 → 10〜20)"
            },
            exclamFullwidth: { ja: "縦中横にしない「!」「?」を全角にして正立させます", en: "Makes ! and ? that are not in Tate-Chu-Yoko full-width" },
            proportionalFullwidthLatin: {
                ja: "全角の英数字（Ａ〜Ｚ・ａ〜ｚ・０〜９）に OpenType 機能の［プロポーショナルメトリクス］を適用します（文字の書き換えのあと）",
                en: "Applies the OpenType Proportional Metrics feature to full-width letters and digits (after the rewriting)"
            },
            ichiNoTightening: {
                ja: "「一」のプロポーショナルメトリクスと文字ツメを外します（縦組みの「一」は字面が薄く、詰めると前後に寄って見えにくくなるため）。簡易モードでも常にかけます",
                en: "Removes proportional metrics and tsume from 一, whose face is so thin in vertical text that tightening makes it hard to see; always applied, in Simple mode too"
            },
            singleLetterFullwidth: {
                ja: "1字だけの英字（Aランクの A など）を全角にして正立させます",
                en: "Makes a lone letter (the A in Aランク) full-width"
            },
            singleDigitFullwidth: { ja: "1桁の数字を全角にして正立させます", en: "Makes single digits full-width so they stand upright" },
            longDigitsFullwidth: {
                ja: "縦中横にしない3桁以上の数字を全角にして正立させます（2026 → ２０２６）。桁区切り・小数点のある数は整数部の桁数で数えます。電話番号は除く",
                en: "Makes numbers of three or more digits that are not in Tate-Chu-Yoko full-width (2026 → ２０２６); numbers with separators count their integer digits; phone numbers are left"
            },
            shortCapsFullwidth: {
                ja: "大文字だけの3文字以内の英単語を全角にして正立させます（PDF → ＰＤＦ、A → Ａ）。［大文字の英字（2〜3字）を縦中横］がオンなら縦中横を優先します",
                en: "Makes all-capital words of up to three letters full-width so they stand upright (PDF → ＰＤＦ); TCY for capitals takes priority when it is on"
            },
            nonTcyDigitsFullwidth: {
                ja: "縦中横にしない数字をすべて全角にして正立させます（桁区切り・小数点の隣や電話番号の数字も。漢数字にする数字は除く）",
                en: "Makes all digits not in Tate-Chu-Yoko full-width so they stand upright (including those next to separators and in phone numbers; not those made kanji)"
            },
            japaneseEra: {
                ja: "「2026年」を「令和8年」にします。月日があれば改元の前後を月日で判定します",
                en: "2026年 → 令和8年; a following month and day decide the era at a change"
            },
            kanjiToArabic: {
                ja: "混じった漢数字を算用数字にしてから縦中横・全角を決めます（2019年四月30日 → 2019年4月30日）。2字以上の漢数字と、月・日・時・分・秒の前の1字が対象（「一緒」「数十万」は変えません）。漢数字に変換するときは使えません",
                en: "Turns stray kanji numerals into digits before Tate-Chu-Yoko and full-width are decided (2019年四月30日 → 2019年4月30日). Covers runs of two or more and a single one before 月 日 時 分 秒 (一緒 and 数十万 stay); unavailable with kanji numerals"
            },
            kanjiZeroRei: { ja: "0を「〇」ではなく「零」にします（二〇二六 → 二零二六）", en: "Writes 0 as 零 instead of 〇" },
            kanjiIchiSen: { ja: "十・百・千を入れるとき、千を「一千」と書きます（1500 → 一千五百）", en: "Writes 1000 as 一千 when using 十・百・千" },
            unitsKumimoji: {
                ja: "数字の直後（間の半角スペースは詰める）の mm・cm・km・m・mg・g・kg・t・ml・dL・kL・L・cal・kcal・cc を ㍉・㌢・㌖・㍍・㍉㌘・㌘・㌕・㌧・㍉㍑・㌥㍑・㌔㍑・㍑・㌍・㌔㌍・㏄ に、m2・cm3・m² などを ㎡・㎤ にします。km/h・mmHg のように後ろに英字や「/」が続くものは変えません。字形の無いフォントもあります",
                en: "Turns units right after digits (a space between is removed), such as mm, cm, kg, ml, kcal and cc, into squares, and m2, cm3, m² into ㎡, ㎤. Units followed by letters or / (km/h, mmHg) are left. Some fonts lack these glyphs"
            },
            kanjiDigit: { ja: "1字ずつ漢数字にします（2026 → 二〇二六）", en: "Digit by digit (2026 → 二〇二六)" },
            kanjiPositional: { ja: "十・百・千を入れます（2000 → 二千）。直後が「年」の西暦は1字ずつ", en: "With 十・百・千 (2000 → 二千); years followed by 年 stay digit by digit" },
            kanjiLargeUnits: {
                ja: "万・億・兆だけを入れ、間は1字ずつ書きます（25000 → 二万五〇〇〇）。直後が「年」の西暦は1字ずつ",
                en: "Only 万・億・兆, digit by digit in between (25000 → 二万五〇〇〇); years followed by 年 stay digit by digit"
            },
            stepUp: {
                ja: "値を増やす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Increase (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepDown: {
                ja: "値を減らす（shift＋クリックで10の倍数へ、option＋クリックで0.1ずつ）",
                en: "Decrease (Shift-click to snap to 10s, Option-click by 0.1)"
            },
            stepUpInteger: { ja: "値を増やす（shift＋クリックで10の倍数へ）", en: "Increase (Shift-click to snap to 10s)" },
            stepDownInteger: { ja: "値を減らす（shift＋クリックで10の倍数へ）", en: "Decrease (Shift-click to snap to 10s)" }
        }
    };

    // 設定の保存（再利用パーツ） / Settings store (reusable)

    var SETTINGS_STORE_FOLDER_NAME = "indesign-scripts"; /* Folder.userData の下に作るフォルダー / folder created under Folder.userData */
    var SETTINGS_STORE_MAX_DEPTH = 32;                                /* 入れ子の上限（循環参照よけ）/ nesting limit (guards against cycles) */

    /**
     * 設定の保存先を作る。寿命は "session"（Illustrator の終了まで）か "persistent"（ファイルに保存）
     * @param {string} storeName - 保存名（ふつうは SCRIPT_NAME）。ファイル名と $.global のキーに使う
     * @param {string} lifetime - "session" または "persistent"
     * @param {Object} [storeOptions] - { legacy: function () → 旧形式の保存値のオブジェクト|null }
     * @returns {{load: Function, save: Function, clear: Function}} 読み込み・保存・消去の関数
     */
    function createSettingsStore(storeName, lifetime, storeOptions) {
        var isPersistent = (lifetime === "persistent");
        var legacyReader = (storeOptions && typeof storeOptions.legacy === "function") ? storeOptions.legacy : null;
        var safeStoreName = String(storeName).replace(/[\\\/:*?"<>|]/g, "_");
        var sessionKey = "__" + safeStoreName + "_Settings";
        var settingsFile = isPersistent
            ? new File(Folder.userData + "/" + SETTINGS_STORE_FOLDER_NAME + "/" + safeStoreName + ".json")
            : null;

        /**
         * 保存してある文字列を返す
         * @returns {string|null} 保存文字列。1度も保存していなければ null
         */
        function readStoredText() {
            if (!isPersistent) {
                return (typeof $.global[sessionKey] === "string") ? $.global[sessionKey] : null;
            }
            return settingsStoreReadTextFile(settingsFile);
        }

        /**
         * 文字列を保存する
         * @param {string} storedText - 保存する文字列
         * @returns {boolean} 保存できたら true
         */
        function writeStoredText(storedText) {
            if (!isPersistent) {
                $.global[sessionKey] = storedText;
                return true;
            }
            return settingsStoreWriteTextFile(settingsFile, storedText);
        }

        /**
         * 保存値を読み込み、既定値と突き合わせて返す（型の合わない値・知らない項目は捨てる）
         * @param {Object} defaultSettings - 既定値
         * @returns {Object} 設定（毎回新しいオブジェクト）
         */
        function load(defaultSettings) {
            var savedSettings = null;
            try {
                var storedText = readStoredText();
                if (storedText !== null) {
                    savedSettings = settingsStoreParse(storedText);
                } else if (legacyReader) {
                    savedSettings = legacyReader();
                }
            } catch (e) {
                $.writeln("SettingsStore.load(" + storeName + "): " + e);
                savedSettings = null;
            }
            return settingsStoreMerge(defaultSettings, savedSettings);
        }

        /**
         * 設定を保存する
         * @param {Object} settingValues - 保存する値
         * @returns {boolean} 保存できたら true
         */
        function save(settingValues) {
            try {
                return writeStoredText(settingsStoreSerialize(settingValues, "", 0));
            } catch (e) {
                $.writeln("SettingsStore.save(" + storeName + "): " + e);
                return false;
            }
        }

        /**
         * 保存を消す。旧形式を読み継ぐストアでは空の保存を書き、旧設定が戻らないようにする
         * @returns {boolean} 消せたら true
         */
        function clear() {
            if (legacyReader) return writeStoredText("{}");
            if (!isPersistent) {
                try { delete $.global[sessionKey]; } catch (e) { $.global[sessionKey] = undefined; }
                return true;
            }
            try {
                return settingsFile.exists ? settingsFile.remove() : true;
            } catch (e) {
                $.writeln("SettingsStore.clear(" + storeName + "): " + e);
                return false;
            }
        }

        return { load: load, save: save, clear: clear };
    }

    /**
     * 旧形式の設定ファイルを読む（key=value の行 / toSource / JSON を自動判別。eval は使わない）
     * @param {File|string} legacyFileOrPath - 旧ファイルかそのパス
     * @returns {Object|null} 読み込んだ値（key=value は値がすべて文字列）。無い・読めないときは null
     */
    function readSettingsLegacyFile(legacyFileOrPath) {
        try {
            var legacyFile = (legacyFileOrPath instanceof File) ? legacyFileOrPath : new File(legacyFileOrPath);
            var legacyText = settingsStoreReadTextFile(legacyFile);
            return (legacyText === null) ? null : settingsStoreParseLegacyText(legacyText);
        } catch (e) {
            $.writeln("readSettingsLegacyFile: " + e);
            return null;
        }
    }

    /**
     * app.preferences に文字列で保存していた旧設定を読む（形式は readSettingsLegacyFile と同じく自動判別）
     * @param {string} preferenceKey - 環境設定のキー
     * @returns {Object|null} 読み込んだ値。無い・読めないときは null
     */
    function readSettingsLegacyPreference(preferenceKey) {
        try {
            var legacyText = app.preferences.getStringPreference(preferenceKey);
            if (!legacyText) return null;
            return settingsStoreParseLegacyText(String(legacyText));
        } catch (e) {
            $.writeln("readSettingsLegacyPreference: " + e);
            return null;
        }
    }

    /**
     * テキストファイルを UTF-8 で読む
     * @param {File} textFile - 読むファイル
     * @returns {string|null} 中身。ファイルが無ければ null
     */
    function settingsStoreReadTextFile(textFile) {
        if (!textFile.exists) return null;
        textFile.encoding = "UTF-8";
        if (!textFile.open("r")) throw new Error("cannot open " + textFile.fsName);
        try {
            return textFile.read().replace(/^\uFEFF/, "");
        } finally {
            textFile.close();
        }
    }

    /**
     * テキストファイルを UTF-8 で書く（フォルダーが無ければ作る）
     * @param {File} textFile - 書くファイル
     * @param {string} fileText - 中身
     * @returns {boolean} 書けたら true
     */
    function settingsStoreWriteTextFile(textFile, fileText) {
        try {
            var parentFolder = textFile.parent;
            if (!parentFolder.exists && !parentFolder.create()) throw new Error("cannot create " + parentFolder.fsName);
            textFile.encoding = "UTF-8";
            textFile.lineFeed = "Unix";
            if (!textFile.open("w")) throw new Error("cannot open " + textFile.fsName);
            try {
                textFile.write(fileText);
            } finally {
                textFile.close();
            }
            return true;
        } catch (e) {
            $.writeln("SettingsStore write: " + e);
            return false;
        }
    }

    /**
     * 値が配列か
     * @param {*} checkedValue - 調べる値
     * @returns {boolean} 配列なら true
     */
    function settingsStoreIsArray(checkedValue) {
        return Object.prototype.toString.call(checkedValue) === "[object Array]";
    }

    /**
     * 値が素のオブジェクト（{ } で作ったもの）か
     * @param {*} checkedValue - 調べる値
     * @returns {boolean} 素のオブジェクトなら true
     */
    function settingsStoreIsPlainObject(checkedValue) {
        return checkedValue !== null && typeof checkedValue === "object"
            && Object.prototype.toString.call(checkedValue) === "[object Object]"
            && checkedValue.constructor === Object;
    }

    /**
     * 文字列を JSON の文字列リテラルにする（ASCII 以外は \uXXXX にして、文字コードの取り違えに強くする）
     * @param {string} sourceText - 文字列
     * @returns {string} 引用符つきの文字列
     */
    function settingsStoreQuote(sourceText) {
        var quotedText = "\"";
        for (var i = 0; i < sourceText.length; i++) {
            var charCode = sourceText.charCodeAt(i);
            var oneChar = sourceText.charAt(i);
            if (oneChar === "\"" || oneChar === "\\") quotedText += "\\" + oneChar;
            else if (oneChar === "\n") quotedText += "\\n";
            else if (oneChar === "\r") quotedText += "\\r";
            else if (oneChar === "\t") quotedText += "\\t";
            else if (charCode < 0x20 || charCode > 0x7E) quotedText += "\\u" + ("0000" + charCode.toString(16)).slice(-4);
            else quotedText += oneChar;
        }
        return quotedText + "\"";
    }

    /**
     * 値を JSON の文字列にする（オブジェクトは1項目1行、中身が値だけの配列は1行）。
     * undefined・関数・DOM オブジェクトは項目ごと省き、配列の中では null にする。有限でない数値は null
     * @param {*} sourceValue - 値
     * @param {string} indentText - 今の字下げ
     * @param {number} depth - 入れ子の深さ
     * @returns {string|undefined} JSON の文字列。書けない値は undefined
     */
    function settingsStoreSerialize(sourceValue, indentText, depth) {
        if (depth > SETTINGS_STORE_MAX_DEPTH) throw new Error("settings are nested too deeply");
        if (sourceValue === null) return "null";
        var valueType = typeof sourceValue;
        if (valueType === "boolean") return sourceValue ? "true" : "false";
        if (valueType === "number") return isFinite(sourceValue) ? String(sourceValue) : "null";
        if (valueType === "string") return settingsStoreQuote(sourceValue);
        var innerIndent = indentText + "  ";
        var itemTexts = [];
        var i;
        if (settingsStoreIsArray(sourceValue)) {
            var hasNested = false;
            for (i = 0; i < sourceValue.length; i++) {
                var itemText = settingsStoreSerialize(sourceValue[i], innerIndent, depth + 1);
                itemTexts.push(itemText === undefined ? "null" : itemText);
                if (sourceValue[i] !== null && typeof sourceValue[i] === "object") hasNested = true;
            }
            if (!itemTexts.length) return "[]";
            if (!hasNested) return "[" + itemTexts.join(", ") + "]";
            return "[\n" + innerIndent + itemTexts.join(",\n" + innerIndent) + "\n" + indentText + "]";
        }
        if (settingsStoreIsPlainObject(sourceValue)) {
            for (var key in sourceValue) {
                if (!sourceValue.hasOwnProperty(key)) continue;
                var memberText = settingsStoreSerialize(sourceValue[key], innerIndent, depth + 1);
                if (memberText !== undefined) itemTexts.push(settingsStoreQuote(key) + ": " + memberText);
            }
            if (!itemTexts.length) return "{}";
            return "{\n" + innerIndent + itemTexts.join(",\n" + innerIndent) + "\n" + indentText + "}";
        }
        return undefined; /* 関数・DOM オブジェクトなど / functions, DOM objects, etc. */
    }

    /**
     * JSON（と toSource の出力）を読む。eval は使わない。
     * キーの引用符なし・'…' の文字列・全体の ( ) ・末尾のカンマ・(void 0) も受け付ける
     * @param {string} sourceText - 読む文字列
     * @returns {*} 読み込んだ値
     */
    function settingsStoreParse(sourceText) {
        var readPos = 0;
        var textLength = sourceText.length;

        /**
         * 読み取り位置で失敗を知らせる
         * @param {string} reasonText - 理由
         * @returns {void}
         */
        function fail(reasonText) {
            throw new Error("settings parse error at " + readPos + ": " + reasonText);
        }

        /**
         * 空白を読み飛ばす
         * @returns {void}
         */
        function skipSpaces() {
            while (readPos < textLength && /\s/.test(sourceText.charAt(readPos))) readPos++;
        }

        /**
         * 識別子（英数字・_・$）を読む
         * @returns {string} 識別子。無ければ空文字
         */
        function readWord() {
            var startPos = readPos;
            while (readPos < textLength && /[\w$]/.test(sourceText.charAt(readPos))) readPos++;
            return sourceText.substring(startPos, readPos);
        }

        /**
         * 引用符で囲んだ文字列を読む（" と ' のどちらでも）
         * @returns {string} 文字列
         */
        function readString() {
            var quoteChar = sourceText.charAt(readPos++);
            var resultText = "";
            while (readPos < textLength) {
                var oneChar = sourceText.charAt(readPos++);
                if (oneChar === quoteChar) return resultText;
                if (oneChar !== "\\") { resultText += oneChar; continue; }
                var escapeChar = sourceText.charAt(readPos++);
                if (escapeChar === "n") resultText += "\n";
                else if (escapeChar === "r") resultText += "\r";
                else if (escapeChar === "t") resultText += "\t";
                else if (escapeChar === "b") resultText += "\b";
                else if (escapeChar === "f") resultText += "\f";
                else if (escapeChar === "v") resultText += "\v";
                else if (escapeChar === "0") resultText += "\0";
                else if (escapeChar === "u" || escapeChar === "x") {
                    var hexLength = (escapeChar === "u") ? 4 : 2;
                    var hexText = sourceText.substr(readPos, hexLength);
                    if (!new RegExp("^[0-9A-Fa-f]{" + hexLength + "}$").test(hexText)) fail("bad escape");
                    resultText += String.fromCharCode(parseInt(hexText, 16));
                    readPos += hexLength;
                } else resultText += escapeChar;
            }
            fail("unterminated string");
        }

        /**
         * 値を1つ読む
         * @param {number} depth - 入れ子の深さ
         * @returns {*} 値
         */
        function readValue(depth) {
            if (depth > SETTINGS_STORE_MAX_DEPTH) fail("nested too deeply");
            skipSpaces();
            var oneChar = sourceText.charAt(readPos);
            if (oneChar === "{") return readObject(depth);
            if (oneChar === "[") return readArray(depth);
            if (oneChar === "\"" || oneChar === "'") return readString();
            if (oneChar === "(") {
                readPos++;
                var innerValue = readValue(depth + 1);
                skipSpaces();
                if (sourceText.charAt(readPos) !== ")") fail("expected )");
                readPos++;
                return innerValue;
            }
            var numberMatch = /^-?(\d+\.?\d*|\.\d+)([eE][+\-]?\d+)?/.exec(sourceText.substring(readPos, readPos + 64));
            if (numberMatch) {
                readPos += numberMatch[0].length;
                return Number(numberMatch[0]);
            }
            var wordText = readWord();
            if (wordText === "true") return true;
            if (wordText === "false") return false;
            if (wordText === "null") return null;
            if (wordText === "NaN") return NaN;
            if (wordText === "Infinity") return Infinity;
            if (wordText === "void") { readValue(depth + 1); return undefined; } /* toSource の (void 0) */
            fail("unexpected " + (wordText || oneChar || "end of text"));
        }

        /**
         * 配列を読む
         * @param {number} depth - 入れ子の深さ
         * @returns {Array} 配列
         */
        function readArray(depth) {
            var resultArray = [];
            readPos++;
            skipSpaces();
            while (sourceText.charAt(readPos) !== "]") {
                resultArray.push(readValue(depth + 1));
                skipSpaces();
                if (sourceText.charAt(readPos) === ",") { readPos++; skipSpaces(); continue; }
                if (sourceText.charAt(readPos) !== "]") fail("expected , or ]");
            }
            readPos++;
            return resultArray;
        }

        /**
         * オブジェクトを読む（__proto__ のキーは捨てる）
         * @param {number} depth - 入れ子の深さ
         * @returns {Object} オブジェクト
         */
        function readObject(depth) {
            var resultObject = {};
            readPos++;
            skipSpaces();
            while (sourceText.charAt(readPos) !== "}") {
                var keyChar = sourceText.charAt(readPos);
                var memberKey = (keyChar === "\"" || keyChar === "'") ? readString() : readWord();
                if (memberKey === "") fail("expected a key");
                skipSpaces();
                if (sourceText.charAt(readPos) !== ":") fail("expected :");
                readPos++;
                var memberValue = readValue(depth + 1);
                if (memberKey !== "__proto__") resultObject[memberKey] = memberValue;
                skipSpaces();
                if (sourceText.charAt(readPos) === ",") { readPos++; skipSpaces(); continue; }
                if (sourceText.charAt(readPos) !== "}") fail("expected , or }");
            }
            readPos++;
            return resultObject;
        }

        var parsedValue = readValue(0);
        skipSpaces();
        if (readPos < textLength) fail("unexpected text after the value");
        return parsedValue;
    }

    /**
     * 旧形式の文字列を読む。{ [ ( で始まれば JSON / toSource、それ以外は key=value の行とみなす
     * @param {string} legacyText - 旧形式の文字列
     * @returns {Object|null} 読み込んだ値
     */
    function settingsStoreParseLegacyText(legacyText) {
        var trimmedText = legacyText.replace(/^\uFEFF/, "").replace(/^\s+|\s+$/g, "");
        if (trimmedText === "") return null;
        if (/^[\{\[\(]/.test(trimmedText)) return settingsStoreParse(trimmedText);
        var keyValues = {};
        var textLines = trimmedText.split(/\r\n|\r|\n/);
        for (var i = 0; i < textLines.length; i++) {
            var separatorIndex = textLines[i].indexOf("=");
            if (separatorIndex < 1) continue;
            var lineKey = textLines[i].substring(0, separatorIndex).replace(/^\s+|\s+$/g, "");
            if (lineKey !== "" && lineKey !== "__proto__") keyValues[lineKey] = textLines[i].substring(separatorIndex + 1);
        }
        return keyValues;
    }

    /**
     * 値を深くコピーする（素のデータだけ。関数・DOM オブジェクトは null）
     * @param {*} sourceValue - コピー元
     * @returns {*} コピー
     */
    function settingsStoreClone(sourceValue) {
        if (sourceValue === null || typeof sourceValue !== "object") {
            return (typeof sourceValue === "function" || sourceValue === undefined) ? null : sourceValue;
        }
        var i;
        if (settingsStoreIsArray(sourceValue)) {
            var arrayCopy = [];
            for (i = 0; i < sourceValue.length; i++) arrayCopy.push(settingsStoreClone(sourceValue[i]));
            return arrayCopy;
        }
        if (!settingsStoreIsPlainObject(sourceValue)) return null;
        var objectCopy = {};
        for (var key in sourceValue) {
            if (sourceValue.hasOwnProperty(key)) objectCopy[key] = settingsStoreClone(sourceValue[key]);
        }
        return objectCopy;
    }

    /**
     * 保存値を既定値と突き合わせる。型は既定値に合わせ、合わなければ既定値を使う。
     * 既定値が {} か null なら中身を問わず受け取り、配列は配列なら受け取る。既定値に無い項目は捨てる
     * @param {*} defaultValue - 既定値
     * @param {*} savedValue - 保存値
     * @returns {*} 突き合わせた値（新しいオブジェクト）
     */
    function settingsStoreMerge(defaultValue, savedValue) {
        if (defaultValue === null || defaultValue === undefined) {
            return (savedValue === undefined) ? null : settingsStoreClone(savedValue);
        }
        var defaultType = typeof defaultValue;
        var savedType = typeof savedValue;
        if (defaultType === "boolean") {
            if (savedType === "boolean") return savedValue;
            if (savedValue === 1 || savedValue === "1" || savedValue === "true") return true;
            if (savedValue === 0 || savedValue === "0" || savedValue === "false") return false;
            return defaultValue;
        }
        if (defaultType === "number") {
            if (savedType === "number" && isFinite(savedValue)) return savedValue;
            if (savedType === "string" && /\S/.test(savedValue)) {
                var parsedNumber = Number(savedValue);
                if (isFinite(parsedNumber)) return parsedNumber;
            }
            return defaultValue;
        }
        if (defaultType === "string") {
            if (savedType === "string") return savedValue;
            if (savedType === "number" && isFinite(savedValue)) return String(savedValue);
            if (savedType === "boolean") return String(savedValue);
            return defaultValue;
        }
        if (settingsStoreIsArray(defaultValue)) {
            return settingsStoreClone(settingsStoreIsArray(savedValue) ? savedValue : defaultValue);
        }
        if (defaultType === "object") {
            var savedIsObject = settingsStoreIsPlainObject(savedValue);
            var hasDefaultKeys = false;
            var mergedObject = {};
            for (var key in defaultValue) {
                if (!defaultValue.hasOwnProperty(key)) continue;
                hasDefaultKeys = true;
                mergedObject[key] = settingsStoreMerge(defaultValue[key], savedIsObject ? savedValue[key] : undefined);
            }
            /* 既定値が {} なら自由な入れ物として中身ごと受け取る / an empty default {} is a free-form map */
            if (!hasDefaultKeys && savedIsObject) return settingsStoreClone(savedValue);
            return mergedObject;
        }
        return defaultValue;
    }

    // 設定の保存（再利用パーツ）ここまで / End of the reusable settings store

    // =========================================
    // 変換の計画 / Conversion plan
    // =========================================
    var KANJI_DIGITS = ["〇", "一", "二", "三", "四", "五", "六", "七", "八", "九"];
    var KANJI_SMALL_UNITS = ["", "十", "百", "千"];
    var KANJI_LARGE_UNITS = ["", "万", "億", "兆", "京"];

    /**
     * 半角数字か
     * @param {string} currentChar - 1文字
     * @returns {boolean} 0〜9 なら true
     */
    function isDigitChar(currentChar) {
        return currentChar >= "0" && currentChar <= "9";
    }

    /**
     * 半角英字か
     * @param {string} currentChar - 1文字
     * @returns {boolean} A〜Z・a〜z なら true
     */
    function isLatinLetter(currentChar) {
        return (currentChar >= "A" && currentChar <= "Z") || (currentChar >= "a" && currentChar <= "z");
    }

    /**
     * 感嘆符・疑問符か（半角・全角）
     * @param {string} currentChar - 1文字
     * @returns {boolean} ! ? ！ ？ なら true
     */
    function isExclamOrQuestion(currentChar) {
        return currentChar === "!" || currentChar === "?" || currentChar === "！" || currentChar === "？";
    }

    /* ［単位を組文字に］の対応（数字の直後の英字だけ） / Units turned into katakana squares (only right after digits) */
    var UNIT_KUMIMOJI = {
        mm: "㍉", cm: "㌢", km: "㌖", m: "㍍",
        mg: "㍉㌘", g: "㌘", kg: "㌕", t: "㌧",
        ml: "㍉㍑", mL: "㍉㍑", dl: "㌥㍑", dL: "㌥㍑", kl: "㌔㍑", kL: "㌔㍑", l: "㍑", L: "㍑",
        cal: "㌍", kcal: "㌔㌍", cc: "㏄"
    };
    /* 面積・体積（m2・m²・cm3 など）の組文字 / Squares for area and volume (m2, m², cm3 ...) */
    var UNIT_POWER_KUMIMOJI = {
        mm2: "㎟", cm2: "㎠", m2: "㎡", km2: "㎢",
        mm3: "㎣", cm3: "㎤", m3: "㎥", km3: "㎦"
    };

    /**
     * その位置から始まる単位（全角の英字も可）を組文字にした文字列と、元の文字数を返す。
     * 2・3・²・³ が続けば面積・体積の組文字に。後ろに英字・数字・「/」が続くもの（km/h、mmHg、5m20）は単位とみなさない
     * @param {string} text - 対象の文字列
     * @param {number} startIndex - 単位の先頭の位置
     * @returns {{length: number, text: string}|null} 単位でなければ null
     */
    function matchUnitKumimoji(text, startIndex) {
        var letterEnd = startIndex;
        while (letterEnd < text.length && isAnyLatinLetter(text.charAt(letterEnd))) letterEnd++;
        if (letterEnd === startIndex) return null;
        var unitText = toHalfwidthAlnum(text.substring(startIndex, letterEnd));
        var powerText = toHalfwidthAlnum(text.charAt(letterEnd)).replace("²", "2").replace("³", "3");
        var squareText = null;
        var unitLength = letterEnd - startIndex;
        if ((powerText === "2" || powerText === "3") && UNIT_POWER_KUMIMOJI.hasOwnProperty(unitText + powerText)) {
            squareText = UNIT_POWER_KUMIMOJI[unitText + powerText];
            unitLength++;
        } else if (UNIT_KUMIMOJI.hasOwnProperty(unitText)) {
            squareText = UNIT_KUMIMOJI[unitText];
        }
        if (!squareText) return null;
        var nextChar = text.charAt(startIndex + unitLength);
        if (isAnyLatinLetter(nextChar) || isAnyDigitChar(nextChar) || nextChar === "/" || nextChar === "／") return null;
        return { length: unitLength, text: squareText };
    }

    /**
     * 数字と単位の間に入れてよいスペースか（半角・ノーブレーク・細いスペース類。全角スペースは除く）
     * @param {string} currentChar - 1文字
     * @returns {boolean} 該当すれば true
     */
    function isUnitGapSpace(currentChar) {
        return currentChar === " " || currentChar === "\u00A0" || (currentChar >= "\u2000" && currentChar <= "\u200A") || currentChar === "\u202F";
    }

    /* 欧文のまとまり：単語（英字で始まるか、数字のあとに英字が続くもの。. ' - を含む。全角の英数字も可）が、スペースまたは「&」（全角も可）でつながったもの。
       スペースは半角・全角のほか、ノーブレークスペースや細いスペースなども含める。
       ExtendScript の正規表現は、入れ子の量指定と選択を含むパターンを誤って評価する（Design Week の「Week」が外れる）ので、1文字ずつ走査する
       A Roman run: words (starting with a letter, or digits followed by a letter; may contain . ' -; full-width alphanumerics allowed) joined by spaces or & (full-width too).
       ExtendScript's regex engine mis-evaluates nested quantifiers with alternation (dropping "Week" from Design Week), so scan by hand */
    var LATIN_SPACES = "               　";
    var LATIN_AMPERSANDS = "&＆";

    /**
     * 半角・全角の英字か（欧文のまとまりの判定用。1語ずつの変換は半角の isLatinLetter だけを見る）
     * @param {string} currentChar - 1文字
     * @returns {boolean} A〜Z・a〜z・Ａ〜Ｚ・ａ〜ｚ なら true
     */
    function isAnyLatinLetter(currentChar) {
        return isLatinLetter(currentChar) || (currentChar >= "Ａ" && currentChar <= "Ｚ") || (currentChar >= "ａ" && currentChar <= "ｚ");
    }

    /**
     * 単語を構成する文字か（英数字と . ' -）
     * @param {string} currentChar - 1文字
     * @returns {boolean} 単語の文字なら true
     */
    function isLatinWordPart(currentChar) {
        return currentChar !== "" && (isAnyLatinLetter(currentChar) || isAnyDigitChar(currentChar) || ".'-".indexOf(currentChar) >= 0);
    }

    /**
     * 欧文のまとまりのつなぎに使うスペースか
     * @param {string} currentChar - 1文字
     * @returns {boolean} スペースなら true
     */
    function isLatinSpace(currentChar) {
        return currentChar !== "" && LATIN_SPACES.indexOf(currentChar) >= 0;
    }

    /**
     * その位置から始まる1語を読む。単語の途中・数字＋単位（5mm など。［単位を組文字に］の対象）は語として扱わない
     * @param {string} text - 対象の文字列
     * @param {number} startIndex - 調べる位置
     * @returns {{end: number, isSentenceEnd: boolean, isCapsTcy: boolean, isShortCaps: boolean}|null} 終わり（含まない）、文末のピリオドで終わるか、
     *     縦中横にする大文字（半角2〜3字）か、全角にする大文字（半角1〜3字）か。語でなければ null
     */
    function readLatinWord(text, startIndex) {
        var previousChar = text.charAt(startIndex - 1);
        if (startIndex > 0 && (isAnyLatinLetter(previousChar) || isAnyDigitChar(previousChar))) return null;
        var index = startIndex;
        while (index < text.length && isAnyDigitChar(text.charAt(index))) index++;
        var letterStart = index;
        if (!isAnyLatinLetter(text.charAt(letterStart))) return null;
        var wordEnd = letterStart + 1;
        while (wordEnd < text.length && isLatinWordPart(text.charAt(wordEnd))) wordEnd++;
        var wordText = text.substring(startIndex, wordEnd);
        /* 数字のあとが単位だけなら、数字と単位として扱う / Digits followed only by a unit stay a number and a unit */
        var unitMatch = (letterStart > startIndex) ? matchUnitKumimoji(text, letterStart) : null;
        if (unitMatch && letterStart + unitMatch.length === wordEnd) return null;
        /* 文末：4字以上の語がピリオドで終わる（Mr. や U.S. などの略語は除く） / Sentence end: a word of 4+ chars ending in a period (not Mr. or U.S.) */
        var coreText = wordText.replace(/\.+$/, "");
        var isSentenceEnd = coreText !== wordText && coreText.length >= 4 && coreText.indexOf(".") < 0;
        var isCapsTcy = /^[A-Z]{2,3}$/.test(wordText);
        var isShortCaps = /^[A-Z]{1,3}$/.test(wordText);
        return { end: wordEnd, isSentenceEnd: isSentenceEnd, isCapsTcy: isCapsTcy, isShortCaps: isShortCaps };
    }

    /**
     * その位置から始まる欧文のまとまりの終わりと語数を返す
     * ［大文字を縦中横に］がオンで、全部の語が縦中横にする大文字（NHK BS など）なら、最初の1語だけを返す。
     * ［3文字以内の大文字の英単語を全角に］がオンで、全部の語が3文字以内の大文字なら同じく最初の1語だけ
     * @param {string} text - 対象の文字列
     * @param {number} startIndex - 調べる位置（どこでもよい）
     * @param {Object} formatOptions - 変換の設定（tcyCapitals・shortCapsFullwidth を見る）
     * @returns {{end: number, wordCount: number}|null} 終わり（含まない）と語数。語で始まらなければ null
     */
    function scanLatinRun(text, startIndex, formatOptions) {
        var word = readLatinWord(text, startIndex);
        if (!word) return null;
        var firstWordEnd = word.end;
        var wordEnd = word.end;
        var wordCount = 1;
        var isAllCapsTcy = word.isCapsTcy;
        var isAllShortCaps = word.isShortCaps;
        while (true) {
            /* つなぎ：スペースの並び、または前後にスペースを挟んでよい「&」 / joiner: spaces, or & with optional spaces around it */
            var nextIndex = wordEnd;
            while (nextIndex < text.length && isLatinSpace(text.charAt(nextIndex))) nextIndex++;
            var joinerChar = text.charAt(nextIndex);
            if (joinerChar !== "" && LATIN_AMPERSANDS.indexOf(joinerChar) >= 0) {
                nextIndex++;
                while (nextIndex < text.length && isLatinSpace(text.charAt(nextIndex))) nextIndex++;
            }
            if (nextIndex === wordEnd) break;
            var nextWord = readLatinWord(text, nextIndex);
            if (!nextWord) break;
            /* 文末のピリオドのあと、大文字で始まる語は別の文 / After a sentence-ending period, a capitalized word starts a new sentence */
            var nextChar = text.charAt(nextIndex);
            if (word.isSentenceEnd && ((nextChar >= "A" && nextChar <= "Z") || (nextChar >= "Ａ" && nextChar <= "Ｚ"))) break;
            word = nextWord;
            wordEnd = word.end;
            wordCount++;
            if (!word.isCapsTcy) isAllCapsTcy = false;
            if (!word.isShortCaps) isAllShortCaps = false;
        }
        var splitsCaps = formatOptions && ((isAllCapsTcy && formatOptions.tcyCapitals) || (isAllShortCaps && formatOptions.shortCapsFullwidth));
        if (wordCount >= 2 && splitsCaps) return { end: firstWordEnd, wordCount: 1 };
        return { end: wordEnd, wordCount: wordCount };
    }

    var FULLWIDTH_SYMBOLS = "()[]{}:;/%&#@*+=<>";   /* ［記号を全角に］の対象 / symbols made full-width */
    var RANGE_MARKS = "-~－～";                      /* ［範囲の「-」「~」→「〜」］の対象 / range marks */

    /**
     * 半角の英数字・記号（! 〜 ~）を全角にする
     * @param {string} asciiText - 半角の文字列
     * @returns {string} 全角の文字列
     */
    function toFullwidthAscii(asciiText) {
        var resultText = "";
        for (var i = 0; i < asciiText.length; i++) {
            var charCode = asciiText.charCodeAt(i);
            resultText += (charCode >= 0x21 && charCode <= 0x7E) ? String.fromCharCode(charCode + 0xFEE0) : asciiText.charAt(i);
        }
        return resultText;
    }

    /**
     * 半角・全角の数字か
     * @param {string} currentChar - 1文字
     * @returns {boolean} 0〜9・０〜９ なら true
     */
    function isAnyDigitChar(currentChar) {
        return isDigitChar(currentChar) || (currentChar >= "０" && currentChar <= "９");
    }

    /**
     * 数字・英字・感嘆符以外の1文字を、記号・引用符・範囲の設定に合わせて置き換える
     * @param {string} text - 対象の文字列
     * @param {number} index - 文字の位置
     * @param {Object} formatOptions - 変換の設定
     * @param {Object} quoteState - 半角の「"」の開き・閉じを数える状態（{ isOpen }）
     * @returns {string} 置き換えた文字
     */
    function convertOtherChar(text, index, formatOptions, quoteState) {
        var currentChar = text.charAt(index);
        if (formatOptions.rangeToWave && RANGE_MARKS.indexOf(currentChar) >= 0 && isAnyDigitChar(text.charAt(index - 1)) && isAnyDigitChar(text.charAt(index + 1))) {
            return "〜";
        }
        if (formatOptions.quotesToChonchon) {
            if (currentChar === "“") return "〝";
            if (currentChar === "”") return "〟";
            if (currentChar === "\"") {
                /* 半角の「"」は開きと閉じを交互に / Straight quotes alternate between opening and closing */
                quoteState.isOpen = !quoteState.isOpen;
                return quoteState.isOpen ? "〝" : "〟";
            }
        }
        /* 英字の間の「/」（km/h、and/or）は欧文のまま / A slash between letters (km/h, and/or) stays half-width */
        if (currentChar === "/" && isAnyLatinLetter(text.charAt(index - 1)) && isAnyLatinLetter(text.charAt(index + 1))) return currentChar;
        if (formatOptions.symbolsFullwidth && FULLWIDTH_SYMBOLS.indexOf(currentChar) >= 0) return toFullwidthAscii(currentChar);
        return currentChar;
    }

    /**
     * その位置から始まる英単語の連続（スペースや「&」でつながった2語以上）を返す
     * @param {string} text - 対象の文字列
     * @param {number} startIndex - 調べる位置（どこでもよい。語で始まらなければ null）
     * @param {Object} formatOptions - 変換の設定
     * @returns {string|null} まとまりの文字列（語で始まらない・1語だけなら null）
     */
    function matchLatinPhrase(text, startIndex, formatOptions) {
        var latinRun = scanLatinRun(text, startIndex, formatOptions);
        return (latinRun && latinRun.wordCount >= 2) ? text.substring(startIndex, latinRun.end) : null;
    }

    /**
     * 全角にする短い英単語か（［1文字の英字を全角に］［○文字以下の英単語を全角に］）
     * @param {string} letterText - 英字だけの並び
     * @param {Object} formatOptions - 変換の設定
     * @returns {boolean} 全角にするなら true
     */
    function isShortWordForFullwidth(letterText, formatOptions) {
        if (formatOptions.singleLetterFullwidth && letterText.length === 1) return true;
        return formatOptions.shortWordFullwidth && letterText.length <= formatOptions.shortWordMaxChars;
    }

    /**
     * 全角の英数字を半角にする（1文字ずつ置き換えるので文字数は変わらない）
     * @param {string} text - 対象の文字列
     * @returns {string} 置き換えた文字列
     */
    function toHalfwidthAlnum(text) {
        var resultText = "";
        for (var i = 0; i < text.length; i++) {
            var charCode = text.charCodeAt(i);
            var isFullAlnum = (charCode >= 0xFF10 && charCode <= 0xFF19) || (charCode >= 0xFF21 && charCode <= 0xFF3A) || (charCode >= 0xFF41 && charCode <= 0xFF5A);
            resultText += isFullAlnum ? String.fromCharCode(charCode - 0xFEE0) : text.charAt(i);
        }
        return resultText;
    }

    /**
     * 数字1字の漢数字を返す（0 は設定で「〇」か「零」）
     * @param {number} digitValue - 0〜9
     * @param {Object} formatOptions - 変換の設定
     * @returns {string} 漢数字1字
     */
    function getKanjiDigit(digitValue, formatOptions) {
        return (digitValue === 0 && formatOptions.kanjiZeroRei) ? "零" : KANJI_DIGITS[digitValue];
    }

    /**
     * 数字を1字ずつ漢数字にする（2026 → 二〇二六）
     * @param {string} digitText - 半角数字の文字列
     * @param {Object} formatOptions - 変換の設定
     * @returns {string} 漢数字の文字列
     */
    function toKanjiDigitByDigit(digitText, formatOptions) {
        var resultText = "";
        for (var i = 0; i < digitText.length; i++) {
            resultText += getKanjiDigit(digitText.charCodeAt(i) - 48, formatOptions);
        }
        return resultText;
    }

    /**
     * 整数を十・百・千と万・億…を入れた漢数字にする（2026 → 二千二十六、10000 → 一万）
     * 十・百の前の「一」は省く。千の前は設定で「一千」にする。京の位を超える桁は1字ずつにする
     * @param {string} digitText - 半角数字の文字列
     * @param {Object} formatOptions - 変換の設定
     * @returns {string} 漢数字の文字列
     */
    function toKanjiPositional(digitText, formatOptions) {
        var trimmedText = digitText.replace(/^0+/, "");
        if (trimmedText === "") return getKanjiDigit(0, formatOptions);
        if (trimmedText.length > KANJI_LARGE_UNITS.length * 4) return toKanjiDigitByDigit(digitText, formatOptions);
        var resultText = "";
        var groupCount = Math.ceil(trimmedText.length / 4);
        for (var g = groupCount - 1; g >= 0; g--) {
            var groupEnd = trimmedText.length - g * 4;
            var groupText = trimmedText.substring(Math.max(0, groupEnd - 4), groupEnd);
            var groupKanji = "";
            for (var i = 0; i < groupText.length; i++) {
                var digitValue = groupText.charCodeAt(i) - 48;
                if (digitValue === 0) continue;
                var place = groupText.length - 1 - i;
                /* 十・百の前の「一」は書かない。千は設定次第（一千） / Omit "one" before ten and hundred; before thousand it depends on the setting */
                var omitsOne = (digitValue === 1 && place > 0 && !(place === 3 && formatOptions.kanjiIchiSen));
                if (!omitsOne) groupKanji += KANJI_DIGITS[digitValue];
                groupKanji += KANJI_SMALL_UNITS[place];
            }
            if (groupKanji !== "") resultText += groupKanji + KANJI_LARGE_UNITS[g];
        }
        return resultText;
    }

    /**
     * 整数を万・億・兆…の単位語だけ入れた漢数字にする（25000 → 二万五〇〇〇、123456789 → 一億二三四五万六七八九）
     * 単位語の間は1字ずつ書き、すべて0の4桁は単位語ごと省く
     * @param {string} digitText - 半角数字の文字列
     * @param {Object} formatOptions - 変換の設定
     * @returns {string} 漢数字の文字列
     */
    function toKanjiLargeUnits(digitText, formatOptions) {
        var trimmedText = digitText.replace(/^0+/, "");
        if (trimmedText === "") return getKanjiDigit(0, formatOptions);
        if (trimmedText.length > KANJI_LARGE_UNITS.length * 4) return toKanjiDigitByDigit(digitText, formatOptions);
        var resultText = "";
        var groupCount = Math.ceil(trimmedText.length / 4);
        for (var g = groupCount - 1; g >= 0; g--) {
            var groupEnd = trimmedText.length - g * 4;
            var groupText = trimmedText.substring(Math.max(0, groupEnd - 4), groupEnd);
            if (/^0+$/.test(groupText)) continue;
            resultText += toKanjiDigitByDigit(groupText, formatOptions) + KANJI_LARGE_UNITS[g];
        }
        return resultText;
    }

    /**
     * 文字列のその位置から数字のまとまり（桁区切り・小数を含む）を読む
     * @param {string} text - 対象の文字列
     * @param {number} startIndex - 数字で始まる位置
     * @returns {{length: number, parts: Array<{type: string, text: string}>, integerDigits: number, hasSeparator: boolean, hasComma: boolean, hasDecimal: boolean}}
     *   parts の type は "digits" / "separator"（, ，）/ "decimal"（. ．）
     */
    function readNumberToken(text, startIndex) {
        var parts = [];
        var i = startIndex;
        var integerDigits = 0;
        var hasSeparator = false;
        var hasComma = false;
        var hasDecimal = false;

        /**
         * その位置から続く数字を読み、parts に足す
         * @returns {number} 読んだ桁数
         */
        function readDigits() {
            var digitStart = i;
            while (i < text.length && isDigitChar(text.charAt(i))) i++;
            parts.push({ type: "digits", text: text.substring(digitStart, i) });
            return i - digitStart;
        }

        integerDigits += readDigits();
        /* 桁区切り：「,」「，」のあとにちょうど3桁 / Group separator: "," or "，" followed by exactly three digits */
        while ((text.charAt(i) === "," || text.charAt(i) === "，") && isDigitChar(text.charAt(i + 1)) && isDigitChar(text.charAt(i + 2)) &&
                isDigitChar(text.charAt(i + 3)) && !isDigitChar(text.charAt(i + 4))) {
            parts.push({ type: "separator", text: text.charAt(i) });
            i++;
            integerDigits += readDigits();
            hasSeparator = true;
            hasComma = true;
        }
        /* 小数点：「.」「．」のあとに数字 / Decimal point: "." or "．" followed by a digit */
        if ((text.charAt(i) === "." || text.charAt(i) === "．") && isDigitChar(text.charAt(i + 1))) {
            parts.push({ type: "decimal", text: text.charAt(i) });
            i++;
            readDigits();
            hasSeparator = true;
            hasDecimal = true;
        }
        return { length: i - startIndex, parts: parts, integerDigits: integerDigits, hasSeparator: hasSeparator, hasComma: hasComma, hasDecimal: hasDecimal };
    }

    /**
     * 桁区切り・小数点を設定に合わせて置き換える（置き換えないときは元の文字のまま）
     * @param {Object} part - readNumberToken の parts の要素（separator / decimal）
     * @param {Object} formatOptions - 変換の設定
     * @returns {string} 置き換えた文字
     */
    function convertNumberMark(part, formatOptions) {
        if (part.type === "separator") {
            if (formatOptions.commaStyle === "touten") return "、";
            if (formatOptions.commaStyle === "remove") return "";
            return part.text;
        }
        return formatOptions.periodToNakaguro ? "・" : part.text;
    }

    /**
     * 数字のまとまりを漢数字にする（小数部は書き方によらず1字ずつ）
     * @param {Object} numberToken - readNumberToken の戻り値
     * @param {Object} formatOptions - 変換の設定
     * @param {boolean} [forceDigitByDigit] - 書き方によらず1字ずつにする（西暦の年など）
     * @returns {string} 漢数字の文字列
     */
    function convertNumberToKanji(numberToken, formatOptions, forceDigitByDigit) {
        var parts = numberToken.parts;
        var resultText = "";
        if (!forceDigitByDigit && (formatOptions.kanjiStyle === "positional" || formatOptions.kanjiStyle === "largeUnits")) {
            /* 整数部は桁区切りを外して位取りで読む / Read the integer part positionally, without separators */
            var integerText = "";
            var partIndex = 0;
            while (partIndex < parts.length && parts[partIndex].type !== "decimal") {
                if (parts[partIndex].type === "digits") integerText += parts[partIndex].text;
                partIndex++;
            }
            resultText = (formatOptions.kanjiStyle === "positional") ? toKanjiPositional(integerText, formatOptions) : toKanjiLargeUnits(integerText, formatOptions);
            if (partIndex < parts.length) {
                resultText += convertNumberMark(parts[partIndex], formatOptions) + toKanjiDigitByDigit(parts[partIndex + 1].text, formatOptions);
            }
            return resultText;
        }
        for (var i = 0; i < parts.length; i++) {
            resultText += (parts[i].type === "digits") ? toKanjiDigitByDigit(parts[i].text, formatOptions) : convertNumberMark(parts[i], formatOptions);
        }
        return resultText;
    }

    /**
     * 縦中横にしない数字を全角にするか（［縦中横以外の数字を全角に］［1桁の数字を全角に］［3桁以上の数字を全角に］）
     * @param {number} digitCount - 並びの桁数
     * @param {number} numberDigitCount - 3桁以上の判定に使う桁数（桁区切り・小数点のある数は整数部の桁数）
     * @param {Object} formatOptions - 変換の設定
     * @returns {boolean} 全角にするなら true
     */
    function isFullwidthDigitCount(digitCount, numberDigitCount, formatOptions) {
        if (formatOptions.nonTcyDigitsFullwidth) return true;
        if (formatOptions.singleDigitFullwidth && digitCount === 1) return true;
        return formatOptions.longDigitsFullwidth && numberDigitCount >= 3;
    }

    /**
     * 数字だけの並び（1つの digits）を、縦中横・全角・そのままのどれかにして出力に足す
     * @param {string} digitText - 半角数字の文字列
     * @param {Object} formatOptions - 変換の設定
     * @param {function(string, boolean): void} emit - 出力に足す関数（文字列、縦中横にするか）
     * @param {number} [numberDigitCount] - 3桁以上の判定に使う桁数（桁区切りのある数の一部のときは数全体の整数部の桁数。省くと並びの桁数）
     * @returns {void}
     */
    function emitDigitRun(digitText, formatOptions, emit, numberDigitCount) {
        var digitCount = digitText.length;
        if (formatOptions.tcyNumbers && formatOptions["tcyDigits" + digitCount] === true) {
            emit(digitText, true);
        } else if (isFullwidthDigitCount(digitCount, numberDigitCount || digitCount, formatOptions)) {
            emit(toFullwidthAscii(digitText), false);
        } else {
            emit(digitText, false);
        }
    }

    /**
     * 数字だけの並びを、範囲内なら漢数字、そうでなければ縦中横・全角・そのままにして出力に足す
     * @param {string} digitText - 半角数字の文字列
     * @param {Object} formatOptions - 変換の設定
     * @param {function(string, boolean): void} emit - 出力に足す関数
     * @returns {void}
     */
    function emitPlainDigits(digitText, formatOptions, emit) {
        if (formatOptions.kanji && digitText.length >= formatOptions.kanjiMinDigits && digitText.length <= formatOptions.kanjiMaxDigits) {
            emit(convertNumberToKanji({ parts: [{ type: "digits", text: digitText }] }, formatOptions), false);
        } else {
            emitDigitRun(digitText, formatOptions, emit);
        }
    }

    /**
     * 数字のまとまり（桁区切り・小数を含む）を、漢数字・縦中横・全角・そのままのどれかにして出力に足す
     * @param {string} numberText - まとまりの文字列
     * @param {Object} numberToken - readNumberToken() の戻り値
     * @param {string} nextChar - まとまりの直後の文字
     * @param {Object} formatOptions - 変換の設定
     * @param {function(string, boolean): void} emit - 出力に足す関数
     * @returns {void}
     */
    function emitNumberToken(numberText, numberToken, nextChar, formatOptions, emit) {
        var isMergedComma = numberToken.hasComma && !numberToken.hasDecimal && formatOptions.commaStyle === "remove";
        if (formatOptions.kanji && numberToken.integerDigits >= formatOptions.kanjiMinDigits && numberToken.integerDigits <= formatOptions.kanjiMaxDigits) {
            /* 西暦の年（直後が「年」）は書き方によらず1字ずつ / A year (followed by 年) is always digit by digit */
            emit(convertNumberToKanji(numberToken, formatOptions, nextChar === "年"), false);
        } else if (!numberToken.hasSeparator || isMergedComma) {
            /* 桁区切りを取ったときは、つないだ数字を1つの数として扱う / With separators removed, the joined digits are one number */
            emitDigitRun(numberText.replace(/[,，]/g, ""), formatOptions, emit);
        } else if (formatOptions.tcyExcludeAdjacent) {
            /* 桁区切り・小数点の隣の数字は縦中横にしない（全角は［縦中横以外の数字を全角に］のときだけ）
               Numbers next to separators get no TCY (full-width only with "Non-TCY digits to full-width") */
            var isFullwidthNumber = formatOptions.nonTcyDigitsFullwidth || (formatOptions.longDigitsFullwidth && numberToken.integerDigits >= 3);
            for (var p = 0; p < numberToken.parts.length; p++) {
                var part = numberToken.parts[p];
                if (part.type !== "digits") emit(convertNumberMark(part, formatOptions), false);
                else emit(isFullwidthNumber ? toFullwidthAscii(part.text) : part.text, false);
            }
        } else {
            for (var q = 0; q < numberToken.parts.length; q++) {
                var numberPart = numberToken.parts[q];
                if (numberPart.type === "digits") emitDigitRun(numberPart.text, formatOptions, emit, numberToken.integerDigits);
                else emit(convertNumberMark(numberPart, formatOptions), false);
            }
        }
    }

    /* 元号と開始日（YYYYMMDD）。新しい順 / Japanese eras and their start dates (YYYYMMDD), newest first */
    var JAPANESE_ERAS = [
        { name: "令和", start: 20190501 },
        { name: "平成", start: 19890108 },
        { name: "昭和", start: 19261225 },
        { name: "大正", start: 19120730 },
        { name: "明治", start: 18681023 }
    ];

    /**
     * その位置の「西暦4桁＋年」を読み、元号と年を返す。月日が続けば改元の境目も月日で判定する
     * （月日が無い改元の年は新しい元号にする：2019年 → 令和元年）
     * @param {string} text - 対象の文字列
     * @param {number} startIndex - 数字で始まる位置
     * @returns {{eraName: string, eraYear: number}|null} 西暦の年でなければ null
     */
    function matchWesternYear(text, startIndex) {
        /* 入れ子の量指定の正規表現は ExtendScript で誤評価されるので、年・月・日を順に読む
           Nested quantified groups mis-evaluate in ExtendScript, so read year, month and day in turn */
        var yearMatch = /^(\d{4})年/.exec(text.substr(startIndex, 5));
        if (!yearMatch) return null;
        var year = parseInt(yearMatch[1], 10);
        var month = 12;
        var day = 31;
        var monthMatch = /^(\d{1,2})月/.exec(text.substr(startIndex + 5, 3));
        if (monthMatch) {
            month = parseInt(monthMatch[1], 10);
            var dayMatch = /^(\d{1,2})日/.exec(text.substr(startIndex + 5 + monthMatch[0].length, 3));
            if (dayMatch) day = parseInt(dayMatch[1], 10);
        }
        var dateKey = year * 10000 + month * 100 + day;
        for (var i = 0; i < JAPANESE_ERAS.length; i++) {
            if (dateKey >= JAPANESE_ERAS[i].start) {
                return { eraName: JAPANESE_ERAS[i].name, eraYear: year - Math.floor(JAPANESE_ERAS[i].start / 10000) + 1 };
            }
        }
        return null;
    }

    /* 番号のハイフンとみなす文字 / Characters treated as hyphens in phone and postal numbers */
    var PHONE_HYPHENS = "-－‐−";

    /**
     * その位置の電話番号・郵便番号（数字-数字-数字…、または 3桁-4桁）を読む
     * @param {string} text - 対象の文字列
     * @param {number} startIndex - 数字で始まる位置
     * @returns {string|null} 番号の文字列（番号でなければ null）
     */
    function matchPhoneNumber(text, startIndex) {
        var restText = text.substr(startIndex, 40);
        var phoneMatch = /^\d+(?:[-－‐−]\d+){2,}/.exec(restText) || /^\d{3}[-－‐−]\d{4}(?!\d)/.exec(restText);
        return phoneMatch ? phoneMatch[0] : null;
    }

    /**
     * 番号のハイフンを設定に合わせて置き換える
     * @param {string} phoneText - 番号の文字列
     * @param {Object} formatOptions - 変換の設定（phoneHyphenStyle）
     * @returns {string} 置き換えた文字列
     */
    function convertPhoneHyphens(phoneText, formatOptions) {
        if (formatOptions.phoneHyphenStyle === "keep") return phoneText;
        /* 縦組みで縦になる文字にする。全角の「－」（U+FF0D）は縦組み用の字形が無く横棒のまま
           Use characters that turn vertical; full-width － (U+FF0D) has no vertical form and stays horizontal */
        var hyphenText = (formatOptions.phoneHyphenStyle === "choon") ? "ー" : "\u2010";
        var resultText = "";
        for (var i = 0; i < phoneText.length; i++) {
            resultText += (PHONE_HYPHENS.indexOf(phoneText.charAt(i)) >= 0) ? hyphenText : phoneText.charAt(i);
        }
        return resultText;
    }

    /**
     * テキストの変換内容を決める。書き換え（後ろから順）と、書き換え後の縦中横の位置を返す
     * @param {string} sourceText - 元の文字列
     * @param {Object} formatOptions - 変換の設定
     * @returns {{edits: Array<{start: number, length: number, text: string}>, tcySpans: Array<{start: number, length: number}>,
     *     changes: Array<{before: string, after: string, tcy: boolean, tcyLength: number}>, outputLength: number}}
     *     edits は後ろから順、changes は確認の一覧用（前から順）
     */
    function planVerticalText(sourceText, formatOptions) {
        var text = formatOptions.halfwidthAlnum ? toHalfwidthAlnum(sourceText) : sourceText;
        var edits = [];
        var tcySpans = [];
        var changes = [];
        var outputLength = 0;
        var segmentText = "";
        var segmentHasTcy = false;
        var segmentTcyLength = 0;
        var quoteState = { isOpen: false };

        /**
         * 出力に文字列を足す（縦中横なら位置を控える）
         * @param {string} pieceText - 足す文字列
         * @param {boolean} isTcy - 縦中横にするか
         * @returns {void}
         */
        function emit(pieceText, isTcy) {
            if (isTcy) {
                tcySpans.push({ start: outputLength, length: pieceText.length });
                segmentHasTcy = true;
                segmentTcyLength = pieceText.length;
            }
            outputLength += pieceText.length;
            segmentText += pieceText;
        }

        /**
         * 元の [start, start+length) を出力 segmentText に置き換えたことを控える（変わらなければ控えない）
         * @param {number} start - 元の位置
         * @param {number} length - 元の文字数
         * @returns {void}
         */
        function closeSegment(start, length) {
            var originalText = sourceText.substr(start, length);
            if (segmentText !== originalText) {
                edits.push({ start: start, length: length, text: segmentText });
            }
            if (segmentText !== originalText || segmentHasTcy) {
                changes.push({ before: originalText, after: segmentText, tcy: segmentHasTcy, tcyLength: segmentTcyLength });
            }
            segmentText = "";
            segmentHasTcy = false;
            segmentTcyLength = 0;
        }

        var i = 0;
        while (i < text.length) {
            var currentChar = text.charAt(i);
            var runStart = i;
            var westernYear = (formatOptions.japaneseEra && isDigitChar(currentChar)) ? matchWesternYear(text, i) : null;
            var phraseText = westernYear ? null : matchLatinPhrase(text, i, formatOptions);
            /* 数字の直後の単位。数字との間の半角スペースは詰める / A unit right after digits; a space between them is removed */
            var unitGap = (isUnitGapSpace(currentChar) && isAnyDigitChar(text.charAt(i - 1))) ? 1 : 0;
            var unitMatch = (!phraseText && formatOptions.unitsKumimoji && isAnyDigitChar(text.charAt(i - 1))) ? matchUnitKumimoji(text, i + unitGap) : null;
            var kanjiNumeral = (formatOptions.kanjiToArabic && !formatOptions.kanji) ? matchKanjiNumeral(text, i) : null;
            if (westernYear) {
                emit(westernYear.eraName, false);
                /* 1年は「元年」 / The first year is written 元 */
                if (westernYear.eraYear === 1) emit("元", false);
                else emitPlainDigits(String(westernYear.eraYear), formatOptions, emit);
                i += 4;
            } else if (phraseText) {
                /* 英単語の連続（2語以上。3D Printing のように数字で始まる語も）は横倒しの欧文として残す（回転しない）。
                   中の全角英数字・幅の広いスペース・「＆」は半角に戻す
                   A run of two or more words (including ones like 3D Printing) stays sideways (not rotated);
                   full-width alphanumerics, wide spaces and ＆ inside become half-width */
                emit(toHalfwidthAlnum(phraseText).replace(/[\u2000-\u2003\u3000]/g, " ").replace(/＆/g, "&"), false);
                i += phraseText.length;
            } else if (unitMatch) {
                emit(unitMatch.text, false);
                i += unitGap + unitMatch.length;
            } else if (isDigitChar(currentChar) && matchPhoneNumber(text, i)) {
                /* 電話番号・郵便番号は範囲の「〜」にも縦中横・漢数字にもしない / Phone and postal numbers are not ranges, TCY or kanji */
                var phoneText = matchPhoneNumber(text, i);
                var phoneOutput = convertPhoneHyphens(phoneText, formatOptions);
                emit(formatOptions.nonTcyDigitsFullwidth ? phoneOutput.replace(/[0-9]+/g, toFullwidthAscii) : phoneOutput, false);
                i += phoneText.length;
            } else if (kanjiNumeral) {
                /* 漢数字は算用数字に読み替えてから、数字と同じに扱う / Kanji numerals are read as digits, then handled like digits */
                emitNumberToken(kanjiNumeral.text, readNumberToken(kanjiNumeral.text, 0), text.charAt(i + kanjiNumeral.length), formatOptions, emit);
                i += kanjiNumeral.length;
            } else if (isDigitChar(currentChar)) {
                var numberToken = readNumberToken(text, i);
                emitNumberToken(text.substr(i, numberToken.length), numberToken, text.charAt(i + numberToken.length), formatOptions, emit);
                i += numberToken.length;
            } else if (isLatinLetter(currentChar)) {
                /* 1語は半角だけを変換する（全角の英字はそのままでよい） / Single words: only half-width letters need converting */
                while (i < text.length && isLatinLetter(text.charAt(i))) i++;
                var letterText = text.substring(runStart, i);
                var isCapsTcy = formatOptions.tcyCapitals && letterText.length >= 2 && letterText.length <= 3 && letterText === letterText.toUpperCase();
                var isShortCaps = formatOptions.shortCapsFullwidth && /^[A-Z]{1,3}$/.test(letterText);
                if (isCapsTcy) emit(letterText, true);
                else if (isShortCaps || isShortWordForFullwidth(letterText, formatOptions)) emit(toFullwidthAscii(letterText), false);
                else emit(letterText, false);
            } else if (isExclamOrQuestion(currentChar)) {
                while (i < text.length && isExclamOrQuestion(text.charAt(i))) i++;
                var markText = text.substring(runStart, i);
                if (formatOptions.tcyExclamation && markText.length === 2) {
                    /* 縦中横にする組は半角にそろえる / Use half-width marks for the Tate-Chu-Yoko pair */
                    emit(markText.replace(/！/g, "!").replace(/？/g, "?"), true);
                } else if (formatOptions.exclamFullwidth) {
                    emit(toFullwidthAscii(markText), false);
                } else {
                    emit(markText, false);
                }
            } else {
                emit(convertOtherChar(text, i, formatOptions, quoteState), false);
                i++;
            }
            closeSegment(runStart, i - runStart);
        }
        edits.reverse();
        return { edits: edits, tcySpans: tcySpans, changes: changes, outputLength: outputLength };
    }

    // =========================================
    // 縦組み用の書き換えを戻す / Undo the vertical rewriting
    // =========================================

    /* すでに縦組みのテキストは、HorizontalTextFormatter と同じ既定の変換で横組み用に戻してから適用する（再実行できるように）。
       漢数字・和暦は、このスクリプトがそれらをオンで処理した記録（ストーリーのラベル）のあるテキストだけ戻す（原稿の「数十万」などを壊さない）。範囲の「〜」は戻さない
       Text that is already vertical is first returned to horizontal form with HorizontalTextFormatter's default conversions,
       so the script can be run again. Kanji numerals and eras are reverted only in stories labeled
       as processed with them on (so 数十万 in the original text is safe); range 〜 is left as it is */
    var APPLIED_LABEL_KEY = "VerticalTextFormatter";   /* 処理した設定を残すストーリーのラベルのキー / key of the story label that records the applied options */
    var KANJI_NUMERAL_DIGITS = "〇一二三四五六七八九";
    var KANJI_SMALL_UNIT_VALUES = { "十": 10, "百": 100, "千": 1000 };
    var KANJI_LARGE_UNIT_VALUES = { "万": 10000, "億": 100000000, "兆": 1000000000000 };
    var KUMIMOJI_UNIT_PAIRS = [["㍉㌘", "mg"], ["㍉㍑", "ml"], ["㌥㍑", "dL"], ["㌔㍑", "kL"], ["㌔㌍", "kcal"]];   /* 2字の組み合わせを先に / two-character pairs first */
    var KUMIMOJI_UNITS = {
        "㍉": "mm", "㌢": "cm", "㌖": "km", "㍍": "m", "㌘": "g", "㌕": "kg", "㌧": "t", "㍑": "L", "㌍": "cal", "㏄": "cc",
        "㎟": "mm²", "㎠": "cm²", "㎡": "m²", "㎢": "km²", "㎣": "mm³", "㎤": "cm³", "㎥": "m³", "㎦": "km³"
    };
    var HALFWIDTH_SYMBOLS = "％＆＃＠＊＋＝＜＞／";   /* 半角に戻す記号（括弧・「：」「；」は除く） / symbols made half-width (not brackets, ： ；) */
    var PHONE_HYPHEN_SOURCE = "[-‐ー－−]";          /* 番号のハイフンとみなす文字 / hyphens in phone and postal numbers */

    /* 縦組みのテキストを戻すときの変換（HorizontalTextFormatter の既定。範囲の「〜」・和暦・漢数字は別に決める）
       Conversions used to return vertical text (HorizontalTextFormatter's defaults; range 〜, eras and kanji are decided separately) */
    var VERTICAL_RESET_OPTIONS = {
        fullwidthToHalf: true, toutenToComma: true, nakaguroToPeriod: true, symbolsToHalf: true, chonchonToQuotes: true,
        phoneHyphenToAscii: true, kumimojiToLetters: true, waveToHyphen: false, eraToWestern: false, kanjiToArabic: false
    };

    /**
     * 漢数字の並びを算用数字の文字列にする（二〇二六 → "2026"、二千二十六 → "2026"、二万五〇〇〇 → "25000"）。
     * 単位語（十・百・千・万…）が無ければ1字ずつ置き換えて桁を残す
     * @param {string} kanjiText - 漢数字の並び（「零」も可）
     * @returns {string|null} 算用数字（読めなければ null）
     */
    function parseKanjiNumber(kanjiText) {
        kanjiText = kanjiText.replace(/零/g, "〇");
        if (!/[十百千万億兆]/.test(kanjiText)) {
            var digitText = "";
            for (var i = 0; i < kanjiText.length; i++) digitText += KANJI_NUMERAL_DIGITS.indexOf(kanjiText.charAt(i));
            return digitText;
        }
        var total = 0;
        var section = 0;
        var pendingDigits = "";
        for (var j = 0; j < kanjiText.length; j++) {
            var kanjiChar = kanjiText.charAt(j);
            var digitIndex = KANJI_NUMERAL_DIGITS.indexOf(kanjiChar);
            if (digitIndex >= 0) {
                pendingDigits += digitIndex;
            } else if (KANJI_SMALL_UNIT_VALUES[kanjiChar]) {
                section += (pendingDigits === "" ? 1 : parseInt(pendingDigits, 10)) * KANJI_SMALL_UNIT_VALUES[kanjiChar];
                pendingDigits = "";
            } else if (KANJI_LARGE_UNIT_VALUES[kanjiChar]) {
                section += (pendingDigits === "" ? 0 : parseInt(pendingDigits, 10));
                if (section === 0) section = 1;
                total += section * KANJI_LARGE_UNIT_VALUES[kanjiChar];
                section = 0;
                pendingDigits = "";
            } else {
                return null;
            }
        }
        return String(total + section + (pendingDigits === "" ? 0 : parseInt(pendingDigits, 10)));
    }

    /**
     * 1字の漢数字が日付・時刻の数か（一月・七日・三時・五秒、「五分」は後ろに数字か「秒」が続くか末尾のときだけ。「十分」「一緒」は除く）
     * ExtendScript は選択を含む先読みを誤評価することがあるので、文字で調べる
     * @param {string} sourceText - 対象の文字列
     * @param {number} index - 漢数字の位置
     * @returns {boolean} 該当すれば true
     */
    function isSingleKanjiTimeUnit(sourceText, index) {
        if ("〇零一二三四五六七八九十".indexOf(sourceText.charAt(index)) < 0) return false;
        var unitChar = sourceText.charAt(index + 1);
        if ("月日時秒".indexOf(unitChar) >= 0) return true;
        if (unitChar !== "分") return false;
        var afterChar = sourceText.charAt(index + 2);
        /* 「九分九厘」は除く / Not 九分九厘 */
        if (sourceText.charAt(index + 3) === "厘") return false;
        return afterChar === "" || afterChar === "秒" || isAnyDigitChar(afterChar) || KANJI_NUMERAL_DIGITS.indexOf(afterChar) >= 0;
    }

    /**
     * その位置から始まる漢数字を算用数字（半角）にして返す。2字以上の並び、1字は月・日・時・分・秒の前だけ（「一緒」「十分」は変えない）。
     * 読点で3桁ずつ区切ったもの（三、〇〇〇 → 3,000）と小数（一二・五 → 12.5）も読む。「数十万」「何百」などの概数は読まない
     * Reads kanji numerals at the position as half-width digits: runs of two or more, or a single one before 月 日 時 分 秒 (一緒 stays).
     * Also reads groups split by 、 and decimals; approximate numbers such as 数十万 and 何百 are left
     * @param {string} sourceText - 対象の文字列
     * @param {number} index - 調べる位置
     * @returns {{length: number, text: string}|null} 元の文字数と算用数字（該当しなければ null）
     */
    function matchKanjiNumeral(sourceText, index) {
        var previousChar = sourceText.charAt(index - 1);
        /* 概数の続き（「数十万」の「万」など）も読まない / Not the rest of an approximate number either */
        if (previousChar !== "" && "数何幾〇零一二三四五六七八九十百千万億兆".indexOf(previousChar) >= 0) return null;
        var restText = sourceText.substr(index, 40);
        var matched;
        /* 読点で3桁ずつ区切った漢数字（三、〇〇〇） / Kanji digits grouped by 、 every three */
        if ((matched = /^[〇零一二三四五六七八九]+(?:、[〇零一二三四五六七八九]{3})+(?![〇零一二三四五六七八九])/.exec(restText))) {
            var groupedDigits = matched[0].split("、");
            for (var g = 0; g < groupedDigits.length; g++) groupedDigits[g] = parseKanjiNumber(groupedDigits[g]);
            return { length: matched[0].length, text: groupedDigits.join(",") };
        }
        /* 漢数字の小数（一二・五） / Kanji decimals */
        if ((matched = /^[〇零一二三四五六七八九十百千万億兆]+・[〇零一二三四五六七八九]+/.exec(restText))) {
            var decimalParts = matched[0].split("・");
            return { length: matched[0].length, text: parseKanjiNumber(decimalParts[0]) + "." + parseKanjiNumber(decimalParts[1]) };
        }
        matched = /^[〇零一二三四五六七八九十百千万億兆]{2,}/.exec(restText);
        if (!matched && isSingleKanjiTimeUnit(sourceText, index)) matched = [sourceText.charAt(index)];
        if (!matched) return null;
        var kanjiValue = parseKanjiNumber(matched[0]);
        if (kanjiValue === null || kanjiValue === "NaN") return null;
        return { length: matched[0].length, text: kanjiValue };
    }

    /**
     * 元号の開始年（西暦）を返す
     * @param {string} eraName - 元号
     * @returns {number} 開始年（見つからなければ 0）
     */
    function getEraStartYear(eraName) {
        for (var i = 0; i < JAPANESE_ERAS.length; i++) {
            if (JAPANESE_ERAS[i].name === eraName) return Math.floor(JAPANESE_ERAS[i].start / 10000);
        }
        return 0;
    }

    /**
     * 全角の英数字と「！」「？」なら半角を、そうでなければ null を返す
     * @param {string} oneChar - 1文字
     * @returns {string|null} 半角の文字
     */
    function toHalfwidthAlnumChar(oneChar) {
        var charCode = oneChar.charCodeAt(0);
        var isFullAlnum = (charCode >= 0xFF10 && charCode <= 0xFF19) || (charCode >= 0xFF21 && charCode <= 0xFF3A) ||
            (charCode >= 0xFF41 && charCode <= 0xFF5A) || oneChar === "！" || oneChar === "？";
        return isFullAlnum ? String.fromCharCode(charCode - 0xFEE0) : null;
    }

    /**
     * 1文字を横組み用にした文字を返す（全角英数字・「！？」・数字の間の「、」「・」「〜」・記号・〝〟）
     * @param {string} sourceText - 元の文字列
     * @param {number} index - 文字の位置
     * @param {Object} horizontalOptions - 横組みの設定
     * @returns {string} 置き換えた文字（変えないときは元の文字）
     */
    function convertHorizontalChar(sourceText, index, horizontalOptions) {
        var currentChar = sourceText.charAt(index);
        var previousChar = sourceText.charAt(index - 1);
        var nextChar = sourceText.charAt(index + 1);
        var halfChar = toHalfwidthAlnumChar(currentChar);
        if (horizontalOptions.fullwidthToHalf && halfChar !== null) return halfChar;
        /* 数字の間で、後ろがちょうど3桁なら桁区切り / A separator when exactly three digits follow */
        if (horizontalOptions.toutenToComma && currentChar === "、" && isAnyDigitChar(previousChar) &&
                /^[0-9０-９]{3}(?![0-9０-９])/.test(sourceText.substr(index + 1, 4))) return ",";
        if (horizontalOptions.nakaguroToPeriod && currentChar === "・" && isAnyDigitChar(previousChar) && isAnyDigitChar(nextChar)) return ".";
        if (horizontalOptions.waveToHyphen && (currentChar === "〜" || currentChar === "～") && isAnyDigitChar(previousChar) && isAnyDigitChar(nextChar)) return "-";
        if (horizontalOptions.symbolsToHalf && HALFWIDTH_SYMBOLS.indexOf(currentChar) >= 0) return String.fromCharCode(currentChar.charCodeAt(0) - 0xFEE0);
        if (horizontalOptions.chonchonToQuotes && currentChar === "〝") return "“";
        if (horizontalOptions.chonchonToQuotes && currentChar === "〟") return "”";
        return currentChar;
    }

    /**
     * 横組み用の書き換えを決める（縦組みのテキストを戻すときに VERTICAL_RESET_OPTIONS で使う）
     * @param {string} sourceText - 元の文字列
     * @param {Object} horizontalOptions - 横組みの設定（VERTICAL_RESET_OPTIONS の形）
     * @returns {{edits: Array<{start: number, length: number, text: string}>, changes: Array<{before: string, after: string}>, outputLength: number}}
     *     edits は後ろから順、changes は確認の一覧用（前から順）
     */
    function planHorizontalText(sourceText, horizontalOptions) {
        var edits = [];
        var changes = [];
        var outputLength = 0;
        var i = 0;

        /**
         * 元の [i, i+length) を replacementText にする（同じなら控えない）
         * @param {number} length - 元の文字数
         * @param {string} replacementText - 置き換える文字列
         * @returns {void}
         */
        function addSegment(length, replacementText) {
            var originalText = sourceText.substr(i, length);
            if (replacementText !== originalText) {
                edits.push({ start: i, length: length, text: replacementText });
                changes.push({ before: originalText, after: replacementText });
            }
            outputLength += replacementText.length;
            i += length;
        }

        while (i < sourceText.length) {
            var restText = sourceText.substr(i, 40);
            var currentChar = sourceText.charAt(i);
            var matched = null;
            /* 和暦 → 西暦（令和8年・令和八年 → 2026年） / Japanese era → Western year */
            if (horizontalOptions.eraToWestern && (matched = /^(令和|平成|昭和|大正|明治)(元|[0-9０-９]+|[〇零一二三四五六七八九十百]+)年/.exec(restText))) {
                var eraYear = 1;
                if (matched[2] !== "元") eraYear = parseInt(/[0-9０-９]/.test(matched[2]) ? toHalfwidthAlnum(matched[2]) : parseKanjiNumber(matched[2]), 10);
                addSegment(matched[0].length, (getEraStartYear(matched[1]) + eraYear - 1) + "年");
                continue;
            }
            /* 漢数字 → 算用数字（「、」の3桁区切り・「・」の小数は桁区切り・小数点の設定に合わせる） / Kanji numerals → Arabic */
            var kanjiNumeral = horizontalOptions.kanjiToArabic ? matchKanjiNumeral(sourceText, i) : null;
            if (kanjiNumeral) {
                var arabicText = kanjiNumeral.text;
                if (!horizontalOptions.toutenToComma) arabicText = arabicText.replace(/,/g, "、");
                if (!horizontalOptions.nakaguroToPeriod) arabicText = arabicText.replace(/\./g, "・");
                addSegment(kanjiNumeral.length, arabicText);
                continue;
            }
            /* 電話番号・郵便番号のハイフン → 「-」 / Phone and postal hyphens → "-" */
            if (horizontalOptions.phoneHyphenToAscii && isAnyDigitChar(currentChar) && !isAnyDigitChar(sourceText.charAt(i - 1))) {
                var phoneMatch = new RegExp("^[0-9０-９]+(?:" + PHONE_HYPHEN_SOURCE + "[0-9０-９]+){2,}").exec(restText) ||
                    new RegExp("^[0-9０-９]{3}" + PHONE_HYPHEN_SOURCE + "[0-9０-９]{4}(?![0-9０-９])").exec(restText);
                if (phoneMatch) {
                    var phoneText = phoneMatch[0].replace(new RegExp(PHONE_HYPHEN_SOURCE, "g"), "-");
                    addSegment(phoneMatch[0].length, horizontalOptions.fullwidthToHalf ? toHalfwidthAlnum(phoneText) : phoneText);
                    continue;
                }
            }
            /* 組文字の単位 → 英字 / Unit squares → letters */
            if (horizontalOptions.kumimojiToLetters) {
                var pairText = sourceText.substr(i, 2);
                var pairReplacement = null;
                for (var p = 0; p < KUMIMOJI_UNIT_PAIRS.length; p++) {
                    if (KUMIMOJI_UNIT_PAIRS[p][0] === pairText) pairReplacement = KUMIMOJI_UNIT_PAIRS[p][1];
                }
                if (pairReplacement) {
                    addSegment(2, pairReplacement);
                    continue;
                }
                if (KUMIMOJI_UNITS.hasOwnProperty(currentChar)) {
                    addSegment(1, KUMIMOJI_UNITS[currentChar]);
                    continue;
                }
            }
            addSegment(1, convertHorizontalChar(sourceText, i, horizontalOptions));
        }
        edits.reverse();
        return { edits: edits, changes: changes, outputLength: outputLength };
    }

    /**
     * 縦組み用の書き換えを戻す書き換えを決める（HorizontalTextFormatter の既定の変換。漢数字・和暦は resetOptions で指定したときだけ戻す）
     * @param {string} sourceText - 元の文字列
     * @param {{kanji: boolean, era: boolean}} resetOptions - 漢数字・和暦も戻すか
     * @returns {Array<{start: number, length: number, text: string}>} 書き換え（後ろから順）
     */
    function planVerticalReset(sourceText, resetOptions) {
        var horizontalOptions = mergeObjects(VERTICAL_RESET_OPTIONS, { eraToWestern: resetOptions.era, kanjiToArabic: resetOptions.kanji });
        return planHorizontalText(sourceText, horizontalOptions).edits;
    }

    /**
     * すでに縦組みの対象に、戻す書き換えを用意する。対象の text は戻したあとの文字列にする（確認の一覧と変換の計画はこれを使う）
     * @param {Array<Object>} textTargets - collectTextTargets() の戻り値（resetEdits・sourceText を足す）
     * @returns {void}
     */
    function prepareVerticalResets(textTargets) {
        for (var i = 0; i < textTargets.length; i++) {
            if (!isVerticalStory(textTargets[i].story)) continue;
            textTargets[i].resetEdits = planVerticalReset(textTargets[i].text, readAppliedOptions(textTargets[i].story));
            textTargets[i].sourceText = textTargets[i].text;
            textTargets[i].text = buildEditedText(textTargets[i].text, textTargets[i].resetEdits);
        }
    }

    /**
     * ストーリーのラベルから、前に処理したときの漢数字・和暦の設定を読む（ラベルが無ければどちらも false）
     * @param {Story} story - ストーリー
     * @returns {{kanji: boolean, era: boolean}} 漢数字・和暦をオンで処理したか
     */
    function readAppliedOptions(story) {
        var appliedValue = "";
        try {
            appliedValue = story.extractLabel(APPLIED_LABEL_KEY);
        } catch (e) { /* ラベルを読めなければ戻さない / leave kanji and eras when the label cannot be read */ }
        return { kanji: /(^|,)kanji(,|$)/.test(appliedValue), era: /(^|,)era(,|$)/.test(appliedValue) };
    }

    /**
     * 処理したストーリーに、漢数字・和暦の設定をラベルで残す（次に再実行したとき、オンなら戻す）
     * @param {Array<Object>} textTargets - 処理した対象
     * @param {Object} formatOptions - 変換の設定
     * @returns {void}
     */
    function recordAppliedOptions(textTargets, formatOptions) {
        var appliedValue = "applied" + (formatOptions.kanji ? ",kanji" : "") + (formatOptions.japaneseEra ? ",era" : "");
        for (var i = 0; i < textTargets.length; i++) {
            try {
                textTargets[i].story.insertLabel(APPLIED_LABEL_KEY, appliedValue);
            } catch (e) {
                $.writeln("recordAppliedOptions: " + e);
            }
        }
    }

    /**
     * すでに縦組みの対象を横組み用に戻す：欧文回転・縦中横を外し、書き換えを戻し、字形を標準にする（縦組みのまま）
     * @param {Object} textTarget - prepareVerticalResets() で resetEdits を用意した対象
     * @returns {void}
     */
    function resetVerticalTarget(textTarget) {
        var sourceRange = getTargetRange(textTarget, textTarget.sourceText, 0, textTarget.sourceText.length);
        if (sourceRange) sourceRange.properties = { rotateSingleByteCharacters: false, tatechuyoko: false };
        applyTextEdits(textTarget, textTarget.resetEdits, textTarget.sourceText);
        var resetRange = getTargetRange(textTarget, textTarget.text, 0, textTarget.text.length);
        if (resetRange) resetRange.glyphForm = AlternateGlyphForms.NONE;
    }

    // =========================================
    // 対象のテキスト / Text targets
    // =========================================

    /* 文字の選択とみなす型 / Selection types treated as a text selection */
    var TEXT_SELECTION_TYPES = { Text: true, Character: true, Word: true, Line: true, Paragraph: true, TextColumn: true, TextStyleRange: true };

    /**
     * オブジェクトの型の名前を返す
     * @param {Object} domObject - DOM のオブジェクト
     * @returns {string} 型の名前（読めなければ空文字）
     */
    function getConstructorName(domObject) {
        try {
            return domObject.constructor.name;
        } catch (e) {
            return "";
        }
    }

    /**
     * 配列なら先頭の要素を、そうでなければそのまま返す
     * @param {*} domValue - DOM のプロパティの値
     * @returns {*} 先頭の要素か、渡した値
     */
    function getFirstElement(domValue) {
        return (domValue instanceof Array) ? domValue[0] : domValue;
    }

    /**
     * ストーリーが縦組みか
     * @param {Story} story - ストーリー
     * @returns {boolean} 縦組みなら true
     */
    function isVerticalStory(story) {
        return story.storyPreferences.storyOrientation === StoryHorizontalOrVertical.VERTICAL;
    }

    /**
     * ロック・非表示でない（自身もレイヤーも）テキストフレームか
     * @param {TextFrame} textFrame - テキストフレーム
     * @returns {boolean} 処理してよければ true
     */
    function isEditableFrame(textFrame) {
        try {
            if (textFrame.locked || !textFrame.visible) return false;
            var frameLayer = textFrame.itemLayer;
            return !frameLayer.locked && frameLayer.visible;
        } catch (e) {
            return false;
        }
    }

    /**
     * 選択から処理の対象を集める。文字選択中はその範囲、オブジェクト選択ならテキストフレームのストーリーごと（連結は1つ）
     * @param {Array} selectionItems - app.selection
     * @returns {Array<Object>} { story, offset（ストーリーの文字の番号のずれ）, text, isTextSelection }
     */
    function collectTextTargets(selectionItems) {
        var textTargets = [];
        if (selectionItems.length === 1 && TEXT_SELECTION_TYPES[getConstructorName(selectionItems[0])]) {
            var selectedText = selectionItems[0];
            /* 表のセルや脚注の中の文字は対象にしない。範囲の parent・contents などは配列で返ることがある
               Text in table cells and footnotes is not a target; parent, contents etc. of a range can come back as arrays */
            var textParent = getFirstElement(selectedText.parent);
            if (selectedText.length > 0 && getConstructorName(textParent) === "Story") {
                textTargets.push({ story: textParent, offset: getFirstElement(selectedText.index), text: String(getFirstElement(selectedText.contents)), isTextSelection: true });
            }
            return textTargets;
        }
        collectFrameTargets(selectionItems, textTargets, {});
        return textTargets;
    }

    /**
     * テキストフレーム（グループの中も）のストーリーを対象に足す。同じストーリーは1回だけ
     * @param {Array} pageItems - 選択、またはグループの中のページアイテム
     * @param {Array<Object>} textTargets - 対象を足す配列
     * @param {Object} storyIds - 足したストーリーの ID
     * @returns {void}
     */
    function collectFrameTargets(pageItems, textTargets, storyIds) {
        for (var i = 0; i < pageItems.length; i++) {
            var typeName = getConstructorName(pageItems[i]);
            if (typeName === "Group") {
                collectFrameTargets(pageItems[i].pageItems.everyItem().getElements(), textTargets, storyIds);
                continue;
            }
            if (typeName !== "TextFrame" || !isEditableFrame(pageItems[i])) continue;
            var story = pageItems[i].parentStory;
            if (storyIds[story.id]) continue;
            storyIds[story.id] = true;
            textTargets.push({ story: story, offset: 0, text: story.contents, isTextSelection: false });
        }
    }

    /**
     * 文字列の位置を、ストーリーの文字の番号の差に直す（サロゲートペアの絵文字などは、文字列では2つ、InDesign の文字では1つに数える）
     * @param {string} referenceText - 位置を数える文字列
     * @param {number} stringIndex - 文字列の位置
     * @returns {number} 文字の番号の差
     */
    function toCharacterIndex(referenceText, stringIndex) {
        if (!/[\uD800-\uDBFF]/.test(referenceText)) return stringIndex;
        var surrogatePairs = referenceText.substring(0, stringIndex).match(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g);
        return stringIndex - (surrogatePairs ? surrogatePairs.length : 0);
    }

    /**
     * 対象の中の範囲を返す
     * @param {Object} textTarget - 対象
     * @param {string} referenceText - 位置を数える文字列（そのときのストーリーの中身と同じもの）
     * @param {number} start - 範囲の先頭（文字列の位置）
     * @param {number} length - 文字列の長さ
     * @returns {Text|null} 範囲（長さが0なら null）
     */
    function getTargetRange(textTarget, referenceText, start, length) {
        if (length <= 0) return null;
        var firstIndex = textTarget.offset + toCharacterIndex(referenceText, start);
        var lastIndex = textTarget.offset + toCharacterIndex(referenceText, start + length) - 1;
        return textTarget.story.characters.itemByRange(firstIndex, lastIndex).texts[0];
    }

    /**
     * 書き換えを適用する。文字数が同じなら変わる文字だけを1文字ずつ、異なるなら余分を消して先頭の文字に入れる（書式は先頭の文字のもの）。
     * 後ろから順に書き換えるので、前の位置はずれない
     * @param {Object} textTarget - 対象
     * @param {Array<Object>} edits - planVerticalText() などの edits（後ろから順）
     * @param {string} sourceText - 書き換える前の文字列
     * @returns {void}
     */
    function applyTextEdits(textTarget, edits, sourceText) {
        var characters = textTarget.story.characters;
        for (var i = 0; i < edits.length; i++) {
            var edit = edits[i];
            var baseIndex = textTarget.offset + toCharacterIndex(sourceText, edit.start);
            var originalText = sourceText.substr(edit.start, edit.length);
            if (edit.text.length === edit.length) {
                for (var k = 0; k < edit.text.length; k++) {
                    if (originalText.charAt(k) !== edit.text.charAt(k)) characters[baseIndex + k].contents = edit.text.charAt(k);
                }
            } else {
                if (edit.length > 1) characters.itemByRange(baseIndex + 1, baseIndex + edit.length - 1).remove();
                /* 空文字を入れると文字は消える / Assigning an empty string removes the character */
                characters[baseIndex].contents = edit.text;
            }
        }
    }

    /**
     * 書き換えを元の文字列に当てて、書き換え後の文字列を返す
     * @param {string} sourceText - 元の文字列
     * @param {Array<Object>} edits - planVerticalText() の edits（後ろから順）
     * @returns {string} 書き換え後の文字列
     */
    function buildEditedText(sourceText, edits) {
        var editedText = sourceText;
        for (var i = 0; i < edits.length; i++) {
            editedText = editedText.substring(0, edits[i].start) + edits[i].text + editedText.substring(edits[i].start + edits[i].length);
        }
        return editedText;
    }

    /**
     * 全角の英数字（Ａ〜Ｚ・ａ〜ｚ・０〜９）の並びを探す
     * @param {string} targetText - 対象の文字列
     * @returns {Array<{start: number, length: number}>} 見つかった位置
     */
    function findFullwidthAlnumRuns(targetText) {
        var alnumRuns = [];
        var alnumPattern = /[０-９Ａ-Ｚａ-ｚ]+/g;
        var alnumMatch;
        while ((alnumMatch = alnumPattern.exec(targetText)) !== null) {
            alnumRuns.push({ start: alnumMatch.index, length: alnumMatch[0].length });
        }
        return alnumRuns;
    }

    /**
     * 回転させない欧文を探す。英単語がスペースや「&」でつながった2語以上のまとまりは常に、
     * 1語は minChars 文字以上のとき（minChars が 0 なら1語は対象外）
     * @param {string} targetText - 対象の文字列
     * @param {number} minChars - 1語を対象にする文字数（0 で対象にしない）
     * @param {Object} formatOptions - 変換の設定
     * @returns {Array<{start: number, length: number}>} 見つかった位置
     */
    function findNoRotateLatinRuns(targetText, minChars, formatOptions) {
        var latinRuns = [];
        var i = 0;
        while (i < targetText.length) {
            var latinRun = scanLatinRun(targetText, i, formatOptions);
            if (!latinRun) {
                i++;
                continue;
            }
            var runLength = latinRun.end - i;
            if (latinRun.wordCount >= 2 || (minChars > 0 && runLength >= minChars)) latinRuns.push({ start: i, length: runLength });
            i = latinRun.end;
        }
        return latinRuns;
    }

    /**
     * 回転させない欧文の位置を、設定に合わせて返す（欧文回転がオフなら空）
     * @param {string} targetText - 対象の文字列（書き換え前）
     * @param {Object} formatOptions - 変換の設定
     * @returns {Array<{start: number, length: number}>} 見つかった位置
     */
    function getNoRotateRuns(targetText, formatOptions) {
        if (!formatOptions.rotateRoman) return [];
        return findNoRotateLatinRuns(targetText, formatOptions.rotateSkipLongLatin ? formatOptions.rotateSkipMinChars : 0, formatOptions);
    }

    /**
     * 対象のストーリーを縦組みにする。InDesign ではフレームは作り直されない
     * @param {Array<Object>} textTargets - 対象
     * @returns {void}
     */
    function setStoriesVertical(textTargets) {
        for (var i = 0; i < textTargets.length; i++) {
            if (isVerticalStory(textTargets[i].story)) continue;
            textTargets[i].story.storyPreferences.storyOrientation = StoryHorizontalOrVertical.VERTICAL;
        }
    }

    /**
     * 書き換え後のテキストの全角の英数字に、OpenType のプロポーショナルメトリクスを適用する
     * @param {Object} textTarget - 対象
     * @param {string} outputText - 書き換え後の文字列
     * @returns {void}
     */
    function applyProportionalMetricsToFullwidthAlnum(textTarget, outputText) {
        var alnumRuns = findFullwidthAlnumRuns(outputText);
        for (var i = 0; i < alnumRuns.length; i++) {
            getTargetRange(textTarget, outputText, alnumRuns[i].start, alnumRuns[i].length).otfProportionalMetrics = true;
        }
    }

    /**
     * 書き換え後のテキストの「一」から、プロポーショナルメトリクスと文字ツメを外す（自動カーニングは applyFinalCharacterAttributes() で外す）
     * 縦組みの「一」は字面が薄く、詰めると前後に寄って見えにくくなるため
     * @param {Object} textTarget - 対象
     * @param {string} outputText - 書き換え後の文字列
     * @returns {void}
     */
    function removeIchiTightening(textTarget, outputText) {
        for (var i = outputText.indexOf("一"); i >= 0; i = outputText.indexOf("一", i + 1)) {
            getTargetRange(textTarget, outputText, i, 1).properties = { otfProportionalMetrics: false, tsume: 0 };
        }
    }

    /* 縦中横の字数ごとの等幅字形（確認の一覧の字形名のキーも兼ねる） / Fixed-width form per Tate-Chu-Yoko length (also the label key) */
    var TCY_GLYPH_KEYS_BY_LENGTH = { 2: "half", 3: "third", 4: "quarter" };

    /**
     * 縦中横の字数に合わせた等幅字形を返す（2字は等幅半角・3字は等幅三分・4字は等幅四分で、ほぼ全角1字分に収める）
     * @param {number} charCount - 縦中横の字数
     * @returns {AlternateGlyphForms|null} 字形（2〜4字以外は null）
     */
    function getTcyGlyphForm(charCount) {
        if (charCount === 2) return AlternateGlyphForms.MONOSPACED_HALF_WIDTH_FORM;
        if (charCount === 3) return AlternateGlyphForms.THIRD_WIDTH_FORM;
        if (charCount === 4) return AlternateGlyphForms.QUARTER_WIDTH_FORM;
        return null;
    }

    /**
     * 段落に入れる禁則・文字組みアキ量設定の値を返す
     * @param {Object} tables - doc.kinsokuTables か doc.mojikumiTables
     * @param {string|null} tableName - 設定の名前（null は変えない、TABLE_NONE は「なし」、空文字は組み込みの既定）
     * @param {number} defaultIndex - 組み込みの既定の番号（tables の中の位置）
     * @returns {*} 代入する値（変えないときは null）
     */
    function resolveTableValue(tables, tableName, defaultIndex) {
        if (tableName === null) return null;
        if (tableName === TABLE_NONE) return NothingEnum.NOTHING;
        if (tableName !== "") {
            var namedTable = tables.itemByName(tableName);
            if (namedTable.isValid) return namedTable;
        }
        return (defaultIndex < tables.length) ? tables[defaultIndex] : null;
    }

    /**
     * 対象の段落に、禁則・文字組みアキ量設定・行送り（自動行送りの％）と均等配置（最終行上揃え）を設定する
     * @param {Document} doc - 対象のドキュメント
     * @param {Object} textTarget - 対象
     * @param {Object} formatOptions - 変換の設定（kinsokuName / mojikumiName / leadingPercent。null は変えない）
     * @returns {void}
     */
    function applyParagraphSettings(doc, textTarget, formatOptions) {
        var targetRange = getTargetRange(textTarget, textTarget.text, 0, textTarget.text.length);
        if (!targetRange) return;
        /* 縦組みでは「均等配置（最終行左揃え）」が最終行上揃え / In vertical text, "justify, last line left" means last line top */
        var paragraphProperties = { justification: Justification.LEFT_JUSTIFIED };
        var kinsokuValue = resolveTableValue(doc.kinsokuTables, formatOptions.kinsokuName, KINSOKU_DEFAULT_INDEX);
        if (kinsokuValue !== null) paragraphProperties.kinsokuSet = kinsokuValue;
        var mojikumiValue = resolveTableValue(doc.mojikumiTables, formatOptions.mojikumiName, MOJIKUMI_DEFAULT_INDEX);
        if (mojikumiValue !== null) paragraphProperties.mojikumi = mojikumiValue;
        /* 行送りの％は段落の属性。文字の自動行送りは処理の最後に applyFinalCharacterAttributes() でかける
           The leading percentage is a paragraph attribute; characters get auto leading at the end (applyFinalCharacterAttributes) */
        if (formatOptions.leadingPercent !== null) paragraphProperties.autoLeading = formatOptions.leadingPercent;
        targetRange.properties = paragraphProperties;
    }

    /**
     * 処理したテキスト全体の文字を自動行送りにし、自動カーニングを「なし」（カーニング 0）にする
     * （行送りが常に「自動」になり、文字サイズに追従する）。書き換え・縦中横・字形の変更のあとにかけるので、途中で書式が変わった文字もそろう
     * @param {Object} textTarget - 対象
     * @param {string} outputText - 書き換え後の文字列
     * @returns {void}
     */
    function applyFinalCharacterAttributes(textTarget, outputText) {
        var outputRange = getTargetRange(textTarget, outputText, 0, outputText.length);
        if (outputRange) outputRange.properties = { leading: Leading.AUTO, kerningMethod: KERNING_METHOD_NONE };
    }

    /**
     * 単位を pt にして処理を実行し、元の単位に戻す（枠の座標と文字サイズを pt で読み書きするため）
     * @param {Document} doc - 対象のドキュメント
     * @param {Function} task - 実行する処理
     * @returns {void}
     */
    function runWithPointUnits(doc, task) {
        var viewPreferences = doc.viewPreferences;
        var unitKeys = ["horizontalMeasurementUnits", "verticalMeasurementUnits", "textSizeMeasurementUnits", "typographicMeasurementUnits"];
        var savedUnits = {};
        for (var i = 0; i < unitKeys.length; i++) {
            try {
                savedUnits[unitKeys[i]] = viewPreferences[unitKeys[i]];
                viewPreferences[unitKeys[i]] = MeasurementUnits.POINTS;
            } catch (e) { /* 無い設定は飛ばす / skip settings that do not exist */ }
        }
        try {
            task();
        } finally {
            for (var unitKey in savedUnits) {
                if (!savedUnits.hasOwnProperty(unitKey)) continue;
                try {
                    viewPreferences[unitKey] = savedUnits[unitKey];
                } catch (restoreError) { /* 戻せなくても続ける / keep going */ }
            }
        }
    }

    /**
     * テキストフレームの高さ（縦組みでは1行の長さ）を、文字サイズの整数倍にそろえる（いちばん近い倍数、最小1文字分）
     * フレーム内マージンは除いて測り、足し戻す。回転・シアーしたフレームは変えない
     * @param {Document} doc - 対象のドキュメント
     * @param {Array<Object>} textTargets - 対象
     * @returns {void}
     */
    function adjustFrameHeightToTextSize(doc, textTargets) {
        runWithPointUnits(doc, function () {
            for (var i = 0; i < textTargets.length; i++) {
                var textContainers = textTargets[i].story.textContainers;
                for (var j = 0; j < textContainers.length; j++) {
                    var textFrame = textContainers[j];
                    if (getConstructorName(textFrame) !== "TextFrame" || !isEditableFrame(textFrame) || textFrame.characters.length === 0) continue;
                    if (textFrame.rotationAngle !== 0 || textFrame.shearAngle !== 0) continue;
                    var textSize = textFrame.characters[0].pointSize;
                    if (!(textSize > 0)) continue;
                    var frameBounds = textFrame.geometricBounds;
                    var insetSpacing = textFrame.textFramePreferences.insetSpacing;
                    var insetTop = (insetSpacing instanceof Array) ? insetSpacing[0] : insetSpacing;
                    var insetBottom = (insetSpacing instanceof Array) ? insetSpacing[2] : insetSpacing;
                    var contentHeight = frameBounds[2] - frameBounds[0] - insetTop - insetBottom;
                    var charCount = Math.max(1, Math.round(contentHeight / textSize));
                    textFrame.geometricBounds = [frameBounds[0], frameBounds[1], frameBounds[0] + charCount * textSize + insetTop + insetBottom, frameBounds[3]];
                }
            }
        });
    }

    /**
     * 対象のうち、連結していないテキストフレームを自動サイズ調整（幅のみ・右上基準）にする。縦組みでは行が増えると左へ広がる
     * @param {Array<Object>} textTargets - 対象
     * @returns {void}
     */
    function applyFrameAutoSize(textTargets) {
        for (var i = 0; i < textTargets.length; i++) {
            var textContainers = textTargets[i].story.textContainers;
            if (textContainers.length !== 1 || getConstructorName(textContainers[0]) !== "TextFrame" || !isEditableFrame(textContainers[0])) continue;
            var framePreferences = textContainers[0].textFramePreferences;
            /* 基準点を先に入れる（種類を先に入れると、その時点の基準点で大きさが変わる） / Set the reference point first, or the frame resizes around the old one */
            framePreferences.autoSizingReferencePoint = AutoSizingReferenceEnum.TOP_RIGHT_POINT;
            framePreferences.autoSizingType = AutoSizingTypeEnum.WIDTH_ONLY;
        }
    }

    /**
     * 縦組み用の書き換えを戻す・縦組みにする・段落の設定・欧文回転・文字の書き換え・縦中横を順に適用する
     * （欧文回転は書き換えの前に全体へ掛け、書き換えた文字は前の文字の書式として回転を引き継ぐ）
     * @param {Document} doc - 対象のドキュメント
     * @param {Array<Object>} textTargets - prepareVerticalResets() を通した対象
     * @param {Object} formatOptions - 変換の設定
     * @returns {string} 失敗したときの理由（成功は空文字）
     */
    function runVerticalTextConversion(doc, textTargets, formatOptions) {
        var plans = [];
        var outputTexts = [];
        var tcyTotal = 0;
        for (var i = 0; i < textTargets.length; i++) {
            plans.push(planVerticalText(textTargets[i].text, formatOptions));
            outputTexts.push(buildEditedText(textTargets[i].text, plans[i].edits));
            tcyTotal += plans[i].tcySpans.length;
        }
        var stepTotal = (formatOptions.rotateRoman ? 1 : 0) + textTargets.length + tcyTotal;
        var stepDone = 0;
        var progress = createProgressWindow(getLabel("progress.title"));

        /**
         * 進み具合を1つ進めて表示する
         * @param {string} message - 表示する文言
         * @returns {void}
         */
        function advanceProgress(message) {
            stepDone++;
            progress.set(stepDone / stepTotal, message);
        }

        try {
            /* すでに縦組みの対象を横組み用に戻してから、縦組みにする / Undo the vertical rewriting of already-vertical targets, then make them vertical */
            for (var r = 0; r < textTargets.length; r++) {
                if (textTargets[r].resetEdits) resetVerticalTarget(textTargets[r]);
            }
            setStoriesVertical(textTargets);
            for (var p = 0; p < textTargets.length; p++) applyParagraphSettings(doc, textTargets[p], formatOptions);

            /* まず欧文回転を、書き換え前のテキスト全体に / Rotate first, over the whole text before any edits */
            if (formatOptions.rotateRoman) {
                progress.set(0, getLabel("progress.rotate"));
                for (var k = 0; k < textTargets.length; k++) {
                    var wholeRange = getTargetRange(textTargets[k], textTargets[k].text, 0, textTargets[k].text.length);
                    if (wholeRange) wholeRange.rotateSingleByteCharacters = true;
                    /* 長い欧文は回転を外す（書き換え前の位置で） / Turn rotation off for long Roman text (positions before edits) */
                    var noRotateRuns = getNoRotateRuns(textTargets[k].text, formatOptions);
                    for (var n = 0; n < noRotateRuns.length; n++) {
                        getTargetRange(textTargets[k], textTargets[k].text, noRotateRuns[n].start, noRotateRuns[n].length).rotateSingleByteCharacters = false;
                    }
                }
                advanceProgress(getLabel("progress.rotate"));
            }

            for (var j = 0; j < textTargets.length; j++) {
                applyTextEdits(textTargets[j], plans[j].edits, textTargets[j].text);
                if (formatOptions.proportionalFullwidthLatin) applyProportionalMetricsToFullwidthAlnum(textTargets[j], outputTexts[j]);
                if (formatOptions.ichiNoTightening) removeIchiTightening(textTargets[j], outputTexts[j]);
                advanceProgress(getLabel("progress.edit", { current: j + 1, total: textTargets.length }));
            }

            /* 縦中横と字数に合わせた等幅字形 / Tate-Chu-Yoko and fixed-width forms by length */
            var tcyDone = 0;
            for (var t = 0; t < textTargets.length; t++) {
                var tcySpans = plans[t].tcySpans;
                for (var s = 0; s < tcySpans.length; s++) {
                    var tcyProperties = { tatechuyoko: true };
                    var glyphForm = formatOptions.tcyGlyphByLength ? getTcyGlyphForm(tcySpans[s].length) : null;
                    if (glyphForm !== null) tcyProperties.glyphForm = glyphForm;
                    getTargetRange(textTargets[t], outputTexts[t], tcySpans[s].start, tcySpans[s].length).properties = tcyProperties;
                    tcyDone++;
                    advanceProgress(getLabel("progress.tcy", { current: tcyDone, total: tcyTotal }));
                }
            }

            /* 行送りは常に自動、自動カーニングは常に「なし」に（簡易・詳細とも） / Leading always auto, auto kerning always none (both modes) */
            for (var a = 0; a < textTargets.length; a++) applyFinalCharacterAttributes(textTargets[a], outputTexts[a]);

            /* 枠の高さ（1行の長さ）を文字サイズの整数倍に。自動サイズ調整より前に / Height to a multiple of the type size, before auto size */
            if (formatOptions.areaHeightToSize) adjustFrameHeightToTextSize(doc, textTargets);
            if (formatOptions.areaAutoSize) applyFrameAutoSize(textTargets);

            recordAppliedOptions(textTargets, formatOptions);
            if (formatOptions.colorCheck) colorCheckTargets(doc, textTargets, outputTexts);
            return "";
        } catch (e) {
            $.writeln("runVerticalTextConversion: " + e);
            return e + " (line " + e.line + ")";
        } finally {
            progress.close();
        }
    }

    // =========================================
    // 確認用の色分け（ColorCharactersByWidth から移植） / Check coloring (ported from ColorCharactersByWidth)
    // =========================================

    /**
     * 確認用の色分けのスウォッチを返す（無ければ CMYK のプロセスカラーで作る）
     * @param {Document} doc - 対象のドキュメント
     * @param {string} labelPath - スウォッチ名の LABELS のパス
     * @param {number[]} cmykValues - C, M, Y, K
     * @returns {Color} スウォッチ
     */
    function getCheckSwatch(doc, labelPath, cmykValues) {
        var swatchName = getLabel(labelPath);
        var namedColor = doc.colors.itemByName(swatchName);
        if (namedColor.isValid) return namedColor;
        return doc.colors.add({ name: swatchName, model: ColorModel.PROCESS, space: ColorSpace.CMYK, colorValue: cmykValues });
    }

    /**
     * 確認用の色分けの色を返す（ベースは［黒］、ほかは CHECK_* の値のスウォッチ）
     * @param {Document} doc - 対象のドキュメント
     * @returns {{baseColor: Swatch, fullWidthColor: Color, halfWidthColor: Color, glyphWidthColor: Color}} 色
     */
    function createCheckColors(doc) {
        return {
            baseColor: doc.swatches.itemByName("Black"),
            fullWidthColor: getCheckSwatch(doc, "swatch.fullWidth", CHECK_FULL_WIDTH_CMYK),
            halfWidthColor: getCheckSwatch(doc, "swatch.halfWidth", CHECK_HALF_WIDTH_CMYK),
            glyphWidthColor: getCheckSwatch(doc, "swatch.glyphWidth", CHECK_GLYPH_WIDTH_CMYK)
        };
    }

    /**
     * 等幅字形（等幅全角・半角・三分・四分字形）か
     * @param {AlternateGlyphForms} glyphForm - 字形
     * @returns {boolean} 等幅字形なら true
     */
    function isFixedWidthGlyphForm(glyphForm) {
        return glyphForm === AlternateGlyphForms.FULL_WIDTH_FORM || glyphForm === AlternateGlyphForms.MONOSPACED_HALF_WIDTH_FORM ||
            glyphForm === AlternateGlyphForms.THIRD_WIDTH_FORM || glyphForm === AlternateGlyphForms.QUARTER_WIDTH_FORM;
    }

    /**
     * 対象を塗り分ける（全体をベースの色にし、英数字と「!?」を全角は赤・半角は青、等幅字形の文字を緑）
     * @param {Object} textTarget - 対象
     * @param {string} outputText - 書き換え後の文字列
     * @param {{baseColor: Swatch, fullWidthColor: Color, halfWidthColor: Color, glyphWidthColor: Color}} checkColors - 塗る色
     * @returns {void}
     */
    function colorTargetCharacters(textTarget, outputText, checkColors) {
        var targetRange = getTargetRange(textTarget, outputText, 0, outputText.length);
        if (!targetRange) return;
        targetRange.fillColor = checkColors.baseColor;
        var widthPattern = /[０-９Ａ-Ｚａ-ｚ！？]+|[0-9A-Za-z!?]+/g;
        var widthMatch;
        while ((widthMatch = widthPattern.exec(outputText)) !== null) {
            var widthColor = FULL_WIDTH_PATTERN.test(widthMatch[0]) ? checkColors.fullWidthColor : checkColors.halfWidthColor;
            getTargetRange(textTarget, outputText, widthMatch.index, widthMatch[0].length).fillColor = widthColor;
        }
        /* 等幅字形は全角・半角より優先する。書式の範囲は対象の外へはみ出すことがあるので切り詰める
           Fixed-width glyphs take priority; style ranges can run past the target, so clip them */
        var rangeStart = textTarget.offset;
        var rangeEnd = rangeStart + toCharacterIndex(outputText, outputText.length);
        var styleRanges = targetRange.textStyleRanges.everyItem().getElements();
        for (var i = 0; i < styleRanges.length; i++) {
            if (!isFixedWidthGlyphForm(styleRanges[i].glyphForm)) continue;
            var spanStart = Math.max(styleRanges[i].index, rangeStart);
            var spanEnd = Math.min(styleRanges[i].index + styleRanges[i].length, rangeEnd);
            if (spanEnd > spanStart) textTarget.story.characters.itemByRange(spanStart, spanEnd - 1).fillColor = checkColors.glyphWidthColor;
        }
    }

    /**
     * 処理したテキストを色分けする（ColorCharactersByWidth と同じ塗り分け）
     * @param {Document} doc - 対象のドキュメント
     * @param {Array<Object>} textTargets - 処理した対象
     * @param {string[]} outputTexts - 対象ごとの書き換え後の文字列
     * @returns {void}
     */
    function colorCheckTargets(doc, textTargets, outputTexts) {
        var checkColors = createCheckColors(doc);
        for (var i = 0; i < textTargets.length; i++) colorTargetCharacters(textTargets[i], outputTexts[i], checkColors);
    }

    // =========================================
    // プログレスバー / Progress bar
    // =========================================

    /**
     * 進捗表示用のパレットウィンドウを生成して表示する（非モーダルなので処理中に更新できる）
     * 戻り値の set(fraction 0..1, message) で進捗を更新、close() で閉じる
     * @param {string} title - ウィンドウのタイトル
     * @returns {{set: function, close: function}} 進捗の更新と終了の操作
     */
    function createProgressWindow(title) {
        var progressWindow = new Window("palette", title);
        setupWindow(progressWindow, 8);
        var progressBar = progressWindow.add("progressbar", undefined, 0, 100);
        progressBar.preferredSize = [PROGRESS_WIDTH, 8];
        var progressLabel = progressWindow.add("statictext", undefined, "");
        progressLabel.preferredSize.width = PROGRESS_WIDTH;
        progressWindow.show();
        progressWindow.update();
        return {
            set: function (fraction, message) {
                var percent = Math.round(fraction * 100);
                progressBar.value = (percent < 0) ? 0 : (percent > 100 ? 100 : percent);
                if (message != null) { progressLabel.text = message; }
                progressWindow.update(); /* 同期ループ中でも再描画させる / force a repaint even inside a synchronous loop */
            },
            close: function () { progressWindow.close(); }
        };
    }

    /**
     * 確認の一覧で縦中横の箇所に付ける印を返す（字形を変えるときは字形名も入れる）
     * @param {boolean} glyphByLength - 字数に合わせた等幅字形にするか
     * @param {number} charCount - 縦中横の字数
     * @returns {string} 印
     */
    function getTcyPreviewMark(glyphByLength, charCount) {
        var glyphLabelKey = glyphByLength ? TCY_GLYPH_KEYS_BY_LENGTH[charCount] : undefined;
        if (glyphLabelKey === undefined) return getLabel("preview.tcyMark");
        return getLabel("preview.tcyGlyphMark", { glyph: getLabel("glyphShort." + glyphLabelKey) });
    }

    /**
     * 確認の一覧に出す行を作る（同じ変換はまとめて件数を付ける）
     * @param {Array<Object>} textTargets - 対象
     * @param {Object} formatOptions - 変換の設定
     * @returns {string[]} 一覧の行
     */
    function buildPreviewLines(textTargets, formatOptions) {
        var lineKeys = [];
        var lineCounts = {};

        /**
         * 一覧に1行足す（同じ行は件数を数える）
         * @param {string} lineText - 行の文字列
         * @returns {void}
         */
        function addPreviewLine(lineText) {
            if (lineCounts.hasOwnProperty(lineText)) {
                lineCounts[lineText]++;
            } else {
                lineCounts[lineText] = 1;
                lineKeys.push(lineText);
            }
        }

        for (var i = 0; i < textTargets.length; i++) {
            var noRotateRuns = getNoRotateRuns(textTargets[i].text, formatOptions);
            for (var r = 0; r < noRotateRuns.length; r++) {
                addPreviewLine(textTargets[i].text.substr(noRotateRuns[r].start, noRotateRuns[r].length) + getLabel("preview.noRotateMark"));
            }
            var changes = planVerticalText(textTargets[i].text, formatOptions).changes;
            for (var c = 0; c < changes.length; c++) {
                var change = changes[c];
                var lineText = (change.before === change.after) ? change.before : change.before + " → " + change.after;
                if (change.tcy) lineText += getTcyPreviewMark(formatOptions.tcyGlyphByLength, change.tcyLength);
                addPreviewLine(lineText);
            }
        }
        var previewLines = [];
        for (var k = 0; k < lineKeys.length && k < PREVIEW_MAX_LINES; k++) {
            previewLines.push(lineKeys[k] + (lineCounts[lineKeys[k]] > 1 ? "  ×" + lineCounts[lineKeys[k]] : ""));
        }
        return previewLines;
    }

    // ボタン行（再利用パーツ） / Button row (reusable)

    var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
    var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
    var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
    var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

    /**
     * ダイアログ下部のボタン行を作る。
     * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
     * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
     * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
     * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
     */
    function addButtonRow(parent, rowOptions) {
        var isCentered = !!(rowOptions && rowOptions.centered);
        var btnRowGroup = parent.add("group");
        btnRowGroup.orientation = "row";
        btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
        btnRowGroup.spacing = BUTTON_ROW_SPACING;

        if (isCentered) {
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
        }

        btnRowGroup.alignment = ["fill", "bottom"];

        var btnLeftGroup = btnRowGroup.add("group");
        btnLeftGroup.alignChildren = ["left", "center"];
        btnLeftGroup.spacing = BUTTON_ROW_SPACING;

        /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
        var spacer = btnRowGroup.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var btnRightGroup = btnRowGroup.add("group");
        btnRightGroup.alignChildren = ["right", "center"];
        btnRightGroup.spacing = BUTTON_ROW_SPACING;

        return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
    }

    /**
     * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
     * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
     * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
     * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
     * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
     * @returns {void}
     */
    function alignRightOnlyButtonRow(buttonRow) {
        if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
        var dialogWindow = buttonRow.rowGroup.window;
        dialogWindow.addEventListener("show", function () {
            if (!buttonRow.leftGroup) return;
            var btnRowGroup = buttonRow.rowGroup;
            /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
            if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
            /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
            btnRowGroup.remove(buttonRow.leftGroup);
            btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
            btnRowGroup.alignment = ["center", "bottom"];
            btnRowGroup.alignChildren = ["center", "center"];
            buttonRow.leftGroup = null;
            dialogWindow.layout.layout(true);
        });
    }

    // ボタン行（再利用パーツ）ここまで / End of the reusable button row

    // バージョン表示（再利用パーツ） / Version footer (reusable)

    var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
    var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
    var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
    var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
    var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
    var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

    /* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
       9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
       / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
         nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
    var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
    var VERSION_FOOTER_GLYPHS = {
        "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
        "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
        "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
        "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
        "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
        "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
        "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
        "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
        "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
        "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
        "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
        "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
        "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
        "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
        "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
        "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
        "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
        "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
        "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
        "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
        "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
        "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
        "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
        "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
        "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
        "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
        "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
        "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
        "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
        "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
        "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
        "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
        "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
        "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
        "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
        "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
        "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
        "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
        "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
        "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
        "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
        "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
        "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
        "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
        "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
        "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
        "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
        "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
        "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
        "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
        "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
        "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
        "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
        "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
        "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
        "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
        "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
        "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
        "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
        "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
        ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
        "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
        "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
        "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
        " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
    };

    /**
     * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
     * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
     * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
     * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
     * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
     */
    function addVersionFooter(targetWindow) {
        if (targetWindow.versionFooter) return null;

        /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
        var lastChild = targetWindow.children[targetWindow.children.length - 1];
        if (lastChild && lastChild.type === "group") {
            var rowMargins = lastChild.margins;
            lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
        }
        var windowMargins = targetWindow.margins;
        targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

        var footerGroup = targetWindow.add("group");
        footerGroup.orientation = "row";
        footerGroup.alignment = ["fill", "bottom"];
        footerGroup.alignChildren = ["left", "center"];
        footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

        /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
           左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
           / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
             or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
        var versionText = String(SCRIPT_VERSION);
        var leftCandidates = [versionText];
        if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
        var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
        versionCanvas.alignment = ["fill", "center"];
        bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
        var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
        brandCanvas.alignment = ["right", "center"];
        brandCanvas.maximumSize = brandCanvas.preferredSize;
        targetWindow.versionFooter = footerGroup;
        return versionCanvas;
    }

    /**
     * 文字列のすべての文字に字形があるかを返す
     * @param {string} dotText - 文字列
     * @returns {boolean} すべてあれば true
     */
    function hasVersionFooterGlyphs(dotText) {
        for (var i = 0; i < dotText.length; i++) {
            if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
        }
        return dotText.length > 0;
    }

    /**
     * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
     * @param {Group} parentGroup - 足す先
     * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
     * @returns {Group} 描くグループ
     */
    function addVersionFooterCanvas(parentGroup, dotTexts) {
        var dotCanvas = parentGroup.add("group");
        var shortestText = dotTexts[dotTexts.length - 1];
        dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
        dotCanvas.helpTip = dotTexts[0];
        dotCanvas.onDraw = function () {
            var availableWidth = this.size ? this.size.width : 0;
            var drawText = shortestText;
            for (var i = 0; i < dotTexts.length; i++) {
                if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                    drawText = dotTexts[i];
                    break;
                }
            }
            drawVersionFooterDots(this.graphics, drawText);
        };
        return dotCanvas;
    }

    /**
     * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
     * @param {string} versionText - 文字列
     * @returns {number} 幅（ドット）
     */
    function measureVersionFooterDots(versionText) {
        var dotCount = 0;
        for (var i = 0; i < versionText.length; i++) {
            var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
            if (!glyphRows) continue;
            if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
            dotCount += glyphRows[0].length;
        }
        return dotCount;
    }

    /**
     * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
     * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
     * @param {string} versionText - 文字列
     * @returns {void}
     */
    function drawVersionFooterDots(canvasGraphics, versionText) {
        var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
        var dotSize = VERSION_FOOTER_PIXEL_SIZE;
        var cursorDots = 0;
        canvasGraphics.newPath();
        for (var i = 0; i < versionText.length; i++) {
            var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
            if (!glyphRows) continue;
            if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
            for (var row = 0; row < glyphRows.length; row++) {
                var rowText = glyphRows[row];
                var runStart = -1;
                for (var col = 0; col <= rowText.length; col++) {
                    var isDot = col < rowText.length && rowText.charAt(col) === "#";
                    if (isDot && runStart < 0) runStart = col;
                    if (!isDot && runStart >= 0) {
                        canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                        runStart = -1;
                    }
                }
            }
            cursorDots += glyphRows[0].length;
        }
        canvasGraphics.fillPath(footerBrush);
    }

    // -----------------------------------------
    // このスクリプトについて / About this script
    // -----------------------------------------
    /* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
       この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
       Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
       and keeps its own labels and layout values so the part works on its own */

    var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
    var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
    /* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
       The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
    var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
    var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
    var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

    var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
    var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
    var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
    var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
    var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
    var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
    var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
    /* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
    var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
    var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
    var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
    var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

    var VERSION_INFO_LABELS = {
        dialog: {
            title: { ja: "このスクリプトについて", en: "About This Script" }
        },
        panel: {
            generalInfo: { ja: "基本情報", en: "General" },
            links: { ja: "リンク", en: "Links" }
        },
        fieldLabel: {
            scriptName: { ja: "スクリプト名", en: "Script Name" },
            scriptFeature: { ja: "機能", en: "Feature" },
            scriptVersion: { ja: "バージョン", en: "Version" }
        },
        button: {
            openReadme: { ja: "README", en: "README" },
            openSourceCode: { ja: "ソースコード", en: "Source Code" },
            openArticle: { ja: "記事（note）", en: "Article (note)" },
            revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
            revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
            close: { ja: "閉じる", en: "Close" }
        },
        tooltip: {
            versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
            copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
        },
        alert: {
            copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
        }
    };

    /**
     * VERSION_INFO_LABELS の文言を今の言語で返す
     * @param {Object} labelEntry - { ja, en }
     * @returns {string} 文言
     */
    function getVersionInfoLabel(labelEntry) {
        return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
    }

    /**
     * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
     * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
     * @returns {string} 値
     */
    function getVersionInfoValue(variableKey) {
        var infoValue;
        if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
        else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
        else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
        else if (variableKey === "readme") {
            if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
            else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
        }
        else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
        else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
        return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
    }

    /**
     * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
     * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
     * @returns {void}
     */
    function bindVersionInfoClick(versionCanvas) {
        versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
        /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
           Open on mouseup so the release does not land on the footer after the dialog closes */
        versionCanvas.addEventListener("mouseup", function () {
            showVersionInfoDialog(versionCanvas.window.type === "palette");
        });
    }

    /**
     * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
     * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
     * @returns {void}
     */
    function showVersionInfoDialog(isFromPalette) {
        var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
        infoDialog.orientation = "column";
        infoDialog.alignChildren = "fill";
        infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
        infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

        var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
        /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
        /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
        if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
            addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
        }
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
        alignVersionInfoLabels(infoPanel);

        /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
        var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
        var linkButtonRow = linksPanel.add("group");
        linkButtonRow.orientation = "row";
        linkButtonRow.alignment = ["left", "center"];
        linkButtonRow.alignChildren = ["left", "center"];
        linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
        addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

        /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
        var buttonRow = infoDialog.add("group");
        buttonRow.orientation = "row";
        buttonRow.alignment = ["fill", "bottom"];
        buttonRow.alignChildren = ["left", "center"];
        buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
        buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
        var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
        var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
        if (VERSION_INFO_SCRIPT_FILE.exists) {
            revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
            revealButton.onClick = function () {
                revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
                infoDialog.close();
            };
        } else {
            revealButton.enabled = false;
        }
        /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
        var buttonSpacer = buttonRow.add("group");
        buttonSpacer.alignment = ["fill", "fill"];
        buttonSpacer.minimumSize.width = 0;
        var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
        closeButton.alignment = ["right", "center"];
        /* return でも esc でも閉じる / Close with both Return and Esc */
        infoDialog.defaultElement = closeButton;
        infoDialog.cancelElement = closeButton;
        infoDialog.onShow = function () {
            pinVersionInfoCopyButton(infoPanel);
        };
        infoDialog.show();
    }

    /**
     * 「このスクリプトについて」のダイアログにパネルを足す
     * @param {Window} infoDialog - 足す先のダイアログ
     * @param {Object} titleEntry - パネル名の文言 { ja, en }
     * @returns {Panel} パネル
     */
    function addVersionInfoPanel(infoDialog, titleEntry) {
        var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
        infoPanel.orientation = "column";
        infoPanel.alignChildren = ["fill", "top"];
        infoPanel.alignment = "fill";
        infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
        infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
        return infoPanel;
    }

    /**
     * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
     * @param {Panel} infoPanel - 足す先のパネル
     * @param {Object} labelEntry - 項目名の文言 { ja, en }
     * @param {string} valueText - 表示する値
     * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
     * @returns {StaticText} 値の statictext
     */
    function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
        var infoRow = infoPanel.add("group");
        infoRow.orientation = "row";
        infoRow.alignment = ["fill", "center"];
        infoRow.alignChildren = ["left", "center"];
        infoRow.spacing = VERSION_INFO_ROW_SPACING;
        /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
        var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
        rowLabel.justify = "right";
        var valueLabel = infoRow.add("statictext", undefined, valueText);
        if (copyFromPalette === null) return valueLabel;
        /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
           A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
        var copySpacer = infoRow.add("group");
        copySpacer.alignment = ["fill", "fill"];
        copySpacer.minimumSize.width = 0;
        infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
        return valueLabel;
    }

    /**
     * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
     * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
     * @param {Panel} infoPanel - ［基本情報］パネル
     * @returns {void}
     */
    function pinVersionInfoCopyButton(infoPanel) {
        var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
        for (var i = 0; i < infoPanel.children.length; i++) {
            var infoRow = infoPanel.children[i];
            if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
            infoRow.size = [innerWidth, infoRow.size.height];
            infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
        }
    }

    /**
     * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
     * @param {Panel} infoPanel - 対象のパネル
     * @returns {void}
     */
    function alignVersionInfoLabels(infoPanel) {
        var rowLabels = [];
        var labelWidth = 0;
        for (var i = 0; i < infoPanel.children.length; i++) {
            var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
            rowLabels.push(rowLabel);
            labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
        }
        for (var j = 0; j < rowLabels.length; j++) {
            rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
        }
    }

    /**
     * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
     * @param {Window} infoDialog - ボタンを置くダイアログ
     * @param {Group} buttonGroup - 足す先のグループ
     * @param {Object} labelEntry - ボタンの文言 { ja, en }
     * @param {string} targetUrl - 開く URL（空ならディム表示）
     * @returns {void}
     */
    function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
        var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
        if (!targetUrl) {
            linkButton.enabled = false;
            return;
        }
        linkButton.helpTip = targetUrl;
        linkButton.onClick = function () {
            openVersionInfoUrl(targetUrl);
            infoDialog.close();
        };
    }

    /**
     * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
     * @param {Group} infoRow - 足す先の行
     * @param {StaticText} valueLabel - コピーする値の statictext
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
     * @returns {Group} ボタンとして使う group
     */
    function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
        var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
        var copyButton = infoRow.add("group");
        copyButton.preferredSize = [buttonSize, buttonSize];
        copyButton.minimumSize = [buttonSize, buttonSize];
        copyButton.maximumSize = [buttonSize, buttonSize];
        copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
        copyButton.isPressed = false;
        copyButton.isCopied = false;

        copyButton.onDraw = function () {
            var buttonGraphics = copyButton.graphics;
            var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
            buttonGraphics.newPath();
            buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
            buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
            buttonGraphics.newPath();
            buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
            buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
            if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
            else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
        };

        /**
         * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
         * @param {boolean} isPressed - 押下中なら true
         * @param {boolean} isCopied - コピー済みなら true
         * @returns {void}
         */
        function repaint(isPressed, isCopied) {
            if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
            copyButton.isPressed = isPressed;
            copyButton.isCopied = isCopied;
            copyButton.hide();
            copyButton.show();
        }
        copyButton.addEventListener("mousedown", function () { repaint(true, false); });
        copyButton.addEventListener("mouseup", function () {
            if (!copyButton.isPressed) return;
            var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
            repaint(false, hasCopied);
            if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
        });
        /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
        copyButton.addEventListener("mouseout", function () { repaint(false, false); });
        return copyButton;
    }

    /**
     * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
     * @param {ScriptUIGraphics} buttonGraphics - 描画先
     * @param {number} buttonSize - ボタンの一辺
     * @returns {void}
     */
    function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
        var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
        var sheetSize = 9;
        var offset = 3;
        var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
        var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
        var backLeft = frontLeft - offset;
        var backTop = frontTop - offset;
        /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
        buttonGraphics.newPath();
        buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
        buttonGraphics.lineTo(backLeft, backTop + sheetSize);
        buttonGraphics.lineTo(backLeft, backTop);
        buttonGraphics.lineTo(backLeft + sheetSize, backTop);
        buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
        buttonGraphics.strokePath(iconPen);
        buttonGraphics.newPath();
        buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
        buttonGraphics.strokePath(iconPen);
    }

    /**
     * コピーしたあとのチェックマークを描く
     * @param {ScriptUIGraphics} buttonGraphics - 描画先
     * @param {number} buttonSize - ボタンの一辺
     * @returns {void}
     */
    function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
        var center = buttonSize / 2;
        buttonGraphics.newPath();
        buttonGraphics.moveTo(center - 4.5, center);
        buttonGraphics.lineTo(center - 1.5, center + 3);
        buttonGraphics.lineTo(center + 4.5, center - 3.5);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
    }

    /**
     * 文字列をクリップボードにコピーする。
     * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
     * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
     * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
     * @param {string} copyText - コピーする文字列
     * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
     * @returns {boolean} コピーの操作まで進めたら true
     */
    function copyVersionInfoText(copyText, isFromPalette) {
        try {
            if (VERSION_INFO_IS_INDESIGN) {
                if (File.fs === "Windows") {
                    app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
                } else {
                    app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
                }
                return true;
            }
            var copyScript = buildVersionInfoCopyScript(copyText);
            if (!isFromPalette) return eval(copyScript) === true;
            var copyMessage = new BridgeTalk();
            copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
            copyMessage.body = copyScript;
            copyMessage.send();
            return true;
        } catch (e) {
            return false;
        }
    }

    /**
     * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
     * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
     * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
     * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
     * @param {string} copyText - コピーする文字列
     * @returns {string} 実行すると true / false を返すスクリプト
     */
    function buildVersionInfoCopyScript(copyText) {
        return [
            "(function (copyText) {",
            "    var usingTempDoc = (app.documents.length === 0);",
            "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
            "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
            "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
            "    var tempLayer = null;",
            "    var hasCopied = false;",
            "    try {",
            "        tempLayer = targetDoc.layers.add();",
            "        var tempFrame = tempLayer.textFrames.add();",
            "        tempFrame.contents = copyText;",
            "        app.redraw();",
            "        app.executeMenuCommand('deselectall');",
            "        tempFrame.selected = true;",
            "        app.redraw();",
            "        app.executeMenuCommand('copy');",
            "        app.redraw();",
            "        hasCopied = true;",
            "    } catch (e) { }",
            "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
            "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
            "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
            "    targetDoc.selection = null;",
            "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
            "    app.redraw();",
            "    return hasCopied;",
            "})(" + quoteVersionInfoString(copyText) + ");"
        ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
    }

    /**
     * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
     * @param {string} sourceText - 文字列
     * @returns {string} "…" の形のリテラル
     */
    function quoteVersionInfoString(sourceText) {
        return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
    }

    /**
     * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
     * @param {File} scriptFile - 表示するファイル
     * @returns {void}
     */
    function revealVersionInfoScriptFile(scriptFile) {
        /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
        var hasRevealApp = (File.fs === "Macintosh")
            && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
        /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
        if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
        /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
        scriptFile.parent.execute();
    }

    /**
     * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
     * @param {string} targetPath - 絶対パス
     * @returns {boolean} 書き出せたら true
     */
    function writeVersionInfoRevealPath(targetPath) {
        var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
        pathFile.encoding = "UTF-8";
        pathFile.lineFeed = "Unix";
        if (!pathFile.open("w")) return false;
        var hasWritten = pathFile.write(targetPath);
        pathFile.close();
        return hasWritten;
    }

    /**
     * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
     * @param {string} targetUrl - 開く URL
     * @returns {void}
     */
    function openVersionInfoUrl(targetUrl) {
        var isMac = (File.fs === "Macintosh");
        var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
        shortcutFile.encoding = "UTF-8";
        shortcutFile.open("w");
        if (isMac) {
            var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
            shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
                + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
        } else {
            shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
        }
        shortcutFile.close();
        shortcutFile.execute();
    }

    // バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

    // =========================================
    // プリセット / Presets
    // =========================================
    var presetSettingsStore = createSettingsStore(SCRIPT_NAME + "Presets", "persistent");

    /**
     * 保存したプリセットを返す
     * @returns {Object} プリセット名をキーにした設定の集まり（書き換えても保存されない）
     */
    function loadPresetMap() {
        return presetSettingsStore.load({});
    }

    /**
     * 保存したプリセットの名前を、名前順で返す
     * @returns {string[]} プリセット名
     */
    function getPresetNames() {
        var presetMap = loadPresetMap();
        var presetNames = [];
        for (var presetName in presetMap) {
            if (presetMap.hasOwnProperty(presetName)) presetNames.push(presetName);
        }
        presetNames.sort();
        return presetNames;
    }

    /**
     * 名前が組み込みのプリセットと同じか
     * @param {string} presetName - プリセット名
     * @returns {boolean} 同じなら true
     */
    function isBuiltinPresetName(presetName) {
        for (var i = 0; i < BUILTIN_PRESETS.length; i++) {
            if (getLabel("preset.builtin." + BUILTIN_PRESETS[i].labelKey) === presetName) return true;
        }
        return false;
    }

    /**
     * 既定値にプリセットの値を重ねた設定を返す
     * @param {Object} presetData - プリセットの値（一部だけでもよい）
     * @returns {Object} DEFAULT_SETTINGS と同じ形
     */
    function mergePresetData(presetData) {
        var mergedSettings = {};
        for (var settingKey in DEFAULT_SETTINGS) {
            if (!DEFAULT_SETTINGS.hasOwnProperty(settingKey)) continue;
            var hasValue = presetData.hasOwnProperty(settingKey) && typeof presetData[settingKey] === typeof DEFAULT_SETTINGS[settingKey];
            mergedSettings[settingKey] = hasValue ? presetData[settingKey] : DEFAULT_SETTINGS[settingKey];
        }
        return mergedSettings;
    }

    /**
     * プリセット名を尋ねる
     * @param {string} initialName - 入力欄に入れておく名前
     * @returns {string|null} プリセット名。キャンセルか空なら null
     */
    function showPresetNameDialog(initialName) {
        var nameDialog = new Window("dialog", getLabel("preset.saveTitle"));
        setupWindow(nameDialog);
        var nameRow = nameDialog.add("group");
        setupRow(nameRow, ["left", "center"], 8);
        nameRow.add("statictext", undefined, labelText("preset.name"));
        var nameInput = nameRow.add("edittext", undefined, initialName);
        nameInput.helpTip = getLabel("tooltip.presetName");
        nameInput.characters = PRESET_NAME_CHARS;
        nameInput.active = true;
        var buttonRow = addButtonRow(nameDialog);
        var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
        var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
        alignRightOnlyButtonRow(buttonRow);
        btnCancel.preferredSize.width = BUTTON_WIDTH;
        btnOK.preferredSize.width = BUTTON_WIDTH;
        if (nameDialog.show() !== 1) return null;
        var presetName = nameInput.text.replace(/^\s+|\s+$/g, "");
        if (!presetName || presetName === getLabel("preset.placeholder")) return null;
        if (isBuiltinPresetName(presetName)) {
            alert(getLabel("alert.presetNameTaken"));
            return null;
        }
        return presetName;
    }

    /**
     * 今の設定を名前を付けて保存する（同じ名前は確認してから上書き）
     * @param {Object} currentSettings - readDialogOptions() の戻り値
     * @param {string} initialName - 入力欄に入れておく名前
     * @returns {string|null} 保存したプリセット名。保存しなかったら null
     */
    function saveCurrentPreset(currentSettings, initialName) {
        var presetName = showPresetNameDialog(initialName);
        if (!presetName) return null;
        var presetMap = loadPresetMap();
        if (presetMap.hasOwnProperty(presetName) && !confirm(getLabel("confirm.presetOverwrite", { name: presetName }), true)) return null;
        presetMap[presetName] = currentSettings;
        if (!presetSettingsStore.save(presetMap)) {
            alert(getLabel("alert.presetSaveFailed"));
            return null;
        }
        return presetName;
    }

    /**
     * 保存したプリセットを確認してから削除する
     * @param {string} presetName - プリセット名
     * @returns {boolean} 削除したら true
     */
    function deletePreset(presetName) {
        if (!confirm(getLabel("confirm.presetDelete", { name: presetName }), true)) return false;
        var presetMap = loadPresetMap();
        delete presetMap[presetName];
        if (!presetSettingsStore.save(presetMap)) {
            alert(getLabel("alert.presetSaveFailed"));
            return false;
        }
        return true;
    }

    // =========================================
    // ダイアログ / Dialog
    // =========================================

    /**
     * 「☑［数値］文言」の行で、数値欄のあとに置く文言を追加する（クリックでもチェックボックスを切り替える）
     * @param {Group} row - 追加先の行
     * @param {string} labelPath - 文言の LABELS のパス
     * @param {Checkbox} ownerCheckbox - 対応するチェックボックス
     * @returns {StaticText} 文言
     */
    function addCheckboxSuffix(row, labelPath, ownerCheckbox) {
        var suffixText = row.add("statictext", undefined, getLabel(labelPath));
        suffixText.helpTip = ownerCheckbox.helpTip;
        suffixText.addEventListener("click", function () {
            if (!ownerCheckbox.enabled) return;
            ownerCheckbox.value = !ownerCheckbox.value;
            if (ownerCheckbox.onClick) ownerCheckbox.onClick();
        });
        return suffixText;
    }

    /**
     * チェックボックスを追加する
     * @param {Group|Panel} parent - 追加先
     * @param {string} labelPath - LABELS のパス
     * @param {boolean} value - 初期値
     * @returns {Checkbox} チェックボックス
     */
    function addOptionCheckbox(parent, labelPath, value) {
        var optionCheckbox = parent.add("checkbox", undefined, getLabel(labelPath));
        optionCheckbox.value = value;
        /* 説明があればツールチップに / Show the description as a tooltip when there is one */
        var tooltipEntry = LABELS.tooltip[labelPath.split(".")[1]];
        if (tooltipEntry) optionCheckbox.helpTip = getLabel(tooltipEntry);
        return optionCheckbox;
    }

    /**
     * 字下げしたグループ（親のチェックボックスに従う項目用）を追加する
     * @param {Group|Panel} parent - 追加先
     * @returns {Group} グループ
     */
    function addIndentedGroup(parent) {
        var indentedGroup = parent.add("group");
        indentedGroup.orientation = "column";
        indentedGroup.alignChildren = ["left", "top"];
        indentedGroup.margins = [OPTION_INDENT, 0, 0, 0];
        indentedGroup.spacing = 6;
        return indentedGroup;
    }

    /* 数値欄の∧∨・↑↓で呼ぶ処理（bindDialogEvents で入れる） / Handler for the steppers and arrow keys (set in bindDialogEvents) */
    var digitStepHandler = null;

    /**
     * 数値欄の∧∨・↑↓で増減したことを知らせる
     * @param {EditText} numberInput - 増減した入力欄
     * @returns {void}
     */
    function notifyDigitStep(numberInput) {
        if (digitStepHandler) digitStepHandler(numberInput);
    }

    /**
     * 「項目名 : [ドロップダウン]」の行を追加する
     * @param {Panel} parent - 追加先
     * @param {string} labelPath - 項目名の LABELS のパス
     * @param {Object[]} itemLabels - 選択肢の { ja, en } の配列
     * @param {string} tooltipPath - ツールチップの LABELS のパス
     * @param {number} [labelWidth] - 項目名の幅（右揃え）。省くと文字に合わせる
     * @returns {DropDownList} ドロップダウン
     */
    function addLabeledDropdown(parent, labelPath, itemLabels, tooltipPath, labelWidth) {
        var dropdownRow = parent.add("group");
        setupRow(dropdownRow, ["left", "center"], 8);
        var rowLabel = dropdownRow.add("statictext", undefined, labelText(labelPath));
        if (labelWidth) {
            rowLabel.preferredSize.width = labelWidth;
            rowLabel.justify = "right";
        }
        var optionDropdown = dropdownRow.add("dropdownlist", undefined, []);
        for (var i = 0; i < itemLabels.length; i++) optionDropdown.add("item", getLabel(itemLabels[i]));
        optionDropdown.helpTip = getLabel(tooltipPath);
        return optionDropdown;
    }

    /**
     * 配列の中で値が一致する位置を返す（ES3 に Array.indexOf は無い）
     * @param {Array} values - 配列
     * @param {*} targetValue - 探す値
     * @returns {number} 位置（無ければ -1）
     */
    function indexOfValue(values, targetValue) {
        for (var i = 0; i < values.length; i++) {
            if (values[i] === targetValue) return i;
        }
        return -1;
    }

    /**
     * 禁則処理セット・文字組みアキ量設定の名前を並べる
     * @param {Object} tables - doc.kinsokuTables か doc.mojikumiTables
     * @returns {string[]} 名前（ドキュメントの順）
     */
    function listTableNames(tables) {
        var tableNames = [];
        for (var i = 0; i < tables.length; i++) tableNames.push(tables[i].name);
        return tableNames;
    }

    /**
     * 禁則・文字組みのドロップダウンで選ぶ位置を返す（0 は「なし」）
     * @param {string[]} tableNames - listTableNames() の戻り値
     * @param {string} tableName - 設定の名前（空文字は組み込みの既定、TABLE_NONE は「なし」）
     * @param {number} defaultIndex - 組み込みの既定の tableNames の位置
     * @returns {number} ドロップダウンの位置
     */
    function getTableItemIndex(tableNames, tableName, defaultIndex) {
        if (tableName === TABLE_NONE) return 0;
        var nameIndex = (tableName === "") ? -1 : indexOfValue(tableNames, tableName);
        if (nameIndex < 0) nameIndex = Math.min(defaultIndex, tableNames.length - 1);
        return nameIndex + 1;
    }

    /**
     * 禁則・文字組みのドロップダウンの選択を設定の名前にする
     * @param {DropDownList} tableDropdown - ドロップダウン
     * @param {string[]} tableNames - listTableNames() の戻り値
     * @returns {string} 名前（「なし」は TABLE_NONE）
     */
    function readTableName(tableDropdown, tableNames) {
        var itemIndex = tableDropdown.selection ? tableDropdown.selection.index : 0;
        return (itemIndex === 0) ? TABLE_NONE : tableNames[itemIndex - 1];
    }

    /**
     * 「桁数 : [最小] 〜 [最大]」の行を追加する
     * @param {Group|Panel} parent - 追加先
     * @returns {{minInput: EditText, maxInput: EditText}} 入力欄
     */
    function addDigitRangeRow(parent) {
        var rangeRow = parent.add("group");
        setupRow(rangeRow, ["left", "center"], 4);
        var minInput = addSteppedField(rangeRow, { label: labelText("fieldLabel.digits"), text: "", characters: 3, step: 1, min: 1, max: 99, integer: true, onStep: notifyDigitStep });
        var maxInput = addSteppedField(rangeRow, { label: getLabel("fieldLabel.rangeTo"), text: "", characters: 3, step: 1, min: 1, max: 99, integer: true, onStep: notifyDigitStep });
        return { minInput: minInput, maxInput: maxInput };
    }

    /**
     * 縦に並べる列のグループを追加する
     * @param {Group|Window} parent - 追加先
     * @returns {Group} 列のグループ
     */
    function addLayoutColumn(parent) {
        var layoutColumn = parent.add("group");
        layoutColumn.orientation = "column";
        layoutColumn.alignChildren = ["fill", "top"];
        layoutColumn.spacing = WINDOW_SPACING;
        return layoutColumn;
    }

    /**
     * 最上部の行を追加する（左：簡易／詳細／ウィザード、右：プリセットのドロップダウン・保存・削除）
     * @param {Window} parent - 追加先のダイアログ
     * @param {Object} dialogControls - コントロールを入れるオブジェクト
     * @param {string} dialogMode - "simple" / "detail" / "wizard"
     * @returns {void}
     */
    function buildTopRow(parent, dialogControls, dialogMode) {
        var topRow = parent.add("group");
        topRow.orientation = "row";
        topRow.alignment = ["fill", "top"];
        topRow.spacing = 8;

        var modeGroup = topRow.add("group");
        setupRow(modeGroup, ["left", "center"], 8);
        dialogControls.modeSimpleRadio = modeGroup.add("radiobutton", undefined, getLabel("radio.modeSimple"));
        dialogControls.modeDetailRadio = modeGroup.add("radiobutton", undefined, getLabel("radio.modeDetail"));
        dialogControls.modeWizardRadio = modeGroup.add("radiobutton", undefined, getLabel("radio.modeWizard"));
        dialogControls.modeSimpleRadio.helpTip = getLabel("tooltip.modeSimple");
        dialogControls.modeDetailRadio.helpTip = getLabel("tooltip.modeDetail");
        dialogControls.modeWizardRadio.helpTip = getLabel("tooltip.modeWizard");
        dialogControls.modeSimpleRadio.value = (dialogMode === "simple");
        dialogControls.modeDetailRadio.value = (dialogMode === "detail");
        dialogControls.modeWizardRadio.value = (dialogMode === "wizard");

        /* 余りの幅を吸って、プリセットを右端に寄せる / Absorbs the extra width so the presets sit at the right edge */
        var spacer = topRow.add("group");
        spacer.alignment = ["fill", "fill"];
        spacer.minimumSize.width = 0;

        var presetRow = topRow.add("group");
        setupRow(presetRow, ["right", "center"], 8);
        presetRow.add("statictext", undefined, labelText("preset.label"));
        dialogControls.presetDropdown = presetRow.add("dropdownlist", undefined, []);
        dialogControls.presetDropdown.helpTip = getLabel("tooltip.preset");
        dialogControls.presetDropdown.preferredSize.width = PRESET_DROPDOWN_WIDTH;
        dialogControls.presetSaveIcon = addIconButton(presetRow, PRESET_ICON_SIZE, drawSaveIcon);
        dialogControls.presetSaveIcon.helpTip = getLabel("tooltip.presetSave");
        dialogControls.presetDeleteIcon = addIconButton(presetRow, PRESET_ICON_SIZE, drawTrashIcon);
        dialogControls.presetDeleteIcon.helpTip = getLabel("tooltip.presetDelete");
    }

    /**
     * 「欧文回転・縦中横」パネルを追加する（簡易モードは数字の縦中横と等幅字形まで）
     * @param {Group} parent - 追加先
     * @param {Object} dialogControls - コントロールを入れるオブジェクト
     * @param {Object} settings - 初期値
     * @param {boolean} isDetail - 詳細モードか
     * @returns {void}
     */
    function buildTcyPanel(parent, dialogControls, settings, isDetail) {
        var tcyPanel = parent.add("panel", undefined, getLabel("panel.rotateTcy"));
        setupPanel(tcyPanel, 6);
        dialogControls.rotateRoman = addOptionCheckbox(tcyPanel, "checkbox.rotateRoman", settings.rotateRoman);
        /* ☑［5］文字以上の欧文は除く / Skip Roman text of [5] or more characters */
        var rotateSkipRow = addIndentedGroup(tcyPanel).add("group");
        setupRow(rotateSkipRow, ["left", "center"], 4);
        dialogControls.rotateSkipLongLatin = addOptionCheckbox(rotateSkipRow, "checkbox.rotateSkipLongLatin", settings.rotateSkipLongLatin);
        dialogControls.rotateSkipMinInput = addSteppedField(rotateSkipRow, { label: "", text: "", characters: 3, step: 1, min: 2, max: 99, integer: true, onStep: notifyDigitStep });
        dialogControls.rotateSkipSuffix = addCheckboxSuffix(rotateSkipRow, "fieldLabel.rotateSkipSuffix", dialogControls.rotateSkipLongLatin);
        dialogControls.tcyNumbers = addOptionCheckbox(tcyPanel, "checkbox.tcyNumbers", settings.tcyNumbers);
        /* 桁数は次の行に字下げして並べる / Digit counts go on the next, indented row */
        var tcyNumberGroup = addIndentedGroup(tcyPanel);
        var tcyDigitRow = tcyNumberGroup.add("group");
        setupRow(tcyDigitRow, ["left", "center"], 8);
        dialogControls.tcyDigits2 = addOptionCheckbox(tcyDigitRow, "checkbox.tcyDigits2", settings.tcyDigits2);
        dialogControls.tcyDigits3 = addOptionCheckbox(tcyDigitRow, "checkbox.tcyDigits3", settings.tcyDigits3);
        dialogControls.tcyDigits4 = addOptionCheckbox(tcyDigitRow, "checkbox.tcyDigits4", settings.tcyDigits4);
        if (isDetail) {
            dialogControls.tcyExcludeAdjacent = addOptionCheckbox(tcyNumberGroup, "checkbox.tcyExcludeAdjacent", settings.tcyExcludeAdjacent);
            dialogControls.tcyCapitals = addOptionCheckbox(tcyPanel, "checkbox.tcyCapitals", settings.tcyCapitals);
            dialogControls.tcyExclamation = addOptionCheckbox(tcyPanel, "checkbox.tcyExclamation", settings.tcyExclamation);
        }
        dialogControls.tcyGlyphByLength = addOptionCheckbox(tcyPanel, "checkbox.tcyGlyphByLength", settings.tcyGlyphByLength);
    }

    /**
     * 「文字の変換」パネルを追加する（パネルの中は1列）。
     * 簡易モードは桁区切り・小数点・1文字の英字・1桁の数字だけ（「数字」パネルを作らない）
     * @param {Group} parent - 追加先の列
     * @param {Object} dialogControls - コントロールを入れるオブジェクト
     * @param {Object} settings - 初期値
     * @param {boolean} isDetail - 詳細モードか
     * @returns {void}
     */
    function buildReplacePanel(parent, dialogControls, settings, isDetail) {
        var replacePanel = parent.add("panel", undefined, getLabel("panel.replace"));
        setupPanel(replacePanel, 6);
        dialogControls.commaDropdown = addLabeledDropdown(replacePanel, "fieldLabel.comma", LABELS.dropdown.comma, "tooltip.comma");
        dialogControls.periodToNakaguro = addOptionCheckbox(replacePanel, "checkbox.periodToNakaguro", settings.periodToNakaguro);
        if (isDetail) {
            dialogControls.rangeToWave = addOptionCheckbox(replacePanel, "checkbox.rangeToWave", settings.rangeToWave);
            dialogControls.halfwidthAlnum = addOptionCheckbox(replacePanel, "checkbox.halfwidthAlnum", settings.halfwidthAlnum);
            dialogControls.symbolsFullwidth = addOptionCheckbox(replacePanel, "checkbox.symbolsFullwidth", settings.symbolsFullwidth);
            dialogControls.quotesToChonchon = addOptionCheckbox(replacePanel, "checkbox.quotesToChonchon", settings.quotesToChonchon);
            dialogControls.exclamFullwidth = addOptionCheckbox(replacePanel, "checkbox.exclamFullwidth", settings.exclamFullwidth);
        }
        dialogControls.singleLetterFullwidth = addOptionCheckbox(replacePanel, "checkbox.singleLetterFullwidth", settings.singleLetterFullwidth);
        dialogControls.shortCapsFullwidth = addOptionCheckbox(replacePanel, "checkbox.shortCapsFullwidth", settings.shortCapsFullwidth);
        if (isDetail) {
            /* ☑［4］文字以下の英単語を全角に / Full-width for words of [4] or fewer letters */
            var shortWordRow = replacePanel.add("group");
            setupRow(shortWordRow, ["left", "center"], 4);
            dialogControls.shortWordFullwidth = addOptionCheckbox(shortWordRow, "checkbox.shortWordFullwidth", settings.shortWordFullwidth);
            dialogControls.shortWordMaxInput = addSteppedField(shortWordRow, { label: "", text: "", characters: 3, step: 1, min: 1, max: 98, integer: true, onStep: notifyDigitStep });
            addCheckboxSuffix(shortWordRow, "fieldLabel.shortWordSuffix", dialogControls.shortWordFullwidth);
        }
        /* 簡易モードは「数字」パネルを作らず、1桁の全角もここに入れる / The simple mode has no Numbers panel; single digits go here */
        if (!isDetail) {
            dialogControls.singleDigitFullwidth = addOptionCheckbox(replacePanel, "checkbox.singleDigitFullwidth", settings.singleDigitFullwidth);
            dialogControls.longDigitsFullwidth = addOptionCheckbox(replacePanel, "checkbox.longDigitsFullwidth", settings.longDigitsFullwidth);
            dialogControls.nonTcyDigitsFullwidth = addOptionCheckbox(replacePanel, "checkbox.nonTcyDigitsFullwidth", settings.nonTcyDigitsFullwidth);
        }
    }

    /**
     * 「数字」パネル（詳細モードだけ）を追加する
     * @param {Group} parent - 追加先
     * @param {Object} dialogControls - コントロールを入れるオブジェクト
     * @param {Object} settings - 初期値
     * @returns {void}
     */
    function buildNumberPanel(parent, dialogControls, settings) {
        var numberPanel = parent.add("panel", undefined, getLabel("panel.numbers"));
        setupPanel(numberPanel, 6);
        dialogControls.singleDigitFullwidth = addOptionCheckbox(numberPanel, "checkbox.singleDigitFullwidth", settings.singleDigitFullwidth);
        dialogControls.longDigitsFullwidth = addOptionCheckbox(numberPanel, "checkbox.longDigitsFullwidth", settings.longDigitsFullwidth);
        dialogControls.nonTcyDigitsFullwidth = addOptionCheckbox(numberPanel, "checkbox.nonTcyDigitsFullwidth", settings.nonTcyDigitsFullwidth);
        dialogControls.unitsKumimoji = addOptionCheckbox(numberPanel, "checkbox.unitsKumimoji", settings.unitsKumimoji);
        dialogControls.japaneseEra = addOptionCheckbox(numberPanel, "checkbox.japaneseEra", settings.japaneseEra);
        dialogControls.kanjiToArabic = addOptionCheckbox(numberPanel, "checkbox.kanjiToArabic", settings.kanjiToArabic);
        dialogControls.kanji = addOptionCheckbox(numberPanel, "checkbox.kanji", settings.kanji);
        var kanjiGroup = addIndentedGroup(numberPanel);
        var kanjiRange = addDigitRangeRow(kanjiGroup);
        dialogControls.kanjiMinInput = kanjiRange.minInput;
        dialogControls.kanjiMaxInput = kanjiRange.maxInput;
        /* ラジオは同じ親の中だけ排他になるので、1つのグループに縦に並べる / Radios are exclusive only within one parent; stack them vertically */
        var kanjiStyleGroup = kanjiGroup.add("group");
        kanjiStyleGroup.orientation = "column";
        kanjiStyleGroup.alignChildren = ["left", "top"];
        kanjiStyleGroup.spacing = 6;
        dialogControls.kanjiDigitRadio = kanjiStyleGroup.add("radiobutton", undefined, getLabel("radio.kanjiDigit"));
        dialogControls.kanjiPositionalRadio = kanjiStyleGroup.add("radiobutton", undefined, getLabel("radio.kanjiPositional"));
        dialogControls.kanjiDigitRadio.helpTip = getLabel("tooltip.kanjiDigit");
        dialogControls.kanjiPositionalRadio.helpTip = getLabel("tooltip.kanjiPositional");
        dialogControls.kanjiLargeUnitsRadio = kanjiStyleGroup.add("radiobutton", undefined, getLabel("radio.kanjiLargeUnits"));
        dialogControls.kanjiLargeUnitsRadio.helpTip = getLabel("tooltip.kanjiLargeUnits");
        var kanjiDetailRow = kanjiGroup.add("group");
        setupRow(kanjiDetailRow, ["left", "center"], 8);
        dialogControls.kanjiZeroRei = addOptionCheckbox(kanjiDetailRow, "checkbox.kanjiZeroRei", settings.kanjiZeroRei);
        dialogControls.kanjiIchiSen = addOptionCheckbox(kanjiDetailRow, "checkbox.kanjiIchiSen", settings.kanjiIchiSen);
        dialogControls.phoneHyphenDropdown = addLabeledDropdown(numberPanel, "fieldLabel.phoneHyphen", LABELS.dropdown.phoneHyphen, "tooltip.phoneHyphen");
    }

    /**
     * 「文字・段落」パネル（詳細モードだけ）を追加する
     * @param {Group} parent - 追加先
     * @param {Object} dialogControls - コントロールを入れるオブジェクト
     * @param {Object} settings - 初期値
     * @returns {void}
     */
    function buildParagraphPanel(parent, dialogControls, settings) {
        var paragraphPanel = parent.add("panel", undefined, getLabel("panel.paragraph"));
        setupPanel(paragraphPanel, 6);
        /* 「なし」のあとにドキュメントの禁則処理セット・文字組みアキ量設定（組み込みとカスタム）を並べる / "None", then the document's sets (built-in and custom) */
        dialogControls.kinsokuNames = listTableNames(app.activeDocument.kinsokuTables);
        dialogControls.mojikumiNames = listTableNames(app.activeDocument.mojikumiTables);
        dialogControls.kinsokuDropdown = addLabeledDropdown(paragraphPanel, "fieldLabel.kinsoku", [LABELS.dropdown.none], "tooltip.kinsoku", PARAGRAPH_LABEL_WIDTH);
        dialogControls.mojikumiDropdown = addLabeledDropdown(paragraphPanel, "fieldLabel.mojikumi", [LABELS.dropdown.none], "tooltip.mojikumi", PARAGRAPH_LABEL_WIDTH);
        for (var k = 0; k < dialogControls.kinsokuNames.length; k++) dialogControls.kinsokuDropdown.add("item", dialogControls.kinsokuNames[k]);
        for (var m = 0; m < dialogControls.mojikumiNames.length; m++) dialogControls.mojikumiDropdown.add("item", dialogControls.mojikumiNames[m]);
        dialogControls.kinsokuDropdown.preferredSize.width = PARAGRAPH_DROPDOWN_WIDTH;
        dialogControls.mojikumiDropdown.preferredSize.width = PARAGRAPH_DROPDOWN_WIDTH;
        /* 行送り : [150%]（自動行送りの％） / Leading: [150%] (auto-leading percentage) */
        dialogControls.leadingInput = addSteppedField(paragraphPanel, {
            label: labelText("fieldLabel.leading"), labelWidth: PARAGRAPH_LABEL_WIDTH,
            text: "", characters: 5, step: 1, min: 50, max: 500, integer: true, unit: "%"
        });
        dialogControls.leadingInput.helpTip = getLabel("tooltip.leading");
        /* チェックボックスはドロップダウン・行送りの欄と間を空ける / Keep a gap between the fields and the checkboxes */
        var paragraphOptionGroup = paragraphPanel.add("group");
        paragraphOptionGroup.orientation = "column";
        paragraphOptionGroup.alignChildren = ["left", "top"];
        paragraphOptionGroup.spacing = 6;
        paragraphOptionGroup.margins = [0, PARAGRAPH_OPTION_TOP_MARGIN, 0, 0];
        /* 文字の書き換えではなく OpenType の書式なので、ここに置く / An OpenType setting, not a rewrite, so it lives here */
        dialogControls.proportionalFullwidthLatin = addOptionCheckbox(paragraphOptionGroup, "checkbox.proportionalFullwidthLatin", settings.proportionalFullwidthLatin);
        dialogControls.ichiNoTightening = addOptionCheckbox(paragraphOptionGroup, "checkbox.ichiNoTightening", settings.ichiNoTightening);
        dialogControls.areaHeightToSize = addOptionCheckbox(paragraphOptionGroup, "checkbox.areaHeightToSize", settings.areaHeightToSize);
        dialogControls.areaAutoSize = addOptionCheckbox(paragraphOptionGroup, "checkbox.areaAutoSize", settings.areaAutoSize);
    }

    /**
     * 「確認用の色分け」パネル（詳細モードだけ）を追加する。色は CHECK_* の変数で決め、ここでは ON/OFF だけ
     * @param {Group} parent - 追加先の列
     * @param {Object} dialogControls - コントロールを入れるオブジェクト
     * @param {Object} settings - 初期値
     * @returns {void}
     */
    function buildColorCheckPanel(parent, dialogControls, settings) {
        var colorCheckPanel = parent.add("panel", undefined, getLabel("panel.colorCheck"));
        setupPanel(colorCheckPanel, 6);
        dialogControls.colorCheck = addOptionCheckbox(colorCheckPanel, "checkbox.colorCheck", settings.colorCheck);
    }

    /**
     * ウィザードの「やりたいこと」パネルを追加する（WIZARD_GOALS の順にチェックボックスを縦に並べる）
     * @param {Window} parent - 追加先のダイアログ
     * @param {Object} dialogControls - コントロールを入れるオブジェクト
     * @param {Object} settings - 初期値（wizardGoals を見る）
     * @returns {void}
     */
    function buildWizardPanel(parent, dialogControls, settings) {
        var wizardPanel = parent.add("panel", undefined, getLabel("panel.wizard"));
        setupPanel(wizardPanel, 6);
        var savedGoals = settings.wizardGoals || DEFAULT_SETTINGS.wizardGoals;
        dialogControls.wizardGoalChecks = {};
        for (var i = 0; i < WIZARD_GOALS.length; i++) {
            var goalKey = WIZARD_GOALS[i].key;
            var goalCheckbox = wizardPanel.add("checkbox", undefined, getLabel("wizard." + goalKey + ".label"));
            goalCheckbox.helpTip = getLabel("wizard." + goalKey + ".tip");
            goalCheckbox.value = (savedGoals[goalKey] === true);
            dialogControls.wizardGoalChecks[goalKey] = goalCheckbox;
        }
        /* プリセットは詳細の項目に読み込むものなので、ウィザードでは使わない / Presets fill the detailed options, so they are off in the wizard */
        dialogControls.presetDropdown.enabled = false;
        setIconButtonEnabled(dialogControls.presetSaveIcon, false);
        setIconButtonEnabled(dialogControls.presetDeleteIcon, false);
    }

    /**
     * ウィザードのイベントをつなぐ（option＋クリックでまとめて切り替え、漢数字で縦中横・全角の数字を無効に、何も使わないときは OK と確認を無効に）
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @returns {void}
     */
    function bindWizardEvents(dialogControls) {
        for (var i = 0; i < WIZARD_GOALS.length; i++) {
            dialogControls.wizardGoalChecks[WIZARD_GOALS[i].key].onClick = function () {
                setAllWizardGoalsOnOption(this);
                updateWizardEnabledStates();
            };
        }
        updateWizardEnabledStates();

        /**
         * overriddenBy のやりたいことがオンなら無効にし、使えるものが無ければ OK と［変換の確認...］を無効にする
         * @returns {void}
         */
        function updateWizardEnabledStates() {
            var wizardGoals = readWizardGoals(dialogControls);
            for (var j = 0; j < WIZARD_GOALS.length; j++) {
                var overriddenBy = WIZARD_GOALS[j].overriddenBy;
                dialogControls.wizardGoalChecks[WIZARD_GOALS[j].key].enabled = !(overriddenBy && wizardGoals[overriddenBy]);
            }
            var canRun = hasActiveWizardGoal(wizardGoals);
            dialogControls.btnOK.enabled = canRun;
            dialogControls.btnPreview.enabled = canRun;
        }

        /**
         * option（Alt）を押しながらクリックしたら、すべてオンにする。すべてオンのときは、クリックしたものだけを残してほかをオフにする
         * （クリックで値はもう反転しているので、クリック前の状態は反転して見る）
         * @param {Checkbox} clickedCheckbox - クリックしたチェックボックス
         * @returns {void}
         */
        function setAllWizardGoalsOnOption(clickedCheckbox) {
            if (!ScriptUI.environment.keyboardState.altKey) return;
            var wasAllOn = !clickedCheckbox.value;
            var goalKey;
            for (goalKey in dialogControls.wizardGoalChecks) {
                if (dialogControls.wizardGoalChecks.hasOwnProperty(goalKey) && dialogControls.wizardGoalChecks[goalKey] !== clickedCheckbox &&
                        !dialogControls.wizardGoalChecks[goalKey].value) wasAllOn = false;
            }
            for (goalKey in dialogControls.wizardGoalChecks) {
                if (!dialogControls.wizardGoalChecks.hasOwnProperty(goalKey)) continue;
                dialogControls.wizardGoalChecks[goalKey].value = wasAllOn ? (dialogControls.wizardGoalChecks[goalKey] === clickedCheckbox) : true;
            }
        }
    }

    /**
     * ウィザードのチェックを { key: boolean } で返す
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @returns {Object} WIZARD_GOALS の key ごとのチェック
     */
    function readWizardGoals(dialogControls) {
        var wizardGoals = {};
        for (var i = 0; i < WIZARD_GOALS.length; i++) wizardGoals[WIZARD_GOALS[i].key] = dialogControls.wizardGoalChecks[WIZARD_GOALS[i].key].value;
        return wizardGoals;
    }

    /**
     * やりたいことを実行に使うか（チェックしていて、overriddenBy のやりたいことがオフ）
     * @param {Object} wizardGoal - WIZARD_GOALS の要素
     * @param {Object} wizardGoals - readWizardGoals() の戻り値
     * @returns {boolean} 使うなら true
     */
    function isWizardGoalActive(wizardGoal, wizardGoals) {
        if (!wizardGoals[wizardGoal.key]) return false;
        return !(wizardGoal.overriddenBy && wizardGoals[wizardGoal.overriddenBy]);
    }

    /**
     * 使えるやりたいことが1つでもあるか
     * @param {Object} wizardGoals - readWizardGoals() の戻り値
     * @returns {boolean} あれば true
     */
    function hasActiveWizardGoal(wizardGoals) {
        for (var i = 0; i < WIZARD_GOALS.length; i++) {
            if (isWizardGoalActive(WIZARD_GOALS[i], wizardGoals)) return true;
        }
        return false;
    }

    /**
     * ウィザードのチェックから実行に使う設定を作る。真偽値の項目はいったんすべてオフ（常にかける項目と漢数字の書き方は除く）、
     * 禁則・文字組み・行送り・桁区切り・番号のハイフンは変えない設定にしてから、チェックしたものの data を順に重ねる
     * @param {Object} baseSettings - 元の設定（数値・漢数字の書き方などはここから引き継ぐ）
     * @param {Object} wizardGoals - readWizardGoals() の戻り値
     * @returns {Object} 実行に使う設定
     */
    function buildWizardOptions(baseSettings, wizardGoals) {
        var formatOptions = mergePresetData(baseSettings);
        /* 漢数字の書き方（零・一千）は詳細モードの設定を使う / The kanji style (零, 一千) comes from the Detailed mode */
        var keptKeys = ALWAYS_APPLIED_KEYS.concat(["kanjiZeroRei", "kanjiIchiSen"]);
        for (var i = 0; i < CHECKBOX_SETTING_KEYS.length; i++) {
            if (indexOfValue(keptKeys, CHECKBOX_SETTING_KEYS[i]) < 0) formatOptions[CHECKBOX_SETTING_KEYS[i]] = false;
        }
        formatOptions.rotateSkipMinChars = DEFAULT_SETTINGS.rotateSkipMinChars;
        formatOptions.shortWordMaxChars = DEFAULT_SETTINGS.rotateSkipMinChars - 1;
        formatOptions.commaStyle = "keep";
        formatOptions.phoneHyphenStyle = "keep";
        formatOptions.kinsokuName = null;
        formatOptions.leadingPercent = null;
        formatOptions.mojikumiName = null;
        for (var j = 0; j < WIZARD_GOALS.length; j++) {
            if (isWizardGoalActive(WIZARD_GOALS[j], wizardGoals)) formatOptions = mergeObjects(formatOptions, WIZARD_GOALS[j].data);
        }
        return formatOptions;
    }

    /**
     * ボタン行（左：変換の確認、右：キャンセル・OK）を追加する
     * @param {Window} dialog - ダイアログ
     * @param {Object} dialogControls - コントロールを入れるオブジェクト
     * @returns {void}
     */
    function buildButtonRow(dialog, dialogControls) {
        var buttonRow = addButtonRow(dialog);
        /* 変換の確認は別のダイアログボックスで開く / Conversion Check opens in a separate dialog box */
        dialogControls.btnPreview = buttonRow.leftGroup.add("button", undefined, getLabel("button.preview"));
        dialogControls.btnPreview.helpTip = getLabel("tooltip.preview");
        dialogControls.btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
        dialogControls.btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
        alignRightOnlyButtonRow(buttonRow);
        dialogControls.btnCancel.preferredSize.width = BUTTON_WIDTH;
        dialogControls.btnOK.preferredSize.width = BUTTON_WIDTH;
    }

    /**
     * ダイアログを組み立てる。簡易モードはよく使う項目だけを並べ、ほかの項目はコントロールを作らない
     * @param {Object} settings - 初期値（DEFAULT_SETTINGS の形）
     * @returns {Object} dialog と各コントロール（作らなかった項目は settings の値を baseSettings に持つ）
     */
    function buildDialog(settings) {
        var dialogMode = (settings.dialogMode === "detail" || settings.dialogMode === "wizard") ? settings.dialogMode : "simple";
        var isDetail = (dialogMode === "detail");
        var dialog = new Window("dialog", getLabel("dialog.title"));
        setupWindow(dialog);
        var dialogControls = { dialog: dialog, baseSettings: mergePresetData(settings), dialogMode: dialogMode };

        buildTopRow(dialog, dialogControls, dialogMode);
        if (dialogMode === "wizard") {
            buildWizardPanel(dialog, dialogControls, settings);
            buildButtonRow(dialog, dialogControls);
            return dialogControls;
        }

        var columnsGroup = dialog.add("group");
        columnsGroup.orientation = "row";
        columnsGroup.alignChildren = ["fill", "top"];
        columnsGroup.spacing = COLUMN_SPACING;
        var leftColumn = addLayoutColumn(columnsGroup);
        if (isDetail) {
            /* 左：数字、文字の変換／右：欧文回転・縦中横、文字・段落、確認用の色分け
               Left: numbers, character conversion; right: rotation, TCY, character & paragraph, check coloring */
            buildNumberPanel(leftColumn, dialogControls, settings);
            buildReplacePanel(leftColumn, dialogControls, settings, isDetail);
            var rightColumn = addLayoutColumn(columnsGroup);
            buildTcyPanel(rightColumn, dialogControls, settings, isDetail);
            buildParagraphPanel(rightColumn, dialogControls, settings);
            buildColorCheckPanel(rightColumn, dialogControls, settings);
        } else {
            buildTcyPanel(leftColumn, dialogControls, settings, isDetail);
            buildReplacePanel(leftColumn, dialogControls, settings, isDetail);
        }

        buildButtonRow(dialog, dialogControls);
        /* 数値欄・ラジオ・ドロップダウンの初期値はまとめて入れる / Fill fields, radios and dropdowns in one place */
        writeDialogSettings(dialogControls, settings);
        return dialogControls;
    }

    /**
     * 数値欄の整数を読む（読めなければ既定値）
     * @param {EditText} numberInput - 入力欄
     * @param {number} fallbackValue - 読めないときの値
     * @returns {number} 整数
     */
    function readDigitInput(numberInput, fallbackValue) {
        var value = parseInt(numberInput.text, 10);
        return isNaN(value) ? fallbackValue : value;
    }

    /**
     * ダイアログの値を設定のオブジェクトにする（最小と最大が逆なら入れ替える。作らなかった項目は baseSettings の値）
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @returns {Object} DEFAULT_SETTINGS と同じ形
     */
    function readDialogOptions(dialogControls) {
        var formatOptions = mergePresetData(dialogControls.baseSettings);
        /* ウィザードはチェックだけを控え、詳細の設定はそのまま残す。モードの切り替えでは dialogMode が先に変わるので、コントロールで見分ける
           The wizard keeps only its checks; the detailed settings stay. A mode switch changes dialogMode first, so check the controls */
        if (dialogControls.wizardGoalChecks) {
            formatOptions.wizardGoals = readWizardGoals(dialogControls);
            formatOptions.dialogMode = dialogControls.dialogMode;
            return formatOptions;
        }
        for (var i = 0; i < CHECKBOX_SETTING_KEYS.length; i++) {
            var settingKey = CHECKBOX_SETTING_KEYS[i];
            if (dialogControls[settingKey]) formatOptions[settingKey] = dialogControls[settingKey].value;
        }
        if (dialogControls.kanjiMinInput) {
            var kanjiMin = readDigitInput(dialogControls.kanjiMinInput, DEFAULT_SETTINGS.kanjiMinDigits);
            var kanjiMax = readDigitInput(dialogControls.kanjiMaxInput, DEFAULT_SETTINGS.kanjiMaxDigits);
            formatOptions.kanjiMinDigits = Math.min(kanjiMin, kanjiMax);
            formatOptions.kanjiMaxDigits = Math.max(kanjiMin, kanjiMax);
        }
        formatOptions.rotateSkipMinChars = Math.max(2, readDigitInput(dialogControls.rotateSkipMinInput, DEFAULT_SETTINGS.rotateSkipMinChars));
        /* 短い英単語は「○文字以上の欧文は除く」の1つ下に連動 / Short words are linked to one below "Skip Roman text of ... or more characters" */
        formatOptions.shortWordMaxChars = formatOptions.rotateSkipMinChars - 1;
        if (dialogControls.kanjiPositionalRadio) formatOptions.kanjiStyle = readKanjiStyle(dialogControls);
        if (dialogControls.commaDropdown.selection) formatOptions.commaStyle = COMMA_STYLES[dialogControls.commaDropdown.selection.index];
        if (dialogControls.phoneHyphenDropdown && dialogControls.phoneHyphenDropdown.selection) formatOptions.phoneHyphenStyle = PHONE_HYPHEN_STYLES[dialogControls.phoneHyphenDropdown.selection.index];
        if (dialogControls.kinsokuDropdown) formatOptions.kinsokuName = readTableName(dialogControls.kinsokuDropdown, dialogControls.kinsokuNames);
        if (dialogControls.leadingInput) formatOptions.leadingPercent = Math.min(500, Math.max(50, readDigitInput(dialogControls.leadingInput, DEFAULT_SETTINGS.leadingPercent)));
        if (dialogControls.mojikumiDropdown) formatOptions.mojikumiName = readTableName(dialogControls.mojikumiDropdown, dialogControls.mojikumiNames);
        formatOptions.dialogMode = dialogControls.dialogMode;
        return formatOptions;
    }

    /**
     * 漢数字の書き方のラジオから値を返す
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @returns {string} "digit" / "positional" / "largeUnits"
     */
    function readKanjiStyle(dialogControls) {
        if (dialogControls.kanjiPositionalRadio.value) return "positional";
        if (dialogControls.kanjiLargeUnitsRadio.value) return "largeUnits";
        return "digit";
    }

    /**
     * 実行と確認の一覧に使う設定を返す。簡易モードでは、表示していない項目をオフにし、禁則・文字組みは変えない。
     * ウィザードはチェックしたやりたいことから作る
     * （保存する設定は readDialogOptions() のまま、詳細モードの値を残す）
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @returns {Object} 実行に使う設定
     */
    function readEffectiveOptions(dialogControls) {
        if (dialogControls.wizardGoalChecks) return buildWizardOptions(dialogControls.baseSettings, readWizardGoals(dialogControls));
        var formatOptions = readDialogOptions(dialogControls);
        if (dialogControls.dialogMode !== "simple") return formatOptions;
        for (var i = 0; i < CHECKBOX_SETTING_KEYS.length; i++) {
            var settingKey = CHECKBOX_SETTING_KEYS[i];
            if (dialogControls[settingKey] || indexOfValue(ALWAYS_APPLIED_KEYS, settingKey) >= 0) continue;
            formatOptions[settingKey] = false;
        }
        formatOptions.kinsokuName = null;
        formatOptions.leadingPercent = null;
        formatOptions.phoneHyphenStyle = "keep";
        formatOptions.mojikumiName = null;
        return formatOptions;
    }

    /**
     * 設定の値をダイアログの各項目に書き込む（作っていない項目は baseSettings に持つ）
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @param {Object} settings - DEFAULT_SETTINGS と同じ形
     * @returns {void}
     */
    function writeDialogSettings(dialogControls, settings) {
        dialogControls.baseSettings = mergePresetData(settings);
        for (var i = 0; i < CHECKBOX_SETTING_KEYS.length; i++) {
            var settingKey = CHECKBOX_SETTING_KEYS[i];
            if (dialogControls[settingKey]) dialogControls[settingKey].value = settings[settingKey];
        }
        if (dialogControls.kanjiMinInput) {
            dialogControls.kanjiMinInput.text = String(settings.kanjiMinDigits);
            dialogControls.kanjiMaxInput.text = String(settings.kanjiMaxDigits);
        }
        dialogControls.rotateSkipMinInput.text = String(settings.rotateSkipMinChars);
        if (dialogControls.shortWordMaxInput) dialogControls.shortWordMaxInput.text = String(settings.rotateSkipMinChars - 1);
        if (dialogControls.kanjiPositionalRadio) {
            dialogControls.kanjiPositionalRadio.value = (settings.kanjiStyle === "positional");
            dialogControls.kanjiLargeUnitsRadio.value = (settings.kanjiStyle === "largeUnits");
            dialogControls.kanjiDigitRadio.value = !dialogControls.kanjiPositionalRadio.value && !dialogControls.kanjiLargeUnitsRadio.value;
        }
        dialogControls.commaDropdown.selection = Math.max(0, indexOfValue(COMMA_STYLES, settings.commaStyle));
        if (dialogControls.phoneHyphenDropdown) dialogControls.phoneHyphenDropdown.selection = Math.max(0, indexOfValue(PHONE_HYPHEN_STYLES, settings.phoneHyphenStyle));
        if (dialogControls.leadingInput) dialogControls.leadingInput.text = settings.leadingPercent + "%";
        if (dialogControls.kinsokuDropdown) dialogControls.kinsokuDropdown.selection = getTableItemIndex(dialogControls.kinsokuNames, settings.kinsokuName, KINSOKU_DEFAULT_INDEX);
        if (dialogControls.mojikumiDropdown) dialogControls.mojikumiDropdown.selection = getTableItemIndex(dialogControls.mojikumiNames, settings.mojikumiName, MOJIKUMI_DEFAULT_INDEX);
    }

    /**
     * ダイアログのイベントをつなぐ（有効／無効の切り替えと確認の一覧の更新）
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @param {Array<Object>} textTargets - prepareVerticalResets() を通した対象
     * @returns {void}
     */
    function bindDialogEvents(dialogControls, textTargets) {
        dialogControls.btnPreview.onClick = function () {
            showPreviewDialog(buildPreviewLines(textTargets, readEffectiveOptions(dialogControls)));
        };
        bindModeSwitch(dialogControls, dialogControls.modeSimpleRadio, "simple");
        bindModeSwitch(dialogControls, dialogControls.modeDetailRadio, "detail");
        bindModeSwitch(dialogControls, dialogControls.modeWizardRadio, "wizard");
        /* ウィザードはチェックボックスだけで、プリセットも無い / The wizard has only checkboxes and no presets */
        if (dialogControls.wizardGoalChecks) {
            bindWizardEvents(dialogControls);
            return;
        }

        /**
         * 親のチェックボックスに合わせて子の項目を有効／無効にする
         * @returns {void}
         */
        function updateEnabledStates() {
            /**
             * 作ってある項目だけ有効／無効を切り替える（簡易モードでは作らない項目がある）
             * @param {string} controlName - dialogControls のキー
             * @param {boolean} isEnabled - 有効にするか
             * @returns {void}
             */
            function setEnabledIfExists(controlName, isEnabled) {
                if (dialogControls[controlName]) dialogControls[controlName].enabled = isEnabled;
            }
            setEnabledIfExists("rotateSkipLongLatin", dialogControls.rotateRoman.value);
            setEnabledIfExists("rotateSkipSuffix", dialogControls.rotateRoman.value);
            setSteppedFieldEnabled(dialogControls.rotateSkipMinInput, dialogControls.rotateRoman.value && dialogControls.rotateSkipLongLatin.value);
            if (dialogControls.shortWordMaxInput) setSteppedFieldEnabled(dialogControls.shortWordMaxInput, dialogControls.shortWordFullwidth.value);
            setEnabledIfExists("tcyDigits2", dialogControls.tcyNumbers.value);
            setEnabledIfExists("tcyDigits3", dialogControls.tcyNumbers.value);
            setEnabledIfExists("tcyDigits4", dialogControls.tcyNumbers.value);
            setEnabledIfExists("tcyExcludeAdjacent", dialogControls.tcyNumbers.value);
            /* 全角にする数字に1桁・3桁以上も含まれる / Non-TCY digits already include single and 3+ digit numbers */
            setEnabledIfExists("singleDigitFullwidth", !dialogControls.nonTcyDigitsFullwidth.value);
            setEnabledIfExists("longDigitsFullwidth", !dialogControls.nonTcyDigitsFullwidth.value);
            /* 漢数字の項目は詳細モードだけ / Kanji options exist only in the detailed mode */
            if (dialogControls.kanji) {
                setEnabledIfExists("kanjiToArabic", !dialogControls.kanji.value);
                setSteppedFieldEnabled(dialogControls.kanjiMinInput, dialogControls.kanji.value);
                setSteppedFieldEnabled(dialogControls.kanjiMaxInput, dialogControls.kanji.value);
                setEnabledIfExists("kanjiDigitRadio", dialogControls.kanji.value);
                setEnabledIfExists("kanjiPositionalRadio", dialogControls.kanji.value);
                setEnabledIfExists("kanjiLargeUnitsRadio", dialogControls.kanji.value);
                setEnabledIfExists("kanjiZeroRei", dialogControls.kanji.value);
                /* 一千は十・百・千を入れるときだけ / 一千 applies only to the positional style */
                setEnabledIfExists("kanjiIchiSen", dialogControls.kanji.value && dialogControls.kanjiPositionalRadio.value);
            }
        }

        var clickControlNames = CHECKBOX_SETTING_KEYS.concat(["kanjiDigitRadio", "kanjiPositionalRadio", "kanjiLargeUnitsRadio"]);
        for (var i = 0; i < clickControlNames.length; i++) {
            if (!dialogControls[clickControlNames[i]]) continue;
            dialogControls[clickControlNames[i]].onClick = updateEnabledStates;
        }

        /**
         * 数値欄が変わったら、連動する欄をそろえる
         * @param {EditText} [changedInput] - 変わった入力欄
         * @returns {void}
         */
        function onDigitInputChanged(changedInput) {
            syncWordLengthFields(dialogControls, changedInput);
        }

        digitStepHandler = onDigitInputChanged;
        wrapDigitInputUpdate(dialogControls.rotateSkipMinInput, onDigitInputChanged);
        if (dialogControls.shortWordMaxInput) wrapDigitInputUpdate(dialogControls.shortWordMaxInput, onDigitInputChanged);

        bindPresetEvents(dialogControls, updateEnabledStates);
        updateEnabledStates();
    }

    /**
     * 「変換の確認」のダイアログボックスを開く（一覧と［閉じる］だけ）
     * @param {string[]} previewLines - buildPreviewLines() の戻り値
     * @returns {void}
     */
    function showPreviewDialog(previewLines) {
        var previewDialog = new Window("dialog", getLabel("panel.preview"));
        setupWindow(previewDialog);
        var previewList = previewDialog.add("listbox", undefined, []);
        previewList.preferredSize = PREVIEW_LIST_SIZE;
        if (previewLines.length === 0) previewLines.push(getLabel("preview.none"));
        for (var i = 0; i < previewLines.length; i++) previewList.add("item", previewLines[i]);
        var buttonRow = addButtonRow(previewDialog);
        var btnClose = buttonRow.rightGroup.add("button", undefined, getLabel("button.close"), { name: "ok" });
        btnClose.preferredSize.width = BUTTON_WIDTH;
        alignRightOnlyButtonRow(buttonRow);
        previewDialog.show();
    }

    /**
     * モードのラジオボタンを押したら、今の値のまま開き直す（作り直しは main で行う）
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @param {RadioButton} modeRadio - モードのラジオボタン
     * @param {string} dialogMode - "simple" / "detail" / "wizard"
     * @returns {void}
     */
    function bindModeSwitch(dialogControls, modeRadio, dialogMode) {
        modeRadio.onClick = function () {
            if (dialogControls.dialogMode === dialogMode) return;
            dialogControls.dialogMode = dialogMode;
            dialogControls.switchCenter = getWindowCenter(dialogControls.dialog);
            dialogControls.dialog.close(MODE_SWITCH_RESULT);
        };
    }

    /**
     * プリセットの行のイベントをつなぐ（選ぶと読み込み、保存・削除でドロップダウンを作り直す）
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @param {function(): void} onPresetApplied - プリセットを読み込んだあとに呼ぶ
     * @returns {void}
     */
    function bindPresetEvents(dialogControls, onPresetApplied) {
        /* プリセットの並び：--- / 組み込み / 区切り / 保存したもの / Preset list: placeholder, built-ins, separator, saved ones */
        var presetEntries = [];
        var isFillingPresets = false;

        /**
         * プリセットのドロップダウンを作り直す（作り直しでも onChange が来るので、その間は読まない）
         * @param {string|null} selectedName - 選んでおく保存したプリセット名（null なら「---」）
         * @returns {void}
         */
        function fillPresetDropdown(selectedName) {
            isFillingPresets = true;
            var presetDropdown = dialogControls.presetDropdown;
            presetDropdown.removeAll();
            presetEntries = [{ type: "none" }];
            presetDropdown.add("item", getLabel("preset.placeholder"));
            for (var b = 0; b < BUILTIN_PRESETS.length; b++) {
                presetEntries.push({ type: "builtin", data: BUILTIN_PRESETS[b].data });
                presetDropdown.add("item", getLabel("preset.builtin." + BUILTIN_PRESETS[b].labelKey));
            }
            var savedNames = getPresetNames();
            var selectedIndex = 0;
            if (savedNames.length > 0) {
                presetEntries.push({ type: "separator" });
                presetDropdown.add("separator");
                for (var n = 0; n < savedNames.length; n++) {
                    if (savedNames[n] === selectedName) selectedIndex = presetEntries.length;
                    presetEntries.push({ type: "saved", name: savedNames[n] });
                    presetDropdown.add("item", savedNames[n]);
                }
            }
            presetDropdown.selection = selectedIndex;
            setIconButtonEnabled(dialogControls.presetDeleteIcon, presetEntries[selectedIndex].type === "saved");
            isFillingPresets = false;
        }

        /**
         * 選んでいるプリセットの項目を返す
         * @returns {Object} presetEntries の要素
         */
        function getSelectedPresetEntry() {
            var presetSelection = dialogControls.presetDropdown.selection;
            return presetSelection ? presetEntries[presetSelection.index] : presetEntries[0];
        }

        dialogControls.presetDropdown.onChange = function () {
            if (isFillingPresets) return;
            var presetEntry = getSelectedPresetEntry();
            setIconButtonEnabled(dialogControls.presetDeleteIcon, presetEntry.type === "saved");
            var presetData = null;
            if (presetEntry.type === "builtin") presetData = presetEntry.data;
            else if (presetEntry.type === "saved") presetData = loadPresetMap()[presetEntry.name];
            if (!presetData) return;
            /* ウィザードのチェックとモードはプリセットで変えない / Presets do not change the wizard checks or the mode */
            var presetSettings = mergePresetData(presetData);
            presetSettings.wizardGoals = dialogControls.baseSettings.wizardGoals;
            presetSettings.dialogMode = dialogControls.dialogMode;
            writeDialogSettings(dialogControls, presetSettings);
            onPresetApplied();
        };
        dialogControls.presetSaveIcon.onClick = function () {
            var presetEntry = getSelectedPresetEntry();
            var savedName = saveCurrentPreset(readDialogOptions(dialogControls), presetEntry.type === "saved" ? presetEntry.name : "");
            if (savedName) fillPresetDropdown(savedName);
        };
        dialogControls.presetDeleteIcon.onClick = function () {
            var presetEntry = getSelectedPresetEntry();
            if (presetEntry.type !== "saved") return;
            if (deletePreset(presetEntry.name)) fillPresetDropdown(null);
        };

        fillPresetDropdown(null);
    }

    /**
     * ウィンドウの中心の座標を返す
     * @param {Window} targetWindow - 対象のウィンドウ
     * @returns {number[]} [x, y]
     */
    function getWindowCenter(targetWindow) {
        var windowBounds = targetWindow.bounds;
        return [(windowBounds.left + windowBounds.right) / 2, (windowBounds.top + windowBounds.bottom) / 2];
    }

    /**
     * 表示したときに、ウィンドウの中心を指定の座標に合わせる（位置の復元のあとに動かす）
     * @param {Window} targetWindow - 対象のウィンドウ
     * @param {number[]} centerPoint - 中心の座標 [x, y]
     * @returns {void}
     */
    function keepWindowCenterOnShow(targetWindow, centerPoint) {
        var previousOnShow = targetWindow.onShow;
        targetWindow.onShow = function () {
            if (previousOnShow) previousOnShow.apply(this, arguments);
            var windowBounds = targetWindow.bounds;
            var windowWidth = windowBounds.right - windowBounds.left;
            var windowHeight = windowBounds.bottom - windowBounds.top;
            targetWindow.location = [Math.round(centerPoint[0] - windowWidth / 2), Math.round(centerPoint[1] - windowHeight / 2)];
        };
    }

    /**
     * 数値欄を直接入力したときも確認の一覧を更新する
     * （部品の onChange は値をそろえるだけなので、包んで後ろに足す）
     * @param {EditText} numberInput - addSteppedField() の入力欄
     * @param {function(EditText): void} onUpdate - 更新の処理（引数は入力欄）
     * @returns {void}
     */
    function wrapDigitInputUpdate(numberInput, onUpdate) {
        var normalizeOnChange = numberInput.onChange;
        numberInput.onChange = function () {
            normalizeOnChange();
            onUpdate(numberInput);
        };
    }

    /**
     * ［○文字以上の欧文は除く］と［○文字以下の英単語を全角に］の文字数をそろえる（全角は「除く」の1つ下）
     * @param {Object} dialogControls - buildDialog() の戻り値
     * @param {EditText} [changedInput] - 変わった入力欄
     * @returns {void}
     */
    function syncWordLengthFields(dialogControls, changedInput) {
        var shortWordInput = dialogControls.shortWordMaxInput;
        if (!shortWordInput) return;
        var rotateSkipInput = dialogControls.rotateSkipMinInput;
        if (changedInput === shortWordInput) {
            rotateSkipInput.text = String(Math.min(99, readDigitInput(shortWordInput, DEFAULT_SETTINGS.shortWordMaxChars) + 1));
        } else if (changedInput === rotateSkipInput) {
            shortWordInput.text = String(Math.max(1, readDigitInput(rotateSkipInput, DEFAULT_SETTINGS.rotateSkipMinChars) - 1));
        }
    }

    // =========================================
    // メイン処理 / Main
    // =========================================

    /**
     * 選択を確かめ、ダイアログで設定を選んで実行する
     * @returns {void}
     */
    function main() {
        if (app.documents.length === 0) {
            alert(getLabel("alert.noSelection"));
            return;
        }
        var doc = app.activeDocument;
        var textTargets = collectTextTargets(app.selection);
        if (textTargets.length === 0) {
            alert(getLabel("alert.noSelection"));
            return;
        }
        prepareVerticalResets(textTargets);

        var settingsStore = createSettingsStore(SCRIPT_NAME, "persistent");
        var dialogSettings = settingsStore.load(DEFAULT_SETTINGS);
        var dialogControls;
        var dialogResult;
        var switchCenter = null;
        /* モードの切り替えは、値を引き継いで同じ中心の位置に作り直す / A mode switch rebuilds the dialog at the same center, keeping the values */
        do {
            dialogControls = buildDialog(dialogSettings);
            bindDialogEvents(dialogControls, textTargets);
            if (switchCenter) keepWindowCenterOnShow(dialogControls.dialog, switchCenter);
            addVersionFooter(dialogControls.dialog);
            dialogResult = dialogControls.dialog.show();
            if (dialogResult === MODE_SWITCH_RESULT) {
                dialogSettings = readDialogOptions(dialogControls);
                switchCenter = dialogControls.switchCenter;
            }
        } while (dialogResult === MODE_SWITCH_RESULT);
        if (dialogResult !== 1) return;

        settingsStore.save(readDialogOptions(dialogControls));
        var formatOptions = readEffectiveOptions(dialogControls);
        var failureReason = "";
        /* 一括で取り消せるように doScript でまとめて実行（ダイアログボックスを閉じてから） / One undo step, run after the dialog box is closed */
        app.doScript(function () {
            failureReason = runVerticalTextConversion(doc, textTargets, formatOptions);
        }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, getLabel("progress.title"));
        if (failureReason !== "") alert(getLabel("alert.actionFailed") + "\n\n" + failureReason);
    }

    main();

})();
