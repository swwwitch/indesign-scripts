#target indesign
#targetengine "IdCharacterWidthConverter"

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdCharacterWidthConverter
Name=文字の種類ごとに全角・半角を変換
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.6.2
Release-Date=2026-10-30
Description-BEGIN
カタカナ・英数字・スペース・句読点・括弧・記号を、文字の種類ごとに「そのまま／半角／全角」を選んで変換します。
設定は［横組み］［縦組み］のタブごとに持ち、開いているタブの設定で変換します。縦組み用・欧文組版用などのプリセットで設定を切り替えられます。

Converts katakana, letters, digits, spaces, punctuation, brackets and symbols between half-width and full-width, choosing "Keep", "Half" or "Full" for each kind of character.
The Horizontal and Vertical tabs each keep their own settings, and the open tab's settings are used. Presets such as vertical and Western typesetting switch the settings.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

カタカナ・英数字・スペース・句読点・括弧・記号を、文字の種類ごとに「そのまま／半角／全角」を選んで変換します。
設定は［横組み］［縦組み］のタブごとに持ち、開いているタブの設定で変換します。縦組み用・欧文組版用などのプリセットで設定を切り替えられます。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdCharacterWidthConverter.md

note記事も参照してください。
https://note.com/dtp_tranist/n/nf9d7245b0653

### Overview

Converts katakana, letters, digits, spaces, punctuation, brackets and symbols between half-width and full-width, choosing "Keep", "Half" or "Full" for each kind of character.
The Horizontal and Vertical tabs each keep their own settings, and the open tab's settings are used. Presets such as vertical and Western typesetting switch the settings.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdCharacterWidthConverter.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdCharacterWidthConverter";    /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.6.2";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-10-30";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "文字の種類ごとに全角・半角を変換"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdCharacterWidthConverter.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdCharacterWidthConverter.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/nf9d7245b0653"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/text/IdCharacterWidthConverter.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

// =========================================
// ユーザー設定 / User settings
// =========================================

/* 選択肢の番号（ダイアログの列の順）/ Option indexes, in the order of the dialog columns */
var OPTION_KEEP = 0;
var OPTION_HALF = 1;
var OPTION_FULL = 2;

/* ［デフォルトに戻す］の値。ここに無い行は「そのまま」/ Values for "Restore Defaults"; rows not listed here are "Keep" */
var DEFAULT_ROW_OPTIONS = {
    katakana: OPTION_FULL,
    alphabet: OPTION_HALF,
    digits: OPTION_HALF,
    kanaPunctuation: OPTION_FULL,
    middleDot: OPTION_FULL,
    kanaLeftBracket: OPTION_FULL,
    kanaRightBracket: OPTION_FULL
};

/* ［変換した文字に色を付ける］の色 / Color for "Color converted characters" */
var HIGHLIGHT_CMYK = [0, 100, 100, 0];             /* CMYK の値 / CMYK values */
var HIGHLIGHT_COLOR_NAME = "IdCharacterWidthConverter"; /* スウォッチ名（無ければ作る）/ swatch name, added when missing */

/* ドキュメントを対象にしたとき、親ページのテキストも変換する / Also convert text on parent pages when the scope is the document */
var INCLUDE_MASTER_PAGES = true;

// =========================================
// 設定の保存 / Settings store
// =========================================

// 設定の保存（再利用パーツ） / Settings store (reusable)

var SETTINGS_STORE_FOLDER_NAME = "indesign-scripts"; /* Folder.userData の下に作るフォルダー / folder created under Folder.userData */
var SETTINGS_STORE_MAX_DEPTH = 32;                                /* 入れ子の上限（循環参照よけ）/ nesting limit (guards against cycles) */

/**
 * 設定の保存先を作る。寿命は "session"（Illustrator の終了まで）か "persistent"（ファイルに保存）
 * @param {string} storeName - 保存名（ふつうは SCRIPT_NAME）。ファイル名と $.global のキーに使う
 * @param {string} lifetime - "session" または "persistent"
 * @param {Object} [storeOptions] - { legacy: function () → 旧形式の保存値のオブジェクト|null }
 * @returns {{load: Function, save: Function, clear: Function}} 読み込み・保存・消去の関数
 */
function createSettingsStore(storeName, lifetime, storeOptions) {
    var isPersistent = (lifetime === "persistent");
    var legacyReader = (storeOptions && typeof storeOptions.legacy === "function") ? storeOptions.legacy : null;
    var safeStoreName = String(storeName).replace(/[\\\/:*?"<>|]/g, "_");
    var sessionKey = "__" + safeStoreName + "_Settings";
    var settingsFile = isPersistent
        ? new File(Folder.userData + "/" + SETTINGS_STORE_FOLDER_NAME + "/" + safeStoreName + ".json")
        : null;

    /**
     * 保存してある文字列を返す
     * @returns {string|null} 保存文字列。1度も保存していなければ null
     */
    function readStoredText() {
        if (!isPersistent) {
            return (typeof $.global[sessionKey] === "string") ? $.global[sessionKey] : null;
        }
        return settingsStoreReadTextFile(settingsFile);
    }

    /**
     * 文字列を保存する
     * @param {string} storedText - 保存する文字列
     * @returns {boolean} 保存できたら true
     */
    function writeStoredText(storedText) {
        if (!isPersistent) {
            $.global[sessionKey] = storedText;
            return true;
        }
        return settingsStoreWriteTextFile(settingsFile, storedText);
    }

    /**
     * 保存値を読み込み、既定値と突き合わせて返す（型の合わない値・知らない項目は捨てる）
     * @param {Object} defaultSettings - 既定値
     * @returns {Object} 設定（毎回新しいオブジェクト）
     */
    function load(defaultSettings) {
        var savedSettings = null;
        try {
            var storedText = readStoredText();
            if (storedText !== null) {
                savedSettings = settingsStoreParse(storedText);
            } else if (legacyReader) {
                savedSettings = legacyReader();
            }
        } catch (e) {
            $.writeln("SettingsStore.load(" + storeName + "): " + e);
            savedSettings = null;
        }
        return settingsStoreMerge(defaultSettings, savedSettings);
    }

    /**
     * 設定を保存する
     * @param {Object} settingValues - 保存する値
     * @returns {boolean} 保存できたら true
     */
    function save(settingValues) {
        try {
            return writeStoredText(settingsStoreSerialize(settingValues, "", 0));
        } catch (e) {
            $.writeln("SettingsStore.save(" + storeName + "): " + e);
            return false;
        }
    }

    /**
     * 保存を消す。旧形式を読み継ぐストアでは空の保存を書き、旧設定が戻らないようにする
     * @returns {boolean} 消せたら true
     */
    function clear() {
        if (legacyReader) return writeStoredText("{}");
        if (!isPersistent) {
            try { delete $.global[sessionKey]; } catch (e) { $.global[sessionKey] = undefined; }
            return true;
        }
        try {
            return settingsFile.exists ? settingsFile.remove() : true;
        } catch (e) {
            $.writeln("SettingsStore.clear(" + storeName + "): " + e);
            return false;
        }
    }

    return { load: load, save: save, clear: clear };
}

/**
 * 旧形式の設定ファイルを読む（key=value の行 / toSource / JSON を自動判別。eval は使わない）
 * @param {File|string} legacyFileOrPath - 旧ファイルかそのパス
 * @returns {Object|null} 読み込んだ値（key=value は値がすべて文字列）。無い・読めないときは null
 */
function readSettingsLegacyFile(legacyFileOrPath) {
    try {
        var legacyFile = (legacyFileOrPath instanceof File) ? legacyFileOrPath : new File(legacyFileOrPath);
        var legacyText = settingsStoreReadTextFile(legacyFile);
        return (legacyText === null) ? null : settingsStoreParseLegacyText(legacyText);
    } catch (e) {
        $.writeln("readSettingsLegacyFile: " + e);
        return null;
    }
}

/**
 * app.preferences に文字列で保存していた旧設定を読む（形式は readSettingsLegacyFile と同じく自動判別）
 * @param {string} preferenceKey - 環境設定のキー
 * @returns {Object|null} 読み込んだ値。無い・読めないときは null
 */
function readSettingsLegacyPreference(preferenceKey) {
    try {
        var legacyText = app.preferences.getStringPreference(preferenceKey);
        if (!legacyText) return null;
        return settingsStoreParseLegacyText(String(legacyText));
    } catch (e) {
        $.writeln("readSettingsLegacyPreference: " + e);
        return null;
    }
}

/**
 * テキストファイルを UTF-8 で読む
 * @param {File} textFile - 読むファイル
 * @returns {string|null} 中身。ファイルが無ければ null
 */
function settingsStoreReadTextFile(textFile) {
    if (!textFile.exists) return null;
    textFile.encoding = "UTF-8";
    if (!textFile.open("r")) throw new Error("cannot open " + textFile.fsName);
    try {
        return textFile.read().replace(/^\uFEFF/, "");
    } finally {
        textFile.close();
    }
}

/**
 * テキストファイルを UTF-8 で書く（フォルダーが無ければ作る）
 * @param {File} textFile - 書くファイル
 * @param {string} fileText - 中身
 * @returns {boolean} 書けたら true
 */
function settingsStoreWriteTextFile(textFile, fileText) {
    try {
        var parentFolder = textFile.parent;
        if (!parentFolder.exists && !parentFolder.create()) throw new Error("cannot create " + parentFolder.fsName);
        textFile.encoding = "UTF-8";
        textFile.lineFeed = "Unix";
        if (!textFile.open("w")) throw new Error("cannot open " + textFile.fsName);
        try {
            textFile.write(fileText);
        } finally {
            textFile.close();
        }
        return true;
    } catch (e) {
        $.writeln("SettingsStore write: " + e);
        return false;
    }
}

/**
 * 値が配列か
 * @param {*} checkedValue - 調べる値
 * @returns {boolean} 配列なら true
 */
function settingsStoreIsArray(checkedValue) {
    return Object.prototype.toString.call(checkedValue) === "[object Array]";
}

/**
 * 値が素のオブジェクト（{ } で作ったもの）か
 * @param {*} checkedValue - 調べる値
 * @returns {boolean} 素のオブジェクトなら true
 */
function settingsStoreIsPlainObject(checkedValue) {
    return checkedValue !== null && typeof checkedValue === "object"
        && Object.prototype.toString.call(checkedValue) === "[object Object]"
        && checkedValue.constructor === Object;
}

/**
 * 文字列を JSON の文字列リテラルにする（ASCII 以外は \uXXXX にして、文字コードの取り違えに強くする）
 * @param {string} sourceText - 文字列
 * @returns {string} 引用符つきの文字列
 */
function settingsStoreQuote(sourceText) {
    var quotedText = "\"";
    for (var i = 0; i < sourceText.length; i++) {
        var charCode = sourceText.charCodeAt(i);
        var oneChar = sourceText.charAt(i);
        if (oneChar === "\"" || oneChar === "\\") quotedText += "\\" + oneChar;
        else if (oneChar === "\n") quotedText += "\\n";
        else if (oneChar === "\r") quotedText += "\\r";
        else if (oneChar === "\t") quotedText += "\\t";
        else if (charCode < 0x20 || charCode > 0x7E) quotedText += "\\u" + ("0000" + charCode.toString(16)).slice(-4);
        else quotedText += oneChar;
    }
    return quotedText + "\"";
}

/**
 * 値を JSON の文字列にする（オブジェクトは1項目1行、中身が値だけの配列は1行）。
 * undefined・関数・DOM オブジェクトは項目ごと省き、配列の中では null にする。有限でない数値は null
 * @param {*} sourceValue - 値
 * @param {string} indentText - 今の字下げ
 * @param {number} depth - 入れ子の深さ
 * @returns {string|undefined} JSON の文字列。書けない値は undefined
 */
function settingsStoreSerialize(sourceValue, indentText, depth) {
    if (depth > SETTINGS_STORE_MAX_DEPTH) throw new Error("settings are nested too deeply");
    if (sourceValue === null) return "null";
    var valueType = typeof sourceValue;
    if (valueType === "boolean") return sourceValue ? "true" : "false";
    if (valueType === "number") return isFinite(sourceValue) ? String(sourceValue) : "null";
    if (valueType === "string") return settingsStoreQuote(sourceValue);
    var innerIndent = indentText + "  ";
    var itemTexts = [];
    var i;
    if (settingsStoreIsArray(sourceValue)) {
        var hasNested = false;
        for (i = 0; i < sourceValue.length; i++) {
            var itemText = settingsStoreSerialize(sourceValue[i], innerIndent, depth + 1);
            itemTexts.push(itemText === undefined ? "null" : itemText);
            if (sourceValue[i] !== null && typeof sourceValue[i] === "object") hasNested = true;
        }
        if (!itemTexts.length) return "[]";
        if (!hasNested) return "[" + itemTexts.join(", ") + "]";
        return "[\n" + innerIndent + itemTexts.join(",\n" + innerIndent) + "\n" + indentText + "]";
    }
    if (settingsStoreIsPlainObject(sourceValue)) {
        for (var key in sourceValue) {
            if (!sourceValue.hasOwnProperty(key)) continue;
            var memberText = settingsStoreSerialize(sourceValue[key], innerIndent, depth + 1);
            if (memberText !== undefined) itemTexts.push(settingsStoreQuote(key) + ": " + memberText);
        }
        if (!itemTexts.length) return "{}";
        return "{\n" + innerIndent + itemTexts.join(",\n" + innerIndent) + "\n" + indentText + "}";
    }
    return undefined; /* 関数・DOM オブジェクトなど / functions, DOM objects, etc. */
}

/**
 * JSON（と toSource の出力）を読む。eval は使わない。
 * キーの引用符なし・'…' の文字列・全体の ( ) ・末尾のカンマ・(void 0) も受け付ける
 * @param {string} sourceText - 読む文字列
 * @returns {*} 読み込んだ値
 */
function settingsStoreParse(sourceText) {
    var readPos = 0;
    var textLength = sourceText.length;

    /**
     * 読み取り位置で失敗を知らせる
     * @param {string} reasonText - 理由
     * @returns {void}
     */
    function fail(reasonText) {
        throw new Error("settings parse error at " + readPos + ": " + reasonText);
    }

    /**
     * 空白を読み飛ばす
     * @returns {void}
     */
    function skipSpaces() {
        while (readPos < textLength && /\s/.test(sourceText.charAt(readPos))) readPos++;
    }

    /**
     * 識別子（英数字・_・$）を読む
     * @returns {string} 識別子。無ければ空文字
     */
    function readWord() {
        var startPos = readPos;
        while (readPos < textLength && /[\w$]/.test(sourceText.charAt(readPos))) readPos++;
        return sourceText.substring(startPos, readPos);
    }

    /**
     * 引用符で囲んだ文字列を読む（" と ' のどちらでも）
     * @returns {string} 文字列
     */
    function readString() {
        var quoteChar = sourceText.charAt(readPos++);
        var resultText = "";
        while (readPos < textLength) {
            var oneChar = sourceText.charAt(readPos++);
            if (oneChar === quoteChar) return resultText;
            if (oneChar !== "\\") { resultText += oneChar; continue; }
            var escapeChar = sourceText.charAt(readPos++);
            if (escapeChar === "n") resultText += "\n";
            else if (escapeChar === "r") resultText += "\r";
            else if (escapeChar === "t") resultText += "\t";
            else if (escapeChar === "b") resultText += "\b";
            else if (escapeChar === "f") resultText += "\f";
            else if (escapeChar === "v") resultText += "\v";
            else if (escapeChar === "0") resultText += "\0";
            else if (escapeChar === "u" || escapeChar === "x") {
                var hexLength = (escapeChar === "u") ? 4 : 2;
                var hexText = sourceText.substr(readPos, hexLength);
                if (!new RegExp("^[0-9A-Fa-f]{" + hexLength + "}$").test(hexText)) fail("bad escape");
                resultText += String.fromCharCode(parseInt(hexText, 16));
                readPos += hexLength;
            } else resultText += escapeChar;
        }
        fail("unterminated string");
    }

    /**
     * 値を1つ読む
     * @param {number} depth - 入れ子の深さ
     * @returns {*} 値
     */
    function readValue(depth) {
        if (depth > SETTINGS_STORE_MAX_DEPTH) fail("nested too deeply");
        skipSpaces();
        var oneChar = sourceText.charAt(readPos);
        if (oneChar === "{") return readObject(depth);
        if (oneChar === "[") return readArray(depth);
        if (oneChar === "\"" || oneChar === "'") return readString();
        if (oneChar === "(") {
            readPos++;
            var innerValue = readValue(depth + 1);
            skipSpaces();
            if (sourceText.charAt(readPos) !== ")") fail("expected )");
            readPos++;
            return innerValue;
        }
        var numberMatch = /^-?(\d+\.?\d*|\.\d+)([eE][+\-]?\d+)?/.exec(sourceText.substring(readPos, readPos + 64));
        if (numberMatch) {
            readPos += numberMatch[0].length;
            return Number(numberMatch[0]);
        }
        var wordText = readWord();
        if (wordText === "true") return true;
        if (wordText === "false") return false;
        if (wordText === "null") return null;
        if (wordText === "NaN") return NaN;
        if (wordText === "Infinity") return Infinity;
        if (wordText === "void") { readValue(depth + 1); return undefined; } /* toSource の (void 0) */
        fail("unexpected " + (wordText || oneChar || "end of text"));
    }

    /**
     * 配列を読む
     * @param {number} depth - 入れ子の深さ
     * @returns {Array} 配列
     */
    function readArray(depth) {
        var resultArray = [];
        readPos++;
        skipSpaces();
        while (sourceText.charAt(readPos) !== "]") {
            resultArray.push(readValue(depth + 1));
            skipSpaces();
            if (sourceText.charAt(readPos) === ",") { readPos++; skipSpaces(); continue; }
            if (sourceText.charAt(readPos) !== "]") fail("expected , or ]");
        }
        readPos++;
        return resultArray;
    }

    /**
     * オブジェクトを読む（__proto__ のキーは捨てる）
     * @param {number} depth - 入れ子の深さ
     * @returns {Object} オブジェクト
     */
    function readObject(depth) {
        var resultObject = {};
        readPos++;
        skipSpaces();
        while (sourceText.charAt(readPos) !== "}") {
            var keyChar = sourceText.charAt(readPos);
            var memberKey = (keyChar === "\"" || keyChar === "'") ? readString() : readWord();
            if (memberKey === "") fail("expected a key");
            skipSpaces();
            if (sourceText.charAt(readPos) !== ":") fail("expected :");
            readPos++;
            var memberValue = readValue(depth + 1);
            if (memberKey !== "__proto__") resultObject[memberKey] = memberValue;
            skipSpaces();
            if (sourceText.charAt(readPos) === ",") { readPos++; skipSpaces(); continue; }
            if (sourceText.charAt(readPos) !== "}") fail("expected , or }");
        }
        readPos++;
        return resultObject;
    }

    var parsedValue = readValue(0);
    skipSpaces();
    if (readPos < textLength) fail("unexpected text after the value");
    return parsedValue;
}

/**
 * 旧形式の文字列を読む。{ [ ( で始まれば JSON / toSource、それ以外は key=value の行とみなす
 * @param {string} legacyText - 旧形式の文字列
 * @returns {Object|null} 読み込んだ値
 */
function settingsStoreParseLegacyText(legacyText) {
    var trimmedText = legacyText.replace(/^\uFEFF/, "").replace(/^\s+|\s+$/g, "");
    if (trimmedText === "") return null;
    if (/^[\{\[\(]/.test(trimmedText)) return settingsStoreParse(trimmedText);
    var keyValues = {};
    var textLines = trimmedText.split(/\r\n|\r|\n/);
    for (var i = 0; i < textLines.length; i++) {
        var separatorIndex = textLines[i].indexOf("=");
        if (separatorIndex < 1) continue;
        var lineKey = textLines[i].substring(0, separatorIndex).replace(/^\s+|\s+$/g, "");
        if (lineKey !== "" && lineKey !== "__proto__") keyValues[lineKey] = textLines[i].substring(separatorIndex + 1);
    }
    return keyValues;
}

/**
 * 値を深くコピーする（素のデータだけ。関数・DOM オブジェクトは null）
 * @param {*} sourceValue - コピー元
 * @returns {*} コピー
 */
function settingsStoreClone(sourceValue) {
    if (sourceValue === null || typeof sourceValue !== "object") {
        return (typeof sourceValue === "function" || sourceValue === undefined) ? null : sourceValue;
    }
    var i;
    if (settingsStoreIsArray(sourceValue)) {
        var arrayCopy = [];
        for (i = 0; i < sourceValue.length; i++) arrayCopy.push(settingsStoreClone(sourceValue[i]));
        return arrayCopy;
    }
    if (!settingsStoreIsPlainObject(sourceValue)) return null;
    var objectCopy = {};
    for (var key in sourceValue) {
        if (sourceValue.hasOwnProperty(key)) objectCopy[key] = settingsStoreClone(sourceValue[key]);
    }
    return objectCopy;
}

/**
 * 保存値を既定値と突き合わせる。型は既定値に合わせ、合わなければ既定値を使う。
 * 既定値が {} か null なら中身を問わず受け取り、配列は配列なら受け取る。既定値に無い項目は捨てる
 * @param {*} defaultValue - 既定値
 * @param {*} savedValue - 保存値
 * @returns {*} 突き合わせた値（新しいオブジェクト）
 */
function settingsStoreMerge(defaultValue, savedValue) {
    if (defaultValue === null || defaultValue === undefined) {
        return (savedValue === undefined) ? null : settingsStoreClone(savedValue);
    }
    var defaultType = typeof defaultValue;
    var savedType = typeof savedValue;
    if (defaultType === "boolean") {
        if (savedType === "boolean") return savedValue;
        if (savedValue === 1 || savedValue === "1" || savedValue === "true") return true;
        if (savedValue === 0 || savedValue === "0" || savedValue === "false") return false;
        return defaultValue;
    }
    if (defaultType === "number") {
        if (savedType === "number" && isFinite(savedValue)) return savedValue;
        if (savedType === "string" && /\S/.test(savedValue)) {
            var parsedNumber = Number(savedValue);
            if (isFinite(parsedNumber)) return parsedNumber;
        }
        return defaultValue;
    }
    if (defaultType === "string") {
        if (savedType === "string") return savedValue;
        if (savedType === "number" && isFinite(savedValue)) return String(savedValue);
        if (savedType === "boolean") return String(savedValue);
        return defaultValue;
    }
    if (settingsStoreIsArray(defaultValue)) {
        return settingsStoreClone(settingsStoreIsArray(savedValue) ? savedValue : defaultValue);
    }
    if (defaultType === "object") {
        var savedIsObject = settingsStoreIsPlainObject(savedValue);
        var hasDefaultKeys = false;
        var mergedObject = {};
        for (var key in defaultValue) {
            if (!defaultValue.hasOwnProperty(key)) continue;
            hasDefaultKeys = true;
            mergedObject[key] = settingsStoreMerge(defaultValue[key], savedIsObject ? savedValue[key] : undefined);
        }
        /* 既定値が {} なら自由な入れ物として中身ごと受け取る / an empty default {} is a free-form map */
        if (!hasDefaultKeys && savedIsObject) return settingsStoreClone(savedValue);
        return mergedObject;
    }
    return defaultValue;
}

// 設定の保存（再利用パーツ）ここまで / End of the reusable settings store

/* 前回の設定は InDesign を終了するまで（#targetengine が必要）、プリセットはファイルに保存 / The last settings last until InDesign quits (needs #targetengine); presets are saved to a file */
var sessionStore = createSettingsStore(SCRIPT_NAME, "session");
var presetStore = createSettingsStore(SCRIPT_NAME, "persistent");

// =========================================
// レイアウト / Layout
// =========================================

// UIレイアウト（再利用パーツ） / UI layout (reusable)

/* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
var COLUMN_SPACING = 12;                 /* カラムの間隔 / gap between columns */
var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

/**
 * ウィンドウの共通設定
 * @param {Window} targetWindow - 対象のウィンドウ
 * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
 * @returns {void}
 */
function setupWindow(targetWindow, spacing) {
    targetWindow.orientation = "column";
    targetWindow.alignChildren = "fill";
    targetWindow.margins = WINDOW_MARGINS;
    targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
}

/**
 * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
 * @param {Panel} targetPanel - 対象のパネル
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupPanel(targetPanel, spacing) {
    targetPanel.orientation = "column";
    targetPanel.alignChildren = ["fill", "top"];
    targetPanel.alignment = "fill";
    targetPanel.margins = PANEL_MARGINS;
    targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * タブの共通設定
 * @param {Tab} targetTab - 対象のタブ
 * @param {number} [spacing] - 要素間隔（省略時は変えない）
 * @returns {void}
 */
function setupTab(targetTab, spacing) {
    targetTab.orientation = "column";
    targetTab.alignChildren = "fill";
    targetTab.margins = TAB_MARGINS;
    if (typeof spacing === "number") targetTab.spacing = spacing;
}

/**
 * 横並びの行グループの共通設定（ボタン列など）。
 * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
 * @param {Group} rowGroup - 対象のグループ
 * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupRow(rowGroup, rowAlignment, spacing) {
    rowGroup.orientation = "row";
    rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
    rowGroup.alignChildren = ["left", "center"];
    rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
 * @param {Button} targetButton - 対象のボタン
 * @param {number} trimPixels - 詰める量（px）
 * @returns {void}
 */
function trimButtonHeight(targetButton, trimPixels) {
    /* レイアウト前は size が無い / size is not set until the layout runs */
    if (!targetButton.size) return;
    targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
}

// UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

var TABLE_ROW_SPACING     = 2;   /* 表の行どうしの間隔 / spacing between table rows */
var TABLE_CELL_SPACING    = 4;   /* 項目名と選択肢の列の間隔 / spacing between the row label and the option columns */
var OPTION_COLUMN_WIDTH   = 52;  /* 選択肢の列の幅 / width of each option column */
var PRESET_DROPDOWN_WIDTH = 220; /* プリセットのドロップダウンの幅 / width of the preset dropdown */
var STYLE_LIST_WIDTH      = 220; /* 除外するスタイルのリストの幅 / width of the excluded-style lists */
var STYLE_LIST_HEIGHT     = 280; /* 除外するスタイルのリストの高さ / height of the excluded-style lists */
var EXCLUDED_STYLES_BUTTON_PADDING = 32; /* ［除外するスタイル...］の文字の左右に足す幅 / width added around the Excluded Styles button label */

// =========================================
// ラベル定義 / Labels
// =========================================

// ローカライズ（再利用パーツ） / Localization (reusable)

/**
 * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
 * @returns {string} "ja" または "en"
 */
function getCurrentLang() {
    return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
}

var uiLang = getCurrentLang();

/**
 * LABELS から今の UI 言語の文言を取り出す。
 * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
 * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
 * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
 */
function getLabel(labelRef, placeholderValues) {
    var labelEntry = labelRef;
    if (typeof labelRef === "string") {
        var labelPathKeys = labelRef.split(".");
        labelEntry = LABELS;
        for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
            labelEntry = labelEntry[labelPathKeys[i]];
        }
    }
    var labelString;
    if (typeof labelEntry === "string") labelString = labelEntry;
    else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
    else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
    else return (typeof labelRef === "string") ? labelRef : "";
    return fillLabelPlaceholders(String(labelString), placeholderValues);
}

/**
 * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {Object|Array} [placeholderValues] - getLabel と同じ
 * @returns {string} コロン付きの文言
 */
function labelText(labelRef, placeholderValues) {
    return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
}

/**
 * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {string|number} value - コロンのあとに続ける値
 * @returns {string} 項目名と値をつないだ文字列
 */
function labelValueText(labelRef, value) {
    return labelText(labelRef) + " " + value;
}

/**
 * 文言の {name} や %1 に値を差し込む
 * @param {string} labelString - 文言
 * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
 * @returns {string} 差し込んだ文言
 */
function fillLabelPlaceholders(labelString, placeholderValues) {
    if (placeholderValues == null) return labelString;
    if (placeholderValues instanceof Array) {
        /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
        for (var i = placeholderValues.length; i >= 1; i--) {
            labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
        }
        return labelString;
    }
    for (var placeholderKey in placeholderValues) {
        if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
        labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
    }
    return labelString;
}

// ローカライズ（再利用パーツ）ここまで / End of the reusable localization

var LABELS = {
    dialog: {
        title: { ja: "全角・半角の変換と整形", en: "Convert Width & Clean Up Text" },
        excludedStyles: { ja: "除外するスタイル", en: "Excluded Styles" }
    },
    tab: {
        horizontal: { ja: "横組み", en: "Horizontal" },
        vertical: { ja: "縦組み", en: "Vertical" }
    },
    panel: {
        target: { ja: "対象", en: "Scope" },
        characterType: { ja: "文字種", en: "Character Types" },
        symbol: { ja: "記号", en: "Symbols" },
        bracket: { ja: "括弧", en: "Brackets" },
        punctuation: { ja: "句読点", en: "Punctuation" },
        vertical: { ja: "縦組み用", en: "Vertical Text" },
        highlight: { ja: "確認用の色分け", en: "Check Coloring" },
        paragraphStyles: { ja: "段落スタイル", en: "Paragraph Styles" },
        characterStyles: { ja: "文字スタイル", en: "Character Styles" }
    },
    radio: {
        targetSelection: { ja: "選択範囲", en: "Selection" },
        targetStory: { ja: "ストーリー", en: "Story" },
        targetDocument: { ja: "ドキュメント", en: "Document" }
    },
    column: {
        keep: { ja: "そのまま", en: "Keep" },
        half: { ja: "半角", en: "Half" },
        full: { ja: "全角", en: "Full" }
    },
    row: {
        katakana: { ja: "カタカナ", en: "Katakana" },
        alphabet: { ja: "アルファベット", en: "Letters" },
        digits: { ja: "数字", en: "Digits" },
        space: { ja: "スペース", en: "Space" },
        exclamation: { ja: "感嘆符", en: "Exclamation mark" },
        doubleQuote: { ja: "二重引用符", en: "Double quote" },
        numberSign: { ja: "シャープ", en: "Number sign" },
        dollar: { ja: "ドル", en: "Dollar sign" },
        percent: { ja: "パーセント", en: "Percent sign" },
        ampersand: { ja: "アンパサンド", en: "Ampersand" },
        apostrophe: { ja: "引用符", en: "Apostrophe" },
        leftParen: { ja: "左かっこ", en: "Left parenthesis" },
        rightParen: { ja: "右かっこ", en: "Right parenthesis" },
        asterisk: { ja: "アスタリスク", en: "Asterisk" },
        plus: { ja: "プラス", en: "Plus sign" },
        comma: { ja: "コンマ", en: "Comma" },
        hyphen: { ja: "ハイフン", en: "Hyphen" },
        period: { ja: "ピリオド", en: "Period" },
        slash: { ja: "スラッシュ", en: "Slash" },
        colon: { ja: "コロン", en: "Colon" },
        semicolon: { ja: "セミコロン", en: "Semicolon" },
        lessThan: { ja: "小なり", en: "Less-than sign" },
        equals: { ja: "イコール", en: "Equals sign" },
        greaterThan: { ja: "大なり", en: "Greater-than sign" },
        question: { ja: "疑問符", en: "Question mark" },
        exclamationQuestion: { ja: "感嘆符疑問符", en: "Exclamation-question" },
        exclamationRun: { ja: "2個以上の感嘆符", en: "Two or more exclamation marks" },
        atSign: { ja: "アットマーク", en: "At sign" },
        leftBracket: { ja: "左大かっこ", en: "Left bracket" },
        backslash: { ja: "バックスラッシュ", en: "Backslash" },
        rightBracket: { ja: "右大かっこ", en: "Right bracket" },
        caret: { ja: "ハット", en: "Caret" },
        underscore: { ja: "アンダースコア", en: "Underscore" },
        backtick: { ja: "バッククォート", en: "Backtick" },
        leftBrace: { ja: "左中かっこ", en: "Left brace" },
        verticalBar: { ja: "パイプ", en: "Vertical bar" },
        rightBrace: { ja: "右中かっこ", en: "Right brace" },
        tilde: { ja: "チルダ", en: "Tilde" },
        yen: { ja: "円マーク", en: "Yen sign" },
        kanaPunctuation: { ja: "句読点", en: "Japanese punctuation" },
        middleDot: { ja: "中黒", en: "Middle dot" },
        kanaLeftBracket: { ja: "左かぎかっこ", en: "Left corner bracket" },
        kanaRightBracket: { ja: "右かぎかっこ", en: "Right corner bracket" }
    },
    fieldLabel: {
        preset: { ja: "プリセット", en: "Preset" },
        /* 「…」は ScriptUI で天地中央に出るので「...」で書く / Written as "..." since "…" sits vertically centered in ScriptUI */
        toEllipsis: { ja: "...に変換", en: "Convert to ..." },
        punctuationStyle: { ja: "句読点の種類", en: "Punctuation style" },
        dashForm: { ja: "ダッシュ", en: "Dashes" },
        quoteForm: { ja: "全角の引用符", en: "Full-width quotes" },
        hyphenForm: { ja: "全角のハイフン", en: "Full-width hyphen" },
        tildeForm: { ja: "全角のチルダ", en: "Full-width tilde" },
        asteriskForm: { ja: "全角のアスタリスク", en: "Full-width asterisk" }
    },
    checkbox: {
        digitsByLength: { ja: "数字は1桁を全角、2桁以上を半角にする", en: "Digits: one digit full-width, two or more half-width" },
        spaceBetweenJapaneseOnly: { ja: "和文にはさまれたスペースだけを変換", en: "Convert spaces only between Japanese characters" },
        japaneseLatinSpace: { ja: "和欧間のスペースを削除", en: "Remove spaces between Japanese and Western text" },
        nakaguroToEllipsis: { ja: "・・・", en: "・・・" },
        periodsToEllipsis: { ja: "...", en: "..." },
        kutenToEllipsis: { ja: "。。。", en: "。。。" },
        westernPunctuationSpace: { ja: "欧文の,.:のあとにスペースを入れる", en: "Add a space after , . : in Western text" },
        bracketInnerSpace: { ja: "括弧の内側のスペースを削除", en: "Remove spaces inside brackets" },
        bracketOuterSpace: { ja: "括弧の外側のスペースを削除", en: "Remove spaces outside brackets" },
        numberCommaToTouten: { ja: "数字の中の「,」を「、」にする", en: "\",\" in numbers to \"、\"" },
        decimalToNakaguro: { ja: "数字の中の「.」を「・」にする", en: "\".\" in numbers to \"・\"" },
        longDigitsFullwidth: { ja: "3桁以上の数字は全角にする", en: "Numbers of 3+ digits to full-width" },
        twoDigitGlyphForm: { ja: "2桁の数字は等幅2桁字形にする", en: "Half-width forms for 2-digit numbers" },
        threeDigitGlyphForm: { ja: "3桁の数字は等幅3桁字形にする", en: "Third-width forms for 3-digit numbers" },
        shortCapsFullwidth: { ja: "3文字以内の大文字で構成する英単語は全角にする", en: "All-capital words of up to 3 letters to full-width" },
        unitsKumimoji: { ja: "数字の直後の単位を組文字にする（kg → ㌕）", en: "Units after digits to squares (kg → ㌕)" },
        highlightChanges: { ja: "変換した文字に色を付ける", en: "Color converted characters" }
    },
    preset: {
        standard: { ja: "標準", en: "Standard" },
        allKeep: { ja: "すべてそのまま", en: "Keep all" },
        asciiHalf: { ja: "英数字・記号を半角", en: "Letters, digits & symbols to half-width" },
        asciiFull: { ja: "英数字・記号を全角", en: "Letters, digits & symbols to full-width" },
        katakanaOnly: { ja: "カタカナだけ全角", en: "Katakana to full-width only" },
        vertical: { ja: "縦組み用", en: "For vertical typesetting" },
        western: { ja: "欧文組版用", en: "For Western typesetting" }
    },
    dropdown: {
        customPreset: { ja: "カスタム", en: "Custom" },
        punctuationStyleKeep: { ja: "そのまま", en: "Keep" },
        punctuationStyleJapanese: { ja: "、。にそろえる", en: "Unify to 、。" },
        punctuationStyleWestern: { ja: "，．にそろえる", en: "Unify to ，．" },
        dashFormKeep: { ja: "そのまま", en: "Keep" },
        dashFormEmDash: { ja: "—（全角ダッシュ）にそろえる", en: "Unify to — (em dash)" },
        dashFormHorizontalBar: { ja: "―（水平バー）にそろえる", en: "Unify to ― (horizontal bar)" },
        dashFormBoxDrawing: { ja: "─（罫線）にそろえる", en: "Unify to ─ (box drawing)" },
        quoteFormPlain: { ja: "＂＇（全角）", en: "＂＇ (full-width)" },
        quoteFormCurly: { ja: "“ ” ‘ ’（向きあり）", en: "“ ” ‘ ’ (curly)" },
        quoteFormMinute: { ja: "〝 〟（ミニュート）", en: "〝 〟 (minutes)" },
        hyphenFormPlain: { ja: "－（全角ハイフンマイナス）", en: "－ (full-width hyphen-minus)" },
        hyphenFormHyphen: { ja: "‐（ハイフン）", en: "‐ (hyphen)" },
        hyphenFormMinus: { ja: "−（マイナス）", en: "− (minus sign)" },
        tildeFormPlain: { ja: "～（全角チルダ）", en: "～ (full-width tilde)" },
        tildeFormWave: { ja: "〜（波ダッシュ）", en: "〜 (wave dash)" },
        asteriskFormPlain: { ja: "＊（全角アスタリスク）", en: "＊ (full-width asterisk)" },
        asteriskFormReference: { ja: "※（米印）", en: "※ (reference mark)" }
    },
    button: {
        restoreDefaults: { ja: "デフォルトに戻す", en: "Restore Defaults" },
        savePreset: { ja: "保存...", en: "Save..." },
        deletePreset: { ja: "削除", en: "Delete" },
        excludedStyles: { ja: "除外するスタイル...", en: "Excluded Styles..." },
        excludedStylesCount: { ja: "除外するスタイル（{count}）...", en: "Excluded Styles ({count})..." },
        clearSelection: { ja: "選択を解除", en: "Clear Selection" },
        ok: { ja: "OK", en: "OK" },
        cancel: { ja: "キャンセル", en: "Cancel" },
        convert: { ja: "変換する", en: "Convert" }
    },
    tooltip: {
        targetSelection: { ja: "選択した文字、または選択したテキストフレームのストーリーを変換します。", en: "Converts the selected text, or the stories of the selected text frames." },
        targetStory: { ja: "選択した文字やフレームを含むストーリー全体を変換します。", en: "Converts the whole stories that contain the selection." },
        targetDocument: { ja: "ドキュメント内のすべてのテキストを変換します。", en: "Converts all text in the document." },
        keep: { ja: "変換しません。", en: "Leaves the characters as they are." },
        half: { ja: "全角の文字を半角にします。", en: "Converts full-width characters to half-width." },
        full: { ja: "半角の文字を全角にします。", en: "Converts half-width characters to full-width." },
        digitsByLength: {
            ja: "数字が1桁なら全角、2桁以上続くなら半角にします。3.5 や 1,000 のように区切りをはさむ数字はひとつながりとして数え、英字に続く数字（A4 など）は半角にします。オンのあいだ、数字の行の選択肢は使いません。",
            en: "One digit becomes full-width, two or more become half-width. Numbers such as 3.5 or 1,000 count as one number, and digits next to letters (A4) become half-width. The digits row is ignored while this is on."
        },
        spaceBetweenJapaneseOnly: {
            ja: "スペースの行で変換するのを、前と後ろがどちらも和文の文字（かな・漢字・全角文字）のスペースだけにします。",
            en: "The space row converts only spaces with Japanese characters (kana, kanji, full-width characters) on both sides."
        },
        punctuationStyle: { ja: "，．（全角コンマ・ピリオド）と、。のどちらかにそろえます。", en: "Unifies Japanese punctuation to either 、。 or ，．." },
        japaneseLatinSpace: {
            ja: "和文の文字（かな・漢字・全角文字）と英数字のあいだのスペース（半角・全角）を削除します（第 3 章 → 第3章）。",
            en: "Removes spaces (half- or full-width) between Japanese characters (kana, kanji, full-width characters) and Latin letters or digits (第 3 章 → 第3章)."
        },
        westernPunctuationSpace: {
            ja: "英数字と英字にはさまれた半角の「,」、英字にはさまれた「:」、小文字と大文字にはさまれた「.」のあとに半角スペースを入れます（apples,oranges → apples, oranges、end.Next → end. Next）。1,000 や example.com、10:30 は変えません。",
            en: "Adds a space after a half-width \",\" between a letter or digit and a letter, a \":\" between letters, and a \".\" between a lowercase and an uppercase letter (apples,oranges → apples, oranges; end.Next → end. Next). 1,000, example.com and 10:30 are left alone."
        },
        nakaguroToEllipsis: {
            ja: "3つ続く中黒（・ ･）を三点リーダー（…）にします。6つなら……になります。",
            en: "Turns three middle dots in a row (・ or ･) into an ellipsis (…); six become ……."
        },
        periodsToEllipsis: {
            ja: "3つ続くピリオド（. ．）を三点リーダー（…）にします。6つなら……になります。",
            en: "Turns three periods in a row (. or ．) into an ellipsis (…); six become ……."
        },
        kutenToEllipsis: {
            ja: "3つ続く句点（。 ｡）を三点リーダー（…）にします。6つなら……になります。",
            en: "Turns three Japanese full stops in a row (。 or ｡) into an ellipsis (…); six become ……."
        },
        dashForm: {
            ja: "—（U+2014 全角ダッシュ）・―（U+2015 水平バー）・─（U+2500 罫線）を、選んだ字形にそろえます。続いたもの（—— ―― ──）は1字ずつ変えます。—だけの続きで、前後がどちらも和文の文字でないもの（word—word や 2020—2021）は欧文のダッシュとして残します。",
            en: "Unifies — (U+2014 em dash), ― (U+2015 horizontal bar) and ─ (U+2500 box drawing) to the chosen form; runs (——, ――, ──) are converted one by one. Runs of — alone with no Japanese character on either side (word—word, 2020—2021) are left as Western dashes."
        },
        bracketInnerSpace: {
            ja: "開き括弧の直後と閉じ括弧の直前のスペース（半角・全角）を削除します。向きの無い \" ' と < > は対象外です。",
            en: "Removes spaces (half- or full-width) right after opening brackets and right before closing brackets. Straight quotes and < > are not affected."
        },
        bracketOuterSpace: {
            ja: "全角の括弧・かぎかっこの直前と直後のスペースを削除します。半角の括弧の外側のスペースは残します。",
            en: "Removes spaces right before and after full-width brackets. Spaces outside half-width brackets are kept."
        },
        quoteForm: {
            ja: "二重引用符・引用符を全角にしたときの字形です。“ ” ‘ ’ と 〝 〟 は段落の中の順番で開き・閉じを決め、英数字にはさまれた ' はアポストロフィ（’）にします。〝 〟（縦組み用）のときの引用符は ＇ にします。半角にするときは、選んだ字形だけを半角に戻します。",
            en: "The form used when quotes become full-width. Curly quotes and minutes (〝 〟) open and close by their order in the paragraph; a ' between letters becomes an apostrophe (’). With minutes (for vertical text), single quotes become ＇. Converting to half-width only reverts the chosen form."
        },
        numberCommaToTouten: {
            ja: "数字にはさまれ、後ろがちょうど3桁の「,」「，」を「、」にします（1,000 → 1、000）。",
            en: "Turns \",\" and \"，\" between digits, followed by exactly three digits, into \"、\" (1,000 → 1、000)."
        },
        decimalToNakaguro: {
            ja: "数字にはさまれた「.」「．」を「・」にします（12.5 → 12・5）。",
            en: "Turns \".\" and \"．\" between digits into \"・\" (12.5 → 12・5)."
        },
        longDigitsFullwidth: {
            ja: "3桁以上の数字を全角にします（2026 → ２０２６）。3.5 や 1,000 のように区切りをはさむ数字はひとつながりとして数え、英字に続く数字は変えません。1〜2桁の数字は数字の行（または［数字は1桁を全角、2桁以上を半角にする］）に従います。",
            en: "Makes numbers of three or more digits full-width (2026 → ２０２６). Numbers such as 3.5 or 1,000 count as one number, and digits next to letters are left alone. Numbers of one or two digits follow the digits row (or \"Digits: one digit full-width…\")."
        },
        twoDigitGlyphForm: {
            ja: "半角2桁の数字に等幅半角の字形を適用し、2桁で全角1字分の幅にします（縦中横向け。縦中横は設定しません）。3.5 や 1,000 のように区切りをはさむ数字、英字に続く数字、全角の数字は変えません。",
            en: "Applies half-width forms to two half-width digits so they take one full-width character (for Tate-Chu-Yoko, which is not set). Numbers with separators (3.5, 1,000), digits next to letters and full-width digits are left alone."
        },
        threeDigitGlyphForm: {
            ja: "半角3桁の数字に等幅三分の字形を適用し、3桁で全角1字分の幅にします（縦中横向け。縦中横は設定しません）。3.5 や 1,000 のように区切りをはさむ数字、英字に続く数字、全角の数字は変えません。［3桁以上の数字は全角にする］で全角にした数字も変えません。",
            en: "Applies third-width forms to three half-width digits so they take one full-width character (for Tate-Chu-Yoko, which is not set). Numbers with separators (3.5, 1,000), digits next to letters and full-width digits are left alone, including those made full-width by \"Numbers of 3+ digits to full-width\"."
        },
        shortCapsFullwidth: {
            ja: "大文字だけでできた3文字以内の英単語を全角にします（PDF → ＰＤＦ、A → Ａ）。数字や記号を含む語（A4、U.S.）と4文字以上の語は変えません。",
            en: "Makes words of up to three capital letters full-width (PDF → ＰＤＦ, A → Ａ). Words with digits or marks (A4, U.S.) and longer words are left alone."
        },
        unitsKumimoji: {
            ja: "数字の直後（間の半角スペースは詰める）の mm・cm・km・m・mg・g・kg・t・ml・dL・kL・L・cal・kcal・cc を ㍉・㌢・㌖・㍍・㍉㌘・㌘・㌕・㌧・㍉㍑・㌥㍑・㌔㍑・㍑・㌍・㌔㌍・㏄ に、m2・cm3・m² などを ㎡・㎤ にします。全角の英字も対象です。km/h・mmHg・5m20 のように後ろに英字・数字・「/」が続くものは変えません。字形の無いフォントもあります。",
            en: "Turns units right after digits (a space between is removed), such as mm, cm, kg, ml, kcal and cc, into squares, and m2, cm3, m² into ㎡, ㎤; full-width letters too. Units followed by letters, digits or / (km/h, mmHg, 5m20) are left alone. Some fonts lack these glyphs."
        },
        highlightChanges: {
            ja: "変換した文字の塗りを赤にします（仕上がりの確認用。元の色には戻りません）。削除したスペースには付きません。",
            en: "Fills converted characters with red (for checking; the original colors are not restored). Removed spaces are not marked."
        },
        hyphenForm: { ja: "ハイフンを全角にしたときの字形です。半角にするときは、この字形だけを半角に戻します。", en: "The form used when hyphens become full-width. Converting to half-width only reverts this form." },
        tildeForm: { ja: "チルダを全角にしたときの字形です。半角にするときは、この字形だけを半角に戻します。", en: "The form used when tildes become full-width. Converting to half-width only reverts this form." },
        asteriskForm: { ja: "アスタリスクを全角にしたときの字形です。※（米印）を選ぶと、* と ※ を変換します。", en: "The form used when asterisks become full-width. Choose ※ (reference mark) to convert between * and ※." },
        excludedStyles: { ja: "選んだ段落スタイル・文字スタイルの文字は変換しません。", en: "Text in the chosen paragraph and character styles is not converted." },
        optionClick: { ja: "Option キーを押しながらクリックすると、このパネルの行をすべて同じ選択肢にします。", en: "Option-click to set every row in this panel to the same option." },
        restoreDefaults: { ja: "選択肢を最初の状態に戻します。", en: "Resets the options to their defaults." },
        preset: { ja: "選んだプリセットの設定を各行に反映します。今の設定に合うプリセットが無いときは「カスタム」になります。", en: "Applies the chosen preset to the rows. Shows \"Custom\" when no preset matches the current settings." },
        savePreset: { ja: "今の設定に名前を付けてプリセットとして保存します。", en: "Saves the current settings as a named preset." },
        deletePreset: { ja: "選んでいるプリセットを削除します（組み込みのプリセットは削除できません）。", en: "Deletes the chosen preset (built-in presets cannot be deleted)." }
    },
    prompt: {
        presetName: { ja: "プリセット名を入力してください。", en: "Enter a name for the preset." }
    },
    confirm: {
        overwritePreset: { ja: "プリセット「{name}」を上書きしますか？", en: "Overwrite the preset \"{name}\"?" },
        deletePreset: { ja: "プリセット「{name}」を削除しますか？", en: "Delete the preset \"{name}\"?" }
    },
    alert: {
        builtInPresetName: { ja: "「{name}」は組み込みのプリセットと同じ名前のため使えません。", en: "\"{name}\" is the name of a built-in preset and cannot be used." },
        presetSaveFailed: { ja: "プリセットを保存できませんでした。", en: "Could not save the presets." },
        noDocument: { ja: "ドキュメントを開いてください。", en: "Please open a document." },
        allKeep: { ja: "すべて「そのまま」のため、変換する文字がありません。", en: "Every row is set to \"Keep\", so there is nothing to convert." },
        notFound: { ja: "変換する文字は見つかりませんでした。", en: "No characters to convert were found." },
        converted: { ja: "{count} か所を変換しました。", en: "Converted {count} places." },
        breakdownLine: { ja: "{label} : {count}", en: "{label}: {count}" },
        failed: { ja: "{count} か所は変換できませんでした（ロックされたテキストなど）。", en: "{count} places could not be converted (locked text, etc.)." }
    },
    resultLabel: {
        punctuationStyle: { ja: "句読点の種類", en: "Punctuation style" },
        westernPunctuationSpace: { ja: "欧文の,.:のあとのスペース", en: "Spaces after , . : in Western text" },
        japaneseLatinSpace: { ja: "和欧間のスペース", en: "Spaces between Japanese and Western text" },
        nakaguroToEllipsis: { ja: "・・・ → …", en: "・・・ → …" },
        periodsToEllipsis: { ja: "... → …", en: "... → …" },
        kutenToEllipsis: { ja: "。。。 → …", en: "。。。 → …" },
        dashForm: { ja: "ダッシュ", en: "Dashes" },
        bracketInnerSpace: { ja: "括弧の内側のスペース", en: "Spaces inside brackets" },
        bracketOuterSpace: { ja: "括弧の外側のスペース", en: "Spaces outside brackets" },
        numberCommaToTouten: { ja: "数字の中の「,」", en: "\",\" in numbers" },
        decimalToNakaguro: { ja: "数字の中の「.」", en: "\".\" in numbers" },
        longDigitsFullwidth: { ja: "3桁以上の数字", en: "Numbers of 3+ digits" },
        twoDigitGlyphForm: { ja: "2桁の数字の等幅2桁字形", en: "Half-width forms for 2-digit numbers" },
        threeDigitGlyphForm: { ja: "3桁の数字の等幅3桁字形", en: "Third-width forms for 3-digit numbers" },
        shortCapsFullwidth: { ja: "3文字以内の大文字の英単語", en: "Capital words of up to 3 letters" },
        unitsKumimoji: { ja: "単位の組文字", en: "Units to squares" }
    },
    undo: {
        convert: { ja: "全角・半角の変換と整形", en: "Convert Width & Clean Up Text" }
    }
};

// =========================================
// 変換表 / Conversion table
// =========================================

/* 全角と半角のコード差（ASCII の ! 〜 ~ と全角英数・記号）/ Code offset between ASCII ! to ~ and their full-width forms */
var FULL_WIDTH_OFFSET = 0xFEE0;

/* 半角カタカナと全角の対応（同じ位置どうし）/ Half-width katakana and their full-width forms, matched by position */
var HALF_KANA = "ｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝﾞﾟ";
var FULL_KANA = "ヲァィゥェォャュョッーアイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワン゛゜";

/* 濁音・半濁音は半角では2文字になる / Voiced and semi-voiced kana take two characters in half-width */
var HALF_VOICED_BASES      = "ｳｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾊﾋﾌﾍﾎﾜｦ";
var FULL_VOICED_KANA       = "ヴガギグゲゴザジズゼゾダヂヅデドバビブベボヷヺ";
var HALF_SEMI_VOICED_BASES = "ﾊﾋﾌﾍﾎ";
var FULL_SEMI_VOICED_KANA  = "パピプペポ";

/* 記号の行（キー・半角の文字[・全角の文字]）/ Symbol rows (key, half-width character[, full-width character]) */
var SYMBOL_ROW_DEFS = [
    ["hyphen", "-"], ["underscore", "_"], ["ampersand", "&"], ["numberSign", "#"],
    ["dollar", "$"], ["yen", "¥", "￥"], ["percent", "%"], ["atSign", "@"],
    ["asterisk", "*"], ["equals", "="], ["plus", "+"], ["slash", "/"], ["backslash", "\\"],
    ["verticalBar", "|"], ["caret", "^"], ["backtick", "`"], ["tilde", "~"]
];

/* 句読点の行（ASCII の句読点。和文の句読点は PUNCTUATION_ROWS で足す）/ Punctuation rows (ASCII punctuation; the Japanese punctuation is added in PUNCTUATION_ROWS) */
var ASCII_PUNCTUATION_ROW_DEFS = [
    ["comma", ","], ["period", "."], ["colon", ":"],
    ["semicolon", ";"], ["exclamation", "!"], ["question", "?"]
];

/* 括弧の行（ASCII の引用符・括弧・不等号。かぎかっこは BRACKET_ROWS で足す）/ Bracket rows (ASCII quotes, brackets and less/greater-than signs; the corner brackets are added in BRACKET_ROWS) */
var ASCII_BRACKET_ROW_DEFS = [
    ["doubleQuote", "\""], ["apostrophe", "'"],
    ["leftParen", "("], ["rightParen", ")"], ["leftBracket", "["],
    ["rightBracket", "]"], ["leftBrace", "{"], ["rightBrace", "}"],
    ["lessThan", "<"], ["greaterThan", ">"]
];

/**
 * 1文字の半角とその全角（コード差 FULL_WIDTH_OFFSET）の組を返す
 * @param {number} halfCode - 半角の文字コード
 * @returns {string[]} [半角, 全角]
 */
function offsetPair(halfCode) {
    return [String.fromCharCode(halfCode), String.fromCharCode(halfCode + FULL_WIDTH_OFFSET)];
}

/**
 * 文字コードの範囲の半角・全角の組を並べる
 * @param {number} firstCode - 最初の半角の文字コード
 * @param {number} lastCode - 最後の半角の文字コード
 * @returns {Array<string[]>} [半角, 全角] の配列
 */
function offsetPairsInRange(firstCode, lastCode) {
    var pairs = [];
    for (var code = firstCode; code <= lastCode; code++) pairs.push(offsetPair(code));
    return pairs;
}

/**
 * 同じ長さの2つの文字列から、同じ位置の文字どうしの組を作る
 * @param {string} halfChars - 半角側の文字列
 * @param {string} fullChars - 全角側の文字列
 * @param {string} [halfSuffix] - 半角側の各文字に付ける文字（濁点・半濁点）
 * @returns {Array<string[]>} [半角, 全角] の配列
 */
function zipPairs(halfChars, fullChars, halfSuffix) {
    var pairs = [];
    for (var i = 0; i < halfChars.length; i++) {
        pairs.push([halfChars.charAt(i) + (halfSuffix || ""), fullChars.charAt(i)]);
    }
    return pairs;
}

/**
 * カタカナの半角・全角の組を返す（濁音・半濁音を含む）
 * @returns {Array<string[]>} [半角, 全角] の配列
 */
function buildKatakanaPairs() {
    return zipPairs(HALF_KANA, FULL_KANA)
        .concat(zipPairs(HALF_VOICED_BASES, FULL_VOICED_KANA, "ﾞ"))
        .concat(zipPairs(HALF_SEMI_VOICED_BASES, FULL_SEMI_VOICED_KANA, "ﾟ"));
}

/**
 * 行の定義を作る
 * @param {string} key - 行のキー（LABELS.row のキー、設定の保存にも使う）
 * @param {string} glyph - 項目名の後ろに添える文字（無ければ空文字）
 * @param {Array<string[]>} pairs - [半角, 全角] の配列
 * @param {Object} [rowFlags] - { keepsUnit: true } なら「そのまま」でも組をひとまとまりとして拾い、1文字ずつの行の変換から守る。
 *     { runChar: [半角, 全角] } なら、その文字が2個以上続く並びを1組として扱う（pairs は使わない）
 * @returns {{key: string, glyph: string, pairs: Array<string[]>, keepsUnit: boolean, runChar: string[]|null}} 行の定義
 */
function rowDef(key, glyph, pairs, rowFlags) {
    return {
        key: key,
        glyph: glyph,
        pairs: pairs,
        keepsUnit: !!(rowFlags && rowFlags.keepsUnit),
        runChar: (rowFlags && rowFlags.runChar) || null
    };
}

var CHARACTER_TYPE_ROWS = [
    rowDef("katakana", "", buildKatakanaPairs()),
    rowDef("alphabet", "", offsetPairsInRange(0x41, 0x5A).concat(offsetPairsInRange(0x61, 0x7A))),
    rowDef("digits", "", offsetPairsInRange(0x30, 0x39)),
    rowDef("space", "", [[" ", "　"]])
];

/**
 * ASCII の記号1文字ずつの行を作る（全角は3つ目の文字、無ければコード差 FULL_WIDTH_OFFSET）
 * @param {Array<string[]>} symbolRowDefs - [キー, 半角の文字, 全角の文字（省略可）] の配列
 * @returns {Array} 行の定義の配列
 */
function buildSymbolRows(symbolRowDefs) {
    var symbolRows = [];
    for (var i = 0; i < symbolRowDefs.length; i++) {
        var symbolChar = symbolRowDefs[i][1];
        var symbolPair = symbolRowDefs[i][2] ? [symbolChar, symbolRowDefs[i][2]] : offsetPair(symbolChar.charCodeAt(0));
        symbolRows.push(rowDef(symbolRowDefs[i][0], symbolChar, [symbolPair]));
    }
    return symbolRows;
}

/* 中黒は記号パネルに置くが、プリセットでは和文の約物として扱う / The middle dot sits in the symbol panel but presets treat it as Japanese punctuation */
var ASCII_SYMBOL_ROWS = buildSymbolRows(SYMBOL_ROW_DEFS);
var SYMBOL_ROWS = ASCII_SYMBOL_ROWS.concat([
    rowDef("middleDot", "･", [["･", "・"]])
]);

var ASCII_BRACKET_ROWS = buildSymbolRows(ASCII_BRACKET_ROW_DEFS);
var BRACKET_ROWS = ASCII_BRACKET_ROWS.concat([
    rowDef("kanaLeftBracket", "｢", [["｢", "「"]]),
    rowDef("kanaRightBracket", "｣", [["｣", "」"]])
]);

/* !? ?! と2個以上続く ! は1組。「そのまま」なら、感嘆符・疑問符の行の設定に関係なく元のまま残す / "!?", "?!" and runs of "!" are handled as units; when kept, they stay as they are whatever the exclamation and question rows say */
var ASCII_PUNCTUATION_ROWS = buildSymbolRows(ASCII_PUNCTUATION_ROW_DEFS).concat([
    rowDef("exclamationQuestion", "!?", [["!?", "！？"], ["?!", "？！"]], { keepsUnit: true }),
    rowDef("exclamationRun", "!!", [], { runChar: ["!", "！"] })
]);
var PUNCTUATION_ROWS = [
    rowDef("kanaPunctuation", "｡､", [["｡", "。"], ["､", "、"]])
].concat(ASCII_PUNCTUATION_ROWS);

var ALL_ROWS = CHARACTER_TYPE_ROWS.concat(PUNCTUATION_ROWS).concat(SYMBOL_ROWS).concat(BRACKET_ROWS);

/* 全角にしたときの字形を選べる行（行のキー → 設定のキーと字形の候補）。2文字の字形は、前後で決まる開き・閉じ / Rows whose full-width form can be chosen (row key → setting key and candidate forms); a two-character form is an opening/closing pair chosen by context */
var FULL_FORM_CHOICES = {
    hyphen: { settingKey: "hyphenForm", forms: [["\uFF0D"], ["\u2010"], ["\u2212"]] },
    tilde: { settingKey: "tildeForm", forms: [["\uFF5E"], ["\u301C"]] },
    asterisk: { settingKey: "asteriskForm", forms: [["\uFF0A"], ["\u203B"]] },
    doubleQuote: { settingKey: "quoteForm", forms: [["\uFF02"], ["\u201C", "\u201D"], ["\u301D", "\u301F"]] },
    apostrophe: { settingKey: "quoteForm", forms: [["\uFF07"], ["\u2018", "\u2019"], ["\uFF07"]] }  /* ミニュートに一重は無いので ＇ / minutes have no single form, so ＇ */
};

/* 行のほかの設定（キーと選べる値の数。値は 0 から数え、0 が既定）。プリセットにも入る。
   tab があるものはそのタブにだけ置き、ほかのタブでは 0 のまま /
   Settings besides the rows (key and number of values, counted from 0, with 0 as the default); saved in presets too.
   Those with a tab appear only on that tab and stay 0 on the other */
var EXTRA_SETTING_DEFS = [
    { key: "digitsByLength", valueCount: 2 },
    { key: "spaceBetweenJapaneseOnly", valueCount: 2 },
    { key: "japaneseLatinSpace", valueCount: 2 },
    { key: "punctuationStyle", valueCount: 3 },
    { key: "nakaguroToEllipsis", valueCount: 2 },
    { key: "periodsToEllipsis", valueCount: 2 },
    { key: "kutenToEllipsis", valueCount: 2 },
    { key: "dashForm", valueCount: 4 },
    { key: "westernPunctuationSpace", valueCount: 2, tab: "horizontal" },
    { key: "bracketInnerSpace", valueCount: 2 },
    { key: "bracketOuterSpace", valueCount: 2 },
    { key: "quoteForm", valueCount: 3 },
    { key: "hyphenForm", valueCount: 3 },
    { key: "tildeForm", valueCount: 2 },
    { key: "asteriskForm", valueCount: 2 },
    { key: "numberCommaToTouten", valueCount: 2, tab: "vertical" },
    { key: "decimalToNakaguro", valueCount: 2, tab: "vertical" },
    { key: "longDigitsFullwidth", valueCount: 2, tab: "vertical" },
    { key: "twoDigitGlyphForm", valueCount: 2, tab: "vertical" },
    { key: "threeDigitGlyphForm", valueCount: 2, tab: "vertical" },
    { key: "shortCapsFullwidth", valueCount: 2, tab: "vertical" },
    { key: "unitsKumimoji", valueCount: 2, tab: "vertical" }
];

/* 設定を別々に持つタブ（組み方向）の並び / Tabs (text directions), each with its own settings */
var TAB_KEYS = ["horizontal", "vertical"];

/* 行と行のほかの設定をまとめた一覧と、キーごとの値の数 / Every setting (rows and extras) and the number of values per key */
var SETTING_DEFS = [];
var SETTING_VALUE_COUNTS = {};
for (var rowIndex = 0; rowIndex < ALL_ROWS.length; rowIndex++) SETTING_DEFS.push({ key: ALL_ROWS[rowIndex].key, valueCount: 3 });
SETTING_DEFS = SETTING_DEFS.concat(EXTRA_SETTING_DEFS);
for (var settingIndex = 0; settingIndex < SETTING_DEFS.length; settingIndex++) {
    SETTING_VALUE_COUNTS[SETTING_DEFS[settingIndex].key] = SETTING_DEFS[settingIndex].valueCount;
}

/* 句読点の種類（punctuationStyle の値 → 置き換える組）/ Punctuation style (punctuationStyle value → replacements) */
var PUNCTUATION_STYLE_MAPS = [
    null,
    { "\uFF0C": "\u3001", "\uFF0E": "\u3002" },  /* ，． → 、。 */
    { "\u3001": "\uFF0C", "\u3002": "\uFF0E" }   /* 、。 → ，． */
];

/* 括弧の内側のスペースを削除する括弧（向きの無い " ' と不等号、アポストロフィと紛れる ‘ ’ は含めない）/ Brackets for removing inner spaces (straight quotes, < >, and ‘ ’ which look like apostrophes are excluded) */
var OPENING_BRACKETS = "([{\uFF08\uFF3B\uFF5B\uFF62\u300C\u300E\u3010\u3014\u3008\u300A\u201C\u301D";
var CLOSING_BRACKETS = ")]}\uFF09\uFF3D\uFF5D\uFF63\u300D\u300F\u3011\u3015\u3009\u300B\u201D\u301F";
/* 括弧の外側のスペースを削除する括弧（全角だけ。欧文の「word (note)」の空きは残す）/ Brackets for removing outer spaces (full-width only, so "word (note)" keeps its space) */
var FULL_WIDTH_OPENING_BRACKETS = "\uFF08\uFF3B\uFF5B\uFF62\u300C\u300E\u3010\u3014\u3008\u300A\u301D";
var FULL_WIDTH_CLOSING_BRACKETS = "\uFF09\uFF3D\uFF5D\uFF63\u300D\u300F\u3011\u3015\u3009\u300B\u301F";

/* 和文の文字（スペースの前後の判定に使う。全角スペースは含めない）/ Japanese characters, for the space check (the ideographic space itself is excluded) */
var JAPANESE_CHAR_PATTERN = /[\u3001-\u303F\u3040-\u30FF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\uFF01-\uFF60\uFF61-\uFF9F\uFFE0-\uFFEF]/;
/* 欧文の英字（1桁の数字に続く文字の判定に使う）/ Latin letters, for digits next to letters */
var LATIN_LETTER_PATTERN = /[A-Za-z\u00C0-\u024F\uFF21-\uFF3A\uFF41-\uFF5A]/;
/* 欧文の英数字（アポストロフィの判定に使う）/ Latin letters and digits, for apostrophes */
var LATIN_ALNUM_PATTERN = /[A-Za-z0-9\u00C0-\u024F]/;
/* 数字と、数字のあいだにはさまる区切り（DIGIT_RUN_PATTERN と同じ。段落の文字列の中で数字のつながりを読むのに使う）/ Digits and the separators inside a number (same as DIGIT_RUN_PATTERN), for reading digit runs in paragraph text */
var DIGIT_PATTERN = /[0-9\uFF10-\uFF19]/;
var DIGIT_SEPARATORS = ",.\uFF0C\uFF0E";
/* 英単語をつくる文字（半角・全角の英数字）と、前後が英数字のときだけ語の一部になるつなぎ（U.S. や AT&T）/ Characters forming a Latin word, and joiners that belong to the word only between two of them (U.S., AT&T) */
var WORD_CHAR_PATTERN = /[A-Za-z0-9\u00C0-\u024F\uFF10-\uFF19\uFF21-\uFF3A\uFF41-\uFF5A]/;
var WORD_JOINERS = "'\u2019-.&";
/* ［3文字以内の大文字で構成する英単語は全角にする］の対象（半角・全角の大文字だけで1〜3文字）/ Words for "all-capital words of up to 3 letters" (one to three capitals, half- or full-width) */
var SHORT_CAPS_WORD_PATTERN = /^[A-Z\uFF21-\uFF3A]{1,3}$/;
/* ［3桁以上の数字は全角にする］の桁数 / Digit count for "numbers of 3+ digits to full-width" */
var LONG_DIGIT_COUNT = 3;
/* ［2桁の数字は等幅2桁字形にする］［3桁の数字は等幅3桁字形にする］の対象（半角の数字だけ）と、桁数 → 設定のキー・字形 /
   Targets of the fixed-width form options (half-width digits only), and digit count → setting key and glyph form */
var HALF_WIDTH_DIGITS_PATTERN = /^[0-9]+$/;
var DIGIT_GLYPH_FORM_DEFS = {
    2: { settingKey: "twoDigitGlyphForm", glyphForm: AlternateGlyphForms.MONOSPACED_HALF_WIDTH_FORM },
    3: { settingKey: "threeDigitGlyphForm", glyphForm: AlternateGlyphForms.THIRD_WIDTH_FORM }
};

/* ［数字の直後の単位を組文字にする］の単位（英字の部分。全角も可）、面積・体積（m2・m²・cm3 など）、英字の範囲、数字との間に入れてよいスペース（全角スペースは除く）/
   Units for "units after digits to squares" (letters, full-width too), area and volume units (m2, m², cm3 ...), unit letters, and spaces allowed between digits and units (not the ideographic space) */
var UNIT_KUMIMOJI = {
    mm: "\u3349", cm: "\u3322", km: "\u3316", m: "\u334D",
    mg: "\u3349\u3318", g: "\u3318", kg: "\u3315", t: "\u3327",
    ml: "\u3349\u3351", mL: "\u3349\u3351", dl: "\u3325\u3351", dL: "\u3325\u3351", kl: "\u3314\u3351", kL: "\u3314\u3351", l: "\u3351", L: "\u3351",
    cal: "\u330D", kcal: "\u3314\u330D", cc: "\u33C4"
};
var UNIT_POWER_KUMIMOJI = {
    mm2: "\u339F", cm2: "\u33A0", m2: "\u33A1", km2: "\u33A2",
    mm3: "\u33A3", cm3: "\u33A4", m3: "\u33A5", km3: "\u33A6"
};
var UNIT_LETTER_PATTERN = /[A-Za-z\uFF21-\uFF3A\uFF41-\uFF5A]/;
var UNIT_GAP_PATTERN = /[ \u00A0\u2000-\u200A\u202F]/;

/* 数字のつながり（3.5 や 1,000 のように区切りをはさむものも1つ）/ A run of digits, including separators as in 3.5 or 1,000 */
var DIGIT_CLASS = "[\\x{0030}-\\x{0039}\\x{FF10}-\\x{FF19}]";
var DIGIT_RUN_PATTERN = DIGIT_CLASS + "+(?:[\\x{002C}\\x{002E}\\x{FF0C}\\x{FF0E}]" + DIGIT_CLASS + "+)*";
/* 大文字だけの1〜3文字（前後が英数字でないもの。つなぎ（U.S. など）はあとで段落の文字列で調べる）/ One to three capitals not touching letters or digits (joiners such as U.S. are checked in the paragraph text afterwards) */
var WORD_CHAR_CLASS = "[A-Za-z0-9\\x{00C0}-\\x{024F}\\x{FF10}-\\x{FF19}\\x{FF21}-\\x{FF3A}\\x{FF41}-\\x{FF5A}]";
var SHORT_CAPS_PATTERN = "(?<!" + WORD_CHAR_CLASS + ")[A-Z\\x{FF21}-\\x{FF3A}]{1,3}(?!" + WORD_CHAR_CLASS + ")";
/* 数字の直後の英字（間に半角スペース1つまで、後ろに 2・3・²・³ が1つまで。単位かどうかはあとで段落の文字列で調べる）/
   Letters right after a digit (up to one space between, and up to one 2, 3, ², ³ after; whether it is a unit is checked in the paragraph text afterwards) */
var UNIT_AFTER_DIGIT_PATTERN = "(?<=" + DIGIT_CLASS + ")[\\x{0020}\\x{00A0}\\x{2000}-\\x{200A}\\x{202F}]?[A-Za-z\\x{FF21}-\\x{FF3A}\\x{FF41}-\\x{FF5A}]+" +
    "[23\\x{FF12}\\x{FF13}\\x{00B2}\\x{00B3}]?";
/* 数字にはさまれ、後ろがちょうど3桁の「,」「，」と、数字にはさまれた「.」「．」/ "," between digits followed by exactly three digits, and "." between digits */
var NUMBER_COMMA_PATTERN = "(?<=" + DIGIT_CLASS + ")[\\x{002C}\\x{FF0C}](?=" + DIGIT_CLASS + "{3}(?!" + DIGIT_CLASS + "))";
var DECIMAL_POINT_PATTERN = "(?<=" + DIGIT_CLASS + ")[\\x{002E}\\x{FF0E}](?=" + DIGIT_CLASS + ")";
/* 三点リーダーにする3つ続きの中黒・ピリオド・句点（半角・全角）/ Three middle dots, periods or Japanese full stops in a row (half- or full-width) that become an ellipsis */
var NAKAGURO_ELLIPSIS_PATTERN = "[\\x{30FB}\\x{FF65}]{3}";
var PERIOD_ELLIPSIS_PATTERN = "[\\x{002E}\\x{FF0E}]{3}";
var KUTEN_ELLIPSIS_PATTERN = "[\\x{3002}\\x{FF61}]{3}";
/* ダッシュの続き（— ― ─ の混在も1つ）と、dashForm の値 → そろえる字形（0 はそのまま）/ Dash runs (mixed — ― ─ count as one) and dashForm value → target form (0 keeps) */
var DASH_RUN_PATTERN = "[\\x{2014}\\x{2015}\\x{2500}]+";
var DASH_FORMS = [null, "\u2014", "\u2015", "\u2500"];
/* 和文の文字と英数字のあいだのスペース（文字の範囲は JAPANESE_CHAR_PATTERN・LATIN_ALNUM_PATTERN と同じ）/ Spaces between Japanese characters and Latin letters or digits (same ranges as JAPANESE_CHAR_PATTERN and LATIN_ALNUM_PATTERN) */
var JAPANESE_CHAR_CLASS = "[\\x{3001}-\\x{303F}\\x{3040}-\\x{30FF}\\x{31F0}-\\x{31FF}\\x{3400}-\\x{4DBF}\\x{4E00}-\\x{9FFF}\\x{F900}-\\x{FAFF}\\x{FF01}-\\x{FF9F}\\x{FFE0}-\\x{FFEF}]";
var LATIN_ALNUM_CLASS = "[A-Za-z0-9\\x{00C0}-\\x{024F}]";
/* スペースを入れる欧文の「,」「.」「:」（「,」は英数字と英字、「.」は小文字と大文字、「:」は英字どうしにはさまれたもの）/ Western ",", "." and ":" that get a space ("," between a letter or digit and a letter, "." between lowercase and uppercase, ":" between letters) */
var WESTERN_PUNCTUATION_SPACE_PATTERN = "(?<=[A-Za-z0-9]),(?=[A-Za-z])|(?<=[a-z])\\.(?=[A-Z])|(?<=[A-Za-z]):(?=[A-Za-z])";
var JAPANESE_LATIN_SPACE_PATTERN = "(?<=" + JAPANESE_CHAR_CLASS + ")[ \\x{3000}]+(?=" + LATIN_ALNUM_CLASS + ")|" +
    "(?<=" + LATIN_ALNUM_CLASS + ")[ \\x{3000}]+(?=" + JAPANESE_CHAR_CLASS + ")";

// =========================================
// 前提チェック / Preconditions
// =========================================
if (app.documents.length === 0) {
    alert(getLabel(LABELS.alert.noDocument));
    return;
}

var activeDocument = app.activeDocument;

// =========================================
// 設定 / Settings
// =========================================

/**
 * 各行と行のほかの設定の既定値を返す
 * @returns {Object} 設定のキー → 値
 */
function getDefaultRowOptions() {
    var rowOptions = {};
    for (var i = 0; i < SETTING_DEFS.length; i++) {
        var settingKey = SETTING_DEFS[i].key;
        rowOptions[settingKey] = DEFAULT_ROW_OPTIONS.hasOwnProperty(settingKey) ? DEFAULT_ROW_OPTIONS[settingKey] : 0;
    }
    return rowOptions;
}

/**
 * すべての行を同じ選択肢にし（行のほかの設定は既定値）、一部だけ別の値にした設定を返す
 * @param {number} baseOption - すべての行の選択肢
 * @param {Object} [overrides] - 設定のキー → 値（baseOption より優先）
 * @returns {Object} 設定のキー → 値
 */
function rowOptionsWith(baseOption, overrides) {
    var rowOptions = {};
    for (var i = 0; i < EXTRA_SETTING_DEFS.length; i++) rowOptions[EXTRA_SETTING_DEFS[i].key] = 0;
    for (var j = 0; j < ALL_ROWS.length; j++) rowOptions[ALL_ROWS[j].key] = baseOption;
    return copyRowOptions(overrides, rowOptions);
}

/**
 * 保存してあった設定のうち、知っているキーの正しい値だけを写す
 * @param {Object} sourceOptions - 写す元（読み込んだ値）
 * @param {Object} rowOptions - 写す先（すべてのキーの値が入ったもの）
 * @returns {Object} 写す先と同じオブジェクト
 */
function copyRowOptions(sourceOptions, rowOptions) {
    if (!sourceOptions) return rowOptions;
    for (var settingKey in rowOptions) {
        if (!rowOptions.hasOwnProperty(settingKey)) continue;
        var value = sourceOptions[settingKey];
        if (typeof value === "number" && value % 1 === 0 && value >= 0 && value < SETTING_VALUE_COUNTS[settingKey]) {
            rowOptions[settingKey] = value;
        }
    }
    return rowOptions;
}

/**
 * 2つの設定がすべてのキーで同じか
 * @param {Object} firstOptions - 設定のキー → 値
 * @param {Object} secondOptions - 設定のキー → 値
 * @returns {boolean} 同じなら true
 */
function isSameRowOptions(firstOptions, secondOptions) {
    for (var i = 0; i < SETTING_DEFS.length; i++) {
        var settingKey = SETTING_DEFS[i].key;
        if (firstOptions[settingKey] !== secondOptions[settingKey]) return false;
    }
    return true;
}

/**
 * そのタブに置かない設定を 0 にした写しを返す
 * @param {Object} rowOptions - 設定のキー → 値（すべてのキーの値が入ったもの）
 * @param {string} tabKey - "horizontal" または "vertical"
 * @returns {Object} 設定のキー → 値（新しいオブジェクト）
 */
function rowOptionsForTab(rowOptions, tabKey) {
    var tabOptions = {};
    for (var i = 0; i < SETTING_DEFS.length; i++) {
        var settingDef = SETTING_DEFS[i];
        tabOptions[settingDef.key] = (settingDef.tab && settingDef.tab !== tabKey) ? 0 : rowOptions[settingDef.key];
    }
    return tabOptions;
}

/**
 * 文字列だけを取り出した配列を返す
 * @param {*} sourceValue - 読み込んだ値
 * @returns {string[]} 文字列の配列（配列でなければ空）
 */
function toStringArray(sourceValue) {
    var strings = [];
    if (!(sourceValue instanceof Array)) return strings;
    for (var i = 0; i < sourceValue.length; i++) {
        if (typeof sourceValue[i] === "string" && sourceValue[i] !== "") strings.push(sourceValue[i]);
    }
    return strings;
}

/**
 * 前回の設定を読む（無ければ既定値）
 * @returns {{rowOptionsByTab: Object, activeTab: string, scope: string|null, excludedStyles: {paragraph: string[], character: string[]}, highlightChanges: boolean}}
 *     タブごとの設定・開いていたタブ・対象・除外するスタイル・色を付けるか
 */
function loadSettings() {
    var saved = sessionStore.load({ rowOptionsByTab: { horizontal: {}, vertical: {} }, activeTab: "horizontal", scope: "", excludedStyles: {}, highlightChanges: false });
    var savedExcluded = saved.excludedStyles || {};
    var rowOptionsByTab = {};
    for (var i = 0; i < TAB_KEYS.length; i++) {
        var tabKey = TAB_KEYS[i];
        rowOptionsByTab[tabKey] = rowOptionsForTab(copyRowOptions(saved.rowOptionsByTab[tabKey], getDefaultRowOptions()), tabKey);
    }
    return {
        rowOptionsByTab: rowOptionsByTab,
        activeTab: (saved.activeTab === "vertical") ? "vertical" : "horizontal",
        scope: saved.scope || null,
        excludedStyles: { paragraph: toStringArray(savedExcluded.paragraph), character: toStringArray(savedExcluded.character) },
        highlightChanges: saved.highlightChanges
    };
}

/**
 * 設定を覚える（InDesign を終了するまで）
 * @param {{rowOptionsByTab: Object, activeTab: string, scope: string, excludedStyles: Object, highlightChanges: boolean}} settings -
 *     タブごとの設定・開いているタブ・対象・除外するスタイル・色を付けるか
 * @returns {void}
 */
function saveSettings(settings) {
    sessionStore.save({
        rowOptionsByTab: settings.rowOptionsByTab,
        activeTab: settings.activeTab,
        scope: settings.scope,
        excludedStyles: settings.excludedStyles,
        highlightChanges: settings.highlightChanges
    });
}

// =========================================
// プリセット / Presets
// =========================================

/* 組み込みのプリセット（削除・上書きはできない）。tab があるものは、選ぶとそのタブに切り替えて反映する / Built-in presets (cannot be deleted or overwritten); choosing one with a tab switches to that tab */
var BUILTIN_PRESETS = [
    { name: getLabel(LABELS.preset.standard), builtIn: true, rowOptions: getDefaultRowOptions() },
    /* すべての行を「そのまま」、オプションはすべてオフ。必要な行だけ選ぶときの起点 / Every row kept and every option off; a starting point for picking only the rows you need */
    { name: getLabel(LABELS.preset.allKeep), builtIn: true, rowOptions: rowOptionsWith(OPTION_KEEP) },
    {
        name: getLabel(LABELS.preset.asciiHalf), builtIn: true,
        rowOptions: rowOptionsWith(OPTION_KEEP, presetOverrides(OPTION_HALF, OPTION_HALF))
    },
    {
        name: getLabel(LABELS.preset.asciiFull), builtIn: true,
        rowOptions: rowOptionsWith(OPTION_KEEP, presetOverrides(OPTION_FULL, OPTION_FULL))
    },
    {
        name: getLabel(LABELS.preset.katakanaOnly), builtIn: true,
        rowOptions: rowOptionsWith(OPTION_KEEP, presetOverrides(OPTION_KEEP, OPTION_KEEP))
    },
    {
        /* 縦組み：数字は1桁を全角・2桁以上を半角（縦中横向け）、!? !! は半角、和文の間のスペースは全角、チルダは波ダッシュ。
           英字・コンマ・ピリオド・引用符の行はそのまま（欧文の単語を崩さない）、数字の中の「,」「.」は「、」「・」。
           和欧間のスペースは削除し、・・・ ... 。。。 は … にする /
           Vertical: one digit full-width, two or more half-width (for tate-chu-yoko); !? and !! half-width; spaces between Japanese full-width;
           tildes become wave dashes. Letter, comma, period and quote rows are kept so English words stay intact; "," and "." in numbers become 、 and ・.
           Spaces between Japanese and Western text are removed, and ・・・ ... 。。。 become … */
        name: getLabel(LABELS.preset.vertical), builtIn: true, tab: "vertical",
        rowOptions: rowOptionsWith(OPTION_FULL, {
            alphabet: OPTION_KEEP,
            digits: OPTION_KEEP,
            comma: OPTION_KEEP,
            period: OPTION_KEEP,
            doubleQuote: OPTION_KEEP,
            apostrophe: OPTION_KEEP,
            exclamationQuestion: OPTION_HALF,
            exclamationRun: OPTION_HALF,
            digitsByLength: 1,
            spaceBetweenJapaneseOnly: 1,
            tildeForm: 1,
            numberCommaToTouten: 1,
            decimalToNakaguro: 1,
            japaneseLatinSpace: 1,
            nakaguroToEllipsis: 1,
            periodsToEllipsis: 1,
            kutenToEllipsis: 1
        })
    },
    {
        /* 欧文組版：ASCII にある文字（全角スペース・円マークも）はすべて半角、和文のカタカナ・約物はそのまま、... は … にし、欧文の,.:のあとにスペース /
           Western typesetting: everything with an ASCII form (ideographic space and yen too) to half-width; Japanese kana and punctuation kept; ... becomes …; a space after , . : */
        name: getLabel(LABELS.preset.western), builtIn: true, tab: "horizontal",
        rowOptions: rowOptionsWith(OPTION_HALF, {
            katakana: OPTION_KEEP,
            kanaPunctuation: OPTION_KEEP,
            middleDot: OPTION_KEEP,
            kanaLeftBracket: OPTION_KEEP,
            kanaRightBracket: OPTION_KEEP,
            periodsToEllipsis: 1,
            westernPunctuationSpace: 1
        })
    }
];

/**
 * 組み込みのプリセットの選択肢を作る（カタカナ・句読点・かぎかっこは全角、スペースはそのまま）
 * @param {number} asciiOption - アルファベット・数字の選択肢
 * @param {number} symbolOption - 記号（円マークを含む）と ASCII の句読点・括弧の行の選択肢
 * @returns {Object} 行のキー → 選択肢の番号
 */
function presetOverrides(asciiOption, symbolOption) {
    var overrides = {
        katakana: OPTION_FULL,
        alphabet: asciiOption,
        digits: asciiOption,
        kanaPunctuation: OPTION_FULL,
        middleDot: OPTION_FULL,
        kanaLeftBracket: OPTION_FULL,
        kanaRightBracket: OPTION_FULL
    };
    var symbolRows = ASCII_SYMBOL_ROWS.concat(ASCII_PUNCTUATION_ROWS).concat(ASCII_BRACKET_ROWS);
    for (var i = 0; i < symbolRows.length; i++) overrides[symbolRows[i].key] = symbolOption;
    return overrides;
}

/**
 * プリセットがそのタブの設定か（tab の無いプリセットはどちらのタブの設定にもなる）。今の設定に合うプリセットを探すときに使う
 * @param {{tab: string|null}} preset - プリセット
 * @param {string} tabKey - "horizontal" または "vertical"
 * @returns {boolean} そのタブの設定なら true
 */
function isPresetForTab(preset, tabKey) {
    return !preset.tab || preset.tab === tabKey;
}

/**
 * 保存してあるユーザーのプリセットを読む
 * @returns {Array<{name: string, builtIn: boolean, tab: string|null, rowOptions: Object}>} プリセットの配列
 */
function loadUserPresets() {
    var storedPresets = presetStore.load({ presets: [] }).presets;
    var userPresets = [];
    for (var i = 0; i < storedPresets.length; i++) {
        var storedPreset = storedPresets[i];
        if (!storedPreset || typeof storedPreset.name !== "string" || storedPreset.name === "") continue;
        /* タブを持たない（v1.3.0 までに保存した）プリセットは、開いているタブに反映する / Presets without a tab (saved up to v1.3.0) apply to the open tab */
        var presetTab = (storedPreset.tab === "horizontal" || storedPreset.tab === "vertical") ? storedPreset.tab : null;
        /* 保存に無い行は「そのまま」/ Rows missing from the file are "Keep" */
        var presetOptions = copyRowOptions(storedPreset.rowOptions, rowOptionsWith(OPTION_KEEP));
        userPresets.push({
            name: storedPreset.name,
            builtIn: false,
            tab: presetTab,
            rowOptions: presetTab ? rowOptionsForTab(presetOptions, presetTab) : presetOptions
        });
    }
    return userPresets;
}

/**
 * ユーザーのプリセットをファイルに保存する
 * @param {Array<{name: string, tab: string|null, rowOptions: Object}>} userPresets - プリセットの配列
 * @returns {boolean} 保存できたら true
 */
function saveUserPresets(userPresets) {
    var storedPresets = [];
    for (var i = 0; i < userPresets.length; i++) {
        var storedPreset = { name: userPresets[i].name, rowOptions: userPresets[i].rowOptions };
        if (userPresets[i].tab) storedPreset.tab = userPresets[i].tab;
        storedPresets.push(storedPreset);
    }
    return presetStore.save({ presets: storedPresets });
}

// =========================================
// 対象の収集 / Target collection
// =========================================

/* findGrep を持つ文字の選択 / Text selections that support findGrep */
var TEXT_TYPES = {
    Text: true, Character: true, Word: true, Line: true, Paragraph: true,
    TextColumn: true, TextStyleRange: true, Story: true
};

/**
 * 表のセルのテキストを返す
 * @param {Cell} cell - 対象のセル
 * @returns {Text|null} セルのテキスト。取れなければ null
 */
function cellTextOf(cell) {
    try {
        if (cell.texts.length > 0) return cell.texts[0];
    } catch (e) { }
    return null;
}

/**
 * 選択から変換の対象を集める
 * @param {Array} items - 選択、またはグループ内のページアイテム
 * @param {boolean} wholeStory - true ならストーリー全体、false なら選択した文字だけ
 * @param {Array} targets - 集めた対象を足す配列
 * @param {Object} storyIds - 足したストーリーの ID（重複を除く）
 * @returns {void}
 */
function collectTargets(items, wholeStory, targets, storyIds) {
    for (var i = 0; i < items.length; i++) {
        var item = items[i];
        var typeName;
        try { typeName = item.constructor.name; } catch (e) { continue; }

        if (typeName === "TextFrame") {
            addStoryTarget(item.parentStory, targets, storyIds);
        } else if (typeName === "Group") {
            collectTargets(item.pageItems.everyItem().getElements(), wholeStory, targets, storyIds);
        } else if (typeName === "Cell" || typeName === "Table") {
            /* 複数セルの選択も Cell 1つで返るので .cells で展開する / A multi-cell selection comes back as one Cell; expand it with .cells */
            var cells = item.cells.everyItem().getElements();
            for (var j = 0; j < cells.length; j++) {
                var cellText = cellTextOf(cells[j]);
                if (!cellText) continue;
                if (wholeStory) addStoryTarget(cellText.parentStory, targets, storyIds);
                else targets.push(cellText);
            }
        } else if (TEXT_TYPES[typeName] || typeName === "InsertionPoint") {
            if (wholeStory) addStoryTarget(typeName === "Story" ? item : item.parentStory, targets, storyIds);
            else if (typeName !== "InsertionPoint" && item.length > 0) targets.push(item);
        }
    }
}

/**
 * ストーリーを対象に足す（同じストーリーは1回だけ）
 * @param {Story} story - 足すストーリー
 * @param {Array} targets - 対象の配列
 * @param {Object} storyIds - 足したストーリーの ID
 * @returns {void}
 */
function addStoryTarget(story, targets, storyIds) {
    if (!story || !story.isValid) return;
    if (storyIds[story.id]) return;
    storyIds[story.id] = true;
    targets.push(story);
}

/**
 * 選択から対象を集めて返す
 * @param {boolean} wholeStory - true ならストーリー全体、false なら選択した文字だけ
 * @returns {Array} 対象（Story・Text など findGrep を持つもの）
 */
function getSelectionTargets(wholeStory) {
    var targets = [];
    collectTargets(app.selection, wholeStory, targets, {});
    return targets;
}

// =========================================
// 変換 / Conversion
// =========================================

/**
 * 行の [半角, 全角の字形の配列] の組を返す（字形を選べる行は、選んだ字形にする）
 * @param {Object} row - 行の定義
 * @param {Object} rowOptions - 設定のキー → 値
 * @returns {Array} [半角, 全角の字形の配列] の配列。字形が2つなら開き・閉じ
 */
function getRowPairs(row, rowOptions) {
    var formChoice = FULL_FORM_CHOICES[row.key];
    if (formChoice) return [[row.pairs[0][0], formChoice.forms[rowOptions[formChoice.settingKey] || 0]]];
    var rowPairs = [];
    for (var i = 0; i < row.pairs.length; i++) rowPairs.push([row.pairs[i][0], [row.pairs[i][1]]]);
    return rowPairs;
}

/**
 * 設定から、変換元の文字 → 変換後の文字の表と、ほかの処理の有無をまとめる
 * @param {Object} rowOptions - 設定のキー → 値
 * @returns {{map: Object, rowKeyBySource: Object, runUnits: Array, size: number, digitsByLength: boolean,
 *     spaceBetweenJapaneseOnly: boolean, japaneseLatinSpace: boolean, punctuationStyle: number, nakaguroToEllipsis: boolean, periodsToEllipsis: boolean, kutenToEllipsis: boolean,
 *     dashForm: number, westernPunctuationSpace: boolean,
 *     bracketInnerSpace: boolean, bracketOuterSpace: boolean,
 *     numberCommaToTouten: boolean, decimalToNakaguro: boolean, longDigitsFullwidth: boolean, unitsKumimoji: boolean, twoDigitGlyphForm: boolean, threeDigitGlyphForm: boolean,
 *     shortCapsFullwidth: boolean}}
 *     変換表（値は文字列、向きで決まる引用符は [開き, 閉じ]）・変換元の行のキー・連続する文字の組・実際に変換する項目の数（守るだけの組は数えない）とほかの処理
 */
function buildConversionMap(rowOptions) {
    var conversionMap = {};
    var rowKeyBySource = {};
    var runUnits = [];
    var mapSize = 0;
    var digitsByLength = (rowOptions.digitsByLength === 1);
    for (var i = 0; i < ALL_ROWS.length; i++) {
        var row = ALL_ROWS[i];
        var option = rowOptions[row.key];
        var isConverting = (option === OPTION_HALF || option === OPTION_FULL);
        /* 桁数で決めるときは、数字の行の選択肢は使わない / The digits row is ignored when digits go by length */
        if (row.key === "digits" && digitsByLength) continue;
        if (row.runChar) {
            /* 「そのまま」でも拾って、1文字ずつの行の変換から守る / Picked up even when kept, so the single-character rows leave it alone */
            runUnits.push({ key: row.key, halfChar: row.runChar[0], fullChar: row.runChar[1], option: option });
            if (isConverting) mapSize++;
            continue;
        }
        var rowPairs = getRowPairs(row, rowOptions);
        for (var j = 0; j < rowPairs.length; j++) {
            var halfText = rowPairs[j][0];
            var fullForms = rowPairs[j][1];
            if (row.keepsUnit) {
                /* ひとまとまりの組は、まず元と同じ文字に置き換える項目を入れて守る（数には入れない）/ Map a unit to itself first to protect it (not counted) */
                conversionMap[halfText] = halfText;
                for (var k = 0; k < fullForms.length; k++) conversionMap[fullForms[k]] = fullForms[k];
            }
            if (!isConverting) continue;
            /* 半角にするなら全角が元、全角にするなら半角が元 / The source is the full-width form when converting to half-width, and vice versa */
            if (option === OPTION_HALF) {
                for (var m = 0; m < fullForms.length; m++) {
                    conversionMap[fullForms[m]] = halfText;
                    rowKeyBySource[fullForms[m]] = row.key;
                }
            } else {
                conversionMap[halfText] = (fullForms.length === 1) ? fullForms[0] : fullForms;
                rowKeyBySource[halfText] = row.key;
            }
            mapSize++;
        }
    }
    return {
        map: conversionMap,
        rowKeyBySource: rowKeyBySource,
        runUnits: runUnits,
        size: mapSize,
        digitsByLength: digitsByLength,
        spaceBetweenJapaneseOnly: (rowOptions.spaceBetweenJapaneseOnly === 1),
        japaneseLatinSpace: (rowOptions.japaneseLatinSpace === 1),
        punctuationStyle: rowOptions.punctuationStyle || 0,
        nakaguroToEllipsis: (rowOptions.nakaguroToEllipsis === 1),
        periodsToEllipsis: (rowOptions.periodsToEllipsis === 1),
        kutenToEllipsis: (rowOptions.kutenToEllipsis === 1),
        dashForm: rowOptions.dashForm || 0,
        westernPunctuationSpace: (rowOptions.westernPunctuationSpace === 1),
        bracketInnerSpace: (rowOptions.bracketInnerSpace === 1),
        bracketOuterSpace: (rowOptions.bracketOuterSpace === 1),
        numberCommaToTouten: (rowOptions.numberCommaToTouten === 1),
        decimalToNakaguro: (rowOptions.decimalToNakaguro === 1),
        longDigitsFullwidth: (rowOptions.longDigitsFullwidth === 1),
        unitsKumimoji: (rowOptions.unitsKumimoji === 1),
        twoDigitGlyphForm: (rowOptions.twoDigitGlyphForm === 1),
        threeDigitGlyphForm: (rowOptions.threeDigitGlyphForm === 1),
        shortCapsFullwidth: (rowOptions.shortCapsFullwidth === 1)
    };
}

/**
 * 変換する処理が1つでもあるか
 * @param {Object} conversion - buildConversionMap() の戻り値
 * @returns {boolean} あれば true
 */
function hasConversionWork(conversion) {
    return conversion.size > 0 || conversion.digitsByLength || conversion.punctuationStyle > 0 ||
        conversion.japaneseLatinSpace || conversion.nakaguroToEllipsis || conversion.periodsToEllipsis || conversion.kutenToEllipsis || conversion.dashForm > 0 ||
        conversion.westernPunctuationSpace ||
        conversion.bracketInnerSpace || conversion.bracketOuterSpace || conversion.numberCommaToTouten || conversion.decimalToNakaguro ||
        conversion.longDigitsFullwidth || conversion.unitsKumimoji || conversion.twoDigitGlyphForm || conversion.threeDigitGlyphForm || conversion.shortCapsFullwidth;
}

/**
 * 文字コードを GREP の \x{XXXX} にする
 * @param {number} charCode - 文字コード
 * @returns {string} GREP の文字コード表記
 */
function toGrepCode(charCode) {
    return "\\x{" + ("0000" + charCode.toString(16).toUpperCase()).slice(-4) + "}";
}

/**
 * 数値の配列を小さい順に並べ替える（比較関数つき sort() は使わない）
 * @param {number[]} numbers - 並べ替える配列（その場で並べ替える）
 * @returns {number[]} 同じ配列
 */
function sortNumbers(numbers) {
    for (var i = 1; i < numbers.length; i++) {
        var current = numbers[i];
        var j = i - 1;
        while (j >= 0 && numbers[j] > current) {
            numbers[j + 1] = numbers[j];
            j--;
        }
        numbers[j + 1] = current;
    }
    return numbers;
}

/**
 * 文字コードの集まりを、連続する範囲をまとめた GREP の文字クラスにする
 * @param {number[]} charCodes - 文字コードの配列
 * @returns {string} [ … ] の文字クラス
 */
function buildCharacterClass(charCodes) {
    var codes = sortNumbers(charCodes);
    var classParts = [];
    var i = 0;
    while (i < codes.length) {
        var rangeEnd = i;
        while (rangeEnd + 1 < codes.length && codes[rangeEnd + 1] === codes[rangeEnd] + 1) rangeEnd++;
        classParts.push(rangeEnd > i ? toGrepCode(codes[i]) + "-" + toGrepCode(codes[rangeEnd]) : toGrepCode(codes[i]));
        i = rangeEnd + 1;
    }
    return "[" + classParts.join("") + "]";
}

/**
 * 文字列の各文字を文字クラスにする
 * @param {string} characters - 文字の並び
 * @returns {string} [ … ] の文字クラス
 */
function buildCharacterClassFromString(characters) {
    var charCodes = [];
    for (var i = 0; i < characters.length; i++) charCodes.push(characters.charCodeAt(i));
    return buildCharacterClass(charCodes);
}

/**
 * 変換表の変換元をすべて拾う GREP を作る。
 * 2個以上続く文字、2文字の組（半角の濁音・半濁音、!? など）を先に並べ、1文字の候補より優先させる
 * @param {Object} conversionMap - 変換元 → 変換後
 * @param {Array} [runUnits] - 2個以上続く文字の組（buildConversionMap() の runUnits）
 * @returns {string} GREP の検索文字列
 */
function buildGrepPattern(conversionMap, runUnits) {
    var singleCodes = [];
    var baseCodesByMark = {};
    var marks = [];
    for (var sourceText in conversionMap) {
        if (!conversionMap.hasOwnProperty(sourceText)) continue;
        if (sourceText.length === 1) {
            singleCodes.push(sourceText.charCodeAt(0));
            continue;
        }
        var mark = sourceText.charAt(1);
        if (!baseCodesByMark[mark]) {
            baseCodesByMark[mark] = [];
            marks.push(mark);
        }
        baseCodesByMark[mark].push(sourceText.charCodeAt(0));
    }
    var alternatives = [];
    for (var r = 0; runUnits && r < runUnits.length; r++) {
        alternatives.push(toGrepCode(runUnits[r].halfChar.charCodeAt(0)) + "{2,}");
        alternatives.push(toGrepCode(runUnits[r].fullChar.charCodeAt(0)) + "{2,}");
    }
    for (var i = 0; i < marks.length; i++) {
        alternatives.push(buildCharacterClass(baseCodesByMark[marks[i]]) + toGrepCode(marks[i].charCodeAt(0)));
    }
    if (singleCodes.length > 0) alternatives.push(buildCharacterClass(singleCodes));
    return alternatives.join("|");
}

/* 検索のオプション。文字コードで拾うので、かな・全角半角は区別する / Find options; matching is by code point, so kana and width stay sensitive */
var GREP_OPTION_VALUES = {
    includeFootnotes: true,
    includeHiddenLayers: false,
    includeLockedLayersForFind: false,
    includeLockedStoriesForFind: false,
    includeMasterPages: INCLUDE_MASTER_PAGES,
    kanaSensitive: true,
    widthSensitive: true
};

/**
 * GREP 検索のオプションを変換用に切り替えて処理を実行し、終わったら元に戻す
 * @param {Function} task - 実行する処理
 * @returns {*} task の戻り値
 */
function runWithGrepOptions(task) {
    var grepOptions = app.findChangeGrepOptions;
    var savedValues = {};
    for (var optionName in GREP_OPTION_VALUES) {
        if (!GREP_OPTION_VALUES.hasOwnProperty(optionName)) continue;
        try {
            savedValues[optionName] = grepOptions[optionName];
            grepOptions[optionName] = GREP_OPTION_VALUES[optionName];
        } catch (e) { }
    }
    app.findGrepPreferences = NothingEnum.NOTHING;
    app.changeGrepPreferences = NothingEnum.NOTHING;
    try {
        return task();
    } finally {
        app.findGrepPreferences = NothingEnum.NOTHING;
        app.changeGrepPreferences = NothingEnum.NOTHING;
        for (var savedName in savedValues) {
            if (savedValues.hasOwnProperty(savedName)) grepOptions[savedName] = savedValues[savedName];
        }
    }
}

/**
 * 括弧のまわりのスペースを拾う GREP を作る
 * @param {boolean} isInner - true なら内側（開き括弧の直後・閉じ括弧の直前）、false なら外側（全角の括弧の直前・直後）
 * @returns {string} GREP の検索文字列
 */
function buildBracketSpacePattern(isInner) {
    var spaces = buildCharacterClassFromString(" \u3000") + "+";
    if (isInner) {
        return "(?<=" + buildCharacterClassFromString(OPENING_BRACKETS) + ")" + spaces + "|" +
            spaces + "(?=" + buildCharacterClassFromString(CLOSING_BRACKETS) + ")";
    }
    return spaces + "(?=" + buildCharacterClassFromString(FULL_WIDTH_OPENING_BRACKETS) + ")|" +
        "(?<=" + buildCharacterClassFromString(FULL_WIDTH_CLOSING_BRACKETS) + ")" + spaces;
}

/**
 * 見つかった文字の段落の文字列と、段落の中での位置を返す
 * @param {Text} foundText - 見つかった文字
 * @returns {{text: string, offset: number}|null} 段落の文字列と位置。取れなければ null
 */
function getParagraphContext(foundText) {
    try {
        var paragraph = foundText.paragraphs[0];
        var paragraphText = paragraph.contents;
        var offset = foundText.index - paragraph.index;
        if (typeof paragraphText !== "string" || offset < 0 || offset >= paragraphText.length) return null;
        return { text: paragraphText, offset: offset };
    } catch (e) {
        return null;
    }
}

/**
 * 見つかった文字の直前と直後の1文字を返す（段落の外は空文字）
 * @param {Text} foundText - 見つかった文字
 * @param {number} foundLength - 見つかった文字の長さ
 * @returns {{previous: string, next: string}} 直前と直後の文字
 */
function getNeighborChars(foundText, foundLength) {
    var context = getParagraphContext(foundText);
    if (!context) return { previous: "", next: "" };
    return {
        previous: context.text.charAt(context.offset - 1),
        next: context.text.charAt(context.offset + foundLength)
    };
}

/**
 * 段落の文字列の位置にある ' が、英数字にはさまれたアポストロフィか
 * @param {string} paragraphText - 段落の文字列
 * @param {number} offset - ' の位置
 * @returns {boolean} アポストロフィなら true
 */
function isApostropheAt(paragraphText, offset) {
    return LATIN_ALNUM_PATTERN.test(paragraphText.charAt(offset - 1)) && LATIN_ALNUM_PATTERN.test(paragraphText.charAt(offset + 1));
}

/**
 * 向きのある引用符の開き・閉じを選ぶ。
 * 段落の中で前にある同じ引用符の数が偶数なら開き、奇数なら閉じ。英数字にはさまれた ' はアポストロフィ（閉じ）
 * @param {Text} foundText - 見つかった引用符
 * @param {string} sourceText - 見つかった文字（" または '）
 * @param {string[]} quoteForms - [開き, 閉じ]
 * @returns {string} 置き換える引用符
 */
function chooseQuoteForm(foundText, sourceText, quoteForms) {
    var context = getParagraphContext(foundText);
    if (!context) return quoteForms[0];
    if (sourceText === "'" && isApostropheAt(context.text, context.offset)) return quoteForms[1];
    var quoteCount = 0;
    for (var i = 0; i < context.offset; i++) {
        if (context.text.charAt(i) !== sourceText) continue;
        if (sourceText === "'" && isApostropheAt(context.text, i)) continue;
        quoteCount++;
    }
    return (quoteCount % 2 === 0) ? quoteForms[0] : quoteForms[1];
}

/**
 * 文字列が同じ文字の2個以上の並びか
 * @param {string} sourceText - 調べる文字列
 * @param {string} repeatedChar - 文字
 * @returns {boolean} 並びなら true
 */
function isRunOf(sourceText, repeatedChar) {
    if (sourceText.length < 2) return false;
    for (var i = 0; i < sourceText.length; i++) {
        if (sourceText.charAt(i) !== repeatedChar) return false;
    }
    return true;
}

/**
 * 文字列の中の文字をすべて別の文字に置き換える
 * @param {string} sourceText - 元の文字列
 * @param {string} fromChar - 置き換える文字
 * @param {string} toChar - 置き換え後の文字
 * @returns {string} 置き換えた文字列
 */
function replaceAllChars(sourceText, fromChar, toChar) {
    return sourceText.split(fromChar).join(toChar);
}

/**
 * 変換表で置き換える文字を決める関数を作る
 * @param {Object} conversion - buildConversionMap() の戻り値
 * @returns {Function} (foundText, sourceText) → {key, text}|null
 */
function makeTableReplacer(conversion) {
    return function (foundText, sourceText) {
        for (var i = 0; i < conversion.runUnits.length; i++) {
            var runUnit = conversion.runUnits[i];
            if (!isRunOf(sourceText, runUnit.halfChar) && !isRunOf(sourceText, runUnit.fullChar)) continue;
            /* 2個以上続く文字。「そのまま」なら守るだけ / A run of characters; only protected when kept */
            var runText = sourceText;
            if (runUnit.option === OPTION_HALF) runText = replaceAllChars(sourceText, runUnit.fullChar, runUnit.halfChar);
            else if (runUnit.option === OPTION_FULL) runText = replaceAllChars(sourceText, runUnit.halfChar, runUnit.fullChar);
            return (runText === sourceText) ? null : { key: runUnit.key, text: runText };
        }
        if (!conversion.map.hasOwnProperty(sourceText)) return null;
        var replacement = conversion.map[sourceText];
        /* 守るだけの組（元と同じ）は書き換えない / Units that are only protected (mapped to themselves) are left untouched */
        if (replacement === sourceText) return null;
        var rowKey = conversion.rowKeyBySource[sourceText];
        if ((rowKey === "digits" && conversion.longDigitsFullwidth) || (rowKey === "alphabet" && conversion.shortCapsFullwidth)) {
            var context = getParagraphContext(foundText);
            if (context && isLeftToLaterPass(context.text, context.offset, rowKey, conversion)) return null;
        }
        if (conversion.spaceBetweenJapaneseOnly && (sourceText === " " || sourceText === "\u3000")) {
            var neighbors = getNeighborChars(foundText, sourceText.length);
            if (!JAPANESE_CHAR_PATTERN.test(neighbors.previous) || !JAPANESE_CHAR_PATTERN.test(neighbors.next)) return null;
        }
        if (replacement instanceof Array) replacement = chooseQuoteForm(foundText, sourceText, replacement);
        return { key: conversion.rowKeyBySource[sourceText], text: replacement };
    };
}

/**
 * 位置から始まる数字のつながりを読む（3.5 や 1,000 のように、数字にはさまれた区切りもつながりに含める）
 * @param {string} text - 文字列
 * @param {number} startOffset - つながりの先頭（数字）の位置
 * @returns {{end: number, digitCount: number}} 終わり（含まない）と数字の数
 */
function readDigitRun(text, startOffset) {
    var runEnd = startOffset;
    var digitCount = 0;
    while (runEnd < text.length) {
        if (DIGIT_PATTERN.test(text.charAt(runEnd))) {
            digitCount++;
            runEnd++;
        } else if (DIGIT_SEPARATORS.indexOf(text.charAt(runEnd)) >= 0 && DIGIT_PATTERN.test(text.charAt(runEnd + 1))) {
            runEnd++;
        } else {
            break;
        }
    }
    return { end: runEnd, digitCount: digitCount };
}

/**
 * 数字のつながりを［3桁以上の数字は全角にする］で全角にするか（英字に続くものは除く）
 * @param {string} text - 文字列
 * @param {number} runStart - つながりの先頭
 * @param {{end: number, digitCount: number}} digitRun - readDigitRun() の戻り値
 * @returns {boolean} 全角にするなら true
 */
function isLongDigitRun(text, runStart, digitRun) {
    return digitRun.digitCount >= LONG_DIGIT_COUNT &&
        !LATIN_LETTER_PATTERN.test(text.charAt(runStart - 1)) && !LATIN_LETTER_PATTERN.test(text.charAt(digitRun.end));
}

/**
 * 位置の数字を含む数字のつながりの先頭を返す（数字にはさまれた区切りもつながりに含める）
 * @param {string} text - 文字列
 * @param {number} offset - 数字の位置
 * @returns {number} つながりの先頭
 */
function findDigitRunStart(text, offset) {
    var runStart = offset;
    while (runStart > 0) {
        if (DIGIT_PATTERN.test(text.charAt(runStart - 1))) runStart--;
        else if (DIGIT_SEPARATORS.indexOf(text.charAt(runStart - 1)) >= 0 && DIGIT_PATTERN.test(text.charAt(runStart - 2))) runStart -= 2;
        else break;
    }
    return runStart;
}

/**
 * 位置の数字が、［3桁以上の数字は全角にする］で全角にするつながりの中にあるか
 * @param {string} text - 文字列
 * @param {number} offset - 数字の位置
 * @returns {boolean} 中にあれば true
 */
function isInLongDigitRun(text, offset) {
    var runStart = findDigitRunStart(text, offset);
    return isLongDigitRun(text, runStart, readDigitRun(text, runStart));
}

/**
 * 位置の文字が英単語の一部か（つなぎは前後が英数字のときだけ）
 * @param {string} text - 文字列
 * @param {number} offset - 位置
 * @returns {boolean} 英単語の一部なら true
 */
function isWordCharAt(text, offset) {
    var currentChar = text.charAt(offset);
    if (currentChar === "") return false;
    if (WORD_CHAR_PATTERN.test(currentChar)) return true;
    return WORD_JOINERS.indexOf(currentChar) >= 0 && WORD_CHAR_PATTERN.test(text.charAt(offset - 1)) && WORD_CHAR_PATTERN.test(text.charAt(offset + 1));
}

/**
 * 位置の文字を含む英単語の範囲を返す
 * @param {string} text - 文字列
 * @param {number} offset - 英単語の中の位置
 * @returns {{start: number, end: number}} 先頭と終わり（含まない）
 */
function findWordBounds(text, offset) {
    var wordStart = offset;
    while (wordStart > 0 && isWordCharAt(text, wordStart - 1)) wordStart--;
    var wordEnd = offset + 1;
    while (wordEnd < text.length && isWordCharAt(text, wordEnd)) wordEnd++;
    return { start: wordStart, end: wordEnd };
}

/**
 * 位置の文字が、［3文字以内の大文字で構成する英単語は全角にする］の対象の語の中にあるか
 * @param {string} text - 文字列
 * @param {number} offset - 位置
 * @returns {boolean} 中にあれば true
 */
function isInShortCapsWord(text, offset) {
    var wordBounds = findWordBounds(text, offset);
    return SHORT_CAPS_WORD_PATTERN.test(text.substring(wordBounds.start, wordBounds.end));
}

/**
 * 数字の幅をそろえる（区切りはそのまま）
 * @param {string} sourceText - 数字のつながり
 * @param {boolean} toFullWidth - true なら全角、false なら半角
 * @returns {string} そろえた文字列
 */
function setDigitWidth(sourceText, toFullWidth) {
    var digitText = "";
    for (var i = 0; i < sourceText.length; i++) {
        var charCode = sourceText.charCodeAt(i);
        if (toFullWidth && charCode >= 0x30 && charCode <= 0x39) charCode += FULL_WIDTH_OFFSET;
        else if (!toFullWidth && charCode >= 0xFF10 && charCode <= 0xFF19) charCode -= FULL_WIDTH_OFFSET;
        digitText += String.fromCharCode(charCode);
    }
    return digitText;
}

/**
 * 数字のつながりの置き換えを決める。［3桁以上の数字は全角にする］の対象なら全角、
 * ［数字は1桁を全角、2桁以上を半角にする］なら1桁を全角・2桁以上を半角（英字に続く数字は半角）、どちらでもなければ変えない
 * @param {string} text - 文字列
 * @param {number} runStart - つながりの先頭
 * @param {{end: number, digitCount: number}} digitRun - readDigitRun() の戻り値
 * @param {{digitsByLength: boolean, longDigitsFullwidth: boolean}} conversion - どちらの処理をするか
 * @returns {{key: string, text: string}|null} 置き換え。変えなければ null
 */
function decideDigitRunReplacement(text, runStart, digitRun, conversion) {
    var sourceText = text.substring(runStart, digitRun.end);
    var replacementKey;
    var toFullWidth;
    if (conversion.longDigitsFullwidth && isLongDigitRun(text, runStart, digitRun)) {
        replacementKey = "longDigitsFullwidth";
        toFullWidth = true;
    } else if (conversion.digitsByLength) {
        replacementKey = "digits";
        toFullWidth = (digitRun.digitCount === 1 && !LATIN_LETTER_PATTERN.test(text.charAt(runStart - 1)) && !LATIN_LETTER_PATTERN.test(text.charAt(digitRun.end)));
    } else {
        return null;
    }
    var digitText = setDigitWidth(sourceText, toFullWidth);
    return (digitText === sourceText) ? null : { key: replacementKey, text: digitText };
}

/**
 * 英単語の置き換えを決める（大文字だけの3文字以内の語なら、半角の大文字を全角にする）
 * @param {string} text - 文字列
 * @param {{start: number, end: number}} wordBounds - 英単語の範囲
 * @returns {{key: string, text: string}|null} 置き換え。変えなければ null
 */
function decideShortCapsReplacement(text, wordBounds) {
    var wordText = text.substring(wordBounds.start, wordBounds.end);
    if (!SHORT_CAPS_WORD_PATTERN.test(wordText)) return null;
    var fullText = "";
    for (var i = 0; i < wordText.length; i++) {
        var charCode = wordText.charCodeAt(i);
        fullText += String.fromCharCode((charCode >= 0x41 && charCode <= 0x5A) ? charCode + FULL_WIDTH_OFFSET : charCode);
    }
    return (fullText === wordText) ? null : { key: "shortCapsFullwidth", text: fullText };
}

/**
 * 変換表の置き換えを、［3桁以上の数字は全角にする］［3文字以内の大文字で構成する英単語は全角にする］に任せるか
 * （その処理で全角にする文字は、数字・アルファベットの行で変えない）
 * @param {string} text - 文字列
 * @param {number} offset - 置き換える文字の位置
 * @param {string} rowKey - 置き換える文字の行のキー
 * @param {{longDigitsFullwidth: boolean, shortCapsFullwidth: boolean}} conversion - どちらの処理をするか
 * @returns {boolean} 任せるなら true
 */
function isLeftToLaterPass(text, offset, rowKey, conversion) {
    if (rowKey === "digits") return conversion.longDigitsFullwidth && isInLongDigitRun(text, offset);
    if (rowKey === "alphabet") return conversion.shortCapsFullwidth && isInShortCapsWord(text, offset);
    return false;
}

/**
 * 見つかった数字のつながりを置き換える関数を作る（置き換え方は decideDigitRunReplacement()）
 * @param {Object} conversion - buildConversionMap() の戻り値
 * @returns {Function} (foundText, sourceText) → {key, text}|null
 */
function makeDigitRunReplacer(conversion) {
    return function (foundText, sourceText) {
        /* 桁数は見つかった文字の中だけで数え、前後の英字は段落の文字列で見る（選択した文字の途中から始まっても長さが合うように）/
           Digits are counted within the match and neighbors read from the paragraph, so the length matches even for a partial selection */
        var context = getParagraphContext(foundText);
        var paragraphText = context ? context.text : sourceText;
        var runStart = context ? context.offset : 0;
        var digitRun = { end: runStart + sourceText.length, digitCount: readDigitRun(sourceText, 0).digitCount };
        return decideDigitRunReplacement(paragraphText, runStart, digitRun, conversion);
    };
}

/**
 * 見つかった数字のつながりに付ける等幅字形を決める関数を作る（［2桁の数字は等幅2桁字形にする］［3桁の数字は等幅3桁字形にする］）。
 * 半角の数字だけで区切りをはさまず、段落の中でもそれだけで1つの数字（前後が数字・区切り・英字でない）ものが対象。すでにその字形なら変えない
 * @param {{twoDigitGlyphForm: boolean, threeDigitGlyphForm: boolean}} conversion - どちらの処理をするか
 * @returns {Function} (foundText, sourceText) → {key, glyphForm}|null
 */
function makeDigitGlyphFormDecider(conversion) {
    return function (foundText, sourceText) {
        if (!HALF_WIDTH_DIGITS_PATTERN.test(sourceText)) return null;
        var glyphFormDef = DIGIT_GLYPH_FORM_DEFS[sourceText.length];
        if (!glyphFormDef || !conversion[glyphFormDef.settingKey]) return null;
        /* 選択した文字の途中から始まる数字や、英字に続く数字（A12 など）は除く / Skip numbers cut by the selection and digits next to letters (A12) */
        var context = getParagraphContext(foundText);
        if (context) {
            var runEnd = context.offset + sourceText.length;
            if (findDigitRunStart(context.text, context.offset) !== context.offset || readDigitRun(context.text, context.offset).end !== runEnd) return null;
            if (LATIN_LETTER_PATTERN.test(context.text.charAt(context.offset - 1)) || LATIN_LETTER_PATTERN.test(context.text.charAt(runEnd))) return null;
        }
        if (foundText.glyphForm === glyphFormDef.glyphForm) return null;
        return { key: glyphFormDef.settingKey, glyphForm: glyphFormDef.glyphForm };
    };
}

/**
 * 見つかったダッシュの続きを選んだ字形にそろえる関数を作る（— だけの続きで前後がどちらも和文の文字でなければ、欧文のダッシュとして残す）
 * @param {string} dashChar - そろえる字形（DASH_FORMS の値）
 * @returns {Function} (foundText, sourceText) → {key, text}|null
 */
function makeDashReplacer(dashChar) {
    return function (foundText, sourceText) {
        if (/^\u2014+$/.test(sourceText)) {
            var neighbors = getNeighborChars(foundText, sourceText.length);
            if (!JAPANESE_CHAR_PATTERN.test(neighbors.previous) && !JAPANESE_CHAR_PATTERN.test(neighbors.next)) return null;
        }
        var dashText = sourceText.replace(/[\u2014\u2015\u2500]/g, dashChar);
        return (dashText === sourceText) ? null : { key: "dashForm", text: dashText };
    };
}

/**
 * 全角の英数字・記号を半角にする
 * @param {string} sourceText - 文字列
 * @returns {string} 半角にした文字列
 */
function toHalfWidthAscii(sourceText) {
    var asciiText = "";
    for (var i = 0; i < sourceText.length; i++) {
        var charCode = sourceText.charCodeAt(i);
        asciiText += String.fromCharCode((charCode >= 0xFF01 && charCode <= 0xFF5E) ? charCode - FULL_WIDTH_OFFSET : charCode);
    }
    return asciiText;
}

/**
 * 位置から始まる単位（全角の英字も可）を組文字にした文字列と、元の文字数を返す。
 * 2・3・²・³ が続けば面積・体積の組文字に。後ろに英字・数字・「/」が続くもの（km/h、mmHg、5m20）は単位とみなさない
 * @param {string} text - 文字列
 * @param {number} startOffset - 単位の先頭の位置
 * @returns {{length: number, text: string}|null} 単位でなければ null
 */
function matchUnitKumimoji(text, startOffset) {
    var letterEnd = startOffset;
    while (letterEnd < text.length && UNIT_LETTER_PATTERN.test(text.charAt(letterEnd))) letterEnd++;
    if (letterEnd === startOffset) return null;
    var unitText = toHalfWidthAscii(text.substring(startOffset, letterEnd));
    var powerText = toHalfWidthAscii(text.charAt(letterEnd)).replace("\u00B2", "2").replace("\u00B3", "3");
    var squareText = null;
    var unitLength = letterEnd - startOffset;
    if ((powerText === "2" || powerText === "3") && UNIT_POWER_KUMIMOJI.hasOwnProperty(unitText + powerText)) {
        squareText = UNIT_POWER_KUMIMOJI[unitText + powerText];
        unitLength++;
    } else if (UNIT_KUMIMOJI.hasOwnProperty(unitText)) {
        squareText = UNIT_KUMIMOJI[unitText];
    }
    if (!squareText) return null;
    var nextChar = text.charAt(startOffset + unitLength);
    if (UNIT_LETTER_PATTERN.test(nextChar) || DIGIT_PATTERN.test(nextChar) || nextChar === "/" || nextChar === "\uFF0F") return null;
    return { length: unitLength, text: squareText };
}

/**
 * 見つかった数字の直後の英字が単位なら組文字にする（数字との間の半角スペースは詰める）
 * @param {Text} foundText - 見つかった英字（前に半角スペースが付くこともある）
 * @param {string} sourceText - 見つかった文字列
 * @returns {{key: string, text: string}|null} 置き換え。単位でなければ null
 */
function replaceUnitWithKumimoji(foundText, sourceText) {
    /* 後ろの文字は段落の文字列で見る / The following character is read from the paragraph */
    var context = getParagraphContext(foundText);
    var paragraphText = context ? context.text : sourceText;
    var gapLength = UNIT_GAP_PATTERN.test(sourceText.charAt(0)) ? 1 : 0;
    var unitMatch = matchUnitKumimoji(paragraphText, (context ? context.offset : 0) + gapLength);
    if (!unitMatch || gapLength + unitMatch.length !== sourceText.length) return null;
    return { key: "unitsKumimoji", text: unitMatch.text };
}

/**
 * 見つかった大文字が、大文字だけでできた3文字以内の英単語そのものなら全角にする
 * @param {Text} foundText - 見つかった大文字
 * @param {string} sourceText - 見つかった文字列
 * @returns {{key: string, text: string}|null} 置き換え。変えなければ null
 */
function replaceShortCaps(foundText, sourceText) {
    var context = getParagraphContext(foundText);
    if (!context) return null;
    var wordBounds = findWordBounds(context.text, context.offset);
    /* つなぎで前後の語とつながっていれば対象外（U.S. など）/ Not a word of its own when a joiner links it to more (U.S.) */
    if (wordBounds.start !== context.offset || wordBounds.end !== context.offset + sourceText.length) return null;
    return decideShortCapsReplacement(context.text, wordBounds);
}

/**
 * 段落スタイル・文字スタイル名の集まりを、名前 → true の表にする（どちらも空なら null）
 * @param {{paragraph: string[], character: string[]}} excludedStyles - 除外するスタイル名
 * @returns {{paragraph: Object, character: Object}|null} 除外するスタイル名の表
 */
function buildExcludedStyleLookup(excludedStyles) {
    if (!excludedStyles || (excludedStyles.paragraph.length === 0 && excludedStyles.character.length === 0)) return null;
    var styleLookup = { paragraph: {}, character: {} };
    for (var i = 0; i < excludedStyles.paragraph.length; i++) styleLookup.paragraph[excludedStyles.paragraph[i]] = true;
    for (var j = 0; j < excludedStyles.character.length; j++) styleLookup.character[excludedStyles.character[j]] = true;
    return styleLookup;
}

/**
 * 見つかった文字が、除外する段落スタイル・文字スタイルのものか
 * @param {Text} foundText - 見つかった文字
 * @param {{paragraph: Object, character: Object}} styleLookup - 除外するスタイル名の表
 * @returns {boolean} 除外するなら true
 */
function isInExcludedStyle(foundText, styleLookup) {
    try {
        if (styleLookup.paragraph[foundText.paragraphs[0].appliedParagraphStyle.name]) return true;
    } catch (e) { }
    try {
        if (styleLookup.character[foundText.characters[0].appliedCharacterStyle.name]) return true;
    } catch (e2) { }
    return false;
}

/**
 * 見つかった文字を置き換える。長さが同じなら、変わる文字だけを1文字ずつ差し替えて書式を残す。空文字なら削除する
 * @param {Text} foundText - 見つかった文字
 * @param {string} sourceText - 見つかった文字列
 * @param {string} replacementText - 置き換え後の文字列
 * @param {Color|null} highlightColor - 変換した文字に付ける色（付けないなら null）。書き換える前の文字に付け、書き換えで引き継がせる
 * @returns {void}
 */
function applyReplacement(foundText, sourceText, replacementText, highlightColor) {
    if (replacementText === "") {
        foundText.remove();
        return;
    }
    if (sourceText.length > 1 && replacementText.length === sourceText.length) {
        for (var i = sourceText.length - 1; i >= 0; i--) {
            if (sourceText.charAt(i) === replacementText.charAt(i)) continue;
            var changedChar = foundText.characters[i];
            if (highlightColor) changedChar.fillColor = highlightColor;
            changedChar.contents = replacementText.charAt(i);
        }
        return;
    }
    if (highlightColor) foundText.fillColor = highlightColor;
    foundText.contents = replacementText;
}

/**
 * 見つかった文字に字形を適用する（文字は変えない）
 * @param {Text} foundText - 見つかった文字
 * @param {AlternateGlyphForms} glyphForm - 字形
 * @param {Color|null} highlightColor - 変換した文字に付ける色（付けないなら null）
 * @returns {void}
 */
function applyGlyphForm(foundText, glyphForm, highlightColor) {
    if (highlightColor) foundText.fillColor = highlightColor;
    foundText.glyphForm = glyphForm;
}

/**
 * ［変換した文字に色を付ける］のスウォッチを返す（無ければ HIGHLIGHT_CMYK で作る）
 * @returns {Color} スウォッチ
 */
function getHighlightSwatch() {
    var highlightSwatch = activeDocument.colors.itemByName(HIGHLIGHT_COLOR_NAME);
    if (highlightSwatch.isValid) return highlightSwatch;
    return activeDocument.colors.add({ name: HIGHLIGHT_COLOR_NAME, model: ColorModel.PROCESS, space: ColorSpace.CMYK, colorValue: HIGHLIGHT_CMYK });
}

/**
 * GREP で拾った文字を、置き換えを決める関数に従って置き換える（後ろから順に。glyphForm を返したときは文字を変えずに字形を適用する）
 * @param {Array} targets - 対象（Document・Story・Text など）
 * @param {string} grepPattern - GREP の検索文字列
 * @param {Function} decideReplacement - (foundText, sourceText) → {key, text}|{key, glyphForm}|null
 * @param {Object|null} styleLookup - 除外するスタイル名の表
 * @param {{converted: number, failed: number, countsByKey: Object}} result - 数を足していく結果
 * @param {Color|null} highlightColor - 変換した文字に付ける色（付けないなら null）
 * @returns {void}
 */
function runReplacePass(targets, grepPattern, decideReplacement, styleLookup, result, highlightColor) {
    app.findGrepPreferences.findWhat = grepPattern;
    for (var i = 0; i < targets.length; i++) {
        var foundTexts = targets[i].findGrep();
        /* 後ろから置き換え、前の見つかった位置がずれないようにする / Replace from the end so earlier matches keep their positions */
        for (var j = foundTexts.length - 1; j >= 0; j--) {
            var foundText = foundTexts[j];
            var sourceText = foundText.contents;
            if (typeof sourceText !== "string") continue;
            if (styleLookup && isInExcludedStyle(foundText, styleLookup)) continue;
            var replacement = decideReplacement(foundText, sourceText);
            if (!replacement) continue;
            try {
                if (replacement.glyphForm) applyGlyphForm(foundText, replacement.glyphForm, highlightColor);
                else applyReplacement(foundText, sourceText, replacement.text, highlightColor);
                result.converted++;
                result.countsByKey[replacement.key] = (result.countsByKey[replacement.key] || 0) + 1;
            } catch (e) {
                result.failed++;
            }
        }
    }
}

/**
 * 対象の文字を設定に従って変換する。
 * 三点リーダー → 全角ダッシュ → 和欧間のスペース → 単位の組文字 → 変換表 → 句読点の種類 → 数字の桁数 → 3文字以内の大文字の英単語 → 2・3桁の数字の等幅字形 → 数字の中の「,」「.」 → 欧文の,.:のあとのスペース → 括弧のまわりのスペースの順に処理する。contents の差し替えなので、文字の書式はそのまま残る
 * @param {Array} targets - 対象（Document・Story・Text など）
 * @param {Object} conversion - buildConversionMap() の戻り値に excludedStyles（除外するスタイル名の表）と highlightColor（変換した文字に付ける色、付けないなら null）を足したもの
 * @returns {{converted: number, failed: number, countsByKey: Object}} 変換できた数・できなかった数・キーごとの数
 */
function convertTargets(targets, conversion) {
    return runWithGrepOptions(function () {
        var result = { converted: 0, failed: 0, countsByKey: {} };
        var styleLookup = conversion.excludedStyles;
        var highlightColor = conversion.highlightColor || null;
        /* 行の変換より先に置き換える（中黒・ピリオド・句点が1つずつ変換されて数が重ならないように）/ Before the rows, so the dots are not converted one by one first */
        if (conversion.nakaguroToEllipsis) {
            runReplacePass(targets, NAKAGURO_ELLIPSIS_PATTERN, function () { return { key: "nakaguroToEllipsis", text: "\u2026" }; }, styleLookup, result, highlightColor);
        }
        if (conversion.periodsToEllipsis) {
            runReplacePass(targets, PERIOD_ELLIPSIS_PATTERN, function () { return { key: "periodsToEllipsis", text: "\u2026" }; }, styleLookup, result, highlightColor);
        }
        if (conversion.kutenToEllipsis) {
            runReplacePass(targets, KUTEN_ELLIPSIS_PATTERN, function () { return { key: "kutenToEllipsis", text: "\u2026" }; }, styleLookup, result, highlightColor);
        }
        if (conversion.dashForm > 0) runReplacePass(targets, DASH_RUN_PATTERN, makeDashReplacer(DASH_FORMS[conversion.dashForm]), styleLookup, result, highlightColor);
        /* 英数字を全角にする前に、元の文字で和欧間を判定する / Judged on the original characters, before letters and digits turn full-width */
        if (conversion.japaneseLatinSpace) {
            runReplacePass(targets, JAPANESE_LATIN_SPACE_PATTERN, function () { return { key: "japaneseLatinSpace", text: "" }; }, styleLookup, result, highlightColor);
        }
        /* 英字の行・数字の桁数より先に（kg が全角になったり、英字に続く数字として扱われたりしないように）/
           Before the letter row and digit lengths, so kg is not made full-width and digits are not treated as next to letters */
        if (conversion.unitsKumimoji) runReplacePass(targets, UNIT_AFTER_DIGIT_PATTERN, replaceUnitWithKumimoji, styleLookup, result, highlightColor);
        if (conversion.size > 0) {
            runReplacePass(targets, buildGrepPattern(conversion.map, conversion.runUnits), makeTableReplacer(conversion), styleLookup, result, highlightColor);
        }
        if (conversion.punctuationStyle > 0) {
            var styleMap = PUNCTUATION_STYLE_MAPS[conversion.punctuationStyle];
            runReplacePass(targets, buildGrepPattern(styleMap), function (foundText, sourceText) {
                return styleMap.hasOwnProperty(sourceText) ? { key: "punctuationStyle", text: styleMap[sourceText] } : null;
            }, styleLookup, result, highlightColor);
        }
        if (conversion.digitsByLength || conversion.longDigitsFullwidth) {
            runReplacePass(targets, DIGIT_RUN_PATTERN, makeDigitRunReplacer(conversion), styleLookup, result, highlightColor);
        }
        if (conversion.shortCapsFullwidth) runReplacePass(targets, SHORT_CAPS_PATTERN, replaceShortCaps, styleLookup, result, highlightColor);
        /* 数字の幅を決めたあと（半角のまま残った数字だけが対象）、区切りを「、」「・」にする前（1,000 の 000 を拾わないように）/
           After the digit widths (only digits left half-width), before separators become 、 and ・ (so 000 in 1,000 is not picked up) */
        if (conversion.twoDigitGlyphForm || conversion.threeDigitGlyphForm) {
            runReplacePass(targets, DIGIT_RUN_PATTERN, makeDigitGlyphFormDecider(conversion), styleLookup, result, highlightColor);
        }
        /* 数字の桁数を決めたあとに区切りを置き換える（「、」「・」で数字のつながりが切れないように）/ After the digit lengths, so 、 and ・ do not split the runs */
        if (conversion.numberCommaToTouten) {
            runReplacePass(targets, NUMBER_COMMA_PATTERN, function () { return { key: "numberCommaToTouten", text: "\u3001" }; }, styleLookup, result, highlightColor);
        }
        if (conversion.decimalToNakaguro) {
            runReplacePass(targets, DECIMAL_POINT_PATTERN, function () { return { key: "decimalToNakaguro", text: "\u30FB" }; }, styleLookup, result, highlightColor);
        }
        /* 行の変換のあと（半角のまま残った「,」「.」「:」だけが対象）/ After the rows, so only "," "." ":" left half-width are touched */
        if (conversion.westernPunctuationSpace) {
            runReplacePass(targets, WESTERN_PUNCTUATION_SPACE_PATTERN, function (foundText, sourceText) { return { key: "westernPunctuationSpace", text: sourceText + " " }; },
                styleLookup, result, highlightColor);
        }
        if (conversion.bracketInnerSpace) {
            runReplacePass(targets, buildBracketSpacePattern(true), function () { return { key: "bracketInnerSpace", text: "" }; }, styleLookup, result, highlightColor);
        }
        if (conversion.bracketOuterSpace) {
            runReplacePass(targets, buildBracketSpacePattern(false), function () { return { key: "bracketOuterSpace", text: "" }; }, styleLookup, result, highlightColor);
        }
        return result;
    });
}

// =========================================
// ダイアログ / Dialog
// =========================================

// ボタン行（再利用パーツ） / Button row (reusable)

var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

/**
 * ダイアログ下部のボタン行を作る。
 * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
 * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
 * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
 * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
 */
function addButtonRow(parent, rowOptions) {
    var isCentered = !!(rowOptions && rowOptions.centered);
    var btnRowGroup = parent.add("group");
    btnRowGroup.orientation = "row";
    btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
    btnRowGroup.spacing = BUTTON_ROW_SPACING;

    if (isCentered) {
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
    }

    btnRowGroup.alignment = ["fill", "bottom"];

    var btnLeftGroup = btnRowGroup.add("group");
    btnLeftGroup.alignChildren = ["left", "center"];
    btnLeftGroup.spacing = BUTTON_ROW_SPACING;

    /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
    var spacer = btnRowGroup.add("group");
    spacer.alignment = ["fill", "fill"];
    spacer.minimumSize.width = 0;

    var btnRightGroup = btnRowGroup.add("group");
    btnRightGroup.alignChildren = ["right", "center"];
    btnRightGroup.spacing = BUTTON_ROW_SPACING;

    return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
}

/**
 * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
 * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
 * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
 * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
 * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
 * @returns {void}
 */
function alignRightOnlyButtonRow(buttonRow) {
    if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
    var dialogWindow = buttonRow.rowGroup.window;
    dialogWindow.addEventListener("show", function () {
        if (!buttonRow.leftGroup) return;
        var btnRowGroup = buttonRow.rowGroup;
        /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
        if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
        /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
        btnRowGroup.remove(buttonRow.leftGroup);
        btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        buttonRow.leftGroup = null;
        dialogWindow.layout.layout(true);
    });
}

// ボタン行（再利用パーツ）ここまで / End of the reusable button row

// UI の明暗（再利用パーツ） / UI theme (reusable)

/**
 * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
 * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
 */
function isDarkUI() {
    try {
        if (app.preferences && app.preferences.getRealPreference) {
            return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
        }
        return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
    } catch (e) {
        return false;
    }
}

// UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

// バージョン表示（再利用パーツ） / Version footer (reusable)

var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

/* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
   9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
   / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
     nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
var VERSION_FOOTER_GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
    "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
    "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
    "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
    "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
    "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
    "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
    "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
    "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
    "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
    "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
    "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
    "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
    "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
    "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
    "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
    "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
    "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
    "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
    "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
    "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
    "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
    "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
    "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
    "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
    "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
    "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
    "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
    "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
    "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
    "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
    "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
    "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
    "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
    "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
    "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
    "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
    "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
    ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
    "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
    "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
    "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
    " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
};

/**
 * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
 * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
 * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
 * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
 * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
 */
function addVersionFooter(targetWindow) {
    if (targetWindow.versionFooter) return null;

    /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
    var lastChild = targetWindow.children[targetWindow.children.length - 1];
    if (lastChild && lastChild.type === "group") {
        var rowMargins = lastChild.margins;
        lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
    }
    var windowMargins = targetWindow.margins;
    targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

    var footerGroup = targetWindow.add("group");
    footerGroup.orientation = "row";
    footerGroup.alignment = ["fill", "bottom"];
    footerGroup.alignChildren = ["left", "center"];
    footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

    /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
       左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
       / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
         or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
    var versionText = String(SCRIPT_VERSION);
    var leftCandidates = [versionText];
    if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
    var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
    versionCanvas.alignment = ["fill", "center"];
    bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
    var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
    brandCanvas.alignment = ["right", "center"];
    brandCanvas.maximumSize = brandCanvas.preferredSize;
    targetWindow.versionFooter = footerGroup;
    return versionCanvas;
}

/**
 * 文字列のすべての文字に字形があるかを返す
 * @param {string} dotText - 文字列
 * @returns {boolean} すべてあれば true
 */
function hasVersionFooterGlyphs(dotText) {
    for (var i = 0; i < dotText.length; i++) {
        if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
    }
    return dotText.length > 0;
}

/**
 * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
 * @param {Group} parentGroup - 足す先
 * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
 * @returns {Group} 描くグループ
 */
function addVersionFooterCanvas(parentGroup, dotTexts) {
    var dotCanvas = parentGroup.add("group");
    var shortestText = dotTexts[dotTexts.length - 1];
    dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
    dotCanvas.helpTip = dotTexts[0];
    dotCanvas.onDraw = function () {
        var availableWidth = this.size ? this.size.width : 0;
        var drawText = shortestText;
        for (var i = 0; i < dotTexts.length; i++) {
            if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                drawText = dotTexts[i];
                break;
            }
        }
        drawVersionFooterDots(this.graphics, drawText);
    };
    return dotCanvas;
}

/**
 * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
 * @param {string} versionText - 文字列
 * @returns {number} 幅（ドット）
 */
function measureVersionFooterDots(versionText) {
    var dotCount = 0;
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
        dotCount += glyphRows[0].length;
    }
    return dotCount;
}

/**
 * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
 * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
 * @param {string} versionText - 文字列
 * @returns {void}
 */
function drawVersionFooterDots(canvasGraphics, versionText) {
    var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
    var dotSize = VERSION_FOOTER_PIXEL_SIZE;
    var cursorDots = 0;
    canvasGraphics.newPath();
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
        for (var row = 0; row < glyphRows.length; row++) {
            var rowText = glyphRows[row];
            var runStart = -1;
            for (var col = 0; col <= rowText.length; col++) {
                var isDot = col < rowText.length && rowText.charAt(col) === "#";
                if (isDot && runStart < 0) runStart = col;
                if (!isDot && runStart >= 0) {
                    canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                    runStart = -1;
                }
            }
        }
        cursorDots += glyphRows[0].length;
    }
    canvasGraphics.fillPath(footerBrush);
}

// -----------------------------------------
// このスクリプトについて / About this script
// -----------------------------------------
/* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
   この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
   Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
   and keeps its own labels and layout values so the part works on its own */

var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
/* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
   The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
/* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

var VERSION_INFO_LABELS = {
    dialog: {
        title: { ja: "このスクリプトについて", en: "About This Script" }
    },
    panel: {
        generalInfo: { ja: "基本情報", en: "General" },
        links: { ja: "リンク", en: "Links" }
    },
    fieldLabel: {
        scriptName: { ja: "スクリプト名", en: "Script Name" },
        scriptFeature: { ja: "機能", en: "Feature" },
        scriptVersion: { ja: "バージョン", en: "Version" }
    },
    button: {
        openReadme: { ja: "README", en: "README" },
        openSourceCode: { ja: "ソースコード", en: "Source Code" },
        openArticle: { ja: "記事（note）", en: "Article (note)" },
        revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
        revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
        close: { ja: "閉じる", en: "Close" }
    },
    tooltip: {
        versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
        copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
    },
    alert: {
        copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
    }
};

/**
 * VERSION_INFO_LABELS の文言を今の言語で返す
 * @param {Object} labelEntry - { ja, en }
 * @returns {string} 文言
 */
function getVersionInfoLabel(labelEntry) {
    return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
}

/**
 * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
 * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
 * @returns {string} 値
 */
function getVersionInfoValue(variableKey) {
    var infoValue;
    if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
    else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
    else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
    else if (variableKey === "readme") {
        if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
        else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
    }
    else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
    else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
    return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
}

/**
 * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
 * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
 * @returns {void}
 */
function bindVersionInfoClick(versionCanvas) {
    versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
    /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
       Open on mouseup so the release does not land on the footer after the dialog closes */
    versionCanvas.addEventListener("mouseup", function () {
        showVersionInfoDialog(versionCanvas.window.type === "palette");
    });
}

/**
 * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
 * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
 * @returns {void}
 */
function showVersionInfoDialog(isFromPalette) {
    var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
    infoDialog.orientation = "column";
    infoDialog.alignChildren = "fill";
    infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
    infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

    var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
    /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
    /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
    if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
    }
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
    alignVersionInfoLabels(infoPanel);

    /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
    var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
    var linkButtonRow = linksPanel.add("group");
    linkButtonRow.orientation = "row";
    linkButtonRow.alignment = ["left", "center"];
    linkButtonRow.alignChildren = ["left", "center"];
    linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

    /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
    var buttonRow = infoDialog.add("group");
    buttonRow.orientation = "row";
    buttonRow.alignment = ["fill", "bottom"];
    buttonRow.alignChildren = ["left", "center"];
    buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
    buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
    var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
    if (VERSION_INFO_SCRIPT_FILE.exists) {
        revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
        revealButton.onClick = function () {
            revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
            infoDialog.close();
        };
    } else {
        revealButton.enabled = false;
    }
    /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
    var buttonSpacer = buttonRow.add("group");
    buttonSpacer.alignment = ["fill", "fill"];
    buttonSpacer.minimumSize.width = 0;
    var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
    closeButton.alignment = ["right", "center"];
    /* return でも esc でも閉じる / Close with both Return and Esc */
    infoDialog.defaultElement = closeButton;
    infoDialog.cancelElement = closeButton;
    infoDialog.onShow = function () {
        pinVersionInfoCopyButton(infoPanel);
    };
    infoDialog.show();
}

/**
 * 「このスクリプトについて」のダイアログにパネルを足す
 * @param {Window} infoDialog - 足す先のダイアログ
 * @param {Object} titleEntry - パネル名の文言 { ja, en }
 * @returns {Panel} パネル
 */
function addVersionInfoPanel(infoDialog, titleEntry) {
    var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
    infoPanel.orientation = "column";
    infoPanel.alignChildren = ["fill", "top"];
    infoPanel.alignment = "fill";
    infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
    infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
    return infoPanel;
}

/**
 * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
 * @param {Panel} infoPanel - 足す先のパネル
 * @param {Object} labelEntry - 項目名の文言 { ja, en }
 * @param {string} valueText - 表示する値
 * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
 * @returns {StaticText} 値の statictext
 */
function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
    var infoRow = infoPanel.add("group");
    infoRow.orientation = "row";
    infoRow.alignment = ["fill", "center"];
    infoRow.alignChildren = ["left", "center"];
    infoRow.spacing = VERSION_INFO_ROW_SPACING;
    /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
    var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
    rowLabel.justify = "right";
    var valueLabel = infoRow.add("statictext", undefined, valueText);
    if (copyFromPalette === null) return valueLabel;
    /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
       A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
    var copySpacer = infoRow.add("group");
    copySpacer.alignment = ["fill", "fill"];
    copySpacer.minimumSize.width = 0;
    infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
    return valueLabel;
}

/**
 * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
 * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
 * @param {Panel} infoPanel - ［基本情報］パネル
 * @returns {void}
 */
function pinVersionInfoCopyButton(infoPanel) {
    var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
    for (var i = 0; i < infoPanel.children.length; i++) {
        var infoRow = infoPanel.children[i];
        if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
        infoRow.size = [innerWidth, infoRow.size.height];
        infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
    }
}

/**
 * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
 * @param {Panel} infoPanel - 対象のパネル
 * @returns {void}
 */
function alignVersionInfoLabels(infoPanel) {
    var rowLabels = [];
    var labelWidth = 0;
    for (var i = 0; i < infoPanel.children.length; i++) {
        var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
        rowLabels.push(rowLabel);
        labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
    }
    for (var j = 0; j < rowLabels.length; j++) {
        rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
    }
}

/**
 * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
 * @param {Window} infoDialog - ボタンを置くダイアログ
 * @param {Group} buttonGroup - 足す先のグループ
 * @param {Object} labelEntry - ボタンの文言 { ja, en }
 * @param {string} targetUrl - 開く URL（空ならディム表示）
 * @returns {void}
 */
function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
    var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
    if (!targetUrl) {
        linkButton.enabled = false;
        return;
    }
    linkButton.helpTip = targetUrl;
    linkButton.onClick = function () {
        openVersionInfoUrl(targetUrl);
        infoDialog.close();
    };
}

/**
 * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
 * @param {Group} infoRow - 足す先の行
 * @param {StaticText} valueLabel - コピーする値の statictext
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {Group} ボタンとして使う group
 */
function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
    var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
    var copyButton = infoRow.add("group");
    copyButton.preferredSize = [buttonSize, buttonSize];
    copyButton.minimumSize = [buttonSize, buttonSize];
    copyButton.maximumSize = [buttonSize, buttonSize];
    copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
    copyButton.isPressed = false;
    copyButton.isCopied = false;

    copyButton.onDraw = function () {
        var buttonGraphics = copyButton.graphics;
        var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
        buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
        if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
        else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
    };

    /**
     * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
     * @param {boolean} isPressed - 押下中なら true
     * @param {boolean} isCopied - コピー済みなら true
     * @returns {void}
     */
    function repaint(isPressed, isCopied) {
        if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
        copyButton.isPressed = isPressed;
        copyButton.isCopied = isCopied;
        copyButton.hide();
        copyButton.show();
    }
    copyButton.addEventListener("mousedown", function () { repaint(true, false); });
    copyButton.addEventListener("mouseup", function () {
        if (!copyButton.isPressed) return;
        var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
        repaint(false, hasCopied);
        if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
    });
    /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
    copyButton.addEventListener("mouseout", function () { repaint(false, false); });
    return copyButton;
}

/**
 * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
    var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
    var sheetSize = 9;
    var offset = 3;
    var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var backLeft = frontLeft - offset;
    var backTop = frontTop - offset;
    /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
    buttonGraphics.newPath();
    buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
    buttonGraphics.strokePath(iconPen);
    buttonGraphics.newPath();
    buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
    buttonGraphics.strokePath(iconPen);
}

/**
 * コピーしたあとのチェックマークを描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
    var center = buttonSize / 2;
    buttonGraphics.newPath();
    buttonGraphics.moveTo(center - 4.5, center);
    buttonGraphics.lineTo(center - 1.5, center + 3);
    buttonGraphics.lineTo(center + 4.5, center - 3.5);
    buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
}

/**
 * 文字列をクリップボードにコピーする。
 * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
 * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
 * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
 * @param {string} copyText - コピーする文字列
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {boolean} コピーの操作まで進めたら true
 */
function copyVersionInfoText(copyText, isFromPalette) {
    try {
        if (VERSION_INFO_IS_INDESIGN) {
            if (File.fs === "Windows") {
                app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
            } else {
                app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
            }
            return true;
        }
        var copyScript = buildVersionInfoCopyScript(copyText);
        if (!isFromPalette) return eval(copyScript) === true;
        var copyMessage = new BridgeTalk();
        copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
        copyMessage.body = copyScript;
        copyMessage.send();
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
 * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
 * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
 * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
 * @param {string} copyText - コピーする文字列
 * @returns {string} 実行すると true / false を返すスクリプト
 */
function buildVersionInfoCopyScript(copyText) {
    return [
        "(function (copyText) {",
        "    var usingTempDoc = (app.documents.length === 0);",
        "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
        "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
        "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
        "    var tempLayer = null;",
        "    var hasCopied = false;",
        "    try {",
        "        tempLayer = targetDoc.layers.add();",
        "        var tempFrame = tempLayer.textFrames.add();",
        "        tempFrame.contents = copyText;",
        "        app.redraw();",
        "        app.executeMenuCommand('deselectall');",
        "        tempFrame.selected = true;",
        "        app.redraw();",
        "        app.executeMenuCommand('copy');",
        "        app.redraw();",
        "        hasCopied = true;",
        "    } catch (e) { }",
        "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
        "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
        "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
        "    targetDoc.selection = null;",
        "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
        "    app.redraw();",
        "    return hasCopied;",
        "})(" + quoteVersionInfoString(copyText) + ");"
    ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
}

/**
 * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
 * @param {string} sourceText - 文字列
 * @returns {string} "…" の形のリテラル
 */
function quoteVersionInfoString(sourceText) {
    return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

/**
 * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
 * @param {File} scriptFile - 表示するファイル
 * @returns {void}
 */
function revealVersionInfoScriptFile(scriptFile) {
    /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
    var hasRevealApp = (File.fs === "Macintosh")
        && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
    /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
    if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
    /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
    scriptFile.parent.execute();
}

/**
 * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
 * @param {string} targetPath - 絶対パス
 * @returns {boolean} 書き出せたら true
 */
function writeVersionInfoRevealPath(targetPath) {
    var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
    pathFile.encoding = "UTF-8";
    pathFile.lineFeed = "Unix";
    if (!pathFile.open("w")) return false;
    var hasWritten = pathFile.write(targetPath);
    pathFile.close();
    return hasWritten;
}

/**
 * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
 * @param {string} targetUrl - 開く URL
 * @returns {void}
 */
function openVersionInfoUrl(targetUrl) {
    var isMac = (File.fs === "Macintosh");
    var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
    shortcutFile.encoding = "UTF-8";
    shortcutFile.open("w");
    if (isMac) {
        var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
        shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
            + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
    } else {
        shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
    }
    shortcutFile.close();
    shortcutFile.execute();
}

// バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

/* 列の見出し（選択肢の順）/ Column headings, in option order */
var OPTION_COLUMNS = [
    { label: LABELS.column.keep, tooltip: LABELS.tooltip.keep },
    { label: LABELS.column.half, tooltip: LABELS.tooltip.half },
    { label: LABELS.column.full, tooltip: LABELS.tooltip.full }
];

/**
 * 行の選択肢を1つだけ選んだ状態にする（ラジオはセルごとに別グループなので排他を自前で行う）。
 * 表示前の value は読み戻せないので、選んだ値は rowControl.option に持つ
 * @param {{radios: RadioButton[], option: number}} rowControl - 行のコントロール
 * @param {number} option - 選ぶ選択肢の番号
 * @returns {void}
 */
function setRowOption(rowControl, option) {
    rowControl.option = option;
    for (var i = 0; i < rowControl.radios.length; i++) {
        rowControl.radios[i].value = (i === option);
    }
}

/**
 * 行で選ばれている選択肢の番号を返す
 * @param {{radios: RadioButton[], option: number}} rowControl - 行のコントロール
 * @returns {number} 選択肢の番号
 */
function getRowOption(rowControl) {
    return rowControl.option;
}

/**
 * 行のほかの設定のチェックボックスを足す（値は 0／1。表示前の value は読み戻せないので値は自前で持つ）
 * @param {Panel|Group} parent - 足す先
 * @param {string} settingKey - 設定のキー
 * @param {Object} labelEntry - 文言の { ja, en }
 * @param {Object} tooltipEntry - ツールチップの { ja, en }
 * @param {{extraControls: Object, onRowChange: Function}} tableContext - 作ったコントロールを足す先と、値を変えたときの処理
 * @returns {void}
 */
function addExtraCheckbox(parent, settingKey, labelEntry, tooltipEntry, tableContext) {
    var extraCheckbox = parent.add("checkbox", undefined, getLabel(labelEntry));
    extraCheckbox.helpTip = getLabel(tooltipEntry);
    var extraControl = {
        value: 0,
        setValue: function (value) {
            extraControl.value = value;
            extraCheckbox.value = (value === 1);
        }
    };
    extraCheckbox.onClick = function () {
        extraControl.value = extraCheckbox.value ? 1 : 0;
        tableContext.onRowChange();
    };
    tableContext.extraControls[settingKey] = extraControl;
}

/**
 * 行のほかの設定の「項目名 : ドロップダウン」を足す（値は項目の番号）
 * @param {Panel|Group} parent - 足す先
 * @param {string} settingKey - 設定のキー
 * @param {Object} fieldLabelEntry - 項目名の { ja, en }
 * @param {Object[]} itemEntries - 項目の { ja, en } の配列
 * @param {Object} tooltipEntry - ツールチップの { ja, en }
 * @param {{extraControls: Object, onRowChange: Function}} tableContext - 作ったコントロールを足す先と、値を変えたときの処理
 * @returns {void}
 */
function addExtraDropdown(parent, settingKey, fieldLabelEntry, itemEntries, tooltipEntry, tableContext) {
    var dropdownRowGroup = parent.add("group");
    setupRow(dropdownRowGroup, "left", 6);
    var fieldLabel = dropdownRowGroup.add("statictext", undefined, labelText(fieldLabelEntry));
    var itemLabels = [];
    for (var i = 0; i < itemEntries.length; i++) itemLabels.push(getLabel(itemEntries[i]));
    var extraDropdown = dropdownRowGroup.add("dropdownlist", undefined, itemLabels);
    extraDropdown.helpTip = getLabel(tooltipEntry);
    var extraControl = {
        value: 0,
        isSetting: false,
        setValue: function (value) {
            extraControl.value = value;
            extraControl.isSetting = true;
            extraDropdown.selection = value;
            extraControl.isSetting = false;
        },
        setEnabled: function (isEnabled) {
            fieldLabel.enabled = isEnabled;
            extraDropdown.enabled = isEnabled;
        }
    };
    extraDropdown.onChange = function () {
        if (extraControl.isSetting || !extraDropdown.selection) return;
        extraControl.value = extraDropdown.selection.index;
        tableContext.onRowChange();
    };
    extraControl.setValue(0);
    tableContext.extraControls[settingKey] = extraControl;
}

/**
 * スタイルの名前を並べる（先頭の［段落スタイルなし］［なし］は除く。同じ名前は1つ）
 * @param {Array} styles - allParagraphStyles または allCharacterStyles
 * @returns {string[]} スタイル名の配列
 */
function getStyleNames(styles) {
    var styleNames = [];
    var seenNames = {};
    for (var i = 1; i < styles.length; i++) {
        var styleName = styles[i].name;
        if (seenNames[styleName]) continue;
        seenNames[styleName] = true;
        styleNames.push(styleName);
    }
    return styleNames;
}

/**
 * スタイル名を複数選べるリストのパネルを足す
 * @param {Group} parent - 足す先
 * @param {Object} titleEntry - パネル名の { ja, en }
 * @param {string[]} styleNames - スタイル名の配列
 * @param {string[]} selectedNames - 最初に選んでおく名前
 * @returns {ListBox} リスト
 */
function addStyleListPanel(parent, titleEntry, styleNames, selectedNames) {
    var stylePanel = parent.add("panel", undefined, getLabel(titleEntry));
    setupPanel(stylePanel);
    var styleList = stylePanel.add("listbox", undefined, styleNames, { multiselect: true });
    styleList.preferredSize = [STYLE_LIST_WIDTH, STYLE_LIST_HEIGHT];
    var selectedIndexes = [];
    for (var i = 0; i < styleNames.length; i++) {
        for (var j = 0; j < selectedNames.length; j++) {
            if (styleNames[i] === selectedNames[j]) selectedIndexes.push(i);
        }
    }
    if (selectedIndexes.length > 0) styleList.selection = selectedIndexes;
    return styleList;
}

/**
 * リストで選ばれている名前を返す
 * @param {ListBox} styleList - リスト
 * @returns {string[]} 選ばれている名前
 */
function getSelectedListNames(styleList) {
    var selectedItems = styleList.selection;
    if (!selectedItems) return [];
    if (!(selectedItems instanceof Array)) selectedItems = [selectedItems];
    var selectedNames = [];
    for (var i = 0; i < selectedItems.length; i++) selectedNames.push(selectedItems[i].text);
    return selectedNames;
}

/**
 * 変換しない段落スタイル・文字スタイルを選ぶダイアログを表示する
 * @param {{paragraph: string[], character: string[]}} excludedStyles - 今の除外するスタイル名
 * @returns {{paragraph: string[], character: string[]}|null} 選んだスタイル名。キャンセルなら null
 */
function showExcludedStylesDialog(excludedStyles) {
    var styleDialog = new Window("dialog", getLabel(LABELS.dialog.excludedStyles));
    setupWindow(styleDialog);
    var listsGroup = styleDialog.add("group");
    listsGroup.orientation = "row";
    listsGroup.alignChildren = ["fill", "fill"];
    listsGroup.spacing = COLUMN_SPACING;
    var paragraphStyleList = addStyleListPanel(listsGroup, LABELS.panel.paragraphStyles,
        getStyleNames(activeDocument.allParagraphStyles), excludedStyles.paragraph);
    var characterStyleList = addStyleListPanel(listsGroup, LABELS.panel.characterStyles,
        getStyleNames(activeDocument.allCharacterStyles), excludedStyles.character);

    var buttonRow = addButtonRow(styleDialog);
    var btnClearSelection = buttonRow.leftGroup.add("button", undefined, getLabel(LABELS.button.clearSelection));
    btnClearSelection.onClick = function () {
        paragraphStyleList.selection = null;
        characterStyleList.selection = null;
    };
    var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.cancel), { name: "cancel" });
    var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.ok), { name: "ok" });
    btnCancel.onClick = function () { styleDialog.close(0); };
    btnOK.onClick = function () { styleDialog.close(1); };
    alignRightOnlyButtonRow(buttonRow);

    if (styleDialog.show() !== 1) return null;
    return { paragraph: getSelectedListNames(paragraphStyleList), character: getSelectedListNames(characterStyleList) };
}

/**
 * 複数のラベル（statictext）の幅を最長のものへ揃え、指定方向に揃えます。
 * 実際の描画幅（preferredSize.width）を測るため、文言長やロケールに依存しません。
 * @param {StaticText[]} labelControls - 幅を揃える statictext の配列。
 * @param {string} [justify] - 揃え方向 "left" | "center" | "right"（省略時は "right"）。
 * @returns {number} 揃えた後の共通ラベル幅（px）。
 */
function alignLabelWidths(labelControls, justify) {
    if (!labelControls || !labelControls.length) return 0;
    justify = justify || 'right';

    /* 1パス目：各ラベルの自然幅を測り、最大値を求める / Pass 1: find the widest natural width */
    var maxLabelWidth = 0;
    for (var i = 0; i < labelControls.length; i++) {
        /* preferredSize を返さない環境では実サイズで代用する / fall back to the laid-out size */
        var naturalWidth = labelControls[i].preferredSize.width || labelControls[i].size.width;
        if (naturalWidth > maxLabelWidth) maxLabelWidth = naturalWidth;
    }

    /* 2パス目：全ラベルを最大幅に固定し、揃え方向を適用 / Pass 2: apply common width and justification */
    for (var j = 0; j < labelControls.length; j++) {
        labelControls[j].preferredSize.width = maxLabelWidth;
        labelControls[j].justify = justify;
    }

    return maxLabelWidth;
}

/**
 * 表の見出し行（列名）を足す
 * @param {Group} tableGroup - 表のグループ
 * @returns {StaticText} 項目名の列の上の空きラベル（幅はあとで項目名に揃える）
 */
function addTableHeader(tableGroup) {
    var headerRowGroup = tableGroup.add("group");
    setupRow(headerRowGroup, "left", TABLE_CELL_SPACING);
    var labelSpacer = headerRowGroup.add("statictext", undefined, "");
    for (var i = 0; i < OPTION_COLUMNS.length; i++) {
        var headerText = headerRowGroup.add("statictext", undefined, getLabel(OPTION_COLUMNS[i].label));
        headerText.preferredSize.width = OPTION_COLUMN_WIDTH;
        headerText.justify = "center";
        headerText.helpTip = getLabel(OPTION_COLUMNS[i].tooltip);
    }
    return labelSpacer;
}

/**
 * ラジオをクリックしたときの処理を作る。Option キーを押していれば、同じパネルの行をすべて同じ選択肢にする
 * @param {{radios: RadioButton[]}} rowControl - 行のコントロール
 * @param {number} option - このラジオの選択肢の番号
 * @param {Array} panelRows - 同じパネルの行の定義の配列
 * @param {{rowControls: Object, onRowChange: Function}} tableContext - 行のコントロールと、選択肢を変えたあとに呼ぶ関数
 * @returns {Function} onClick に入れる関数
 */
function makeRadioClickHandler(rowControl, option, panelRows, tableContext) {
    return function () {
        if (ScriptUI.environment.keyboardState.altKey) {
            for (var i = 0; i < panelRows.length; i++) {
                var panelRowControl = tableContext.rowControls[panelRows[i].key];
                if (panelRowControl) setRowOption(panelRowControl, option);
            }
        } else {
            setRowOption(rowControl, option);
        }
        tableContext.onRowChange();
    };
}

/**
 * 「項目名＋3つの選択肢」の表を足す
 * @param {Panel|Group} parent - 表を足す先
 * @param {Array} rows - 行の定義の配列
 * @param {{rowControls: Object, rowLabels: StaticText[], headerSpacers: StaticText[], onRowChange: Function}} tableContext -
 *     行のコントロール（キー → コントロール）、幅を揃える項目名・見出しの空きラベル（作ったものを足す）、選択肢を変えたときの処理
 * @returns {void}
 */
function addOptionTable(parent, rows, tableContext) {
    var tableGroup = parent.add("group");
    tableGroup.orientation = "column";
    tableGroup.alignChildren = ["left", "top"];
    tableGroup.alignment = ["left", "top"];
    tableGroup.spacing = TABLE_ROW_SPACING;
    tableContext.headerSpacers.push(addTableHeader(tableGroup));

    for (var i = 0; i < rows.length; i++) {
        var rowGroup = tableGroup.add("group");
        setupRow(rowGroup, "left", TABLE_CELL_SPACING);
        var rowLabel = rowGroup.add("statictext", undefined, getLabel(LABELS.row[rows[i].key]) + (rows[i].glyph ? "  " + rows[i].glyph : ""));
        tableContext.rowLabels.push(rowLabel);

        var rowControl = { radios: [], option: OPTION_KEEP };
        for (var option = 0; option < OPTION_COLUMNS.length; option++) {
            /* ラジオを列の中央に置くため、セルごとにグループで包む / Wrap each radio in a cell group to center it under the heading */
            var cellGroup = rowGroup.add("group");
            /* preferredSize はレイアウトの計算し直しで子の幅に戻るので、最小幅で取る / preferredSize is reset when the layout is recalculated, so reserve a minimum width */
            cellGroup.minimumSize.width = OPTION_COLUMN_WIDTH;
            cellGroup.alignChildren = ["center", "center"];
            var optionRadio = cellGroup.add("radiobutton", undefined, "");
            optionRadio.helpTip = getLabel(OPTION_COLUMNS[option].tooltip) + "\n" + getLabel(LABELS.tooltip.optionClick);
            optionRadio.onClick = makeRadioClickHandler(rowControl, option, rows, tableContext);
            rowControl.radios.push(optionRadio);
        }
        tableContext.rowControls[rows[i].key] = rowControl;
    }
}

/**
 * 組み方向のタブを足し、文字種・句読点・括弧・記号のパネルを3カラムで並べる。
 * 縦組みのタブには［縦組み用］、横組みのタブには［欧文の,.:のあとにスペースを入れる］を置く
 * @param {TabbedPanel} tabbedPanel - タブを足す先
 * @param {string} tabKey - "horizontal" または "vertical"
 * @param {Function} onRowChange - 選択肢を変えたときの処理（引数はこのタブのコントロール）
 * @returns {{tab: Tab, tabKey: string, rowControls: Object, extraControls: Object, rowLabels: StaticText[], headerSpacers: StaticText[], onRowChange: Function}}
 *     タブと、そのタブの行のコントロール・行のほかの設定のコントロール・幅を揃える項目名と見出しの空きラベル
 */
function addSettingsTab(tabbedPanel, tabKey, onRowChange) {
    var settingsTab = tabbedPanel.add("tab", undefined, getLabel(LABELS.tab[tabKey]));
    setupTab(settingsTab);
    var isVerticalTab = (tabKey === "vertical");
    var tabControls = {
        tab: settingsTab,
        tabKey: tabKey,
        rowControls: {},
        extraControls: {},
        rowLabels: [],
        headerSpacers: [],
        onRowChange: function () { onRowChange(tabControls); }
    };

    /* 3カラム（左：文字種・句読点、中：括弧、右：記号）。縦に積むと画面に収まらない / Three columns (left: character types and punctuation; middle: brackets; right: symbols); stacked, the dialog does not fit the screen */
    var columnsGroup = settingsTab.add("group");
    columnsGroup.orientation = "row";
    columnsGroup.alignChildren = ["left", "fill"];
    columnsGroup.spacing = COLUMN_SPACING;

    var leftColumnGroup = columnsGroup.add("group");
    leftColumnGroup.orientation = "column";
    leftColumnGroup.alignChildren = ["fill", "top"];
    leftColumnGroup.spacing = PANEL_SPACING;

    var characterTypePanel = leftColumnGroup.add("panel", undefined, getLabel(LABELS.panel.characterType));
    setupPanel(characterTypePanel);
    addOptionTable(characterTypePanel, CHARACTER_TYPE_ROWS, tabControls);
    var characterTypeExtrasGroup = characterTypePanel.add("group");
    characterTypeExtrasGroup.orientation = "column";
    characterTypeExtrasGroup.alignChildren = ["left", "top"];
    characterTypeExtrasGroup.spacing = 6;
    addExtraCheckbox(characterTypeExtrasGroup, "digitsByLength", LABELS.checkbox.digitsByLength, LABELS.tooltip.digitsByLength, tabControls);
    addExtraCheckbox(characterTypeExtrasGroup, "spaceBetweenJapaneseOnly", LABELS.checkbox.spaceBetweenJapaneseOnly,
        LABELS.tooltip.spaceBetweenJapaneseOnly, tabControls);
    addExtraCheckbox(characterTypeExtrasGroup, "japaneseLatinSpace", LABELS.checkbox.japaneseLatinSpace, LABELS.tooltip.japaneseLatinSpace, tabControls);
    if (!isVerticalTab) {
        addExtraCheckbox(characterTypeExtrasGroup, "westernPunctuationSpace", LABELS.checkbox.westernPunctuationSpace, LABELS.tooltip.westernPunctuationSpace, tabControls);
    }

    var punctuationPanel = leftColumnGroup.add("panel", undefined, getLabel(LABELS.panel.punctuation));
    setupPanel(punctuationPanel);
    addOptionTable(punctuationPanel, PUNCTUATION_ROWS, tabControls);
    addExtraDropdown(punctuationPanel, "punctuationStyle", LABELS.fieldLabel.punctuationStyle,
        [LABELS.dropdown.punctuationStyleKeep, LABELS.dropdown.punctuationStyleJapanese, LABELS.dropdown.punctuationStyleWestern],
        LABELS.tooltip.punctuationStyle, tabControls);
    /* 三点リーダーにする文字（「...に変換 : ☐・・・ ☐... ☐。。。」の1行）/ Characters turned into an ellipsis, on one row */
    var ellipsisRowGroup = punctuationPanel.add("group");
    setupRow(ellipsisRowGroup, "left", 6);
    ellipsisRowGroup.add("statictext", undefined, labelText(LABELS.fieldLabel.toEllipsis));
    addExtraCheckbox(ellipsisRowGroup, "nakaguroToEllipsis", LABELS.checkbox.nakaguroToEllipsis, LABELS.tooltip.nakaguroToEllipsis, tabControls);
    addExtraCheckbox(ellipsisRowGroup, "periodsToEllipsis", LABELS.checkbox.periodsToEllipsis, LABELS.tooltip.periodsToEllipsis, tabControls);
    addExtraCheckbox(ellipsisRowGroup, "kutenToEllipsis", LABELS.checkbox.kutenToEllipsis, LABELS.tooltip.kutenToEllipsis, tabControls);
    addExtraDropdown(punctuationPanel, "dashForm", LABELS.fieldLabel.dashForm,
        [LABELS.dropdown.dashFormKeep, LABELS.dropdown.dashFormEmDash, LABELS.dropdown.dashFormHorizontalBar, LABELS.dropdown.dashFormBoxDrawing],
        LABELS.tooltip.dashForm, tabControls);

    var middleColumnGroup = columnsGroup.add("group");
    middleColumnGroup.orientation = "column";
    middleColumnGroup.alignChildren = ["fill", "top"];
    middleColumnGroup.spacing = PANEL_SPACING;

    var bracketPanel = middleColumnGroup.add("panel", undefined, getLabel(LABELS.panel.bracket));
    setupPanel(bracketPanel);
    addOptionTable(bracketPanel, BRACKET_ROWS, tabControls);
    var bracketExtrasGroup = bracketPanel.add("group");
    bracketExtrasGroup.orientation = "column";
    bracketExtrasGroup.alignChildren = ["left", "top"];
    bracketExtrasGroup.spacing = 6;
    addExtraCheckbox(bracketExtrasGroup, "bracketInnerSpace", LABELS.checkbox.bracketInnerSpace, LABELS.tooltip.bracketInnerSpace, tabControls);
    addExtraCheckbox(bracketExtrasGroup, "bracketOuterSpace", LABELS.checkbox.bracketOuterSpace, LABELS.tooltip.bracketOuterSpace, tabControls);
    addExtraDropdown(bracketPanel, "quoteForm", LABELS.fieldLabel.quoteForm,
        [LABELS.dropdown.quoteFormPlain, LABELS.dropdown.quoteFormCurly, LABELS.dropdown.quoteFormMinute], LABELS.tooltip.quoteForm, tabControls);

    /* 縦組み用（縦組みのタブだけ）/ Vertical text (vertical tab only) */
    if (isVerticalTab) {
        var verticalPanel = middleColumnGroup.add("panel", undefined, getLabel(LABELS.panel.vertical));
        setupPanel(verticalPanel, 6);
        addExtraCheckbox(verticalPanel, "longDigitsFullwidth", LABELS.checkbox.longDigitsFullwidth, LABELS.tooltip.longDigitsFullwidth, tabControls);
        addExtraCheckbox(verticalPanel, "twoDigitGlyphForm", LABELS.checkbox.twoDigitGlyphForm, LABELS.tooltip.twoDigitGlyphForm, tabControls);
        addExtraCheckbox(verticalPanel, "threeDigitGlyphForm", LABELS.checkbox.threeDigitGlyphForm, LABELS.tooltip.threeDigitGlyphForm, tabControls);
        addExtraCheckbox(verticalPanel, "numberCommaToTouten", LABELS.checkbox.numberCommaToTouten, LABELS.tooltip.numberCommaToTouten, tabControls);
        addExtraCheckbox(verticalPanel, "decimalToNakaguro", LABELS.checkbox.decimalToNakaguro, LABELS.tooltip.decimalToNakaguro, tabControls);
        addExtraCheckbox(verticalPanel, "shortCapsFullwidth", LABELS.checkbox.shortCapsFullwidth, LABELS.tooltip.shortCapsFullwidth, tabControls);
        addExtraCheckbox(verticalPanel, "unitsKumimoji", LABELS.checkbox.unitsKumimoji, LABELS.tooltip.unitsKumimoji, tabControls);
    }

    var rightColumnGroup = columnsGroup.add("group");
    rightColumnGroup.orientation = "column";
    rightColumnGroup.alignChildren = ["fill", "top"];
    rightColumnGroup.spacing = PANEL_SPACING;

    var symbolPanel = rightColumnGroup.add("panel", undefined, getLabel(LABELS.panel.symbol));
    setupPanel(symbolPanel);
    addOptionTable(symbolPanel, SYMBOL_ROWS, tabControls);
    addExtraDropdown(symbolPanel, "hyphenForm", LABELS.fieldLabel.hyphenForm,
        [LABELS.dropdown.hyphenFormPlain, LABELS.dropdown.hyphenFormHyphen, LABELS.dropdown.hyphenFormMinus], LABELS.tooltip.hyphenForm, tabControls);
    addExtraDropdown(symbolPanel, "asteriskForm", LABELS.fieldLabel.asteriskForm,
        [LABELS.dropdown.asteriskFormPlain, LABELS.dropdown.asteriskFormReference], LABELS.tooltip.asteriskForm, tabControls);
    addExtraDropdown(symbolPanel, "tildeForm", LABELS.fieldLabel.tildeForm,
        [LABELS.dropdown.tildeFormPlain, LABELS.dropdown.tildeFormWave], LABELS.tooltip.tildeForm, tabControls);

    return tabControls;
}

/**
 * 設定（行の選択肢と行のほかの設定）をタブにまとめて反映する（タブに無い設定は飛ばす）
 * @param {{rowControls: Object, extraControls: Object}} tabControls - タブのコントロール
 * @param {Object} rowOptions - 設定のキー → 値
 * @returns {void}
 */
function applyRowOptions(tabControls, rowOptions) {
    for (var settingKey in rowOptions) {
        if (!rowOptions.hasOwnProperty(settingKey)) continue;
        if (tabControls.rowControls[settingKey]) setRowOption(tabControls.rowControls[settingKey], rowOptions[settingKey]);
        else if (tabControls.extraControls[settingKey]) tabControls.extraControls[settingKey].setValue(rowOptions[settingKey]);
    }
    updateDependentControls(tabControls);
}

/**
 * タブの今の設定を返す（タブに無い設定は 0）
 * @param {{rowControls: Object, extraControls: Object}} tabControls - タブのコントロール
 * @returns {Object} 設定のキー → 値（すべてのキー）
 */
function readRowOptions(tabControls) {
    var currentOptions = rowOptionsWith(OPTION_KEEP);
    for (var rowKey in tabControls.rowControls) {
        if (tabControls.rowControls.hasOwnProperty(rowKey)) currentOptions[rowKey] = getRowOption(tabControls.rowControls[rowKey]);
    }
    for (var extraKey in tabControls.extraControls) {
        if (tabControls.extraControls.hasOwnProperty(extraKey)) currentOptions[extraKey] = tabControls.extraControls[extraKey].value;
    }
    return currentOptions;
}

/**
 * ほかの設定で使えるかが決まるコントロールを更新する。
 * 数字を桁数で決めるときは数字の行のラジオを、行が「そのまま」のときは全角の字形のドロップダウンを使えなくする
 * （半角にするときも、選んだ字形だけを戻すので使う。引用符は二重引用符・引用符の両方が「そのまま」なら）
 * @param {{rowControls: Object, extraControls: Object}} tabControls - タブのコントロール
 * @returns {void}
 */
function updateDependentControls(tabControls) {
    var rowControls = tabControls.rowControls;
    var digitsByLengthControl = tabControls.extraControls.digitsByLength;
    var isByLength = !!digitsByLengthControl && (digitsByLengthControl.value === 1);
    for (var i = 0; i < rowControls.digits.radios.length; i++) rowControls.digits.radios[i].enabled = !isByLength;

    var isUsedBySetting = {};
    for (var rowKey in FULL_FORM_CHOICES) {
        if (!FULL_FORM_CHOICES.hasOwnProperty(rowKey)) continue;
        var formSettingKey = FULL_FORM_CHOICES[rowKey].settingKey;
        isUsedBySetting[formSettingKey] = isUsedBySetting[formSettingKey] || (getRowOption(rowControls[rowKey]) !== OPTION_KEEP);
    }
    for (var settingKey in isUsedBySetting) {
        if (isUsedBySetting.hasOwnProperty(settingKey)) tabControls.extraControls[settingKey].setEnabled(isUsedBySetting[settingKey]);
    }
}

/**
 * 変換の設定ダイアログを表示する
 * @param {{rowOptionsByTab: Object, activeTab: string, scope: string|null, excludedStyles: Object, highlightChanges: boolean}} settings - 前回の設定
 * @param {{selection: boolean, story: boolean}} scopeAvailability - 選べる対象
 * @returns {{rowOptionsByTab: Object, activeTab: string, scope: string, excludedStyles: Object, highlightChanges: boolean}|null} 設定。キャンセルなら null
 */
function showConvertDialog(settings, scopeAvailability) {
    var mainDialog = new Window("dialog", getLabel(LABELS.dialog.title));
    setupWindow(mainDialog);

    /* プリセット（開いているタブに反映する）/ Presets (applied to the open tab) */
    var presetRowGroup = mainDialog.add("group");
    setupRow(presetRowGroup, "center", 6);
    presetRowGroup.add("statictext", undefined, labelText(LABELS.fieldLabel.preset));
    var presetDropdown = presetRowGroup.add("dropdownlist");
    presetDropdown.preferredSize.width = PRESET_DROPDOWN_WIDTH;
    presetDropdown.helpTip = getLabel(LABELS.tooltip.preset);
    var btnSavePreset = presetRowGroup.add("button", undefined, getLabel(LABELS.button.savePreset));
    btnSavePreset.helpTip = getLabel(LABELS.tooltip.savePreset);
    var btnDeletePreset = presetRowGroup.add("button", undefined, getLabel(LABELS.button.deletePreset));
    btnDeletePreset.helpTip = getLabel(LABELS.tooltip.deletePreset);

    /* 対象と確認用の色分けの行（対象は余りの幅まで広げる）/ Scope and check coloring on one row (the scope takes the extra width) */
    var topRowGroup = mainDialog.add("group");
    setupRow(topRowGroup, ["fill", "top"], COLUMN_SPACING);
    topRowGroup.alignChildren = ["left", "fill"];

    /* 対象（ラジオは横並び）/ Scope (radios in a row) */
    var targetPanel = topRowGroup.add("panel", undefined, getLabel(LABELS.panel.target));
    setupPanel(targetPanel);
    targetPanel.alignment = ["fill", "fill"];
    targetPanel.orientation = "row";
    targetPanel.alignChildren = ["left", "center"];
    var scopeRadios = {
        selection: targetPanel.add("radiobutton", undefined, getLabel(LABELS.radio.targetSelection)),
        story: targetPanel.add("radiobutton", undefined, getLabel(LABELS.radio.targetStory)),
        document: targetPanel.add("radiobutton", undefined, getLabel(LABELS.radio.targetDocument))
    };
    scopeRadios.selection.helpTip = getLabel(LABELS.tooltip.targetSelection);
    scopeRadios.story.helpTip = getLabel(LABELS.tooltip.targetStory);
    scopeRadios.document.helpTip = getLabel(LABELS.tooltip.targetDocument);
    scopeRadios.selection.enabled = scopeAvailability.selection;
    scopeRadios.story.enabled = scopeAvailability.story;

    /* 前回の対象が選べなければ、選択範囲 → ストーリー → ドキュメントの順に選ぶ / Fall back to selection, story, then document when the last scope is unavailable */
    var initialScope = settings.scope;
    if (!initialScope || !scopeRadios[initialScope] || !scopeRadios[initialScope].enabled) {
        initialScope = scopeAvailability.selection ? "selection" : (scopeAvailability.story ? "story" : "document");
    }
    scopeRadios[initialScope].value = true;

    /* 除外するスタイル（対象パネルの右端）/ Excluded styles (right end of the scope panel) */
    var targetSpacer = targetPanel.add("group");
    targetSpacer.alignment = ["fill", "fill"];
    targetSpacer.minimumSize.width = 0;
    /* ボタンはグループで包み、余りの幅で広がらないようにする / Wrap the button so the extra width does not stretch it */
    var excludedStylesGroup = targetPanel.add("group");
    excludedStylesGroup.alignChildren = ["right", "center"];
    var btnExcludedStyles = excludedStylesGroup.add("button", undefined, "");
    /* 表示後に「（数）」が付いても切れないよう、2桁の数の文言の幅を取っておく / Reserve the width of a two-digit count so the label is not cut off after the dialog is shown */
    try {
        btnExcludedStyles.minimumSize.width = Math.ceil(btnExcludedStyles.graphics.measureString(
            getLabel(LABELS.button.excludedStylesCount, { count: 99 }))[0]) + EXCLUDED_STYLES_BUTTON_PADDING;
    } catch (e) {}
    var excludedStyles = settings.excludedStyles;

    /**
     * ［除外するスタイル...］の文言とツールチップを、選んでいる数・名前に合わせる
     * @returns {void}
     */
    function updateExcludedStylesButton() {
        var excludedNames = excludedStyles.paragraph.concat(excludedStyles.character);
        btnExcludedStyles.text = (excludedNames.length > 0)
            ? getLabel(LABELS.button.excludedStylesCount, { count: excludedNames.length })
            : getLabel(LABELS.button.excludedStyles);
        btnExcludedStyles.helpTip = getLabel(LABELS.tooltip.excludedStyles) + (excludedNames.length > 0 ? "\n" + excludedNames.join(", ") : "");
    }
    updateExcludedStylesButton();
    btnExcludedStyles.onClick = function () {
        var chosenStyles = showExcludedStylesDialog(excludedStyles);
        if (!chosenStyles) return;
        excludedStyles = chosenStyles;
        updateExcludedStylesButton();
    };

    /* 確認用の色分け（どちらのタブでも使う。表示前の value は読み戻せないので値は自前で持つ）/
       Check coloring (used with either tab; the value is kept here, since value cannot be read back before show) */
    var highlightPanel = topRowGroup.add("panel", undefined, getLabel(LABELS.panel.highlight));
    setupPanel(highlightPanel);
    highlightPanel.orientation = "row";
    highlightPanel.alignment = ["right", "fill"];
    highlightPanel.alignChildren = ["left", "center"];
    var highlightCheckbox = highlightPanel.add("checkbox", undefined, getLabel(LABELS.checkbox.highlightChanges));
    highlightCheckbox.helpTip = getLabel(LABELS.tooltip.highlightChanges);
    var highlightChanges = (settings.highlightChanges === true);
    highlightCheckbox.value = highlightChanges;
    highlightCheckbox.onClick = function () { highlightChanges = highlightCheckbox.value; };

    /* 横組み・縦組みのタブ（設定はタブごと。変換には開いているタブの設定を使う）/ Horizontal and vertical tabs (each keeps its own settings; the open tab's are used) */
    var tabbedPanel = mainDialog.add("tabbedpanel");
    tabbedPanel.alignChildren = ["fill", "top"];
    var tabControlsByKey = {};
    var rowLabels = [];
    var headerSpacers = [];
    for (var tabIndex = 0; tabIndex < TAB_KEYS.length; tabIndex++) {
        var tabControls = addSettingsTab(tabbedPanel, TAB_KEYS[tabIndex], function (changedTabControls) {
            updateDependentControls(changedTabControls);
            syncPresetSelection();
        });
        tabControlsByKey[TAB_KEYS[tabIndex]] = tabControls;
        rowLabels = rowLabels.concat(tabControls.rowLabels);
        headerSpacers = headerSpacers.concat(tabControls.headerSpacers);
    }

    /* 項目名の幅をすべての表で同じにし、見出しの空きも同じ幅にする / Give every table the same label width, and the header gap too */
    var rowLabelWidth = alignLabelWidths(rowLabels, "right");
    for (var spacerIndex = 0; spacerIndex < headerSpacers.length; spacerIndex++) {
        headerSpacers[spacerIndex].preferredSize.width = rowLabelWidth;
    }

    /**
     * 開いているタブのコントロールを返す
     * @returns {Object} タブのコントロール（addSettingsTab() の戻り値）
     */
    function getActiveTabControls() {
        return (tabbedPanel.selection === tabControlsByKey.vertical.tab) ? tabControlsByKey.vertical : tabControlsByKey.horizontal;
    }

    /* ドロップダウンの項目番号 → プリセット（「カスタム」と区切り線は null）/ Dropdown item index → preset ("Custom" and separators are null) */
    var userPresets = loadUserPresets();
    var presetItems = [];
    var isUpdatingPresetDropdown = false;

    /**
     * プリセットのドロップダウンを作り直す（組み込み → 区切り線 → ユーザーのプリセット。どちらのタブでもすべて並べる）
     * @returns {void}
     */
    function rebuildPresetDropdown() {
        isUpdatingPresetDropdown = true;
        presetDropdown.removeAll();
        presetItems = [];
        presetDropdown.add("item", getLabel(LABELS.dropdown.customPreset));
        presetItems.push(null);
        for (var i = 0; i < BUILTIN_PRESETS.length; i++) {
            presetDropdown.add("item", BUILTIN_PRESETS[i].name);
            presetItems.push(BUILTIN_PRESETS[i]);
        }
        if (userPresets.length > 0) {
            presetDropdown.add("separator");
            presetItems.push(null);
        }
        for (var j = 0; j < userPresets.length; j++) {
            presetDropdown.add("item", userPresets[j].name);
            presetItems.push(userPresets[j]);
        }
        isUpdatingPresetDropdown = false;
        syncPresetSelection();
    }

    /**
     * 開いているタブの設定に合うプリセットをドロップダウンで選ぶ（合うものが無ければ「カスタム」）。ほかのタブのプリセットは合わせない
     * @returns {void}
     */
    function syncPresetSelection() {
        var activeTabControls = getActiveTabControls();
        var currentOptions = readRowOptions(activeTabControls);
        var matchedIndex = 0;
        for (var i = 0; i < presetItems.length; i++) {
            if (presetItems[i] && isPresetForTab(presetItems[i], activeTabControls.tabKey) && isSameRowOptions(rowOptionsForTab(presetItems[i].rowOptions, activeTabControls.tabKey), currentOptions)) {
                matchedIndex = i;
                break;
            }
        }
        isUpdatingPresetDropdown = true;
        presetDropdown.selection = matchedIndex;
        isUpdatingPresetDropdown = false;
        btnDeletePreset.enabled = !!(presetItems[matchedIndex] && !presetItems[matchedIndex].builtIn);
    }

    /**
     * 名前が同じユーザーのプリセットの番号を返す
     * @param {string} presetName - プリセット名
     * @returns {number} 番号。無ければ -1
     */
    function findUserPresetIndex(presetName) {
        for (var i = 0; i < userPresets.length; i++) {
            if (userPresets[i].name === presetName) return i;
        }
        return -1;
    }

    /**
     * ユーザーのプリセットをファイルに書き、ドロップダウンを作り直す
     * @returns {void}
     */
    function storeUserPresets() {
        if (!saveUserPresets(userPresets)) alert(getLabel(LABELS.alert.presetSaveFailed));
        rebuildPresetDropdown();
    }

    presetDropdown.onChange = function () {
        if (isUpdatingPresetDropdown || !presetDropdown.selection) return;
        var chosenPreset = presetItems[presetDropdown.selection.index];
        btnDeletePreset.enabled = !!(chosenPreset && !chosenPreset.builtIn);
        if (!chosenPreset) return;
        /* タブを持つプリセット（「縦組み用」など）は、そのタブに切り替えて反映する / A preset with a tab (such as vertical) switches to that tab */
        var targetTabControls = chosenPreset.tab ? tabControlsByKey[chosenPreset.tab] : getActiveTabControls();
        applyRowOptions(targetTabControls, chosenPreset.rowOptions);
        if (tabbedPanel.selection !== targetTabControls.tab) {
            tabbedPanel.selection = targetTabControls.tab;
            syncPresetSelection();
        }
    };

    btnSavePreset.onClick = function () {
        var chosenPreset = presetDropdown.selection ? presetItems[presetDropdown.selection.index] : null;
        var suggestedName = (chosenPreset && !chosenPreset.builtIn) ? chosenPreset.name : "";
        var presetName = prompt(getLabel(LABELS.prompt.presetName), suggestedName);
        if (presetName === null) return;
        presetName = String(presetName).replace(/^\s+|\s+$/g, "");
        if (presetName === "") return;
        for (var i = 0; i < BUILTIN_PRESETS.length; i++) {
            if (BUILTIN_PRESETS[i].name === presetName) {
                alert(getLabel(LABELS.alert.builtInPresetName, { name: presetName }));
                return;
            }
        }
        /* 選ぶと保存したタブに切り替える / Choosing it later switches to the tab it was saved from */
        var activeTabControls = getActiveTabControls();
        var newPreset = { name: presetName, builtIn: false, tab: activeTabControls.tabKey, rowOptions: readRowOptions(activeTabControls) };
        var existingIndex = findUserPresetIndex(presetName);
        if (existingIndex >= 0) {
            if (!confirm(getLabel(LABELS.confirm.overwritePreset, { name: presetName }), true)) return;
            userPresets[existingIndex] = newPreset;
        } else {
            userPresets.push(newPreset);
        }
        storeUserPresets();
    };

    btnDeletePreset.onClick = function () {
        var chosenPreset = presetDropdown.selection ? presetItems[presetDropdown.selection.index] : null;
        if (!chosenPreset || chosenPreset.builtIn) return;
        if (!confirm(getLabel(LABELS.confirm.deletePreset, { name: chosenPreset.name }), true)) return;
        userPresets.splice(findUserPresetIndex(chosenPreset.name), 1);
        storeUserPresets();
    };

    for (var applyIndex = 0; applyIndex < TAB_KEYS.length; applyIndex++) {
        applyRowOptions(tabControlsByKey[TAB_KEYS[applyIndex]], settings.rowOptionsByTab[TAB_KEYS[applyIndex]]);
    }
    tabbedPanel.selection = tabControlsByKey[settings.activeTab].tab;
    rebuildPresetDropdown();
    /* タブを切り替えたら、そのタブの設定に合うプリセットを選び直す / Switching tabs re-selects the preset matching that tab */
    tabbedPanel.onChange = function () { syncPresetSelection(); };

    var buttonRow = addButtonRow(mainDialog);
    var btnRestoreDefaults = buttonRow.leftGroup.add("button", undefined, getLabel(LABELS.button.restoreDefaults));
    btnRestoreDefaults.helpTip = getLabel(LABELS.tooltip.restoreDefaults);
    btnRestoreDefaults.onClick = function () {
        applyRowOptions(getActiveTabControls(), getDefaultRowOptions());
        syncPresetSelection();
    };

    var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.cancel), { name: "cancel" });
    var btnConvert = buttonRow.rightGroup.add("button", undefined, getLabel(LABELS.button.convert), { name: "ok" });
    btnCancel.onClick = function () { mainDialog.close(0); };
    btnConvert.onClick = function () { mainDialog.close(1); };
    alignRightOnlyButtonRow(buttonRow);

    addVersionFooter(mainDialog);
    if (mainDialog.show() !== 1) return null;

    var chosenRowOptionsByTab = {};
    for (var readIndex = 0; readIndex < TAB_KEYS.length; readIndex++) {
        chosenRowOptionsByTab[TAB_KEYS[readIndex]] = readRowOptions(tabControlsByKey[TAB_KEYS[readIndex]]);
    }
    var chosenScope = "document";
    for (var scopeKey in scopeRadios) {
        if (scopeRadios.hasOwnProperty(scopeKey) && scopeRadios[scopeKey].value) chosenScope = scopeKey;
    }
    return {
        rowOptionsByTab: chosenRowOptionsByTab,
        activeTab: getActiveTabControls().tabKey,
        scope: chosenScope,
        excludedStyles: excludedStyles,
        highlightChanges: highlightChanges
    };
}

// =========================================
// メイン処理 / Main
// =========================================

/**
 * ダイアログで設定を選び、対象の文字の全角・半角を変換する
 * @returns {void}
 */
function main() {
    var selectionTargets = getSelectionTargets(false);
    var storyTargets = getSelectionTargets(true);

    var settings = showConvertDialog(loadSettings(), {
        selection: selectionTargets.length > 0,
        story: storyTargets.length > 0
    });
    if (!settings) return;
    saveSettings(settings);

    /* 開いていたタブの設定で変換する（タブに無い設定は 0）/ Convert with the open tab's settings (settings not on that tab are 0) */
    var conversion = buildConversionMap(settings.rowOptionsByTab[settings.activeTab]);
    if (!hasConversionWork(conversion)) {
        alert(getLabel(LABELS.alert.allKeep));
        return;
    }
    conversion.excludedStyles = buildExcludedStyleLookup(settings.excludedStyles);

    var targets = [activeDocument];
    if (settings.scope === "selection") targets = selectionTargets;
    else if (settings.scope === "story") targets = storyTargets;

    var result = null;
    /* 一括で取り消せるように doScript でまとめて実行 / Run through doScript so the whole run is a single undo step */
    app.doScript(function () {
        /* スウォッチを足すのも同じ取り消しにまとめる / Adding the swatch is part of the same undo step */
        conversion.highlightColor = settings.highlightChanges ? getHighlightSwatch() : null;
        result = convertTargets(targets, conversion);
    }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, getLabel(LABELS.undo.convert));

    if (result.converted === 0 && result.failed === 0) {
        alert(getLabel(LABELS.alert.notFound));
        return;
    }
    var message = getLabel(LABELS.alert.converted, { count: result.converted });
    if (result.failed > 0) message += "\n" + getLabel(LABELS.alert.failed, { count: result.failed });
    var breakdownLines = formatResultBreakdown(result.countsByKey);
    if (breakdownLines.length > 0) message += "\n\n" + breakdownLines.join("\n");
    alert(message);
}

/* 内訳に出す、行以外のキー（行のあとに並べる）/ Keys besides the rows shown in the breakdown, listed after the rows */
var RESULT_EXTRA_KEYS = ["nakaguroToEllipsis", "periodsToEllipsis", "kutenToEllipsis", "dashForm", "japaneseLatinSpace", "unitsKumimoji", "punctuationStyle", "longDigitsFullwidth", "twoDigitGlyphForm",
    "threeDigitGlyphForm", "shortCapsFullwidth", "numberCommaToTouten", "decimalToNakaguro", "westernPunctuationSpace", "bracketInnerSpace", "bracketOuterSpace"];

/**
 * 変換した数の内訳を、行の並び順で「項目名 : 数」の行にする
 * @param {Object} countsByKey - キー → 変換した数
 * @returns {string[]} 内訳の行
 */
function formatResultBreakdown(countsByKey) {
    var breakdownLines = [];
    for (var i = 0; i < ALL_ROWS.length; i++) {
        var row = ALL_ROWS[i];
        if (!countsByKey[row.key]) continue;
        var rowLabel = getLabel(LABELS.row[row.key]) + (row.glyph ? "  " + row.glyph : "");
        breakdownLines.push(getLabel(LABELS.alert.breakdownLine, { label: rowLabel, count: countsByKey[row.key] }));
    }
    for (var j = 0; j < RESULT_EXTRA_KEYS.length; j++) {
        var extraKey = RESULT_EXTRA_KEYS[j];
        if (!countsByKey[extraKey]) continue;
        breakdownLines.push(getLabel(LABELS.alert.breakdownLine, { label: getLabel(LABELS.resultLabel[extraKey]), count: countsByKey[extraKey] }));
    }
    return breakdownLines;
}

main();

})();
