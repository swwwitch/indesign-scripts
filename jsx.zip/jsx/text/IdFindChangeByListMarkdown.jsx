#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdFindChangeByListMarkdown
Name=Markdown 記法を検索・置換してスタイルを適用
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.0.7
Release-Date=2026-03-17
Description-BEGIN
Markdown 記法をまとめて検索・置換し、対応する段落スタイルと文字スタイルを適用します。

Runs a batch find/change over Markdown notation and applies the matching paragraph and character styles.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

Markdown 記法をまとめて検索・置換し、対応する段落スタイルと文字スタイルを適用します。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdFindChangeByListMarkdown.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n8c0211d92c96

### Overview

Runs a batch find/change over Markdown notation and applies the matching paragraph and character styles.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdFindChangeByListMarkdown.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdFindChangeByListMarkdown";   /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.0.7";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-03-17";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "Markdown 記法を検索・置換してスタイルを適用"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdFindChangeByListMarkdown.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdFindChangeByListMarkdown.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n8c0211d92c96"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/text/IdFindChangeByListMarkdown.jsx"; /* 最新版のソース / latest source */

// Original idea
// Adobe InDesign 付属の FindChangeByList.jsx / Based on the bundled FindChangeByList.jsx

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

(function () {

// =========================================
// ユーザー設定 / User settings
// =========================================

/* ソース形式ごとの既定スタイル名 / Default style names per source format */
var STYLE_PRESETS = {
    html: {
        paragraph: "p", h1: "h1", h2: "h2", h3: "h3", h4: "h4", h5: "h5", h6: "h6",
        bullet: "ul-li", bulletSub: "ul-ul-li", numbered: "ol-li",
        blockquote: "p.blockquote", caption: "p.caption",
        codeBlock: "p.code", codeInline: "code",
        image: "p.img", cell: "td", headerCell: "th",
        bold: "strong-bold", emphasis: "em-i-marker", link: "link"
    },
    msword: {
        paragraph: "Paragraph", h1: "Header1", h2: "Header2", h3: "Header3", h4: "Header4", h5: "Header4", h6: "Header4",
        bullet: "BulList > first", bulletSub: "BulList > BulList > first", numbered: "NumList > first",
        blockquote: "Blockquote > Paragraph", caption: "Caption",
        codeBlock: "CodeBlock", codeInline: "Code",
        image: "Figure", cell: "TablePar", headerCell: "TablePar > TableHeader",
        bold: "Bold", emphasis: "Italic", link: "Link"
    }
};

/* 画像挿入用に一時作成するグラフィックフレームの高さ / Height of the temporary graphic frame used for images */
var TEMP_IMAGE_FRAME_HEIGHT = 50;

// =========================================
// レイアウト設定 / Layout settings
// =========================================

/* 見出しラベルとドロップダウンの幅（px）/ Width of the row label and the style dropdown (px) */
var ROW_LABEL_WIDTH     = 120;
var STYLE_DROPDOWN_WIDTH = 160;

/* スコープ・形式行のラベル幅（px）/ Label width of the scope and format rows (px) */
var SCOPE_LABEL_WIDTH = 80;

/* プログレスバーの幅（px）/ Width of the progress bar (px) */
var PROGRESS_BAR_WIDTH = 300;

// ==============================
// UIレイアウトの共通設定 / Shared UI layout
// ==============================

// UIレイアウト（再利用パーツ） / UI layout (reusable)

/* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

/**
 * ウィンドウの共通設定
 * @param {Window} targetWindow - 対象のウィンドウ
 * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
 * @returns {void}
 */
function setupWindow(targetWindow, spacing) {
    targetWindow.orientation = "column";
    targetWindow.alignChildren = "fill";
    targetWindow.margins = WINDOW_MARGINS;
    targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
}

/**
 * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
 * @param {Panel} targetPanel - 対象のパネル
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupPanel(targetPanel, spacing) {
    targetPanel.orientation = "column";
    targetPanel.alignChildren = ["fill", "top"];
    targetPanel.alignment = "fill";
    targetPanel.margins = PANEL_MARGINS;
    targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * タブの共通設定
 * @param {Tab} targetTab - 対象のタブ
 * @param {number} [spacing] - 要素間隔（省略時は変えない）
 * @returns {void}
 */
function setupTab(targetTab, spacing) {
    targetTab.orientation = "column";
    targetTab.alignChildren = "fill";
    targetTab.margins = TAB_MARGINS;
    if (typeof spacing === "number") targetTab.spacing = spacing;
}

/**
 * 横並びの行グループの共通設定（ボタン列など）。
 * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
 * @param {Group} rowGroup - 対象のグループ
 * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupRow(rowGroup, rowAlignment, spacing) {
    rowGroup.orientation = "row";
    rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
    rowGroup.alignChildren = ["left", "center"];
    rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
 * @param {Button} targetButton - 対象のボタン
 * @param {number} trimPixels - 詰める量（px）
 * @returns {void}
 */
function trimButtonHeight(targetButton, trimPixels) {
    /* レイアウト前は size が無い / size is not set until the layout runs */
    if (!targetButton.size) return;
    targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
}

// UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

// ボタン行（再利用パーツ） / Button row (reusable)

var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

/**
 * ダイアログ下部のボタン行を作る。
 * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
 * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
 * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
 * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
 */
function addButtonRow(parent, rowOptions) {
    var isCentered = !!(rowOptions && rowOptions.centered);
    var btnRowGroup = parent.add("group");
    btnRowGroup.orientation = "row";
    btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
    btnRowGroup.spacing = BUTTON_ROW_SPACING;

    if (isCentered) {
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
    }

    btnRowGroup.alignment = ["fill", "bottom"];

    var btnLeftGroup = btnRowGroup.add("group");
    btnLeftGroup.alignChildren = ["left", "center"];
    btnLeftGroup.spacing = BUTTON_ROW_SPACING;

    /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
    var spacer = btnRowGroup.add("group");
    spacer.alignment = ["fill", "fill"];
    spacer.minimumSize.width = 0;

    var btnRightGroup = btnRowGroup.add("group");
    btnRightGroup.alignChildren = ["right", "center"];
    btnRightGroup.spacing = BUTTON_ROW_SPACING;

    return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
}

/**
 * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
 * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
 * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
 * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
 * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
 * @returns {void}
 */
function alignRightOnlyButtonRow(buttonRow) {
    if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
    var dialogWindow = buttonRow.rowGroup.window;
    dialogWindow.addEventListener("show", function () {
        if (!buttonRow.leftGroup) return;
        var btnRowGroup = buttonRow.rowGroup;
        /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
        if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
        /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
        btnRowGroup.remove(buttonRow.leftGroup);
        btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        buttonRow.leftGroup = null;
        dialogWindow.layout.layout(true);
    });
}

// ボタン行（再利用パーツ）ここまで / End of the reusable button row

// UI の明暗（再利用パーツ） / UI theme (reusable)

/**
 * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
 * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
 */
function isDarkUI() {
    try {
        if (app.preferences && app.preferences.getRealPreference) {
            return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
        }
        return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
    } catch (e) {
        return false;
    }
}

// UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

// バージョン表示（再利用パーツ） / Version footer (reusable)

var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

/* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
   9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
   / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
     nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
var VERSION_FOOTER_GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
    "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
    "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
    "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
    "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
    "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
    "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
    "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
    "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
    "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
    "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
    "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
    "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
    "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
    "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
    "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
    "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
    "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
    "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
    "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
    "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
    "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
    "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
    "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
    "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
    "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
    "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
    "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
    "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
    "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
    "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
    "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
    "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
    "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
    "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
    "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
    "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
    "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
    ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
    "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
    "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
    "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
    " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
};

/**
 * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
 * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
 * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
 * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
 * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
 */
function addVersionFooter(targetWindow) {
    if (targetWindow.versionFooter) return null;

    /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
    var lastChild = targetWindow.children[targetWindow.children.length - 1];
    if (lastChild && lastChild.type === "group") {
        var rowMargins = lastChild.margins;
        lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
    }
    var windowMargins = targetWindow.margins;
    targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

    var footerGroup = targetWindow.add("group");
    footerGroup.orientation = "row";
    footerGroup.alignment = ["fill", "bottom"];
    footerGroup.alignChildren = ["left", "center"];
    footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

    /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
       左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
       / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
         or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
    var versionText = String(SCRIPT_VERSION);
    var leftCandidates = [versionText];
    if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
    var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
    versionCanvas.alignment = ["fill", "center"];
    bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
    var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
    brandCanvas.alignment = ["right", "center"];
    brandCanvas.maximumSize = brandCanvas.preferredSize;
    targetWindow.versionFooter = footerGroup;
    return versionCanvas;
}

/**
 * 文字列のすべての文字に字形があるかを返す
 * @param {string} dotText - 文字列
 * @returns {boolean} すべてあれば true
 */
function hasVersionFooterGlyphs(dotText) {
    for (var i = 0; i < dotText.length; i++) {
        if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
    }
    return dotText.length > 0;
}

/**
 * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
 * @param {Group} parentGroup - 足す先
 * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
 * @returns {Group} 描くグループ
 */
function addVersionFooterCanvas(parentGroup, dotTexts) {
    var dotCanvas = parentGroup.add("group");
    var shortestText = dotTexts[dotTexts.length - 1];
    dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
    dotCanvas.helpTip = dotTexts[0];
    dotCanvas.onDraw = function () {
        var availableWidth = this.size ? this.size.width : 0;
        var drawText = shortestText;
        for (var i = 0; i < dotTexts.length; i++) {
            if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                drawText = dotTexts[i];
                break;
            }
        }
        drawVersionFooterDots(this.graphics, drawText);
    };
    return dotCanvas;
}

/**
 * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
 * @param {string} versionText - 文字列
 * @returns {number} 幅（ドット）
 */
function measureVersionFooterDots(versionText) {
    var dotCount = 0;
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
        dotCount += glyphRows[0].length;
    }
    return dotCount;
}

/**
 * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
 * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
 * @param {string} versionText - 文字列
 * @returns {void}
 */
function drawVersionFooterDots(canvasGraphics, versionText) {
    var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
    var dotSize = VERSION_FOOTER_PIXEL_SIZE;
    var cursorDots = 0;
    canvasGraphics.newPath();
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
        for (var row = 0; row < glyphRows.length; row++) {
            var rowText = glyphRows[row];
            var runStart = -1;
            for (var col = 0; col <= rowText.length; col++) {
                var isDot = col < rowText.length && rowText.charAt(col) === "#";
                if (isDot && runStart < 0) runStart = col;
                if (!isDot && runStart >= 0) {
                    canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                    runStart = -1;
                }
            }
        }
        cursorDots += glyphRows[0].length;
    }
    canvasGraphics.fillPath(footerBrush);
}

// -----------------------------------------
// このスクリプトについて / About this script
// -----------------------------------------
/* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
   この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
   Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
   and keeps its own labels and layout values so the part works on its own */

var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
/* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
   The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
/* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

var VERSION_INFO_LABELS = {
    dialog: {
        title: { ja: "このスクリプトについて", en: "About This Script" }
    },
    panel: {
        generalInfo: { ja: "基本情報", en: "General" },
        links: { ja: "リンク", en: "Links" }
    },
    fieldLabel: {
        scriptName: { ja: "スクリプト名", en: "Script Name" },
        scriptFeature: { ja: "機能", en: "Feature" },
        scriptVersion: { ja: "バージョン", en: "Version" }
    },
    button: {
        openReadme: { ja: "README", en: "README" },
        openSourceCode: { ja: "ソースコード", en: "Source Code" },
        openArticle: { ja: "記事（note）", en: "Article (note)" },
        revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
        revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
        close: { ja: "閉じる", en: "Close" }
    },
    tooltip: {
        versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
        copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
    },
    alert: {
        copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
    }
};

/**
 * VERSION_INFO_LABELS の文言を今の言語で返す
 * @param {Object} labelEntry - { ja, en }
 * @returns {string} 文言
 */
function getVersionInfoLabel(labelEntry) {
    return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
}

/**
 * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
 * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
 * @returns {string} 値
 */
function getVersionInfoValue(variableKey) {
    var infoValue;
    if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
    else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
    else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
    else if (variableKey === "readme") {
        if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
        else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
    }
    else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
    else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
    return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
}

/**
 * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
 * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
 * @returns {void}
 */
function bindVersionInfoClick(versionCanvas) {
    versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
    /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
       Open on mouseup so the release does not land on the footer after the dialog closes */
    versionCanvas.addEventListener("mouseup", function () {
        showVersionInfoDialog(versionCanvas.window.type === "palette");
    });
}

/**
 * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
 * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
 * @returns {void}
 */
function showVersionInfoDialog(isFromPalette) {
    var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
    infoDialog.orientation = "column";
    infoDialog.alignChildren = "fill";
    infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
    infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

    var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
    /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
    /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
    if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
    }
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
    alignVersionInfoLabels(infoPanel);

    /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
    var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
    var linkButtonRow = linksPanel.add("group");
    linkButtonRow.orientation = "row";
    linkButtonRow.alignment = ["left", "center"];
    linkButtonRow.alignChildren = ["left", "center"];
    linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

    /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
    var buttonRow = infoDialog.add("group");
    buttonRow.orientation = "row";
    buttonRow.alignment = ["fill", "bottom"];
    buttonRow.alignChildren = ["left", "center"];
    buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
    buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
    var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
    if (VERSION_INFO_SCRIPT_FILE.exists) {
        revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
        revealButton.onClick = function () {
            revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
            infoDialog.close();
        };
    } else {
        revealButton.enabled = false;
    }
    /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
    var buttonSpacer = buttonRow.add("group");
    buttonSpacer.alignment = ["fill", "fill"];
    buttonSpacer.minimumSize.width = 0;
    var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
    closeButton.alignment = ["right", "center"];
    /* return でも esc でも閉じる / Close with both Return and Esc */
    infoDialog.defaultElement = closeButton;
    infoDialog.cancelElement = closeButton;
    infoDialog.onShow = function () {
        pinVersionInfoCopyButton(infoPanel);
    };
    infoDialog.show();
}

/**
 * 「このスクリプトについて」のダイアログにパネルを足す
 * @param {Window} infoDialog - 足す先のダイアログ
 * @param {Object} titleEntry - パネル名の文言 { ja, en }
 * @returns {Panel} パネル
 */
function addVersionInfoPanel(infoDialog, titleEntry) {
    var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
    infoPanel.orientation = "column";
    infoPanel.alignChildren = ["fill", "top"];
    infoPanel.alignment = "fill";
    infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
    infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
    return infoPanel;
}

/**
 * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
 * @param {Panel} infoPanel - 足す先のパネル
 * @param {Object} labelEntry - 項目名の文言 { ja, en }
 * @param {string} valueText - 表示する値
 * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
 * @returns {StaticText} 値の statictext
 */
function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
    var infoRow = infoPanel.add("group");
    infoRow.orientation = "row";
    infoRow.alignment = ["fill", "center"];
    infoRow.alignChildren = ["left", "center"];
    infoRow.spacing = VERSION_INFO_ROW_SPACING;
    /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
    var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
    rowLabel.justify = "right";
    var valueLabel = infoRow.add("statictext", undefined, valueText);
    if (copyFromPalette === null) return valueLabel;
    /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
       A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
    var copySpacer = infoRow.add("group");
    copySpacer.alignment = ["fill", "fill"];
    copySpacer.minimumSize.width = 0;
    infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
    return valueLabel;
}

/**
 * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
 * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
 * @param {Panel} infoPanel - ［基本情報］パネル
 * @returns {void}
 */
function pinVersionInfoCopyButton(infoPanel) {
    var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
    for (var i = 0; i < infoPanel.children.length; i++) {
        var infoRow = infoPanel.children[i];
        if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
        infoRow.size = [innerWidth, infoRow.size.height];
        infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
    }
}

/**
 * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
 * @param {Panel} infoPanel - 対象のパネル
 * @returns {void}
 */
function alignVersionInfoLabels(infoPanel) {
    var rowLabels = [];
    var labelWidth = 0;
    for (var i = 0; i < infoPanel.children.length; i++) {
        var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
        rowLabels.push(rowLabel);
        labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
    }
    for (var j = 0; j < rowLabels.length; j++) {
        rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
    }
}

/**
 * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
 * @param {Window} infoDialog - ボタンを置くダイアログ
 * @param {Group} buttonGroup - 足す先のグループ
 * @param {Object} labelEntry - ボタンの文言 { ja, en }
 * @param {string} targetUrl - 開く URL（空ならディム表示）
 * @returns {void}
 */
function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
    var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
    if (!targetUrl) {
        linkButton.enabled = false;
        return;
    }
    linkButton.helpTip = targetUrl;
    linkButton.onClick = function () {
        openVersionInfoUrl(targetUrl);
        infoDialog.close();
    };
}

/**
 * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
 * @param {Group} infoRow - 足す先の行
 * @param {StaticText} valueLabel - コピーする値の statictext
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {Group} ボタンとして使う group
 */
function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
    var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
    var copyButton = infoRow.add("group");
    copyButton.preferredSize = [buttonSize, buttonSize];
    copyButton.minimumSize = [buttonSize, buttonSize];
    copyButton.maximumSize = [buttonSize, buttonSize];
    copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
    copyButton.isPressed = false;
    copyButton.isCopied = false;

    copyButton.onDraw = function () {
        var buttonGraphics = copyButton.graphics;
        var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
        buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
        if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
        else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
    };

    /**
     * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
     * @param {boolean} isPressed - 押下中なら true
     * @param {boolean} isCopied - コピー済みなら true
     * @returns {void}
     */
    function repaint(isPressed, isCopied) {
        if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
        copyButton.isPressed = isPressed;
        copyButton.isCopied = isCopied;
        copyButton.hide();
        copyButton.show();
    }
    copyButton.addEventListener("mousedown", function () { repaint(true, false); });
    copyButton.addEventListener("mouseup", function () {
        if (!copyButton.isPressed) return;
        var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
        repaint(false, hasCopied);
        if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
    });
    /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
    copyButton.addEventListener("mouseout", function () { repaint(false, false); });
    return copyButton;
}

/**
 * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
    var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
    var sheetSize = 9;
    var offset = 3;
    var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var backLeft = frontLeft - offset;
    var backTop = frontTop - offset;
    /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
    buttonGraphics.newPath();
    buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
    buttonGraphics.strokePath(iconPen);
    buttonGraphics.newPath();
    buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
    buttonGraphics.strokePath(iconPen);
}

/**
 * コピーしたあとのチェックマークを描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
    var center = buttonSize / 2;
    buttonGraphics.newPath();
    buttonGraphics.moveTo(center - 4.5, center);
    buttonGraphics.lineTo(center - 1.5, center + 3);
    buttonGraphics.lineTo(center + 4.5, center - 3.5);
    buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
}

/**
 * 文字列をクリップボードにコピーする。
 * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
 * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
 * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
 * @param {string} copyText - コピーする文字列
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {boolean} コピーの操作まで進めたら true
 */
function copyVersionInfoText(copyText, isFromPalette) {
    try {
        if (VERSION_INFO_IS_INDESIGN) {
            if (File.fs === "Windows") {
                app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
            } else {
                app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
            }
            return true;
        }
        var copyScript = buildVersionInfoCopyScript(copyText);
        if (!isFromPalette) return eval(copyScript) === true;
        var copyMessage = new BridgeTalk();
        copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
        copyMessage.body = copyScript;
        copyMessage.send();
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
 * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
 * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
 * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
 * @param {string} copyText - コピーする文字列
 * @returns {string} 実行すると true / false を返すスクリプト
 */
function buildVersionInfoCopyScript(copyText) {
    return [
        "(function (copyText) {",
        "    var usingTempDoc = (app.documents.length === 0);",
        "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
        "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
        "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
        "    var tempLayer = null;",
        "    var hasCopied = false;",
        "    try {",
        "        tempLayer = targetDoc.layers.add();",
        "        var tempFrame = tempLayer.textFrames.add();",
        "        tempFrame.contents = copyText;",
        "        app.redraw();",
        "        app.executeMenuCommand('deselectall');",
        "        tempFrame.selected = true;",
        "        app.redraw();",
        "        app.executeMenuCommand('copy');",
        "        app.redraw();",
        "        hasCopied = true;",
        "    } catch (e) { }",
        "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
        "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
        "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
        "    targetDoc.selection = null;",
        "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
        "    app.redraw();",
        "    return hasCopied;",
        "})(" + quoteVersionInfoString(copyText) + ");"
    ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
}

/**
 * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
 * @param {string} sourceText - 文字列
 * @returns {string} "…" の形のリテラル
 */
function quoteVersionInfoString(sourceText) {
    return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

/**
 * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
 * @param {File} scriptFile - 表示するファイル
 * @returns {void}
 */
function revealVersionInfoScriptFile(scriptFile) {
    /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
    var hasRevealApp = (File.fs === "Macintosh")
        && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
    /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
    if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
    /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
    scriptFile.parent.execute();
}

/**
 * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
 * @param {string} targetPath - 絶対パス
 * @returns {boolean} 書き出せたら true
 */
function writeVersionInfoRevealPath(targetPath) {
    var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
    pathFile.encoding = "UTF-8";
    pathFile.lineFeed = "Unix";
    if (!pathFile.open("w")) return false;
    var hasWritten = pathFile.write(targetPath);
    pathFile.close();
    return hasWritten;
}

/**
 * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
 * @param {string} targetUrl - 開く URL
 * @returns {void}
 */
function openVersionInfoUrl(targetUrl) {
    var isMac = (File.fs === "Macintosh");
    var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
    shortcutFile.encoding = "UTF-8";
    shortcutFile.open("w");
    if (isMac) {
        var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
        shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
            + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
    } else {
        shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
    }
    shortcutFile.close();
    shortcutFile.execute();
}

// バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

// =========================================
// ラベル定義 / Labels
// =========================================

// ローカライズ（再利用パーツ） / Localization (reusable)

/**
 * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
 * @returns {string} "ja" または "en"
 */
function getCurrentLang() {
    return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
}

var uiLang = getCurrentLang();

/**
 * LABELS から今の UI 言語の文言を取り出す。
 * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
 * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
 * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
 */
function getLabel(labelRef, placeholderValues) {
    var labelEntry = labelRef;
    if (typeof labelRef === "string") {
        var labelPathKeys = labelRef.split(".");
        labelEntry = LABELS;
        for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
            labelEntry = labelEntry[labelPathKeys[i]];
        }
    }
    var labelString;
    if (typeof labelEntry === "string") labelString = labelEntry;
    else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
    else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
    else return (typeof labelRef === "string") ? labelRef : "";
    return fillLabelPlaceholders(String(labelString), placeholderValues);
}

/**
 * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {Object|Array} [placeholderValues] - getLabel と同じ
 * @returns {string} コロン付きの文言
 */
function labelText(labelRef, placeholderValues) {
    return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
}

/**
 * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {string|number} value - コロンのあとに続ける値
 * @returns {string} 項目名と値をつないだ文字列
 */
function labelValueText(labelRef, value) {
    return labelText(labelRef) + " " + value;
}

/**
 * 文言の {name} や %1 に値を差し込む
 * @param {string} labelString - 文言
 * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
 * @returns {string} 差し込んだ文言
 */
function fillLabelPlaceholders(labelString, placeholderValues) {
    if (placeholderValues == null) return labelString;
    if (placeholderValues instanceof Array) {
        /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
        for (var i = placeholderValues.length; i >= 1; i--) {
            labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
        }
        return labelString;
    }
    for (var placeholderKey in placeholderValues) {
        if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
        labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
    }
    return labelString;
}

// ローカライズ（再利用パーツ）ここまで / End of the reusable localization

var LABELS = {
    dialog: {
        title: { ja: "Markdown → 段落スタイル変換", en: "Markdown to Paragraph Styles" }
    },
    progress: {
        title: { ja: "変換中…", en: "Converting…" },
        label: { ja: "Markdown → 段落スタイル変換", en: "Markdown to Paragraph Styles" }
    },
    scope: {
        label:     { ja: "スコープ", en: "Scope" },
        document:  { ja: "ドキュメント", en: "Document" },
        story:     { ja: "ストーリー", en: "Story" },
        selection: { ja: "選択範囲", en: "Selection" }
    },
    format: {
        label:  { ja: "形式", en: "Format" },
        html:   { ja: "HTML", en: "HTML" },
        msword: { ja: "MS Word", en: "MS Word" }
    },
    panel: {
        headings:  { ja: "基本段落と見出し", en: "Paragraph & Headings" },
        list:      { ja: "リスト", en: "List" },
        options:   { ja: "オプション", en: "Options" },
        code:      { ja: "ソースコード", en: "Source Code" },
        image:     { ja: "画像", en: "Image" },
        table:     { ja: "表組み", en: "Table" },
        charStyle: { ja: "文字スタイル", en: "Character Styles" },
        space:     { ja: "スペース", en: "Space" },
        cleanup:   { ja: "クリーンアップ", en: "Cleanup" }
    },
    row: {
        paragraph:  { ja: "段落", en: "Paragraph" },
        heading1:   { ja: "見出し1", en: "Heading 1" },
        heading2:   { ja: "見出し2", en: "Heading 2" },
        heading3:   { ja: "見出し3", en: "Heading 3" },
        heading4:   { ja: "見出し4", en: "Heading 4" },
        heading5:   { ja: "見出し5", en: "Heading 5" },
        heading6:   { ja: "見出し6", en: "Heading 6" },
        bullet:     { ja: "箇条書き", en: "Bullet List" },
        bulletSub:  { ja: "箇条書き（サブ）", en: "Bullet List (Sub)" },
        numbered:   { ja: "番号リスト", en: "Numbered List" },
        blockquote: { ja: "引用", en: "Blockquote" },
        caption:    { ja: "キャプション", en: "Caption" },
        codeBlock:  { ja: "コードブロック", en: "Code Block" },
        codeInline: { ja: "インライン", en: "Inline" },
        image:      { ja: "画像", en: "Image" },
        cell:       { ja: "セル", en: "Cell" },
        headerCell: { ja: "見出しセル", en: "Header Cell" },
        bold:       { ja: "太字", en: "Bold" },
        emphasis:   { ja: "強調", en: "Emphasis" },
        link:       { ja: "リンク", en: "Link" }
    },
    checkbox: {
        trimLeadingSpace:  { ja: "行頭のスペースを削除", en: "Remove leading spaces" },
        trimTrailingSpace: { ja: "行末のスペースを削除", en: "Remove trailing spaces" },
        convertNbsp:       { ja: "&nbsp; を半角スペースに変換", en: "Convert &nbsp; to space" },
        removeBlankLines:  { ja: "連続する空行を削除", en: "Remove consecutive blank lines" },
        removeComments:    { ja: "コメントアウトを削除", en: "Remove HTML comments" },
        removeRules:       { ja: "水平線を削除", en: "Remove horizontal rules" },
        removeGeta:        { ja: "〓を削除", en: "Remove 〓 marks" }
    },
    button: {
        run:    { ja: "実行", en: "Run" },
        cancel: { ja: "キャンセル", en: "Cancel" }
    },
    alert: {
        noDocument:        { ja: "ドキュメントが開かれていません。", en: "No documents are open." },
        noSelection:       { ja: "ストーリーまたは選択範囲で実行するには、テキストを選択してください。", en: "To run on Story or Selection, select some text first." },
        invalidSelection:  { ja: "選択範囲モードではテキストを選択してください。ストーリーモードではテキストまたはテキストフレームを選択してください。", en: "For Selection mode, select text. For Story mode, select text or a text frame." },
        noTarget:          { ja: "変換対象が選択されていません。", en: "No conversion targets selected." },
        noMatch:           { ja: "該当するMarkdown記法は見つかりませんでした。", en: "No matching Markdown syntax was found." }
    },
    undo: {
        convertMarkdown: { ja: "Markdown → 段落スタイル変換", en: "Markdown to Paragraph Styles" }
    }
};

// =========================================
// UI 補助 / UI helpers
// =========================================

/**
 * ドロップダウンの項目を表示名で選択する
 * @param {DropDownList} dropdown 対象のドロップダウン
 * @param {string} itemName 選択したい項目名
 * @returns {void}
 */
function selectDropdownByName(dropdown, itemName) {
    for (var i = 0; i < dropdown.items.length; i++) {
        if (dropdown.items[i].text === itemName) {
            dropdown.selection = i;
            return;
        }
    }
}

/**
 * スタイル選択ドロップダウンを追加する（推奨候補を先頭にまとめる）
 * @param {Group} parentGroup 追加先のグループ
 * @param {Array<string>} styleNames ドキュメント内のスタイル名一覧
 * @param {string} preferredName 既定で選ぶスタイル名
 * @param {number} dropdownWidth ドロップダウンの幅（px）
 * @param {string} [presetKey] STYLE_PRESETS 内のキー名
 * @returns {DropDownList} 追加したドロップダウン
 */
function addStyleDropdown(parentGroup, styleNames, preferredName, dropdownWidth, presetKey) {
    /* 推奨候補（preferred + 各プリセット）を重複なく集める / Collect preferred and preset candidates without duplicates */
    var candidateNames = [preferredName];
    if (presetKey) {
        for (var presetName in STYLE_PRESETS) {
            if (!STYLE_PRESETS.hasOwnProperty(presetName)) continue;
            var candidate = STYLE_PRESETS[presetName][presetKey];
            if (!candidate) continue;

            var isDuplicate = false;
            for (var i = 0; i < candidateNames.length; i++) {
                if (candidateNames[i] === candidate) {
                    isDuplicate = true;
                    break;
                }
            }
            if (!isDuplicate) candidateNames.push(candidate);
        }
    }

    /* 推奨候補を先頭に、残りのスタイル名を後ろに並べる / Candidates first, remaining document styles after */
    var orderedNames = [];
    for (var j = 0; j < candidateNames.length; j++) {
        orderedNames.push(candidateNames[j]);
    }
    for (var k = 0; k < styleNames.length; k++) {
        var alreadyListed = false;
        for (var m = 0; m < candidateNames.length; m++) {
            if (styleNames[k] === candidateNames[m]) {
                alreadyListed = true;
                break;
            }
        }
        if (!alreadyListed) orderedNames.push(styleNames[k]);
    }

    var styleDropdown = parentGroup.add("dropdownlist", [0, 0, dropdownWidth, 24], orderedNames);
    styleDropdown.selection = 0;
    return styleDropdown;
}

/**
 * ドロップダウンで選択中のスタイル名を取得する
 * @param {DropDownList} dropdown 対象のドロップダウン
 * @returns {string|null} 選択中のスタイル名。未選択時は null
 */
function getSelectedStyleName(dropdown) {
    return dropdown.selection ? dropdown.selection.text : null;
}

/**
 * チェックボックス＋ラベル＋スタイル選択の 1 行を追加する
 * @param {Panel} parentPanel 追加先のパネル
 * @param {string} rowLabel 行のラベル
 * @param {Array<string>} styleNames スタイル名一覧
 * @param {string} preferredName 既定で選ぶスタイル名
 * @param {string} presetKey STYLE_PRESETS 内のキー名
 * @returns {{checkbox: Checkbox, dropdown: DropDownList}} 追加したコントロール
 */
function addStyleRow(parentPanel, rowLabel, styleNames, preferredName, presetKey) {
    var row = parentPanel.add("group");
    setupRow(row, "left", 6);

    var rowCheckbox = row.add("checkbox", undefined, "");
    rowCheckbox.value = true;
    row.add("statictext", [0, 0, ROW_LABEL_WIDTH, 20], rowLabel);
    var rowDropdown = addStyleDropdown(row, styleNames, preferredName, STYLE_DROPDOWN_WIDTH, presetKey);

    return { checkbox: rowCheckbox, dropdown: rowDropdown };
}

// =========================================
// 検索対象の判定 / Target resolution
// =========================================

/**
 * 検索・置換の対象として使えるかを判定する
 * @param {object} selectionItem 選択オブジェクト
 * @returns {boolean} changeGrep / changeText を持っていれば true
 */
function canUseAsTextTarget(selectionItem) {
    if (!selectionItem) return false;
    try {
        if (typeof selectionItem.changeGrep === "function" && typeof selectionItem.changeText === "function") return true;
    } catch (e) {}
    return false;
}

/**
 * 選択オブジェクトから対象ストーリーを取り出す
 * @param {object} selectionItem 選択オブジェクト
 * @returns {Story|null} 対象ストーリー。取得できない場合は null
 */
function resolveStoryTargetFromSelection(selectionItem) {
    if (!selectionItem) return null;
    try {
        if (selectionItem.hasOwnProperty("parentStory") && selectionItem.parentStory != null) {
            return selectionItem.parentStory;
        }
    } catch (e) {}
    try {
        if (selectionItem.hasOwnProperty("texts") && selectionItem.texts.length > 0 &&
            selectionItem.texts[0].parentStory != null) {
            return selectionItem.texts[0].parentStory;
        }
    } catch (e) {}
    return null;
}

// =========================================
// 検索・置換 / Find and change
// =========================================

/**
 * 正規表現で検索・置換し、スタイルを適用する
 * @param {object} target 検索対象
 * @param {string} findWhat 検索する正規表現
 * @param {string} changeTo 置換後の文字列
 * @param {string|null} paragraphStyleName 適用する段落スタイル名
 * @param {string|null} characterStyleName 適用する文字スタイル名
 * @param {string|null} findParagraphStyleName 検索対象を絞り込む段落スタイル名
 * @returns {number} 置換した件数
 */
function findChangeGrep(target, findWhat, changeTo, paragraphStyleName, characterStyleName, findParagraphStyleName) {
    app.findGrepPreferences = NothingEnum.nothing;
    app.changeGrepPreferences = NothingEnum.nothing;

    app.findGrepPreferences.findWhat = findWhat;
    app.changeGrepPreferences.changeTo = changeTo;

    if (findParagraphStyleName != null) {
        try {
            app.findGrepPreferences.appliedParagraphStyle = findParagraphStyleName;
        } catch (e) {
            /* スタイルが見つからない場合は絞り込まない / Do not narrow the search when the style is missing */
        }
    }

    if (paragraphStyleName != null) {
        try {
            app.changeGrepPreferences.appliedParagraphStyle = paragraphStyleName;
        } catch (e) {
            app.findGrepPreferences = NothingEnum.nothing;
            app.changeGrepPreferences = NothingEnum.nothing;
            return 0;
        }
    }

    if (characterStyleName != null) {
        try {
            if (characterStyleName === "[None]" || characterStyleName === "[なし]") {
                app.changeGrepPreferences.appliedCharacterStyle = app.activeDocument.characterStyles[0];
            } else {
                app.changeGrepPreferences.appliedCharacterStyle = characterStyleName;
            }
        } catch (e) {
            app.findGrepPreferences = NothingEnum.nothing;
            app.changeGrepPreferences = NothingEnum.nothing;
            return 0;
        }
    }

    var changedRanges = target.changeGrep();

    app.findGrepPreferences = NothingEnum.nothing;
    app.changeGrepPreferences = NothingEnum.nothing;

    return changedRanges.length;
}

/**
 * 文字列検索で置換する
 * @param {object} target 検索対象
 * @param {string} findWhat 検索する文字列
 * @param {string} changeTo 置換後の文字列
 * @returns {number} 置換した件数
 */
function findChangeText(target, findWhat, changeTo) {
    app.findTextPreferences = NothingEnum.nothing;
    app.changeTextPreferences = NothingEnum.nothing;

    app.findTextPreferences.findWhat = findWhat;
    app.changeTextPreferences.changeTo = changeTo;

    var changedRanges = target.changeText();

    app.findTextPreferences = NothingEnum.nothing;
    app.changeTextPreferences = NothingEnum.nothing;

    return changedRanges.length;
}

// =========================================
// ダイアログと実行 / Dialog and run
// =========================================

/**
 * 変換設定ダイアログを表示し、選択内容に従って変換を実行する
 * @returns {void}
 */
function showDialog() {
    var activeDoc = app.documents.item(0);

    /* ドキュメントのスタイル名一覧 / Style names in the document */
    var paragraphStyleNames = [];
    var allParagraphStyles = activeDoc.allParagraphStyles;
    for (var i = 0; i < allParagraphStyles.length; i++) {
        paragraphStyleNames.push(allParagraphStyles[i].name);
    }
    var characterStyleNames = [];
    var allCharacterStyles = activeDoc.allCharacterStyles;
    for (var j = 0; j < allCharacterStyles.length; j++) {
        characterStyleNames.push(allCharacterStyles[j].name);
    }

    var markdownDialog = new Window("dialog", getLabel("dialog.title"));
    setupWindow(markdownDialog);

    /* スコープ・形式（中央寄せ、内部は左揃え）/ Scope and format (centered block, left-aligned inside) */
    var scopeAndFormatColumn = markdownDialog.add("group");
    scopeAndFormatColumn.orientation = "column";
    scopeAndFormatColumn.alignment = ["center", "top"];
    scopeAndFormatColumn.alignChildren = ["left", "top"];
    scopeAndFormatColumn.spacing = 6;

    var scopeRow = scopeAndFormatColumn.add("group");
    setupRow(scopeRow, "left", 6);
    scopeRow.add("statictext", [0, 0, SCOPE_LABEL_WIDTH, 20], labelText("scope.label"));
    var scopeDocumentRadio  = scopeRow.add("radiobutton", undefined, getLabel("scope.document"));
    var scopeStoryRadio     = scopeRow.add("radiobutton", undefined, getLabel("scope.story"));
    var scopeSelectionRadio = scopeRow.add("radiobutton", undefined, getLabel("scope.selection"));
    scopeStoryRadio.value = true;

    var formatRow = scopeAndFormatColumn.add("group");
    setupRow(formatRow, "left", 6);
    formatRow.add("statictext", [0, 0, SCOPE_LABEL_WIDTH, 20], labelText("format.label"));
    var formatHtmlRadio   = formatRow.add("radiobutton", undefined, getLabel("format.html"));
    var formatMsWordRadio = formatRow.add("radiobutton", undefined, getLabel("format.msword"));
    formatHtmlRadio.value = true;

    /* 2カラム / Two columns */
    var columnsRow = markdownDialog.add("group");
    setupRow(columnsRow, "fill", COLUMN_SPACING);
    columnsRow.alignChildren = ["fill", "top"];

    var leftColumn = columnsRow.add("group");
    leftColumn.orientation = "column";
    leftColumn.alignChildren = ["fill", "top"];
    leftColumn.spacing = PANEL_SPACING;

    var rightColumn = columnsRow.add("group");
    rightColumn.orientation = "column";
    rightColumn.alignChildren = ["fill", "top"];
    rightColumn.spacing = PANEL_SPACING;

    // ---- 左列 / Left column ----

    var headingPanel = leftColumn.add("panel", undefined, getLabel("panel.headings"));
    setupPanel(headingPanel, 4);

    var paragraphRow = addStyleRow(headingPanel, getLabel("row.paragraph"), paragraphStyleNames, "p", "paragraph");

    var headingDefinitions = [
        { label: getLabel("row.heading1"), markdown: "#",      styleName: "h1", presetKey: "h1" },
        { label: getLabel("row.heading2"), markdown: "##",     styleName: "h2", presetKey: "h2" },
        { label: getLabel("row.heading3"), markdown: "###",    styleName: "h3", presetKey: "h3" },
        { label: getLabel("row.heading4"), markdown: "####",   styleName: "h4", presetKey: "h4" },
        { label: getLabel("row.heading5"), markdown: "#####",  styleName: "h5", presetKey: "h5" },
        { label: getLabel("row.heading6"), markdown: "######", styleName: "h6", presetKey: "h6" }
    ];

    var headingRows = [];
    for (var k = 0; k < headingDefinitions.length; k++) {
        headingRows.push(addStyleRow(headingPanel, headingDefinitions[k].label, paragraphStyleNames,
            headingDefinitions[k].styleName, headingDefinitions[k].presetKey));
    }

    var listPanel = leftColumn.add("panel", undefined, getLabel("panel.list"));
    setupPanel(listPanel, 4);
    var bulletRow    = addStyleRow(listPanel, getLabel("row.bullet"), paragraphStyleNames, "ul-li", "bullet");
    var bulletSubRow = addStyleRow(listPanel, getLabel("row.bulletSub"), paragraphStyleNames, "ul-ul-li", "bulletSub");
    var numberedRow  = addStyleRow(listPanel, getLabel("row.numbered"), paragraphStyleNames, "ol-li", "numbered");

    var optionPanel = leftColumn.add("panel", undefined, getLabel("panel.options"));
    setupPanel(optionPanel, 4);
    var blockquoteRow = addStyleRow(optionPanel, getLabel("row.blockquote"), paragraphStyleNames, "p.blockquote", "blockquote");
    var captionRow    = addStyleRow(optionPanel, getLabel("row.caption"), paragraphStyleNames, "p.caption", "caption");

    var codePanel = leftColumn.add("panel", undefined, getLabel("panel.code"));
    setupPanel(codePanel, 4);
    var codeBlockRow  = addStyleRow(codePanel, getLabel("row.codeBlock"), paragraphStyleNames, "p.code", "codeBlock");
    var codeInlineRow = addStyleRow(codePanel, getLabel("row.codeInline"), characterStyleNames, "code", "codeInline");

    // ---- 右列 / Right column ----

    var imagePanel = rightColumn.add("panel", undefined, getLabel("panel.image"));
    setupPanel(imagePanel, 4);
    var imageRow = addStyleRow(imagePanel, getLabel("row.image"), paragraphStyleNames, "p.img", "image");

    var tablePanel = rightColumn.add("panel", undefined, getLabel("panel.table"));
    setupPanel(tablePanel, 4);
    var cellRow       = addStyleRow(tablePanel, getLabel("row.cell"), paragraphStyleNames, "td", "cell");
    var headerCellRow = addStyleRow(tablePanel, getLabel("row.headerCell"), paragraphStyleNames, "th", "headerCell");

    var charStylePanel = rightColumn.add("panel", undefined, getLabel("panel.charStyle"));
    setupPanel(charStylePanel, 4);

    var charStyleDefinitions = [
        { label: getLabel("row.bold"),     find: "\\*\\*([^*\\r\\n]+)\\*\\*", styleName: "strong-bold",  presetKey: "bold" },
        { label: getLabel("row.emphasis"), find: "\\*([^*\\r\\n]+)\\*",       styleName: "em-i-marker",  presetKey: "emphasis" },
        { label: getLabel("row.link"),     find: "\\[([^\\]\\r\\n]+)\\]\\(([^)\\r\\n]+)\\)", styleName: "link", changeTo: "$1 <$2>", presetKey: "link" }
    ];

    var charStyleRows = [];
    for (var n = 0; n < charStyleDefinitions.length; n++) {
        charStyleRows.push(addStyleRow(charStylePanel, charStyleDefinitions[n].label, characterStyleNames,
            charStyleDefinitions[n].styleName, charStyleDefinitions[n].presetKey));
    }

    var spacePanel = rightColumn.add("panel", undefined, getLabel("panel.space"));
    setupPanel(spacePanel, 4);
    spacePanel.alignChildren = ["left", "top"];
    var trimLeadingSpaceCheckbox = spacePanel.add("checkbox", undefined, getLabel("checkbox.trimLeadingSpace"));
    trimLeadingSpaceCheckbox.value = true;
    var trimTrailingSpaceCheckbox = spacePanel.add("checkbox", undefined, getLabel("checkbox.trimTrailingSpace"));
    trimTrailingSpaceCheckbox.value = true;
    var convertNbspCheckbox = spacePanel.add("checkbox", undefined, getLabel("checkbox.convertNbsp"));
    convertNbspCheckbox.value = true;

    var cleanupPanel = rightColumn.add("panel", undefined, getLabel("panel.cleanup"));
    setupPanel(cleanupPanel, 4);
    cleanupPanel.alignChildren = ["left", "top"];
    var removeBlankLinesCheckbox = cleanupPanel.add("checkbox", undefined, getLabel("checkbox.removeBlankLines"));
    removeBlankLinesCheckbox.value = true;
    var removeCommentsCheckbox = cleanupPanel.add("checkbox", undefined, getLabel("checkbox.removeComments"));
    removeCommentsCheckbox.value = true;
    var removeRulesCheckbox = cleanupPanel.add("checkbox", undefined, getLabel("checkbox.removeRules"));
    removeRulesCheckbox.value = true;
    var removeGetaCheckbox = cleanupPanel.add("checkbox", undefined, getLabel("checkbox.removeGeta"));
    removeGetaCheckbox.value = false;

    /* ソース形式プリセットの切り替え / Source-format preset switching */
    var styleDropdownByPresetKey = {
        paragraph: paragraphRow.dropdown,
        h1: headingRows[0].dropdown, h2: headingRows[1].dropdown, h3: headingRows[2].dropdown,
        h4: headingRows[3].dropdown, h5: headingRows[4].dropdown, h6: headingRows[5].dropdown,
        bullet: bulletRow.dropdown, bulletSub: bulletSubRow.dropdown, numbered: numberedRow.dropdown,
        blockquote: blockquoteRow.dropdown, caption: captionRow.dropdown,
        codeBlock: codeBlockRow.dropdown, codeInline: codeInlineRow.dropdown,
        image: imageRow.dropdown, cell: cellRow.dropdown, headerCell: headerCellRow.dropdown,
        bold: charStyleRows[0].dropdown, emphasis: charStyleRows[1].dropdown, link: charStyleRows[2].dropdown
    };

    /**
     * 指定したプリセットのスタイル名を各ドロップダウンへ反映する
     * @param {string} presetName STYLE_PRESETS のキー名
     * @returns {void}
     */
    function applyPreset(presetName) {
        var preset = STYLE_PRESETS[presetName];
        if (!preset) return;
        for (var presetKey in preset) {
            if (preset.hasOwnProperty(presetKey) && styleDropdownByPresetKey[presetKey]) {
                selectDropdownByName(styleDropdownByPresetKey[presetKey], preset[presetKey]);
            }
        }
    }

    formatHtmlRadio.onClick   = function () { applyPreset("html"); };
    formatMsWordRadio.onClick = function () { applyPreset("msword"); };

    /* ボタン行 / Button row */
    var buttonRow = addButtonRow(markdownDialog);
    var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
    var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.run"), { name: "ok" });
    alignRightOnlyButtonRow(buttonRow);

    addVersionFooter(markdownDialog);
    if (markdownDialog.show() !== 1) return;

    // ---------------------------------------
    // 検索対象の決定 / Resolve the target
    // ---------------------------------------
    var target;
    if (scopeSelectionRadio.value) {
        if (app.selection.length === 0) {
            alert(getLabel("alert.noSelection"));
            return;
        }
        target = app.selection[0];
        if (!canUseAsTextTarget(target)) {
            alert(getLabel("alert.invalidSelection"));
            return;
        }
    } else if (scopeStoryRadio.value) {
        if (app.selection.length === 0) {
            alert(getLabel("alert.noSelection"));
            return;
        }
        target = resolveStoryTargetFromSelection(app.selection[0]);
        if (target == null) {
            alert(getLabel("alert.invalidSelection"));
            return;
        }
    } else {
        target = app.documents.item(0);
    }

    // ---------------------------------------
    // 変換リストの作成 / Build the operation list
    // ---------------------------------------
    var operations = [];
    var paragraphStyleName = paragraphRow.checkbox.value ? getSelectedStyleName(paragraphRow.dropdown) : null;

    /* 0. 全体に段落スタイル p、文字スタイルなしを適用 / Reset everything to the base paragraph style with no character style */
    operations.push({ find: ".+", changeTo: "$0", style: "p", charStyle: "[None]" });

    /* 0b. 画像挿入用のグラフィックフレームをクリップボードへ / Copy a graphic frame to the clipboard for image insertion */
    if (imageRow.checkbox.value) {
        operations.push({ type: "createFrame" });
    }

    /* 1. フェンスドコードブロックを先に処理して中身を保護 / Handle fenced code blocks first to protect their contents */
    if (codeBlockRow.checkbox.value) {
        operations.push({
            find: "^```[^\\r]*\\r([\\s\\S]+?)\\r```",
            changeTo: "$1",
            style: getSelectedStyleName(codeBlockRow.dropdown)
        });
    }

    /* 1b. 空行とスペース＋改行の前処理 / Pre-pass for blank lines and space-before-return */
    if (removeBlankLinesCheckbox.value) {
        operations.push({ find: "\\r\\r+", changeTo: "\\r", style: null });
        operations.push({ find: " \\r", changeTo: "\\r", style: null });
    }

    /* 2. 番号リスト（見出しより先に処理して「### 1.」の誤マッチを防ぐ）/ Numbered lists before headings, to avoid matching "### 1." */
    if (numberedRow.checkbox.value) {
        operations.push({ find: "^\\d+\\.\\s(.+)", changeTo: "$1", style: getSelectedStyleName(numberedRow.dropdown) });
    }

    /* 3. 見出し（###### → # の順）/ Headings, from the deepest level up */
    for (var h = headingDefinitions.length - 1; h >= 0; h--) {
        if (headingRows[h].checkbox.value) {
            operations.push({
                find: "^" + headingDefinitions[h].markdown + " (.+)",
                changeTo: "$1",
                style: getSelectedStyleName(headingRows[h].dropdown)
            });
        }
    }

    /* 4. 箇条書き（リンク付き）/ Bullet items that contain a link */
    if (bulletRow.checkbox.value) {
        operations.push({
            find: "- \\[([^\\]\\r\\n]+)\\]\\(([^)\\r\\n]+)\\)",
            changeTo: "$1\r$2",
            style: getSelectedStyleName(bulletRow.dropdown)
        });
    }

    /* 5. 画像 / Images */
    if (imageRow.checkbox.value) {
        var imageStyleName = getSelectedStyleName(imageRow.dropdown);
        operations.push({ find: "^\\s*<img [^>]*src=\"(.+?)\".+>", changeTo: "~C\\r$1", style: imageStyleName });
        operations.push({ find: "^!\\[\\]\\((.+)\\)", changeTo: "~C\\r$1", style: imageStyleName });
    }

    /* 6. 箇条書き / Bullet items */
    if (bulletRow.checkbox.value) {
        var bulletStyleName = getSelectedStyleName(bulletRow.dropdown);
        operations.push({ find: "^- (.+)", changeTo: "$1", style: bulletStyleName });
        operations.push({ find: "^\\* (.+)", changeTo: "$1", style: bulletStyleName });
        operations.push({ find: "^\\+ (.+)", changeTo: "$1", style: bulletStyleName });
        operations.push({ find: "^・(.+)", changeTo: "$1", style: bulletStyleName });
    }
    if (bulletSubRow.checkbox.value) {
        operations.push({ find: "^\\t- (.+)", changeTo: "$1", style: getSelectedStyleName(bulletSubRow.dropdown) });
    }

    /* 7. 引用 / Blockquotes */
    if (blockquoteRow.checkbox.value) {
        operations.push({ find: "^>\\s?(.+)", changeTo: "$1", style: getSelectedStyleName(blockquoteRow.dropdown) });
    }

    /* 8. 行頭スペース削除 / Remove leading spaces */
    if (trimLeadingSpaceCheckbox.value) {
        operations.push({ find: "^[\\s|　]", changeTo: "", style: null });
        operations.push({ find: "\\s*\\t", changeTo: "\\t", style: null });
    }

    /* 9. 文字スタイル（太字 → 強調 → リンクの順）/ Character styles: bold, then emphasis, then link */
    for (var c = 0; c < charStyleDefinitions.length; c++) {
        if (charStyleRows[c].checkbox.value) {
            operations.push({
                find: charStyleDefinitions[c].find,
                changeTo: charStyleDefinitions[c].changeTo || "$1",
                charStyle: getSelectedStyleName(charStyleRows[c].dropdown),
                style: null
            });
        }
    }

    /* 9b. 〓 で囲まれたリンク / Links wrapped in 〓 markers */
    if (charStyleRows.length > 2 && charStyleRows[2].checkbox.value) {
        var linkStyleName = getSelectedStyleName(charStyleRows[2].dropdown);
        if (linkStyleName) {
            operations.push({ find: "〓(.+?)〓", changeTo: "<$1>", charStyle: linkStyleName, style: null });
        }
    }

    /* 10. コードブロック / Code blocks */
    if (codeBlockRow.checkbox.value) {
        var codeBlockStyleName = getSelectedStyleName(codeBlockRow.dropdown);
        operations.push({ find: "^<pre><code>(.+)<\\/code><\\/pre>", changeTo: "$1", style: codeBlockStyleName });
        operations.push({ find: "^<pre>(.+)<\\/pre>", changeTo: "$1", style: codeBlockStyleName });
        operations.push({ find: "^<pre>\\r(.+)\\r<\\/pre>", changeTo: "$1", style: codeBlockStyleName });
        operations.push({ find: "^<pre>\\r", changeTo: "<pre>", style: codeBlockStyleName });
        operations.push({ find: "\\r<\\/pre>(.+)", changeTo: "</pre>", style: codeBlockStyleName });
        operations.push({ find: "^<code>(.+)<\\/code>", changeTo: "$1", style: codeBlockStyleName });
    }

    /* 11. インラインコード / Inline code */
    if (codeInlineRow.checkbox.value) {
        operations.push({
            find: "`([^`\\r\\n]+)`",
            changeTo: "$1",
            charStyle: getSelectedStyleName(codeInlineRow.dropdown),
            style: null
        });
    }

    /* 12. キャプション / Captions */
    if (captionRow.checkbox.value) {
        var captionStyleName = getSelectedStyleName(captionRow.dropdown);
        operations.push({ find: "^[\\[［]?キャプション[\\]］：:]?(.+)", changeTo: "$1", style: captionStyleName });
        operations.push({ find: "^<!-- キャプション -->(.+)<!-- \\/キャプション -->", changeTo: "$1", style: captionStyleName });
        operations.push({ find: "^▲(.+)", changeTo: "$1", style: captionStyleName });
        operations.push({ find: "^caption[：:]\\s?(.+)", changeTo: "$1", style: captionStyleName });
    }

    /* 13. 表組み / Tables */
    var headerCellStyleName = headerCellRow.checkbox.value ? getSelectedStyleName(headerCellRow.dropdown) : null;
    var cellStyleName       = cellRow.checkbox.value ? getSelectedStyleName(cellRow.dropdown) : null;

    /* 13a. 区切り行の直前をヘッダー行として扱う / Treat the line above the separator as the header row */
    if (headerCellRow.checkbox.value) {
        operations.push({ find: "^(.*\\|.*)$\\r?\\n^[-:| ]+$", changeTo: "$1", style: headerCellStyleName });
    }
    /* 13b. 区切り行を削除 / Remove the separator row */
    if (cellRow.checkbox.value || headerCellRow.checkbox.value) {
        operations.push({ find: "^\\|?(\\s*:?-{3,}:?\\s*\\|)+\\s*:?-{3,}:?\\s*\\|?\\r?", changeTo: "", style: null });
    }
    /* 13c. 本文セル行の整形 / Clean up body cell rows */
    if (cellRow.checkbox.value) {
        operations.push({ find: "^\\|\\s*", changeTo: "", style: cellStyleName });
        operations.push({ find: "\\s*\\|\\s*$", changeTo: "", style: cellStyleName });
        operations.push({ find: "\\s*\\|\\s*", changeTo: "\\t", style: cellStyleName });
    }
    /* 13d. ヘッダーセル行の整形（findStyle でヘッダー行のみ対象）/ Clean up header rows, narrowed by findStyle */
    if (headerCellRow.checkbox.value) {
        operations.push({ find: "^\\|\\s*", changeTo: "", style: null, findStyle: headerCellStyleName });
        operations.push({ find: "\\s*\\|\\s*$", changeTo: "", style: null, findStyle: headerCellStyleName });
        operations.push({ find: "\\s*\\|\\s*", changeTo: "\\t", style: null, findStyle: headerCellStyleName });
    }

    /* 14. クリーンアップ（コメント、水平線）/ Cleanup: comments and horizontal rules */
    if (removeCommentsCheckbox.value) {
        operations.push({ find: "<!-- (.+) -->", changeTo: "\\r", style: paragraphStyleName });
    }
    if (removeRulesCheckbox.value) {
        operations.push({ find: "^-+", changeTo: "\\r", style: paragraphStyleName });
    }

    /* 15. 空行削除（後処理）/ Remove blank lines (post-pass) */
    if (removeBlankLinesCheckbox.value) {
        operations.push({ find: "\\r\\r+", changeTo: "\\r", style: null });
    }

    /* 16. スペース / Spaces */
    if (convertNbspCheckbox.value) {
        operations.push({ find: "&nbsp;", changeTo: " ", style: null, type: "text" });
    }
    if (trimTrailingSpaceCheckbox.value) {
        operations.push({ find: "\\s+$", changeTo: " ", style: null });
    }

    /* 17. 〓 の削除 / Remove 〓 markers */
    if (removeGetaCheckbox.value) {
        operations.push({ find: "〓", changeTo: "", style: null });
    }

    /* 18. 行頭以外の画像タグも拾う / Catch image tags that are not at the start of a line */
    if (imageRow.checkbox.value) {
        operations.push({
            find: "<img [^>]*src=\"(.+?)\".+>",
            changeTo: "~C\\r$1",
            style: getSelectedStyleName(imageRow.dropdown)
        });
    }

    if (operations.length === 0) {
        alert(getLabel("alert.noTarget"));
        return;
    }

    // ---------------------------------------
    // 実行 / Run
    // ---------------------------------------
    var progressWindow = new Window("palette", getLabel("progress.title"));
    progressWindow.add("statictext", undefined, getLabel("progress.label"));
    var progressBar = progressWindow.add("progressbar", [0, 0, PROGRESS_BAR_WIDTH, 20], 0, operations.length);
    var progressCountLabel = progressWindow.add("statictext", [0, 0, PROGRESS_BAR_WIDTH, 20], "");
    progressWindow.show();

    var totalChangeCount = 0;

    /* 一括で取り消せるように doScript でまとめて実行 / Run through doScript so the whole run is a single undo step */
    app.doScript(function () {
        for (var i = 0; i < operations.length; i++) {
            var operation = operations[i];
            progressBar.value = i + 1;
            progressCountLabel.text = (i + 1) + " / " + operations.length;
            progressWindow.update();

            if (operation.type === "createFrame") {
                /* 画像挿入用のグラフィックフレームを作ってクリップボードへコピー / Build a graphic frame and copy it for image insertion */
                var currentPage = activeDoc.layoutWindows[0].activePage;
                var pageMargins = currentPage.marginPreferences;
                var pageBounds  = currentPage.bounds;
                var marginWidth = (pageBounds[3] - pageBounds[1]) - pageMargins.left - pageMargins.right;

                var temporaryFrame = currentPage.rectangles.add({
                    geometricBounds: [
                        pageMargins.top,
                        pageMargins.left,
                        pageMargins.top + TEMP_IMAGE_FRAME_HEIGHT,
                        pageMargins.left + marginWidth
                    ],
                    contentType: ContentType.GRAPHIC_TYPE
                });
                temporaryFrame.fillColor   = activeDoc.swatches.itemByName("None");
                temporaryFrame.strokeColor = activeDoc.swatches.itemByName("None");
                app.select(temporaryFrame);
                app.copy();
                temporaryFrame.remove();
                continue;
            }

            var changeCount = (operation.type === "text")
                ? findChangeText(target, operation.find, operation.changeTo)
                : findChangeGrep(target, operation.find, operation.changeTo,
                    operation.style, operation.charStyle, operation.findStyle);

            totalChangeCount += changeCount;
        }
    }, ScriptLanguage.javascript, undefined, UndoModes.ENTIRE_SCRIPT, getLabel("undo.convertMarkdown"));

    progressWindow.close();

    if (totalChangeCount === 0) {
        alert(getLabel("alert.noMatch"));
    }
}

// =========================================
// メイン処理 / Main
// =========================================

/**
 * ドキュメントの有無を確認してダイアログを表示する
 * @returns {void}
 */
function main() {
    app.scriptPreferences.userInteractionLevel = UserInteractionLevels.interactWithAll;
    if (app.documents.length === 0) {
        alert(getLabel("alert.noDocument"));
        return;
    }
    showDialog();
}

main();

})();
