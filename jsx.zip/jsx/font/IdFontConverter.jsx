#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdFontConverter
Name=フォントの種別・ウエイトをまとめて切り替え
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.1.8
Release-Date=2026-06-17
Description-BEGIN
フォントの種別（文字セット・P・UD・N・NT・ウエイト）をまとめて切り替え、選択範囲やドキュメント全体へ適用します。

Switches font variants (character set, P, UD, N, NT and weight) in one pass and applies them to the selection or to the whole document.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

フォントの種別（文字セット・P・UD・N・NT・ウエイト）をまとめて切り替え、選択範囲やドキュメント全体へ適用します。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdFontConverter.md

note記事も参照してください。
https://note.com/dtp_tranist/n/n261c771b4b41

### Overview

Switches font variants (character set, P, UD, N, NT and weight) in one pass and applies them to the selection or to the whole document.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdFontConverter.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdFontConverter";              /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.1.8";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-06-17";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "フォントの種別・ウエイトをまとめて切り替え"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdFontConverter.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdFontConverter.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/n261c771b4b41"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/font/IdFontConverter.jsx"; /* 最新版のソース / latest source */

// Original idea
// https://sttk3.com/blog/tips/illustrator/unify-character-set.html

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php
// ==============================
// UIレイアウトの共通設定 / Shared UI layout
// ==============================

// UIレイアウト（再利用パーツ） / UI layout (reusable)

/* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

/**
 * ウィンドウの共通設定
 * @param {Window} targetWindow - 対象のウィンドウ
 * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
 * @returns {void}
 */
function setupWindow(targetWindow, spacing) {
    targetWindow.orientation = "column";
    targetWindow.alignChildren = "fill";
    targetWindow.margins = WINDOW_MARGINS;
    targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
}

/**
 * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
 * @param {Panel} targetPanel - 対象のパネル
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupPanel(targetPanel, spacing) {
    targetPanel.orientation = "column";
    targetPanel.alignChildren = ["fill", "top"];
    targetPanel.alignment = "fill";
    targetPanel.margins = PANEL_MARGINS;
    targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * タブの共通設定
 * @param {Tab} targetTab - 対象のタブ
 * @param {number} [spacing] - 要素間隔（省略時は変えない）
 * @returns {void}
 */
function setupTab(targetTab, spacing) {
    targetTab.orientation = "column";
    targetTab.alignChildren = "fill";
    targetTab.margins = TAB_MARGINS;
    if (typeof spacing === "number") targetTab.spacing = spacing;
}

/**
 * 横並びの行グループの共通設定（ボタン列など）。
 * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
 * @param {Group} rowGroup - 対象のグループ
 * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
 * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
 * @returns {void}
 */
function setupRow(rowGroup, rowAlignment, spacing) {
    rowGroup.orientation = "row";
    rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
    rowGroup.alignChildren = ["left", "center"];
    rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

/**
 * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
 * @param {Button} targetButton - 対象のボタン
 * @param {number} trimPixels - 詰める量（px）
 * @returns {void}
 */
function trimButtonHeight(targetButton, trimPixels) {
    /* レイアウト前は size が無い / size is not set until the layout runs */
    if (!targetButton.size) return;
    targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
}

// UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

// =========================================
// ユーザー設定 / User settings
// =========================================

/* 実行前に変更内容を確認するか（UI 非表示）/ Whether to confirm changes before running (hidden) */
var CONFIRM_BEFORE_RUN = true;

/* CID フォント（文字セット表記なし）を OTF へ変換するか / Whether to convert CID fonts to OTF */
var CONVERT_CID_TO_OTF = true;

/* G-OTF 学参書体を A-OTF の通常書体に統合してから変換するか（UI 非表示）/ Merge G-OTF Gakusan fonts into A-OTF before converting (hidden) */
var INTEGRATE_GAKUSAN_TO_STANDARD = true;

/* G-OTF 学参書体の PostScript 名プレフィックス（GJ=常改 / G=学参 / K=K書体）。長い順に試す / Gakusan PostScript prefixes, tried longest first */
var GAKUSAN_PREFIXES = ["GJ", "G", "K"];

/* 特殊シリーズ（太さが等価なメンバーを完全名で結ぶ）/ Special series: members of equal thickness linked by full PostScript name
   A1明朝は Std が Bold 1 ウェイトのみで、A P-OTF StdN の Regular と同じ太さ。これを同一シリーズとして対応付ける。
   members のキーは文字セット（+N）。汎用ロジックではなくこの表だけで変換する。 */
var SPECIAL_SERIES = [
    {
        label: "A1明朝",
        members: {
            "Std": "A1MinchoStd-Bold",
            "StdN": "PA1MinchoStdN-Regular"
        }
    }
];

/* CID 変換時、文字セットが「現状維持」のときに補完する文字セット / Charset filled in when converting CID with "keep" */
var CID_FALLBACK_CHARSET = "Pr6";

/* 文字セットを収録文字数の多い順に並べたランキング / Charsets ranked by glyph count, richest first
   Max  は N なしの種類から、MaxN は N あり込みから、最初に選べる文字セットを採用する */
var CHARSET_RANK_NO_N = ["Pr6", "Pr5", "Pro", "Std", "Min2", "Min"];
var CHARSET_RANK_WITH_N = ["Pr6N", "Pr6", "Pr5N", "Pr5", "ProN", "Pro", "StdN", "Std", "Min2", "Min"];

/* 近いウエイトを探す並び順（軽い → 重い）/ Weight order for nearest-weight search (light to heavy) */
var WEIGHT_ORDER = [
    "Light", "Regular", "Medium",
    "DemiBold", "Demi", "DeBold",
    "Bold", "ExtraBold", "ExBold",
    "Heavy", "ExtraHeavy", "ExHeavy", "Ultra"
];

/* 変換対象のフォントファミリー定義（フォントデータベースから生成）/ Target font families (generated from the font database)
   regex の最後のグループをウエイト、それ以外を値（P / UD / Pro|Pr5|Pr6 / N）で自動判別する */
var FONT_FAMILIES = [
    { label: "見出ミンMA31", baseName: "MidashiMinMA31", regex: /^(P)?MidashiMinMA31(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "見出ゴMB31", baseName: "MidashiGoMB31", regex: /^(P)?MidashiGoMB31(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "太ミンA101", baseName: "FutoMinA101", regex: /^(P)?FutoMinA101(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "ゴシックMB101", baseName: "GothicMB101", regex: /^(P)?GothicMB101(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD新ゴ コンデンス90", baseName: "ShinGoCOniz", regex: /^(P)?(UD)?ShinGoCOniz(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD新ゴ コンデンス80", baseName: "ShinGoCOeiz", regex: /^(P)?(UD)?ShinGoCOeiz(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD新ゴ コンデンス70", baseName: "ShinGoCOsez", regex: /^(P)?(UD)?ShinGoCOsez(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD新ゴ コンデンス60", baseName: "ShinGoCOsiz", regex: /^(P)?(UD)?ShinGoCOsiz(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD新ゴ コンデンス50", baseName: "ShinGoCOfiz", regex: /^(P)?(UD)?ShinGoCOfiz(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "見出ミン", baseName: "MidashiMin", regex: /^MidashiMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "太ゴB101", baseName: "FutoGoB101", regex: /^(P)?FutoGoB101(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "新正楷書CBSK1", baseName: "ShinseiKai", regex: /^ShinseiKai(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "凸版文久明朝", baseName: "BunkyuMin", regex: /^(P)?BunkyuMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "中ゴシックBBB", baseName: "GothicBBB", regex: /^(P)?GothicBBB(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "見出ゴ", baseName: "MidashiGo", regex: /^MidashiGo(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "正楷書CB1", baseName: "SeiKaiCB1", regex: /^(P)?SeiKaiCB1(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "黎ミンY10", baseName: "ReimYonz", regex: /^(P)?ReimYonz(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "黎ミンY20", baseName: "ReimYtwz", regex: /^(P)?ReimYtwz(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "黎ミンY30", baseName: "ReimYthz", regex: /^(P)?ReimYthz(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "黎ミンY40", baseName: "ReimYfoz", regex: /^(P)?ReimYfoz(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "秀英明朝", baseName: "ShueiMin", regex: /^(P)?ShueiMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "凸版文久ゴシック", baseName: "BunkyuGo", regex: /^(P)?BunkyuGo(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "新丸ゴ", baseName: "ShinMGo", regex: /^(P)?(UD)?ShinMGo(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "リュウミン", baseName: "Ryumin", regex: /^(P)?Ryumin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "新ゴ / 新ゴNT", baseName: "ShinGo", regex: /^(P)?(UD)?ShinGo(NT)?(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD黎ミン", baseName: "Reimin", regex: /^(P)?(UD)?Reimin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "游明朝体", baseName: "YuMin", regex: /^YuMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "黎ミン", baseName: "Reim", regex: /^(P)?Reim(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "游ゴシック体", baseName: "YuGo", regex: /^YuGo(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },

    // --- フォントワークス書体 ---
    { label: "セザンヌ", baseName: "Cezanne", regex: /^(P)?Cezanne(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "DNP 秀英明朝", baseName: "FOT_DNPShueiMin", regex: /^(P)?FOT_DNPShueiMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "ハミング", baseName: "Humming", regex: /^(P)?Humming(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "マティス", baseName: "Matisse", regex: /^(P)?Matisse(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "モード明朝Aラージ", baseName: "ModeMinALarge", regex: /^(P)?ModeMinALarge(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "モード明朝Bラージ", baseName: "ModeMinBLarge", regex: /^(P)?ModeMinBLarge(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "ニューセザンヌ", baseName: "NewCezanne", regex: /^(P)?NewCezanne(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "ニューグレコ", baseName: "NewGreco", regex: /^(P)?NewGreco(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "ニューロダン", baseName: "NewRodin", regex: /^(P)?NewRodin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "ロダン", baseName: "Rodin", regex: /^(P)?Rodin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "スーラ", baseName: "Seurat", regex: /^(P)?Seurat(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "スキップ", baseName: "Skip", regex: /^(P)?Skip(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "テロップ明朝", baseName: "TelopMin", regex: /^(P)?TelopMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫A見出ミン", baseName: "TsukuAMDMin", regex: /^(P)?TsukuAMDMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Aオールド明朝", baseName: "TsukuAOldMin", regex: /^(P)?TsukuAOldMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Aヴィンテージ明L", baseName: "TsukuAVintageMinL", regex: /^(P)?TsukuAVintageMinL(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Aヴィンテージ明S", baseName: "TsukuAVintageMinS", regex: /^(P)?TsukuAVintageMinS(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫B見出ミン", baseName: "TsukuBMDMin", regex: /^(P)?TsukuBMDMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫B明朝", baseName: "TsukuBMin", regex: /^(P)?TsukuBMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Bオールド明朝", baseName: "TsukuBOldMin", regex: /^(P)?TsukuBOldMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Bヴィンテージ明L", baseName: "TsukuBVintageMinL", regex: /^(P)?TsukuBVintageMinL(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Bヴィンテージ明S", baseName: "TsukuBVintageMinS", regex: /^(P)?TsukuBVintageMinS(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫C見出ミン", baseName: "TsukuCMDMin", regex: /^(P)?TsukuCMDMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Cオールド明朝", baseName: "TsukuCOldMin", regex: /^(P)?TsukuCOldMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Cヴィンテージ明L", baseName: "TsukuCVintageMinL", regex: /^(P)?TsukuCVintageMinL(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫Cヴィンテージ明S", baseName: "TsukuCVintageMinS", regex: /^(P)?TsukuCVintageMinS(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫ゴシック", baseName: "TsukuGo", regex: /^(P)?TsukuGo(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫明朝", baseName: "TsukuMin", regex: /^(P)?TsukuMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "筑紫新聞明朝", baseName: "TsukuNewsMin", regex: /^(P)?TsukuNewsMin(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD角ゴ_ラージ", baseName: "UDKakugo_Large", regex: /^(P)?UDKakugo_Large(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD角ゴ_スモール", baseName: "UDKakugo_Small", regex: /^(P)?UDKakugo_Small(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD丸ゴ_ラージ", baseName: "UDMarugo_Large", regex: /^(P)?UDMarugo_Large(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD丸ゴ_スモール", baseName: "UDMarugo_Small", regex: /^(P)?UDMarugo_Small(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ },
    { label: "UD明朝", baseName: "UDMincho", regex: /^(P)?UDMincho(?:(Pro|Pr5|Pr6|Std)(N)?)?-(.+)$/ }
];

/* AXIS（Type Project）は文字セット体系が Morisawa 系と異なるため専用処理する / AXIS uses a different charset scheme; handled separately
   - 幅（Basic / Cond / Comp）と Joyo は保持する
   - N と Std⇄Pro だけ切り替える（AXIS に無い Pr5 / Pr6 を選んでも現状維持）
   - P / UD / NT は AXIS に無いので無視する
   グループ: 1=幅(Basic|Cond|Comp) / 2=文字セット(Std|Pro|Joyo) / 3=N / 4=ウエイト */
var AXIS_FAMILY = {
    label: "AXIS",
    baseName: "Axis",
    regex: /^Axis(Basic|Cond|Comp)?(Std|Pro|Joyo)?(N)?-(.+)$/
};

// =========================================
// ローカライズ / Localization
// =========================================

// ローカライズ（再利用パーツ） / Localization (reusable)

/**
 * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
 * @returns {string} "ja" または "en"
 */
function getCurrentLang() {
    return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
}

var uiLang = getCurrentLang();

/**
 * LABELS から今の UI 言語の文言を取り出す。
 * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
 * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
 * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
 */
function getLabel(labelRef, placeholderValues) {
    var labelEntry = labelRef;
    if (typeof labelRef === "string") {
        var labelPathKeys = labelRef.split(".");
        labelEntry = LABELS;
        for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
            labelEntry = labelEntry[labelPathKeys[i]];
        }
    }
    var labelString;
    if (typeof labelEntry === "string") labelString = labelEntry;
    else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
    else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
    else return (typeof labelRef === "string") ? labelRef : "";
    return fillLabelPlaceholders(String(labelString), placeholderValues);
}

/**
 * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {Object|Array} [placeholderValues] - getLabel と同じ
 * @returns {string} コロン付きの文言
 */
function labelText(labelRef, placeholderValues) {
    return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
}

/**
 * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
 * @param {string|Object} labelRef - getLabel と同じ
 * @param {string|number} value - コロンのあとに続ける値
 * @returns {string} 項目名と値をつないだ文字列
 */
function labelValueText(labelRef, value) {
    return labelText(labelRef) + " " + value;
}

/**
 * 文言の {name} や %1 に値を差し込む
 * @param {string} labelString - 文言
 * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
 * @returns {string} 差し込んだ文言
 */
function fillLabelPlaceholders(labelString, placeholderValues) {
    if (placeholderValues == null) return labelString;
    if (placeholderValues instanceof Array) {
        /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
        for (var i = placeholderValues.length; i >= 1; i--) {
            labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
        }
        return labelString;
    }
    for (var placeholderKey in placeholderValues) {
        if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
        labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
    }
    return labelString;
}

// ローカライズ（再利用パーツ）ここまで / End of the reusable localization

// ボタン行（再利用パーツ） / Button row (reusable)

var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

/**
 * ダイアログ下部のボタン行を作る。
 * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
 * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
 * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
 * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
 */
function addButtonRow(parent, rowOptions) {
    var isCentered = !!(rowOptions && rowOptions.centered);
    var btnRowGroup = parent.add("group");
    btnRowGroup.orientation = "row";
    btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
    btnRowGroup.spacing = BUTTON_ROW_SPACING;

    if (isCentered) {
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
    }

    btnRowGroup.alignment = ["fill", "bottom"];

    var btnLeftGroup = btnRowGroup.add("group");
    btnLeftGroup.alignChildren = ["left", "center"];
    btnLeftGroup.spacing = BUTTON_ROW_SPACING;

    /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
    var spacer = btnRowGroup.add("group");
    spacer.alignment = ["fill", "fill"];
    spacer.minimumSize.width = 0;

    var btnRightGroup = btnRowGroup.add("group");
    btnRightGroup.alignChildren = ["right", "center"];
    btnRightGroup.spacing = BUTTON_ROW_SPACING;

    return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
}

/**
 * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
 * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
 * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
 * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
 * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
 * @returns {void}
 */
function alignRightOnlyButtonRow(buttonRow) {
    if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
    var dialogWindow = buttonRow.rowGroup.window;
    dialogWindow.addEventListener("show", function () {
        if (!buttonRow.leftGroup) return;
        var btnRowGroup = buttonRow.rowGroup;
        /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
        if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
        /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
        btnRowGroup.remove(buttonRow.leftGroup);
        btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
        btnRowGroup.alignment = ["center", "bottom"];
        btnRowGroup.alignChildren = ["center", "center"];
        buttonRow.leftGroup = null;
        dialogWindow.layout.layout(true);
    });
}

// ボタン行（再利用パーツ）ここまで / End of the reusable button row

// UI の明暗（再利用パーツ） / UI theme (reusable)

/**
 * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
 * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
 */
function isDarkUI() {
    try {
        if (app.preferences && app.preferences.getRealPreference) {
            return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
        }
        return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
    } catch (e) {
        return false;
    }
}

// UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

// バージョン表示（再利用パーツ） / Version footer (reusable)

var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

/* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
   9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
   / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
     nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
var VERSION_FOOTER_GLYPHS = {
    "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
    "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
    "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
    "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
    "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
    "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
    "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
    "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
    "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
    "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
    "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
    "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
    "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
    "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
    "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
    "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
    "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
    "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
    "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
    "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
    "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
    "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
    "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
    "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
    "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
    "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
    "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
    "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
    "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
    "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
    "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
    "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
    "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
    "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
    "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
    "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
    "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
    "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
    "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
    "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
    "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
    "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
    "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
    "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
    "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
    "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
    "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
    "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
    "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
    "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
    "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
    "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
    "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
    ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
    "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
    "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
    "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
    " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
};

/**
 * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
 * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
 * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
 * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
 * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
 */
function addVersionFooter(targetWindow) {
    if (targetWindow.versionFooter) return null;

    /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
    var lastChild = targetWindow.children[targetWindow.children.length - 1];
    if (lastChild && lastChild.type === "group") {
        var rowMargins = lastChild.margins;
        lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
    }
    var windowMargins = targetWindow.margins;
    targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

    var footerGroup = targetWindow.add("group");
    footerGroup.orientation = "row";
    footerGroup.alignment = ["fill", "bottom"];
    footerGroup.alignChildren = ["left", "center"];
    footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

    /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
       左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
       / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
         or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
    var versionText = String(SCRIPT_VERSION);
    var leftCandidates = [versionText];
    if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
    var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
    versionCanvas.alignment = ["fill", "center"];
    bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
    var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
    brandCanvas.alignment = ["right", "center"];
    brandCanvas.maximumSize = brandCanvas.preferredSize;
    targetWindow.versionFooter = footerGroup;
    return versionCanvas;
}

/**
 * 文字列のすべての文字に字形があるかを返す
 * @param {string} dotText - 文字列
 * @returns {boolean} すべてあれば true
 */
function hasVersionFooterGlyphs(dotText) {
    for (var i = 0; i < dotText.length; i++) {
        if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
    }
    return dotText.length > 0;
}

/**
 * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
 * @param {Group} parentGroup - 足す先
 * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
 * @returns {Group} 描くグループ
 */
function addVersionFooterCanvas(parentGroup, dotTexts) {
    var dotCanvas = parentGroup.add("group");
    var shortestText = dotTexts[dotTexts.length - 1];
    dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
    dotCanvas.helpTip = dotTexts[0];
    dotCanvas.onDraw = function () {
        var availableWidth = this.size ? this.size.width : 0;
        var drawText = shortestText;
        for (var i = 0; i < dotTexts.length; i++) {
            if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                drawText = dotTexts[i];
                break;
            }
        }
        drawVersionFooterDots(this.graphics, drawText);
    };
    return dotCanvas;
}

/**
 * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
 * @param {string} versionText - 文字列
 * @returns {number} 幅（ドット）
 */
function measureVersionFooterDots(versionText) {
    var dotCount = 0;
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
        dotCount += glyphRows[0].length;
    }
    return dotCount;
}

/**
 * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
 * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
 * @param {string} versionText - 文字列
 * @returns {void}
 */
function drawVersionFooterDots(canvasGraphics, versionText) {
    var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
    var dotSize = VERSION_FOOTER_PIXEL_SIZE;
    var cursorDots = 0;
    canvasGraphics.newPath();
    for (var i = 0; i < versionText.length; i++) {
        var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
        if (!glyphRows) continue;
        if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
        for (var row = 0; row < glyphRows.length; row++) {
            var rowText = glyphRows[row];
            var runStart = -1;
            for (var col = 0; col <= rowText.length; col++) {
                var isDot = col < rowText.length && rowText.charAt(col) === "#";
                if (isDot && runStart < 0) runStart = col;
                if (!isDot && runStart >= 0) {
                    canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                    runStart = -1;
                }
            }
        }
        cursorDots += glyphRows[0].length;
    }
    canvasGraphics.fillPath(footerBrush);
}

// -----------------------------------------
// このスクリプトについて / About this script
// -----------------------------------------
/* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
   この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
   Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
   and keeps its own labels and layout values so the part works on its own */

var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
/* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
   The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
/* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

var VERSION_INFO_LABELS = {
    dialog: {
        title: { ja: "このスクリプトについて", en: "About This Script" }
    },
    panel: {
        generalInfo: { ja: "基本情報", en: "General" },
        links: { ja: "リンク", en: "Links" }
    },
    fieldLabel: {
        scriptName: { ja: "スクリプト名", en: "Script Name" },
        scriptFeature: { ja: "機能", en: "Feature" },
        scriptVersion: { ja: "バージョン", en: "Version" }
    },
    button: {
        openReadme: { ja: "README", en: "README" },
        openSourceCode: { ja: "ソースコード", en: "Source Code" },
        openArticle: { ja: "記事（note）", en: "Article (note)" },
        revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
        revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
        close: { ja: "閉じる", en: "Close" }
    },
    tooltip: {
        versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
        copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
    },
    alert: {
        copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
    }
};

/**
 * VERSION_INFO_LABELS の文言を今の言語で返す
 * @param {Object} labelEntry - { ja, en }
 * @returns {string} 文言
 */
function getVersionInfoLabel(labelEntry) {
    return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
}

/**
 * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
 * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
 * @returns {string} 値
 */
function getVersionInfoValue(variableKey) {
    var infoValue;
    if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
    else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
    else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
    else if (variableKey === "readme") {
        if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
        else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
    }
    else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
    else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
    return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
}

/**
 * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
 * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
 * @returns {void}
 */
function bindVersionInfoClick(versionCanvas) {
    versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
    /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
       Open on mouseup so the release does not land on the footer after the dialog closes */
    versionCanvas.addEventListener("mouseup", function () {
        showVersionInfoDialog(versionCanvas.window.type === "palette");
    });
}

/**
 * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
 * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
 * @returns {void}
 */
function showVersionInfoDialog(isFromPalette) {
    var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
    infoDialog.orientation = "column";
    infoDialog.alignChildren = "fill";
    infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
    infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

    var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
    /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
    /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
    if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
        addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
    }
    addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
    alignVersionInfoLabels(infoPanel);

    /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
    var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
    var linkButtonRow = linksPanel.add("group");
    linkButtonRow.orientation = "row";
    linkButtonRow.alignment = ["left", "center"];
    linkButtonRow.alignChildren = ["left", "center"];
    linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
    addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

    /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
    var buttonRow = infoDialog.add("group");
    buttonRow.orientation = "row";
    buttonRow.alignment = ["fill", "bottom"];
    buttonRow.alignChildren = ["left", "center"];
    buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
    buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
    var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
    var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
    if (VERSION_INFO_SCRIPT_FILE.exists) {
        revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
        revealButton.onClick = function () {
            revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
            infoDialog.close();
        };
    } else {
        revealButton.enabled = false;
    }
    /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
    var buttonSpacer = buttonRow.add("group");
    buttonSpacer.alignment = ["fill", "fill"];
    buttonSpacer.minimumSize.width = 0;
    var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
    closeButton.alignment = ["right", "center"];
    /* return でも esc でも閉じる / Close with both Return and Esc */
    infoDialog.defaultElement = closeButton;
    infoDialog.cancelElement = closeButton;
    infoDialog.onShow = function () {
        pinVersionInfoCopyButton(infoPanel);
    };
    infoDialog.show();
}

/**
 * 「このスクリプトについて」のダイアログにパネルを足す
 * @param {Window} infoDialog - 足す先のダイアログ
 * @param {Object} titleEntry - パネル名の文言 { ja, en }
 * @returns {Panel} パネル
 */
function addVersionInfoPanel(infoDialog, titleEntry) {
    var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
    infoPanel.orientation = "column";
    infoPanel.alignChildren = ["fill", "top"];
    infoPanel.alignment = "fill";
    infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
    infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
    return infoPanel;
}

/**
 * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
 * @param {Panel} infoPanel - 足す先のパネル
 * @param {Object} labelEntry - 項目名の文言 { ja, en }
 * @param {string} valueText - 表示する値
 * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
 * @returns {StaticText} 値の statictext
 */
function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
    var infoRow = infoPanel.add("group");
    infoRow.orientation = "row";
    infoRow.alignment = ["fill", "center"];
    infoRow.alignChildren = ["left", "center"];
    infoRow.spacing = VERSION_INFO_ROW_SPACING;
    /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
    var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
    rowLabel.justify = "right";
    var valueLabel = infoRow.add("statictext", undefined, valueText);
    if (copyFromPalette === null) return valueLabel;
    /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
       A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
    var copySpacer = infoRow.add("group");
    copySpacer.alignment = ["fill", "fill"];
    copySpacer.minimumSize.width = 0;
    infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
    return valueLabel;
}

/**
 * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
 * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
 * @param {Panel} infoPanel - ［基本情報］パネル
 * @returns {void}
 */
function pinVersionInfoCopyButton(infoPanel) {
    var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
    for (var i = 0; i < infoPanel.children.length; i++) {
        var infoRow = infoPanel.children[i];
        if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
        infoRow.size = [innerWidth, infoRow.size.height];
        infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
    }
}

/**
 * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
 * @param {Panel} infoPanel - 対象のパネル
 * @returns {void}
 */
function alignVersionInfoLabels(infoPanel) {
    var rowLabels = [];
    var labelWidth = 0;
    for (var i = 0; i < infoPanel.children.length; i++) {
        var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
        rowLabels.push(rowLabel);
        labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
    }
    for (var j = 0; j < rowLabels.length; j++) {
        rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
    }
}

/**
 * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
 * @param {Window} infoDialog - ボタンを置くダイアログ
 * @param {Group} buttonGroup - 足す先のグループ
 * @param {Object} labelEntry - ボタンの文言 { ja, en }
 * @param {string} targetUrl - 開く URL（空ならディム表示）
 * @returns {void}
 */
function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
    var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
    if (!targetUrl) {
        linkButton.enabled = false;
        return;
    }
    linkButton.helpTip = targetUrl;
    linkButton.onClick = function () {
        openVersionInfoUrl(targetUrl);
        infoDialog.close();
    };
}

/**
 * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
 * @param {Group} infoRow - 足す先の行
 * @param {StaticText} valueLabel - コピーする値の statictext
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {Group} ボタンとして使う group
 */
function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
    var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
    var copyButton = infoRow.add("group");
    copyButton.preferredSize = [buttonSize, buttonSize];
    copyButton.minimumSize = [buttonSize, buttonSize];
    copyButton.maximumSize = [buttonSize, buttonSize];
    copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
    copyButton.isPressed = false;
    copyButton.isCopied = false;

    copyButton.onDraw = function () {
        var buttonGraphics = copyButton.graphics;
        var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
        buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
        buttonGraphics.newPath();
        buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
        buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
        if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
        else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
    };

    /**
     * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
     * @param {boolean} isPressed - 押下中なら true
     * @param {boolean} isCopied - コピー済みなら true
     * @returns {void}
     */
    function repaint(isPressed, isCopied) {
        if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
        copyButton.isPressed = isPressed;
        copyButton.isCopied = isCopied;
        copyButton.hide();
        copyButton.show();
    }
    copyButton.addEventListener("mousedown", function () { repaint(true, false); });
    copyButton.addEventListener("mouseup", function () {
        if (!copyButton.isPressed) return;
        var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
        repaint(false, hasCopied);
        if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
    });
    /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
    copyButton.addEventListener("mouseout", function () { repaint(false, false); });
    return copyButton;
}

/**
 * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
    var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
    var sheetSize = 9;
    var offset = 3;
    var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
    var backLeft = frontLeft - offset;
    var backTop = frontTop - offset;
    /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
    buttonGraphics.newPath();
    buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop + sheetSize);
    buttonGraphics.lineTo(backLeft, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, backTop);
    buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
    buttonGraphics.strokePath(iconPen);
    buttonGraphics.newPath();
    buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
    buttonGraphics.strokePath(iconPen);
}

/**
 * コピーしたあとのチェックマークを描く
 * @param {ScriptUIGraphics} buttonGraphics - 描画先
 * @param {number} buttonSize - ボタンの一辺
 * @returns {void}
 */
function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
    var center = buttonSize / 2;
    buttonGraphics.newPath();
    buttonGraphics.moveTo(center - 4.5, center);
    buttonGraphics.lineTo(center - 1.5, center + 3);
    buttonGraphics.lineTo(center + 4.5, center - 3.5);
    buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
}

/**
 * 文字列をクリップボードにコピーする。
 * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
 * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
 * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
 * @param {string} copyText - コピーする文字列
 * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
 * @returns {boolean} コピーの操作まで進めたら true
 */
function copyVersionInfoText(copyText, isFromPalette) {
    try {
        if (VERSION_INFO_IS_INDESIGN) {
            if (File.fs === "Windows") {
                app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
            } else {
                app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
            }
            return true;
        }
        var copyScript = buildVersionInfoCopyScript(copyText);
        if (!isFromPalette) return eval(copyScript) === true;
        var copyMessage = new BridgeTalk();
        copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
        copyMessage.body = copyScript;
        copyMessage.send();
        return true;
    } catch (e) {
        return false;
    }
}

/**
 * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
 * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
 * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
 * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
 * @param {string} copyText - コピーする文字列
 * @returns {string} 実行すると true / false を返すスクリプト
 */
function buildVersionInfoCopyScript(copyText) {
    return [
        "(function (copyText) {",
        "    var usingTempDoc = (app.documents.length === 0);",
        "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
        "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
        "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
        "    var tempLayer = null;",
        "    var hasCopied = false;",
        "    try {",
        "        tempLayer = targetDoc.layers.add();",
        "        var tempFrame = tempLayer.textFrames.add();",
        "        tempFrame.contents = copyText;",
        "        app.redraw();",
        "        app.executeMenuCommand('deselectall');",
        "        tempFrame.selected = true;",
        "        app.redraw();",
        "        app.executeMenuCommand('copy');",
        "        app.redraw();",
        "        hasCopied = true;",
        "    } catch (e) { }",
        "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
        "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
        "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
        "    targetDoc.selection = null;",
        "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
        "    app.redraw();",
        "    return hasCopied;",
        "})(" + quoteVersionInfoString(copyText) + ");"
    ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
}

/**
 * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
 * @param {string} sourceText - 文字列
 * @returns {string} "…" の形のリテラル
 */
function quoteVersionInfoString(sourceText) {
    return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
}

/**
 * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
 * @param {File} scriptFile - 表示するファイル
 * @returns {void}
 */
function revealVersionInfoScriptFile(scriptFile) {
    /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
    var hasRevealApp = (File.fs === "Macintosh")
        && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
    /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
    if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
    /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
    scriptFile.parent.execute();
}

/**
 * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
 * @param {string} targetPath - 絶対パス
 * @returns {boolean} 書き出せたら true
 */
function writeVersionInfoRevealPath(targetPath) {
    var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
    pathFile.encoding = "UTF-8";
    pathFile.lineFeed = "Unix";
    if (!pathFile.open("w")) return false;
    var hasWritten = pathFile.write(targetPath);
    pathFile.close();
    return hasWritten;
}

/**
 * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
 * @param {string} targetUrl - 開く URL
 * @returns {void}
 */
function openVersionInfoUrl(targetUrl) {
    var isMac = (File.fs === "Macintosh");
    var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
    shortcutFile.encoding = "UTF-8";
    shortcutFile.open("w");
    if (isMac) {
        var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
        shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
            + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
            + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
    } else {
        shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
    }
    shortcutFile.close();
    shortcutFile.execute();
}

// バージョン表示（再利用パーツ）ここまで / End of the reusable version footer


var LABELS = {
    dialog: {
        title: { ja: "フォント種別変更", en: "Font Variant Switcher" }
    },
    panel: {
        target: { ja: "対象範囲", en: "Target Scope" },
        conversion: { ja: "変換設定", en: "Conversion Settings" },
        charset: { ja: "文字セット", en: "Character Set" },
        nSetting: { ja: "N（JIS2004対応）", en: "N (JIS2004)" },
        ntSetting: { ja: "新ゴ / 新ゴNT", en: "ShinGo / ShinGo NT" },
        udSetting: { ja: "UD", en: "UD" },
        pSetting: { ja: "AP版", en: "AP (Proportional)" },
        options: { ja: "処理オプション", en: "Processing Options" }
    },
    radio: {
        targetSelection: { ja: "選択範囲", en: "Selection" },
        targetStory: { ja: "ストーリー", en: "Story" },
        targetDocument: { ja: "ドキュメント", en: "Document" },
        targetSpread: { ja: "アクティブスプレッド", en: "Active spread" },
        keep: { ja: "現状維持", en: "Keep current" },
        nOff: { ja: "Nなし", en: "Without N" },
        nOn: { ja: "Nあり", en: "With N" },
        ntOff: { ja: "NTなし", en: "Without NT" },
        ntOn: { ja: "NTあり", en: "With NT" },
        udOff: { ja: "UDなし", en: "Without UD" },
        udOn: { ja: "UDあり", en: "With UD" },
        pOff: { ja: "Pなし", en: "Without P" },
        pOn: { ja: "Pあり", en: "With P" }
    },
    checkbox: {
        integrateGakusan: {
            ja: "G-OTF学参書体をA-OTFに統合",
            en: "Merge G-OTF Gakusan fonts into A-OTF"
        },
        includeStyles: {
            ja: "段落/文字スタイルも変更",
            en: "Also update paragraph/character styles"
        },
        includeComposite: {
            ja: "合成フォントを含む",
            en: "Include composite fonts"
        },
        includeLocked: {
            ja: "ロックされたオブジェクトも対象にする",
            en: "Include locked objects"
        },
        includeHidden: {
            ja: "非表示オブジェクトも対象にする",
            en: "Include hidden objects"
        }
    },
    button: {
        cancel: { ja: "キャンセル", en: "Cancel" },
        ok: { ja: "OK", en: "OK" },
        run: { ja: "実行", en: "Run" }
    },
    confirm: {
        title: { ja: "変更内容の確認", en: "Confirm Changes" },
        willChange: {
            ja: "以下のフォントを変更します。",
            en: "The following fonts will be changed."
        },
        nearWeight: {
            ja: "同じウエイトのフォントが見つかりません。近いウエイトに置換します。",
            en: "Exact weight not found. The nearest weight will be substituted."
        },
        notInstalled: {
            ja: "次のフォントはインストールされていないため変更されません。",
            en: "The following fonts are not installed and will not be changed."
        },
        prompt: { ja: "実行しますか？", en: "Run now?" }
    },
    alert: {
        noDocument: { ja: "ドキュメントが開かれていません。", en: "No document is open." },
        noSelection: {
            ja: "テキストオブジェクトを選択してください。",
            en: "Please select text objects."
        },
        noTarget: {
            ja: "対象となるテキストが見つかりませんでした。",
            en: "No target text was found."
        },
        noLayoutWindow: {
            ja: "レイアウトウィンドウがアクティブではありません。ドキュメントのページを表示してから実行してください。",
            en: "No layout window is active. Switch to a document layout view and try again."
        },
        noChange: {
            ja: "変更対象のフォントが見つかりませんでした。",
            en: "No fonts to change were found."
        },
        done: { ja: "処理が完了しました。", en: "Done." },
        changedCount: { ja: "変更数", en: "Changed" }
    },
    tooltip: {
        target: {
            ja: "フォント種別を変更する範囲を選びます。選択範囲、選択が属するストーリー全体、ドキュメント全体、アクティブスプレッド内から選択できます。",
            en: "Choose the scope for changing font variants: the selection, the whole story containing the selection, the entire document, or the active spread."
        },
        charset: {
            ja: "文字セットを Std / Pro / Pr5 / Pr6 から選びます。N の有無は「N（JIS2004対応）」で切り替えます。",
            en: "Choose the character set: Std, Pro, Pr5, or Pr6. Toggle the N variant separately under N (JIS2004)."
        },
        nSetting: {
            ja: "N あり/なしを切り替えます。例：Pr6 → Pr6N。現状維持では現在の N 状態を保ちます。",
            en: "Toggle the N variant on or off, for example Pr6 -> Pr6N. Keep current preserves the current N state."
        },
        udSetting: {
            ja: "UD 書体があるファミリーだけ、UD あり/なしを切り替えます。対応しないファミリーでは無視されます。",
            en: "Toggle the UD variant only for families that support it. Unsupported families are ignored."
        },
        pSetting: {
            ja: "AP版書体へ切り替えます。対応しないファミリーでは無視されます。",
            en: "Switch to the A P-OTF (proportional) version. Unsupported families are ignored."
        },
        includeLocked: {
            ja: "ロック中のオブジェクトも一時的に解除して変更し、処理後に元のロック状態へ戻します。",
            en: "Temporarily unlock locked objects, update them, then restore the original lock state."
        },
        includeHidden: {
            ja: "非表示のオブジェクト（レイヤー非表示を含む）も対象に含めて変更します。",
            en: "Include hidden objects (including hidden layers) in the scope."
        },
        nt: {
            ja: "新ゴと新ゴNTを切り替えます。対象は新ゴ系ファミリーのみです。",
            en: "Switch between ShinGo and ShinGo NT. This applies only to ShinGo families."
        },
        integrateGakusan: {
            ja: "G-OTF の学参・常改・K書体を、通常の A-OTF 書体として扱って変換します。",
            en: "Treat G-OTF Gakusan, revised, and K fonts as standard A-OTF fonts before conversion."
        },
        includeStyles: {
            ja: "段落スタイル・文字スタイルに設定されたフォントも、同じ条件で変更します。",
            en: "Also update fonts assigned in paragraph and character styles using the same conversion settings."
        },
        includeComposite: {
            ja: "合成フォントの各エントリ（漢字・かな・全角約物など）に設定されたフォントも、同じ条件で変更します。",
            en: "Also update fonts assigned in each composite font entry (kanji, kana, etc.) using the same conversion settings."
        },
        presetMax: {
            ja: "N なしで収録文字数が最も多い文字セットを選び、UD・P・NT をありにします。",
            en: "Select the richest available character set without N, and turn on UD, P, and NT."
        },
        presetMaxN: {
            ja: "N ありを含めて収録文字数が最も多い文字セットを選び、UD・P・NT をありにします。",
            en: "Select the richest available character set including N variants, and turn on UD, P, and NT."
        }
    }
};

// =========================================
// UI 共通 / UI helpers
// =========================================

/**
 * 縦並びのグループ（パネルを積むカラム）の共通設定
 * @param {Group} columnGroup 対象グループ
 * @param {number} [spacing] 要素間隔。省略時は PANEL_SPACING
 * @returns {void}
 */
function setupColumn(columnGroup, spacing) {
    columnGroup.orientation = "column";
    columnGroup.alignChildren = ["left", "top"];
    columnGroup.alignment = "fill";
    columnGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
}

// =========================================
// メイン / Main
// =========================================

(function () {

    /* ドキュメントの有無を確認 / Ensure a document is open */
    if (app.documents.length === 0) {
        alert(getLabel("alert.noDocument"));
        return;
    }

    var activeDocument = app.activeDocument;

    /* 選択範囲を判定するテキスト系オブジェクト型 / Text-bearing object types found in a selection */
    var TEXT_TYPES = {
        Text: 1, Story: 1, Paragraph: 1, Line: 1, Word: 1, Character: 1,
        TextStyleRange: 1, InsertionPoint: 1, TextColumn: 1, Cell: 1
    };

    // -----------------------------------------
    // フォントインデックス / Font index by PostScript name
    // -----------------------------------------

    /* PostScript 名 → Font オブジェクト。installed はインストール済みのみ、all は表示名解決用（未インストール含む）
       実体の構築はダイアログ確定後（実処理の直前）まで遅延する。フォント数が多い環境での初回表示を速くするため。
       Maps are populated lazily after the dialog is confirmed (right before processing), so the first dialog opens fast. */
    var installedFontByPs = {};
    var allFontByPs = {};
    /**
     * フォント一覧を PostScript 名で索引化する（installedFontByPs と allFontByPs に入れる）
     * @returns {void}
     */
    function indexFonts() {
        var fonts = app.fonts;

        // まとめて取得する（1 書体ずつのプロパティ参照は DOM 往復が多く非常に遅い）
        // Fetch in bulk; per-font property access crosses the DOM many times and is very slow.
        var elements = null, psNames = null, statuses = null;
        try {
            elements = fonts.everyItem().getElements();
            psNames = fonts.everyItem().postscriptName;
            statuses = fonts.everyItem().status;
        } catch (bulkError) {
            elements = null;
        }

        if (elements && psNames && elements.length === psNames.length) {
            for (var i = 0; i < elements.length; i++) {
                var psName = psNames[i];
                if (!psName) continue;
                if (!allFontByPs.hasOwnProperty(psName)) allFontByPs[psName] = elements[i];
                var installed = statuses ? (statuses[i] === FontStatus.INSTALLED) : true;
                if (installed && !installedFontByPs.hasOwnProperty(psName)) installedFontByPs[psName] = elements[i];
            }
            return;
        }

        // フォールバック：1 件ずつ / Fallback: one by one
        for (var j = 0; j < fonts.length; j++) {
            var font = fonts[j];
            var ps;
            try { ps = font.postscriptName; } catch (e) { continue; }
            if (!ps) continue;
            if (!allFontByPs.hasOwnProperty(ps)) allFontByPs[ps] = font;
            var inst;
            try { inst = (font.status === FontStatus.INSTALLED); } catch (e2) { inst = true; }
            if (inst && !installedFontByPs.hasOwnProperty(ps)) installedFontByPs[ps] = font;
        }
    }

    // -----------------------------------------
    // ダイアログ / Dialog
    // -----------------------------------------

    var mainDialog = new Window("dialog", getLabel("dialog.title"));
    setupWindow(mainDialog, 10);
    mainDialog.alignChildren = "left";

    /* 対象パネル（ラジオは縦並び）/ Target panel (radios in a column) */
    var targetPanel = addPanel(mainDialog, "panel.target", 6);
    targetPanel.helpTip = getLabel("tooltip.target");
    var rbTargetSelection = targetPanel.add("radiobutton", undefined, getLabel("radio.targetSelection"));
    var rbTargetStory = targetPanel.add("radiobutton", undefined, getLabel("radio.targetStory"));
    var rbTargetDocument = targetPanel.add("radiobutton", undefined, getLabel("radio.targetDocument"));
    var rbTargetSpread = targetPanel.add("radiobutton", undefined, getLabel("radio.targetSpread"));
    rbTargetSelection.value = true;

    /* 変換設定パネル（文字セット/N/UD/P と Max/MaxN をまとめる）/ Conversion panel (variant columns + presets) */
    var conversionPanel = addPanel(mainDialog, "panel.conversion");

    /* 変換設定: 3 カラム（左=文字セット / 中央=N・NT / 右=UD・P）/ Conversion: 3 columns */
    var variantColumns = conversionPanel.add("group");
    setupRow(variantColumns, "fill", COLUMN_SPACING);
    variantColumns.alignChildren = ["fill", "top"];

    /* 左カラム: 文字セットパネル（Std/Pro/Pr5/Pr6 はローカライズ不要の固有名）/ Left: character set */
    var charsetPanel = addPanel(variantColumns, "panel.charset", 6);
    charsetPanel.helpTip = getLabel("tooltip.charset");
    var rbCharsetKeep = charsetPanel.add("radiobutton", undefined, getLabel("radio.keep"));
    var rbCharsetStd = charsetPanel.add("radiobutton", undefined, "Std");
    var rbCharsetPro = charsetPanel.add("radiobutton", undefined, "Pro");
    var rbCharsetPr5 = charsetPanel.add("radiobutton", undefined, "Pr5");
    var rbCharsetPr6 = charsetPanel.add("radiobutton", undefined, "Pr6");
    rbCharsetKeep.value = true;

    /* 中央カラム: N 設定・NT 設定 / Center: N and NT */
    var nNtColumn = variantColumns.add("group");
    setupColumn(nNtColumn);

    var nVariantPanel = addPanel(nNtColumn, "panel.nSetting", 6);
    nVariantPanel.helpTip = getLabel("tooltip.nSetting");
    var rbNKeep = nVariantPanel.add("radiobutton", undefined, getLabel("radio.keep"));
    var rbNOff = nVariantPanel.add("radiobutton", undefined, getLabel("radio.nOff"));
    var rbNOn = nVariantPanel.add("radiobutton", undefined, getLabel("radio.nOn"));
    rbNKeep.value = true;

    /* NT 設定パネル（新ゴ ⇄ 新ゴNT）/ NT panel (ShinGo <-> ShinGo NT) */
    var ntPanel = addPanel(nNtColumn, "panel.ntSetting", 6);
    ntPanel.helpTip = getLabel("tooltip.nt");
    var rbNTKeep = ntPanel.add("radiobutton", undefined, getLabel("radio.keep"));
    var rbNTOff = ntPanel.add("radiobutton", undefined, getLabel("radio.ntOff"));
    var rbNTOn = ntPanel.add("radiobutton", undefined, getLabel("radio.ntOn"));
    rbNTKeep.value = true;

    /* 右カラム: UD 設定・P 設定 / Right: UD and P */
    var udProportionalColumn = variantColumns.add("group");
    setupColumn(udProportionalColumn);

    var udVariantPanel = addPanel(udProportionalColumn, "panel.udSetting", 6);
    udVariantPanel.helpTip = getLabel("tooltip.udSetting");
    var rbUDKeep = udVariantPanel.add("radiobutton", undefined, getLabel("radio.keep"));
    var rbUDOff = udVariantPanel.add("radiobutton", undefined, getLabel("radio.udOff"));
    var rbUDOn = udVariantPanel.add("radiobutton", undefined, getLabel("radio.udOn"));
    rbUDKeep.value = true;

    var proportionalPanel = addPanel(udProportionalColumn, "panel.pSetting", 6);
    proportionalPanel.helpTip = getLabel("tooltip.pSetting");
    var rbPKeep = proportionalPanel.add("radiobutton", undefined, getLabel("radio.keep"));
    var rbPOff = proportionalPanel.add("radiobutton", undefined, getLabel("radio.pOff"));
    var rbPOn = proportionalPanel.add("radiobutton", undefined, getLabel("radio.pOn"));
    rbPKeep.value = true;

    /* 文字セット名 → ラジオボタンの対応 / Map charset name to its radio button */
    var charsetRadioByName = {
        Pro: rbCharsetPro,
        Pr5: rbCharsetPr5,
        Pr6: rbCharsetPr6,
        Std: rbCharsetStd
    };

    /**
     * ランキングの先頭から選べる文字セットを探し、文字セットと N のラジオをオンにする
     * @param {string[]} rankList 文字セットのランキング（CHARSET_RANK_NO_N / CHARSET_RANK_WITH_N）
     * @returns {void}
     */
    function applyRichestCharset(rankList) {
        for (var i = 0; i < rankList.length; i++) {
            var token = rankList[i];
            var withN = token.charAt(token.length - 1) === "N";
            var baseCharset = withN ? token.substring(0, token.length - 1) : token;
            var radio = charsetRadioByName[baseCharset];
            if (radio) {
                radio.value = true;
                if (withN) { rbNOn.value = true; } else { rbNOff.value = true; }
                return;
            }
        }
    }

    /* Max/MaxN プリセットが押されたか / Whether a Max/MaxN preset is active
       AXIS は Std と ProN しか無いため、プリセット時は設定に関わらず ProN へ寄せる。
       押下後に文字セット/N を手動変更したら解除する。/ AXIS only has Std & ProN, so a preset forces ProN; cleared if charset/N changes manually. */
    var maxPresetActive = false;
    var presetResetRadios = [rbCharsetKeep, rbCharsetStd, rbCharsetPro, rbCharsetPr5, rbCharsetPr6, rbNKeep, rbNOff, rbNOn];
    for (var presetResetIndex = 0; presetResetIndex < presetResetRadios.length; presetResetIndex++) {
        presetResetRadios[presetResetIndex].onClick = function () { maxPresetActive = false; };
    }

    /* プリセット（Max=収録最多のNなし＋UD＋P、MaxN=収録最多のNあり込み＋UD＋P）/ Presets (Max / MaxN) */
    var presetRow = conversionPanel.add("group");
    setupRow(presetRow, ["center", "top"]); /* 左右中央 / horizontally centered */
    presetRow.margins = [0, 5, 0, 0]; // 上に 5px の余白 / 5px top margin
    var btnPresetMax = presetRow.add("button", undefined, "Max");
    btnPresetMax.helpTip = getLabel("tooltip.presetMax");
    btnPresetMax.onClick = function () {
        applyRichestCharset(CHARSET_RANK_NO_N);
        rbUDOn.value = true;
        rbPOn.value = true;
        rbNTOn.value = true;
        maxPresetActive = true;
    };
    var btnPresetMaxN = presetRow.add("button", undefined, "MaxN");
    btnPresetMaxN.helpTip = getLabel("tooltip.presetMaxN");
    btnPresetMaxN.onClick = function () {
        applyRichestCharset(CHARSET_RANK_WITH_N);
        rbUDOn.value = true;
        rbPOn.value = true;
        rbNTOn.value = true;
        maxPresetActive = true;
    };

    /* オプションパネル / Options panel */
    var optionsPanel = addPanel(mainDialog, "panel.options", 6);
    var cbIntegrateGakusan = optionsPanel.add("checkbox", undefined, getLabel("checkbox.integrateGakusan"));
    cbIntegrateGakusan.helpTip = getLabel("tooltip.integrateGakusan");
    cbIntegrateGakusan.value = INTEGRATE_GAKUSAN_TO_STANDARD;
    var cbIncludeStyles = optionsPanel.add("checkbox", undefined, getLabel("checkbox.includeStyles"));
    cbIncludeStyles.helpTip = getLabel("tooltip.includeStyles");
    cbIncludeStyles.value = true;
    var cbIncludeComposite = optionsPanel.add("checkbox", undefined, getLabel("checkbox.includeComposite"));
    cbIncludeComposite.helpTip = getLabel("tooltip.includeComposite");
    cbIncludeComposite.value = true;
    var cbIncludeLocked = optionsPanel.add("checkbox", undefined, getLabel("checkbox.includeLocked"));
    cbIncludeLocked.helpTip = getLabel("tooltip.includeLocked");
    cbIncludeLocked.value = false;
    var cbIncludeHidden = optionsPanel.add("checkbox", undefined, getLabel("checkbox.includeHidden"));
    cbIncludeHidden.helpTip = getLabel("tooltip.includeHidden");
    cbIncludeHidden.value = false;

    /* ボタン行（キャンセル → OK）/ Button row (Cancel then OK) */
    var buttonRow = addButtonRow(mainDialog);
    var btnCancel = buttonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
    var btnOK = buttonRow.rightGroup.add("button", undefined, getLabel("button.ok"), { name: "ok" });
    btnCancel.onClick = function () { mainDialog.close(0); };
    btnOK.onClick = function () { mainDialog.close(1); };
    alignRightOnlyButtonRow(buttonRow);

    addVersionFooter(mainDialog);
    if (mainDialog.show() !== 1) {
        return;
    }

    // -----------------------------------------
    // 設定値の取得 / Read settings
    // -----------------------------------------

    var targetMode = "selection";
    if (rbTargetStory.value) targetMode = "story";
    if (rbTargetDocument.value) targetMode = "document";
    if (rbTargetSpread.value) targetMode = "spread";

    var charsetMode = "keep"; // keep / Pro / Pr5 / Pr6 / Std
    if (rbCharsetPro.value) charsetMode = "Pro";
    if (rbCharsetPr5.value) charsetMode = "Pr5";
    if (rbCharsetPr6.value) charsetMode = "Pr6";
    if (rbCharsetStd.value) charsetMode = "Std";

    var nMode = radioMode(rbNOn, rbNOff);   // keep / on / off
    var udMode = radioMode(rbUDOn, rbUDOff);
    var pMode = radioMode(rbPOn, rbPOff);
    var ntMode = radioMode(rbNTOn, rbNTOff);
    var maxPreset = maxPresetActive; // Max/MaxN プリセット中か（AXIS を ProN へ寄せる）/ whether a Max/MaxN preset is active (forces AXIS to ProN)

    var integrateGakusan = cbIntegrateGakusan.value;
    var includeStyles = cbIncludeStyles.value;
    var includeComposite = cbIncludeComposite.value;
    var includeLocked = cbIncludeLocked.value;
    var includeHidden = cbIncludeHidden.value;
    var confirmBeforeRun = CONFIRM_BEFORE_RUN;

    /* 選択範囲・ストーリーは選択が必要 / Selection and story modes require a selection */
    if ((targetMode === "selection" || targetMode === "story") && app.selection.length === 0) {
        alert(getLabel("alert.noSelection"));
        return;
    }

    /* スプレッドモードはレイアウトウィンドウが必要 / Spread mode needs an active layout window */
    var isLayoutWindow = false;
    try { isLayoutWindow = (app.activeWindow.constructor.name === "LayoutWindow"); } catch (e) { isLayoutWindow = false; }
    if (targetMode === "spread" && !isLayoutWindow) {
        alert(getLabel("alert.noLayoutWindow"));
        return;
    }

    // フォントインデックスをここで構築（ダイアログ確定・入力検証を通過してから）/ Build the font index now (after the dialog is confirmed and validated)
    indexFonts();

    // -----------------------------------------
    // 対象テキストの収集 / Collect target text
    // -----------------------------------------

    var seenStoryIds = {};
    var targets = []; // {story, ranges, frames, sortKey}
    collectTargets(targetMode);

    // ページ上の位置（上→下、同じ高さは左→右）で並べ替え / Sort by page position (top→bottom, then left→right)
    sortTargetsByPosition(targets);

    if (targets.length === 0 && !includeStyles && !includeComposite) {
        alert(getLabel("alert.noTarget"));
        return;
    }

    // -----------------------------------------
    // 変更内容の事前計算 / Pre-compute changes
    // -----------------------------------------

    var processedFontNames = {};
    var directChanges = [];     // {oldName, newName}
    var weightSubChanges = [];  // {oldName, newName, oldWeight, newWeight}
    var missingChanges = [];    // {oldName, newName}

    /* 対象をスキャンして変換候補を収集 / Scan targets to collect change candidates */
    for (var ti = 0; ti < targets.length; ti++) {
        scanTargetFonts(targets[ti]);
    }

    /* 段落・文字スタイルもスキャン / Scan paragraph and character styles too */
    if (includeStyles) {
        scanStylesForChanges(activeDocument.allParagraphStyles);
        scanStylesForChanges(activeDocument.allCharacterStyles);
    }

    /* 合成フォントのエントリもスキャン / Scan composite font entries too */
    if (includeComposite) {
        scanCompositeFontsForChanges();
    }

    /* インストールされていないフォントしか無いときも変更なしとして知らせる / Report "no change" even when only uninstalled targets were found */
    if (directChanges.length === 0 && weightSubChanges.length === 0) {
        var noChangeMessage = getLabel("alert.noChange");
        if (missingChanges.length > 0) {
            noChangeMessage += "\n\n" + getLabel("confirm.notInstalled") + "\n" + uniqueArray(extractNewFontNames(missingChanges)).join("\n");
        }
        alert(noChangeMessage);
        return;
    }

    // -----------------------------------------
    // 確認ダイアログ / Confirmation dialog
    // -----------------------------------------

    var selectedOldNames = null; // null = すべて適用 / null = apply all
    if (confirmBeforeRun) {
        var confirmResult = showConfirmDialog();
        if (!confirmResult.ok) {
            return;
        }
        selectedOldNames = confirmResult.selected;
    }

    // -----------------------------------------
    // 変換マップの構築 / Build font-name map
    // -----------------------------------------

    var fontNameMap = {}; // oldName -> newName
    addSelectedChanges(directChanges, fontNameMap, selectedOldNames);
    addSelectedChanges(weightSubChanges, fontNameMap, selectedOldNames);

    /* 確認ダイアログですべてのチェックを外したときは何もしない / Nothing to do when every item was unchecked */
    var hasAnyChange = false;
    for (var mapKey in fontNameMap) {
        if (fontNameMap.hasOwnProperty(mapKey)) { hasAnyChange = true; break; }
    }
    if (!hasAnyChange) return;

    // -----------------------------------------
    // 適用（全体を 1 アンドゥにまとめる）/ Apply (wrapped as a single undo step)
    // -----------------------------------------

    var changedCount = 0;
    app.doScript(function () {
        // 同一ストーリーを複数 target で重複カウントしない / Don't count the same story twice across targets
        var countedStoryIds = {};
        for (var tj = 0; tj < targets.length; tj++) {
            var target = targets[tj];
            if (applyChangesToTarget(target, fontNameMap) > 0) {
                var storyId = null;
                try { storyId = target.story.id; } catch (e) { storyId = null; }
                if (storyId === null) {
                    changedCount++;
                } else if (!countedStoryIds[storyId]) {
                    countedStoryIds[storyId] = true;
                    changedCount++;
                }
            }
        }
        // スタイルは適用のみ（テキストオブジェクト数には数えない）/ Styles are applied but not counted as text objects
        if (includeStyles) {
            applyChangesToStyles(activeDocument.allParagraphStyles, fontNameMap);
            applyChangesToStyles(activeDocument.allCharacterStyles, fontNameMap);
        }
        // 合成フォントも適用のみ（テキストオブジェクト数には数えない）/ Composite fonts applied but not counted
        if (includeComposite) {
            applyChangesToCompositeFonts(fontNameMap);
        }
    }, ScriptLanguage.JAVASCRIPT, undefined, UndoModes.ENTIRE_SCRIPT, getLabel("dialog.title"));

    alert(getLabel("alert.done") + "\n\n" + labelValueText("alert.changedCount", changedCount));

    // =========================================
    // 対象収集 / Target collection
    // =========================================

    /**
     * 対象範囲から処理するテキストを targets に集める
     * @param {string} mode 対象範囲（"selection" / "story" / "document" / "spread"）
     * @returns {void}
     */
    function collectTargets(mode) {
        if (mode === "document") {
            var stories = activeDocument.stories;
            for (var i = 0; i < stories.length; i++) {
                addStoryInScope(stories[i]);
            }
            return;
        }
        if (mode === "story") {
            // 選択が属するストーリー全体を対象にする / Whole story that the selection belongs to
            collectStoriesFromSelection(app.selection);
            return;
        }
        if (mode === "spread") {
            // アクティブスプレッド上のフレームのテキストだけを対象にする（連結先の別スプレッドは含めない）
            // Only the text inside frames on the active spread; threaded frames on other spreads are left alone
            var spreadFrames = collectActiveSpreadTextFrames();
            for (var s = 0; s < spreadFrames.length; s++) {
                if (frameInScope(spreadFrames[s])) addFrameTarget(spreadFrames[s]);
            }
            return;
        }
        // selection
        collectFromSelection(app.selection);
    }

    /**
     * アクティブスプレッド上のテキストフレームを集める
     * @returns {Array<TextFrame>} テキストフレームの配列
     */
    function collectActiveSpreadTextFrames() {
        var result = [];
        try {
            var spread = app.activeWindow.activeSpread;
            var items = spread.allPageItems;
            for (var i = 0; i < items.length; i++) {
                if (items[i].constructor.name === "TextFrame") result.push(items[i]);
            }
        } catch (e) { }
        return result;
    }

    /**
     * 選択から対象テキストを targets に集める（グループは中へたどる）
     * @param {Array|PageItems} items 選択、またはグループ内のページアイテム
     * @returns {void}
     */
    function collectFromSelection(items) {
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var typeName;
            try { typeName = item.constructor.name; } catch (e) { continue; }

            if (typeName === "TextFrame") {
                if (frameInScope(item)) addStoryTarget(item.parentStory);
            } else if (typeName === "Cell") {
                // 表セルは cell.texts[0] 経由で扱う / Table cells are handled via cell.texts[0]
                var cellText = cellTextOf(item);
                if (cellText) addTextTarget(cellText);
            } else if (TEXT_TYPES[typeName]) {
                addTextTarget(item); // 選択した文字だけを変える / only the selected characters
            } else if (typeName === "Group") {
                collectFromSelection(item.pageItems);
            }
        }
    }

    /**
     * 選択が属するストーリーを targets に集める（グループは中へたどる）
     * @param {Array|PageItems} items 選択、またはグループ内のページアイテム
     * @returns {void}
     */
    function collectStoriesFromSelection(items) {
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var typeName;
            try { typeName = item.constructor.name; } catch (e) { continue; }

            if (typeName === "TextFrame") {
                if (frameInScope(item)) addStoryTarget(item.parentStory);
            } else if (typeName === "Cell") {
                var cellText = cellTextOf(item);
                if (cellText) {
                    try { addStoryTarget(cellText.parentStory); } catch (e2) { }
                }
            } else if (TEXT_TYPES[typeName]) {
                try { addStoryTarget(item.parentStory); } catch (e3) { }
            } else if (typeName === "Group") {
                collectStoriesFromSelection(item.pageItems);
            }
        }
    }

    /**
     * 表セルのテキストを取得する
     * @param {Cell} cell 対象のセル
     * @returns {Text|null} セル内のテキスト。取得できない場合は null
     */
    function cellTextOf(cell) {
        try {
            var texts = cell.texts;
            if (texts.length > 0) return texts[0];
        } catch (e) { }
        return null;
    }

    /**
     * ストーリーを対象として targets に追加する（同じストーリーは1回だけ）
     * @param {Story} story 追加するストーリー
     * @returns {void}
     */
    function addStoryTarget(story) {
        if (!story || !story.isValid) return;
        var storyId;
        try { storyId = story.id; } catch (e) { return; }
        if (seenStoryIds[storyId]) return;
        seenStoryIds[storyId] = true;

        var frames = collectionToArray(story.textContainers);
        pushTarget(story, story.textStyleRanges, frames, null);
        addNestedTextTargets(story, story, frames);
    }

    /**
     * 対象範囲（ロック・非表示の扱い）に入るフレームのテキストを targets に追加する。
     * すべてのフレームが入ればストーリーごと（オーバーセットも含む）、一部だけならフレーム単位で足す
     * @param {Story} story 対象のストーリー
     * @returns {void}
     */
    function addStoryInScope(story) {
        var frames = collectionToArray(story.textContainers);
        var framesInScope = [];
        for (var i = 0; i < frames.length; i++) {
            if (frameInScope(frames[i])) framesInScope.push(frames[i]);
        }
        if (framesInScope.length === 0) return;
        if (framesInScope.length === frames.length) {
            addStoryTarget(story);
            return;
        }
        for (var j = 0; j < framesInScope.length; j++) {
            addFrameTarget(framesInScope[j]);
        }
    }

    /**
     * 1 つのフレームに収まっているテキストを対象として targets に追加する
     * @param {TextFrame|TextPath} frame 対象のフレーム
     * @returns {void}
     */
    function addFrameTarget(frame) {
        var frameText, story;
        try {
            frameText = frame.texts[0];
            if (!frameText.isValid) return;
            story = frame.parentStory;
        } catch (e) { return; }
        pushTarget(story, frameText.textStyleRanges, [frame], null);
        addNestedTextTargets(frameText, story, [frame]);
    }

    /**
     * 選択したテキストを対象として targets に追加する。書式の区切りが選択の外へはみ出す分は適用時に切り詰める
     * @param {Text} textObject 追加するテキスト
     * @returns {void}
     */
    function addTextTarget(textObject) {
        var story, clip;
        try {
            story = textObject.parentStory;
            if (!story || !story.isValid) return;
            /* 挿入点だけの選択は文字が無いので対象にしない / An insertion point alone has no characters to change */
            var chars = textObject.characters;
            if (chars.length === 0) return;
            clip = {
                first: chars.firstItem().getElements()[0],
                last: chars.lastItem().getElements()[0]
            };
        } catch (e) { return; }

        var frames;
        try { frames = collectionToArray(textObject.parentTextFrames); } catch (e2) { frames = []; }
        pushTarget(story, textObject.textStyleRanges, frames, clip);
        addNestedTextTargets(textObject, story, frames);
    }

    /**
     * 表のセルと脚注のテキストを targets に追加する（本文の textStyleRanges に含まれないため）。入れ子の表もたどる
     * @param {Story|Text} container 表・脚注を持つストーリーまたはテキスト
     * @param {Story} story 所属するストーリー（件数の数え分けに使う）
     * @param {Array<TextFrame>} frames ロック解除と並べ替えに使うフレーム
     * @returns {void}
     */
    function addNestedTextTargets(container, story, frames) {
        var tables = [], footnotes = [];
        try { tables = collectionToArray(container.tables); } catch (e) { }
        try { footnotes = collectionToArray(container.footnotes); } catch (e2) { }

        for (var t = 0; t < tables.length; t++) {
            var cells = [];
            try { cells = collectionToArray(tables[t].cells); } catch (e3) { }
            for (var c = 0; c < cells.length; c++) {
                var cellText = cellTextOf(cells[c]);
                if (!cellText) continue;
                pushTarget(story, cellText.textStyleRanges, frames, null);
                addNestedTextTargets(cellText, story, frames);
            }
        }
        for (var f = 0; f < footnotes.length; f++) {
            var footnoteText;
            try { footnoteText = footnotes[f].texts[0]; } catch (e4) { continue; }
            pushTarget(story, footnoteText.textStyleRanges, frames, null);
        }
    }

    /**
     * targets に 1 件追加する
     * @param {Story} story 所属するストーリー
     * @param {TextStyleRanges} ranges 対象の書式の区切り
     * @param {Array<TextFrame>} frames ロック解除と並べ替えに使うフレーム
     * @param {{first: Character, last: Character}|null} clip 選択の最初と最後の文字。範囲を切り詰めないなら null
     * @returns {void}
     */
    function pushTarget(story, ranges, frames, clip) {
        targets.push({
            story: story,
            ranges: ranges,
            frames: frames,
            sortKey: sortKeyOfFrames(frames),
            clip: clip
        });
    }

    /**
     * フレームが対象範囲（ロック・非表示のオプション）に入るかを判定する
     * @param {PageItem} frame 対象のフレーム
     * @returns {boolean} 入れば true
     */
    function frameInScope(frame) {
        if (!includeLocked && isFrameLocked(frame)) return false;
        if (!includeHidden && isFrameHidden(frame)) return false;
        return true;
    }

    /**
     * DOM のコレクションを配列にする
     * @param {Object|Array} collection コレクション
     * @returns {Array} 要素の配列
     */
    function collectionToArray(collection) {
        var arr = [];
        try {
            for (var i = 0; i < collection.length; i++) arr.push(collection[i]);
        } catch (e) { }
        return arr;
    }

    /**
     * ページ上の位置から並べ替え用のキーを作る
     * @param {Array<TextFrame>} frames 対象のフレーム
     * @returns {Array<number>} 並べ替えキー
     */
    function sortKeyOfFrames(frames) {
        try {
            if (frames.length > 0) {
                var bounds = frames[0].geometricBounds; // [y1, x1, y2, x2] = [top, left, bottom, right]
                return [bounds[0], bounds[1]];
            }
        } catch (e) { }
        return [1e9, 1e9];
    }

    /**
     * 対象をページ上の位置（上から下、同じ高さは左から右）で並べ替える
     * @param {Array<object>} list 対象の配列
     * @returns {void}
     */
    function sortTargetsByPosition(list) {
        list.sort(function (a, b) {
            if (Math.abs(a.sortKey[0] - b.sortKey[0]) > 1.0) return a.sortKey[0] - b.sortKey[0]; // top が小さい方が上
            return a.sortKey[1] - b.sortKey[1];                                                  // left が小さい方が先
        });
    }

    // =========================================
    // ロック・非表示判定 / Lock & hidden checks
    // =========================================

    /**
     * フレームがロックされているかを判定する
     * @param {PageItem} frame 対象のフレーム
     * @returns {boolean} ロックされていれば true
     */
    function isFrameLocked(frame) {
        try { if (frame.locked) return true; } catch (e) { }
        try { if (frame.itemLayer.locked) return true; } catch (e2) { }
        var parent;
        try { parent = frame.parent; } catch (e3) { parent = null; }
        while (parent) {
            var typeName;
            try { typeName = parent.constructor.name; } catch (e4) { break; }
            if (typeName !== "Group") break;
            try { if (parent.locked) return true; } catch (e5) { }
            try { parent = parent.parent; } catch (e6) { break; }
        }
        return false;
    }

    /**
     * フレームが非表示かどうかを判定する
     * @param {PageItem} frame 対象のフレーム
     * @returns {boolean} 非表示なら true
     */
    function isFrameHidden(frame) {
        try { if (!frame.visible) return true; } catch (e) { }
        try { if (!frame.itemLayer.visible) return true; } catch (e2) { }
        var parent;
        try { parent = frame.parent; } catch (e3) { parent = null; }
        while (parent) {
            var typeName;
            try { typeName = parent.constructor.name; } catch (e4) { break; }
            if (typeName !== "Group") break;
            try { if (!parent.visible) return true; } catch (e5) { }
            try { parent = parent.parent; } catch (e6) { break; }
        }
        return false;
    }

    // =========================================
    // 変更内容のスキャン / Change scanning
    // =========================================

    /**
     * 対象テキストのフォントを変更候補に振り分ける
     * @param {object} target 対象テキスト（collectTargets で集めたもの）
     * @returns {void}
     */
    function scanTargetFonts(target) {
        var fonts = appliedFontsOf(target.ranges);
        for (var i = 0; i < fonts.length; i++) {
            var psName = fontPsNameOf(fonts[i]);
            if (psName) classifyFontChange(psName);
        }
    }

    /**
     * 書式の区切りごとのフォントをまとめて取得する（1 件ずつ読むより DOM の往復が少ない）
     * @param {TextStyleRanges} ranges 対象の書式の区切り
     * @returns {Array<Font|string|null>} ranges と同じ並びのフォント
     */
    function appliedFontsOf(ranges) {
        var count = 0;
        try { count = ranges.length; } catch (e) { return []; }
        if (count === 0) return [];
        try {
            var bulkFonts = ranges.everyItem().appliedFont;
            if (!(bulkFonts instanceof Array)) bulkFonts = [bulkFonts];
            if (bulkFonts.length === count) return bulkFonts;
        } catch (eBulk) { }

        // フォールバック：1 件ずつ / Fallback: one by one
        var fonts = [];
        for (var i = 0; i < count; i++) {
            try { fonts.push(ranges[i].appliedFont); } catch (e2) { fonts.push(null); }
        }
        return fonts;
    }

    /**
     * 段落・文字スタイルのフォントを変更候補に振り分ける
     * @param {Array<ParagraphStyle|CharacterStyle>} styles 対象のスタイル
     * @returns {void}
     */
    function scanStylesForChanges(styles) {
        for (var k = 0; k < styles.length; k++) {
            var psName = styleFontPsName(styles[k]);
            if (psName) classifyFontChange(psName);
        }
    }

    /**
     * 合成フォントの各エントリのフォントを変更候補に振り分ける
     * @returns {void}
     */
    function scanCompositeFontsForChanges() {
        var compositeFonts = activeDocument.compositeFonts;
        for (var c = 0; c < compositeFonts.length; c++) {
            var entries = compositeFonts[c].compositeFontEntries;
            for (var e = 0; e < entries.length; e++) {
                var psName = styleFontPsName(entries[e]); // appliedFont を持つので同じ解決でよい
                if (psName) classifyFontChange(psName);
            }
        }
    }

    /**
     * スタイル（または合成フォントのエントリ）に設定されたフォントの PostScript 名を取得する
     * @param {object} style appliedFont を持つオブジェクト
     * @returns {string|null} PostScript 名。取れなければ null
     */
    function styleFontPsName(style) {
        try {
            return fontPsNameOf(style.appliedFont);
        } catch (e) {
            return null;
        }
    }

    /**
     * フォントの PostScript 名を取得する
     * @param {Font|string} font フォントまたはフォント名
     * @returns {string|null} PostScript 名。取れなければ null
     */
    function fontPsNameOf(font) {
        if (!font) return null;
        try {
            if (typeof font === "string") {
                if (!font || font.indexOf("$ID") === 0) return null;
                var resolved = app.fonts.itemByName(font);
                if (!resolved.isValid) return null;
                return resolved.postscriptName;
            }
            return font.postscriptName;
        } catch (e) {
            return null;
        }
    }

    /**
     * 変換後の名前を決め、directChanges / weightSubChanges / missingChanges に振り分ける（同じ名前は1回だけ）
     * @param {string} oldName 現在の PostScript 名
     * @returns {void}
     */
    function classifyFontChange(oldName) {
        if (processedFontNames[oldName]) return;
        processedFontNames[oldName] = true;

        // 特殊シリーズ（A1明朝 など）を優先 / Special series first (e.g. A1 Mincho)
        var seriesTarget = resolveSpecialSeries(oldName);
        if (seriesTarget !== undefined) {
            if (seriesTarget === null) return; // 該当するが変更不要・対応なし
            if (fontExists(seriesTarget)) {
                directChanges.push({ oldName: oldName, newName: seriesTarget });
            } else {
                missingChanges.push({ oldName: oldName, newName: seriesTarget });
            }
            return;
        }

        // AXIS は文字セット体系が異なるため専用処理 / AXIS has its own charset scheme
        var axis = parseAxisName(oldName);
        if (axis) {
            classifyByDesired(oldName, buildAxisNameHead(axis), axis.weight);
            return;
        }

        var parsed = parseFontName(oldName);
        if (!parsed) return;

        classifyByDesired(oldName, buildConvertedNameHead(parsed), parsed.weight);
    }

    /**
     * 変換後のフォントの有無を確かめて振り分ける。同じウエイトが無ければ近いウエイトを探す
     * @param {string} oldName 現在の PostScript 名
     * @param {string|null} nameHead 変換後の名前のウエイトより前（末尾は「-」）。null なら変換しない
     * @param {string} weight ウエイト
     * @returns {void}
     */
    function classifyByDesired(oldName, nameHead, weight) {
        if (nameHead === null) return; // 変換対象外（CID 非変換など）/ not convertible

        var desiredName = nameHead + weight;
        if (desiredName === oldName) return; // 変化なし / no change

        if (fontExists(desiredName)) {
            directChanges.push({ oldName: oldName, newName: desiredName });
            return;
        }

        var nearWeight = findNearestWeight(nameHead, weight);
        if (nearWeight) {
            weightSubChanges.push({
                oldName: oldName,
                newName: nameHead + nearWeight,
                oldWeight: weight,
                newWeight: nearWeight
            });
            return;
        }

        missingChanges.push({ oldName: oldName, newName: desiredName });
    }

    // =========================================
    // フォント名の分解・組み立て / Parse & build font names
    // =========================================

    /**
     * A1明朝など特殊シリーズの対応表から変換後の名前を引く
     * @param {string} oldName 現在の PostScript 名
     * @returns {string|null|undefined} 変換後の名前。特殊シリーズだが変換先が無い・変わらないときは null、特殊シリーズでなければ undefined
     */
    function resolveSpecialSeries(oldName) {
        for (var seriesIndex = 0; seriesIndex < SPECIAL_SERIES.length; seriesIndex++) {
            var members = SPECIAL_SERIES[seriesIndex].members;

            // oldName がどのキー（文字セット）のメンバーか / Which charset key oldName belongs to
            var sourceKey = null;
            for (var key in members) {
                if (members.hasOwnProperty(key) && members[key] === oldName) {
                    sourceKey = key;
                    break;
                }
            }
            if (!sourceKey) continue;

            var targetKey = computeSeriesTargetKey(sourceKey);
            if (!targetKey || !members.hasOwnProperty(targetKey)) return null;

            var targetName = members[targetKey];
            if (!targetName || targetName === oldName) return null;
            return targetName;
        }
        return undefined;
    }

    /**
     * 特殊シリーズの変換先のキー（文字セット＋N）を設定から求める
     * @param {string} sourceKey 元のキー（"Std" / "StdN" など）
     * @returns {string} 変換先のキー
     */
    function computeSeriesTargetKey(sourceKey) {
        var sourceHasN = sourceKey.charAt(sourceKey.length - 1) === "N";
        var sourceBaseCharset = sourceHasN ? sourceKey.substring(0, sourceKey.length - 1) : sourceKey;

        var targetBaseCharset = (charsetMode === "keep") ? sourceBaseCharset : charsetMode;

        var targetHasN = sourceHasN;
        if (nMode === "on") targetHasN = true;
        if (nMode === "off") targetHasN = false;

        return targetBaseCharset + (targetHasN ? "N" : "");
    }

    /**
     * AXIS フォントの名前を要素へ分解する
     * @param {string} name PostScript 名
     * @returns {object|null} { width, charset, hasN, weight }。AXIS でなければ null
     */
    function parseAxisName(name) {
        var matched = name.match(AXIS_FAMILY.regex);
        if (!matched) return null;
        return {
            width: matched[1] || "",    // Basic / Cond / Comp / ""
            charset: matched[2] || "",  // Std / Pro / Joyo / ""
            hasN: !!matched[3],
            weight: matched[4]
        };
    }

    /**
     * 設定に従って AXIS の変換後の名前（ウエイトより前）を組み立てる
     * @param {object} axis parseAxisName の結果
     * @returns {string} 末尾が「-」の名前
     */
    function buildAxisNameHead(axis) {
        // Max/MaxN プリセット時は、設定に関わらず ProN（AXIS の収録最多）へ寄せる。AXIS は Std と ProN しか無いため。
        // Under a Max/MaxN preset, force ProN (the richest AXIS charset) regardless of settings; AXIS only has Std & ProN.
        if (maxPreset) {
            return AXIS_FAMILY.baseName + axis.width + "ProN" + "-";
        }

        // Joyo は別体系なので維持（文字セット・N の切り替え対象外）/ Joyo is a separate scheme; keep as-is
        if (axis.charset === "Joyo") {
            return AXIS_FAMILY.baseName + axis.width + "Joyo" + "-";
        }

        // 文字セット：AXIS は Std / Pro のみ。Pr5 / Pr6 や keep は現状維持 / AXIS only has Std / Pro
        var charset = axis.charset;
        if (charsetMode === "Std" || charsetMode === "Pro") charset = charsetMode;

        // N 切り替え（文字セットがある場合のみ意味を持つ）/ N toggle (only meaningful with a charset)
        var hasN = axis.hasN;
        if (nMode === "on") hasN = true;
        if (nMode === "off") hasN = false;

        var charsetCore = charset ? (charset + (hasN ? "N" : "")) : "";
        return AXIS_FAMILY.baseName + axis.width + charsetCore + "-";
    }

    /**
     * フォント名を文字セットや属性へ分解する（学参書体の統合がオンなら、プレフィックスを外してもう一度試す）
     * @param {string} name PostScript 名
     * @returns {object|null} parseKnownFamily の結果。対象外なら null
     */
    function parseFontName(name) {
        var parsed = parseKnownFamily(name);
        if (parsed) return parsed;

        if (integrateGakusan) {
            for (var prefixIndex = 0; prefixIndex < GAKUSAN_PREFIXES.length; prefixIndex++) {
                var gakusanPrefix = GAKUSAN_PREFIXES[prefixIndex];
                if (name.indexOf(gakusanPrefix) === 0) {
                    parsed = parseKnownFamily(name.substring(gakusanPrefix.length));
                    if (parsed) return parsed;
                }
            }
        }
        return null;
    }

    /**
     * 既知のファミリー一覧に照らしてフォント名を分解する
     * @param {string} name PostScript 名
     * @returns {object|null} { family, isProportional, isUD, isNT, charset, hasN, weight }。対象外なら null
     */
    function parseKnownFamily(name) {
        for (var i = 0; i < FONT_FAMILIES.length; i++) {
            var family = FONT_FAMILIES[i];
            var matched = name.match(family.regex);
            if (!matched) continue;

            var parsed = {
                family: family,
                isProportional: false,
                isUD: false,
                isNT: false,
                charset: "",
                hasN: false,
                weight: ""
            };

            // 最後のグループをウエイト、それ以外は値で判別 / Last group is the weight; others by value
            var lastIndex = matched.length - 1;
            parsed.weight = matched[lastIndex];

            for (var groupIndex = 1; groupIndex < lastIndex; groupIndex++) {
                var groupValue = matched[groupIndex];
                if (!groupValue) continue;
                if (groupValue === "P") parsed.isProportional = true;
                else if (groupValue === "UD") parsed.isUD = true;
                else if (groupValue === "NT") parsed.isNT = true;
                else if (groupValue === "N") parsed.hasN = true;
                else if (groupValue === "Pro" || groupValue === "Pr5" || groupValue === "Pr6" || groupValue === "Std") parsed.charset = groupValue;
            }
            return parsed;
        }
        return null;
    }

    /**
     * 設定に従って変換後の名前（ウエイトより前）を組み立てる
     * @param {object} parsed parseKnownFamily の結果
     * @returns {string|null} 末尾が「-」の名前。CID を変換しないときは null
     */
    function buildConvertedNameHead(parsed) {
        var family = parsed.family;
        var supportsProportional = family.regex.source.indexOf("(P)") !== -1;
        var supportsUD = family.regex.source.indexOf("(UD)") !== -1;
        var isCID = (parsed.charset === "");

        // CID（文字セット表記なし）の扱い / Handle CID (no charset token)
        if (isCID && !CONVERT_CID_TO_OTF) {
            return null; // 変換しない
        }

        // 文字セット / Character set
        var charset;
        if (charsetMode !== "keep") {
            charset = charsetMode;
        } else if (isCID) {
            charset = CID_FALLBACK_CHARSET; // 現状維持かつ CID なら Pr6 を補完
        } else {
            charset = parsed.charset;
        }

        // P / Proportional（対応ファミリーのみ）/ Proportional (supported families only)
        var isProportional = parsed.isProportional;
        if (pMode === "on") isProportional = true;
        if (pMode === "off") isProportional = false;
        if (!supportsProportional) isProportional = false;

        // UD（対応ファミリーのみ）/ UD (supported families only)
        var isUD = parsed.isUD;
        if (udMode === "on") isUD = true;
        if (udMode === "off") isUD = false;
        if (!supportsUD) isUD = false;

        // NT（対応ファミリー＝新ゴ のみ）/ NT (only families that support it, i.e. ShinGo)
        var supportsNT = family.regex.source.indexOf("(NT)") !== -1;
        var isNT = parsed.isNT;
        if (ntMode === "on") isNT = true;
        if (ntMode === "off") isNT = false;
        if (!supportsNT) isNT = false;

        // N
        var hasN = parsed.hasN;
        if (nMode === "on") hasN = true;
        if (nMode === "off") hasN = false;

        var prefix = "";
        if (isProportional) prefix += "P";
        if (isUD) prefix += "UD";

        var charsetCore = "";
        if (charset) {
            charsetCore = charset + (hasN ? "N" : "");
        }

        // 基幹名（新ゴは NT 有無を付与）/ Base name (append NT for ShinGo when enabled)
        var baseName = family.baseName + (isNT ? "NT" : "");

        return prefix + baseName + charsetCore + "-";
    }

    /**
     * 同じウエイトが無いとき、WEIGHT_ORDER で近いウエイトを探す（同じ距離なら重い方）
     * @param {string} nameHead 名前のウエイトより前
     * @param {string} weight 求めるウエイト
     * @returns {string|null} 近いウエイト。無ければ null
     */
    function findNearestWeight(nameHead, weight) {
        var weightIndex = indexOfArray(WEIGHT_ORDER, weight);
        if (weightIndex < 0) return null;

        for (var distance = 1; distance < WEIGHT_ORDER.length; distance++) {
            var heavierIndex = weightIndex + distance;
            var lighterIndex = weightIndex - distance;
            if (heavierIndex < WEIGHT_ORDER.length && fontExists(nameHead + WEIGHT_ORDER[heavierIndex])) {
                return WEIGHT_ORDER[heavierIndex];
            }
            if (lighterIndex >= 0 && fontExists(nameHead + WEIGHT_ORDER[lighterIndex])) {
                return WEIGHT_ORDER[lighterIndex];
            }
        }
        return null;
    }

    // =========================================
    // フォント存在判定 / Font availability
    // =========================================

    /**
     * そのフォントがインストールされているかを判定する
     * @param {string} name PostScript 名
     * @returns {boolean} インストールされていれば true
     */
    function fontExists(name) {
        return installedFontByPs.hasOwnProperty(name);
    }

    /**
     * PostScript 名からインストール済みのフォントを取得する
     * @param {string} name PostScript 名
     * @returns {Font|undefined} フォント。見つからなければ undefined
     */
    function getFontObject(name) {
        return installedFontByPs[name];
    }

    // =========================================
    // 確認ダイアログ / Confirmation dialog
    // =========================================

    /**
     * 変更内容のプレビューを表示し、項目ごとに ON/OFF させる
     * @returns {{ok: boolean, selected: Object|null}} 実行したか、チェックが入った変更前の名前の表（キャンセル時は null）
     */
    function showConfirmDialog() {
        var confirmDialog = new Window("dialog", getLabel("confirm.title"));
        setupWindow(confirmDialog, 10);
        /* 一覧が詰まって見えないよう左右だけ少し広げる / Widen only the sides so the list is not cramped */
        confirmDialog.margins.left += 10;
        confirmDialog.margins.right += 10;

        var itemCheckboxes = []; // {checkbox, oldName}

        // 「変更前」列の幅を全項目でそろえ、→ の位置を一定にする / Fix the "before" column width so arrows line up
        var beforeWidth = computeBeforeColumnWidth(confirmDialog, [directChanges, weightSubChanges]);

        // 一覧はスクロール可能なビューポートに入れる（項目が多くてもボタンが画面外に出ない）
        // Put the list in a scrollable viewport so buttons stay on-screen even with many items
        var MAX_LIST_HEIGHT = 380;
        var listGroup = confirmDialog.add("group");
        setupRow(listGroup, "fill", 2);
        listGroup.alignChildren = ["fill", "fill"];

        var viewport = listGroup.add("group");
        viewport.orientation = "column";
        viewport.alignChildren = ["left", "top"];

        var listContent = viewport.add("group");
        listContent.orientation = "column";
        listContent.alignChildren = ["left", "top"];
        listContent.spacing = 4;

        if (directChanges.length > 0) {
            listContent.add("statictext", undefined, getLabel("confirm.willChange"));
            addChangeCheckboxes(listContent, directChanges, itemCheckboxes, beforeWidth);
        }
        if (weightSubChanges.length > 0) {
            listContent.add("statictext", undefined, getLabel("confirm.nearWeight"));
            addChangeCheckboxes(listContent, weightSubChanges, itemCheckboxes, beforeWidth);
        }
        if (missingChanges.length > 0) {
            listContent.add("statictext", undefined, getLabel("confirm.notInstalled"));
            var missingNames = uniqueArray(extractNewFontNames(missingChanges));
            for (var k = 0; k < missingNames.length; k++) {
                listContent.add("statictext", undefined, "　" + missingNames[k]);
            }
        }

        confirmDialog.add("statictext", undefined, getLabel("confirm.prompt"));

        var confirmButtonRow = addButtonRow(confirmDialog);
        var btnConfirmCancel = confirmButtonRow.rightGroup.add("button", undefined, getLabel("button.cancel"), { name: "cancel" });
        var btnRun = confirmButtonRow.rightGroup.add("button", undefined, getLabel("button.run"), { name: "ok" });
        btnConfirmCancel.onClick = function () { confirmDialog.close(0); };
        btnRun.onClick = function () { confirmDialog.close(1); };
        alignRightOnlyButtonRow(confirmButtonRow);

        // 一覧が高すぎる場合だけスクロールバーを付ける / Add a scrollbar only when the list is too tall
        confirmDialog.layout.layout(true);
        if (listContent.size.height > MAX_LIST_HEIGHT) {
            viewport.maximumSize.height = MAX_LIST_HEIGHT;
            viewport.preferredSize.height = MAX_LIST_HEIGHT;

            var listScrollbar = listGroup.add("scrollbar");
            listScrollbar.preferredSize.width = 16;
            listScrollbar.alignment = ["right", "fill"];
            listScrollbar.minvalue = 0;
            listScrollbar.maxvalue = listContent.size.height - MAX_LIST_HEIGHT;
            listScrollbar.value = 0;
            listScrollbar.stepdelta = 24;
            listScrollbar.jumpdelta = MAX_LIST_HEIGHT;

            confirmDialog.layout.layout(true);
            var listBaseTop = listContent.location.y;
            listScrollbar.onChanging = function () {
                listContent.location.y = listBaseTop - this.value;
            };
        }

        if (confirmDialog.show() !== 1) {
            return { ok: false, selected: null };
        }

        // チェックが ON の項目だけ採用 / Keep only checked items
        var selected = {};
        for (var i = 0; i < itemCheckboxes.length; i++) {
            if (itemCheckboxes[i].checkbox.value) {
                selected[itemCheckboxes[i].oldName] = true;
            }
        }
        return { ok: true, selected: selected };
    }

    /**
     * 変更内容 1 件ごとのチェックボックスを追加する
     * @param {object} parent 追加先のコンテナ
     * @param {Array<object>} changes 変更内容
     * @param {Array<object>} itemCheckboxes 収集先の配列
     * @param {number} beforeWidth 「変更前」列の幅（px）
     * @returns {void}
     */
    function addChangeCheckboxes(parent, changes, itemCheckboxes, beforeWidth) {
        for (var i = 0; i < changes.length; i++) {
            var change = changes[i];
            var row = parent.add("group");
            setupRow(row, "left", 4);

            // 「変更前」はチェックボックス。幅を固定して → の位置をそろえる / "Before" is the checkbox; fixed width aligns the arrow
            var checkbox = row.add("checkbox", undefined, toDisplayFontName(change.oldName));
            checkbox.value = true;
            checkbox.preferredSize.width = beforeWidth;

            var afterLabel = "→ " + toDisplayFontName(change.newName);
            if (change.oldWeight) {
                afterLabel += "（" + change.oldWeight + " → " + change.newWeight + "）";
            }
            row.add("statictext", undefined, afterLabel);

            itemCheckboxes.push({ checkbox: checkbox, oldName: change.oldName });
        }
    }

    /**
     * 確認ダイアログ用にフォントの表示名を返す（日本語 UI では和文名）
     * @param {string} psName PostScript 名
     * @returns {string} 表示用の名前。見つからなければ PostScript 名
     */
    function toDisplayFontName(psName) {
        var font = allFontByPs.hasOwnProperty(psName) ? allFontByPs[psName] : null;
        if (!font) return psName;
        try {
            if (uiLang === "ja" && font.fullNameNative) return font.fullNameNative;
            if (font.fullName) return font.fullName;
            return String(font.name).replace("\t", " ");
        } catch (e) {
            return psName;
        }
    }

    /**
     * 「変更前」列の幅をそろえるための最大幅を求める
     * @param {Window} dialog 対象のダイアログ
     * @param {Array<Array<object>>} changeLists 変更内容の配列の配列
     * @returns {number} 列の幅（px）
     */
    function computeBeforeColumnWidth(dialog, changeLists) {
        var graphics = dialog.graphics;
        var maxTextWidth = 0;
        for (var a = 0; a < changeLists.length; a++) {
            var list = changeLists[a];
            for (var i = 0; i < list.length; i++) {
                var displayName = toDisplayFontName(list[i].oldName);
                var textWidth = graphics.measureString(displayName, graphics.font).width;
                if (textWidth > maxTextWidth) maxTextWidth = textWidth;
            }
        }
        return maxTextWidth + 30; // チェックボックスのボックス＋すき間 / checkbox box + gap
    }

    /**
     * 変更内容のうち選ばれたものを変換表に加える
     * @param {Array<object>} changes 変更内容
     * @param {Object} nameMap 変換表（変更前 → 変更後）
     * @param {Object|null} selectedOldNames 選ばれた変更前の名前の表。null ならすべて
     * @returns {void}
     */
    function addSelectedChanges(changes, nameMap, selectedOldNames) {
        for (var i = 0; i < changes.length; i++) {
            var change = changes[i];
            if (selectedOldNames === null || selectedOldNames[change.oldName]) {
                nameMap[change.oldName] = change.newName;
            }
        }
    }

    /**
     * 変更後のフォント名を集める（重複はそのまま）
     * @param {Array<object>} changes 変更内容
     * @returns {Array<string>} フォント名の配列
     */
    function extractNewFontNames(changes) {
        var newNames = [];
        for (var i = 0; i < changes.length; i++) {
            newNames.push(changes[i].newName);
        }
        return newNames;
    }

    // =========================================
    // 適用 / Apply
    // =========================================

    /**
     * 1 つの対象テキストへフォント変更を適用する
     * @param {object} target 対象テキスト
     * @param {Object} nameMap 変換表（変更前 → 変更後）
     * @returns {number} 変更があれば 1、なければ 0
     */
    function applyChangesToTarget(target, nameMap) {
        var ranges = target.ranges;
        var fonts = appliedFontsOf(ranges);
        var clip = target.clip;
        var clipStart, clipEnd;
        if (clip) {
            try {
                clipStart = clip.first.index;
                clipEnd = clip.last.index;
            } catch (eClip) { return 0; }
        }

        // 先に各区切りの最初と最後の文字を控える（適用で textStyleRange が組み直されても安全）。
        // 文字は getElements() で解決した参照にし、ストーリー・セル・脚注それぞれの中の位置で持つ
        // Record each range's first and last characters up front, resolved with getElements() so they stay
        // valid while ranges are rebuilt, and positioned within their own story, cell or footnote.
        var jobs = [];
        for (var i = 0; i < fonts.length; i++) {
            var psName = fontPsNameOf(fonts[i]);
            if (!psName) continue;
            var newName = nameMap[psName];
            if (!newName) continue;

            var firstChar, lastChar;
            try {
                var chars = ranges[i].characters;
                if (chars.length === 0) continue;
                firstChar = chars.firstItem().getElements()[0];
                lastChar = chars.lastItem().getElements()[0];
                if (clip) {
                    // 選択の外へはみ出した分を切り詰める / Trim the part outside the selection
                    if (firstChar.index < clipStart) firstChar = clip.first;
                    if (lastChar.index > clipEnd) lastChar = clip.last;
                    if (firstChar.index > lastChar.index) continue;
                }
            } catch (e) { continue; }

            jobs.push({ first: firstChar, last: lastChar, font: getFontObject(newName) });
        }
        if (jobs.length === 0) return 0;

        // ロックを一時解除 / Temporarily unlock
        var savedLocked = unlockFramesFor(target);

        var changed = false;
        // 途中でエラーが出てもロックを確実に戻すため try/finally で囲む / Wrap in try/finally so locks are always restored
        try {
            for (var j = 0; j < jobs.length; j++) {
                try {
                    // 文字の親（ストーリー・セル・脚注）の characters で範囲を作る / Build the range on the characters of the owning story, cell or footnote
                    jobs[j].first.parent.characters.itemByRange(jobs[j].first, jobs[j].last).appliedFont = jobs[j].font;
                    changed = true;
                } catch (e3) { }
            }
        } finally {
            // ロック状態を復元 / Restore lock states
            restoreLocks(savedLocked);
        }

        // テキストオブジェクト（ストーリー）単位でカウント / Count per story
        return changed ? 1 : 0;
    }

    /**
     * 対象のフレーム・レイヤー・親グループのロックを一時解除する（includeLocked がオンのときだけ）
     * @param {object} target 対象テキスト
     * @returns {Array<object>} 解除したもの（restoreLocks に渡す）
     */
    function unlockFramesFor(target) {
        var saved = [];
        if (!includeLocked) return saved;
        for (var i = 0; i < target.frames.length; i++) {
            var frame = target.frames[i];
            pushUnlock(frame, saved);
            try { pushUnlock(frame.itemLayer, saved); } catch (e) { }
            var parent;
            try { parent = frame.parent; } catch (e2) { parent = null; }
            while (parent) {
                var typeName;
                try { typeName = parent.constructor.name; } catch (e3) { break; }
                if (typeName !== "Group") break;
                pushUnlock(parent, saved);
                try { parent = parent.parent; } catch (e4) { break; }
            }
        }
        return saved;
    }

    /**
     * ロックされていれば解除して記録する
     * @param {object} container フレーム・レイヤー・グループ
     * @param {Array<object>} saved 記録先
     * @returns {void}
     */
    function pushUnlock(container, saved) {
        try {
            if (container.locked) {
                container.locked = false;
                saved.push(container);
            }
        } catch (e) { }
    }

    /**
     * 一時解除したロックを元に戻す
     * @param {Array<object>} saved unlockFramesFor の戻り値
     * @returns {void}
     */
    function restoreLocks(saved) {
        for (var i = 0; i < saved.length; i++) {
            try { saved[i].locked = true; } catch (e) { }
        }
    }

    /**
     * 段落・文字スタイルへフォント変更を適用する
     * @param {Array<ParagraphStyle|CharacterStyle>} styles 対象のスタイル
     * @param {Object} nameMap 変換表（変更前 → 変更後）
     * @returns {void}
     */
    function applyChangesToStyles(styles, nameMap) {
        for (var k = 0; k < styles.length; k++) {
            var psName = styleFontPsName(styles[k]);
            if (!psName) continue;
            var newName = nameMap[psName];
            if (!newName) continue;
            try {
                styles[k].appliedFont = getFontObject(newName);
            } catch (e) { }
        }
    }

    /**
     * 合成フォントの各エントリへフォント変更を適用する
     * @param {Object} nameMap 変換表（変更前 → 変更後）
     * @returns {void}
     */
    function applyChangesToCompositeFonts(nameMap) {
        var compositeFonts = activeDocument.compositeFonts;
        for (var c = 0; c < compositeFonts.length; c++) {
            var entries = compositeFonts[c].compositeFontEntries;
            for (var e = 0; e < entries.length; e++) {
                var psName = styleFontPsName(entries[e]);
                if (!psName) continue;
                var newName = nameMap[psName];
                if (!newName) continue;
                try {
                    entries[e].appliedFont = getFontObject(newName);
                } catch (eApply) { }
            }
        }
    }

    // =========================================
    // ユーティリティ / Utilities
    // =========================================

    /**
     * ラベル付きのパネルを追加する
     * @param {object} parent 追加先のコンテナ
     * @param {string} labelPath パネル名のラベルキー
     * @param {number} [spacing] 要素間隔（省略時は PANEL_SPACING）
     * @returns {Panel} 追加したパネル
     */
    function addPanel(parent, labelPath, spacing) {
        var panel = parent.add("panel", undefined, getLabel(labelPath));
        setupPanel(panel, spacing);
        return panel;
    }

    /**
     * 3 択ラジオ（現状維持／なし／あり）の選択値を取得する
     * @param {RadioButton} onRadio 「あり」のラジオ
     * @param {RadioButton} offRadio 「なし」のラジオ
     * @returns {string} 選択値
     */
    function radioMode(onRadio, offRadio) {
        if (onRadio.value) return "on";
        if (offRadio.value) return "off";
        return "keep";
    }

    /**
     * 配列内で値が現れる位置を探す
     * @param {Array} arr 対象の配列
     * @param {*} value 探す値
     * @returns {number} 見つかった位置。なければ -1
     */
    function indexOfArray(arr, value) {
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] === value) return i;
        }
        return -1;
    }

    /**
     * 配列から重複を取り除く
     * @param {Array} arr 対象の配列
     * @returns {Array} 重複を除いた配列
     */
    function uniqueArray(arr) {
        var seen = {};
        var unique = [];
        for (var i = 0; i < arr.length; i++) {
            if (!seen[arr[i]]) {
                seen[arr[i]] = true;
                unique.push(arr[i]);
            }
        }
        return unique;
    }

})();
