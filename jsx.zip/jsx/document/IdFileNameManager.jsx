#target indesign

/*
SCRIPTMETA-BEGIN
Script-ID=com.swwwitch.indesign.IdFileNameManager
Name=ファイル名をセグメント単位で編集してリネーム・保存
Author=Masahiro Takano (@swwwitch)
Target-App=InDesign
Version=1.3.10
Release-Date=2026-05-27
Description-BEGIN
アクティブなドキュメントのファイル名を、ベース・サブテキスト・ステータス・日付・連番・バージョンのセグメント単位で編集し、リネーム／別名保存／コピー保存を行います。
保存形式は常に InDesign 形式（.indd）なので、.indd 以外の書類では「別名で保存」だけが使えます。

Edits the active document's file name segment by segment - base, subtext, status, date, sequence number and version - then renames it, saves it under a new name, or saves a copy.
The output is always InDesign format (.indd), so only "Save As" is available for a non-.indd document.
Description-END
SCRIPTMETA-END
*/

/*

### 概要

アクティブなドキュメントのファイル名を、ベース・サブテキスト・ステータス・日付・連番・バージョンのセグメント単位で編集し、リネーム／別名保存／コピー保存を行います。
保存形式は常に InDesign 形式（.indd）なので、.indd 以外の書類では「別名で保存」だけが使えます。

詳細は README を参照してください。
https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdFileNameManager.md

note記事も参照してください。
https://note.com/dtp_tranist/n/nc88dd887eb1c

### Overview

Edits the active document's file name segment by segment - base, subtext, status, date, sequence number and version - then renames it, saves it under a new name, or saves a copy.
The output is always InDesign format (.indd), so only "Save As" is available for a non-.indd document.

See the README for details.
https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdFileNameManager.md

*/

// =========================================
// 基本情報 / Basic info
// =========================================
var SCRIPT_NAME     = "IdFileNameManager";            /* スクリプト名 / script name */
var SCRIPT_VERSION  = "v1.3.10";                       /* バージョン / version */
var SCRIPT_AUTHOR   = "Masahiro Takano (@swwwitch)";  /* 作者 / author */
var SCRIPT_RELEASED = "2026-05-27";                   /* 最初のリリース日 / first release date */
var SCRIPT_UPDATED  = "2026-11-20";                   /* 更新日 / last updated */

var SCRIPT_DESCRIPTION_JA = "ファイル名をセグメント単位で編集してリネーム・保存"; /* README の見出し / README title (Japanese) */

var SCRIPT_README_JA   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-ja/IdFileNameManager.md"; /* README（日本語） */
var SCRIPT_README_EN   = "https://github.com/swwwitch/indesign-scripts/blob/main/readme-en/IdFileNameManager.md"; /* README (English) */
var SCRIPT_ARTICLE_URL = "https://note.com/dtp_tranist/n/nc88dd887eb1c"; /* 紹介記事 / article URL */
var SCRIPT_SOURCE_URL  = "https://github.com/swwwitch/indesign-scripts/blob/main/jsx/document/IdFileNameManager.jsx"; /* 最新版のソース / latest source */

// Released under the MIT license
// http://opensource.org/licenses/mit-license.php

    (function () {

        /* ファイルの保存・リネーム・削除はドキュメント編集ではなく InDesign の取り消し対象外のため、
           doScript でのラップは行わない
           / Saving, renaming and deleting files are file-system operations outside InDesign's undo,
             so this script is not wrapped in doScript */

        // =========================================
        // ユーザー設定 / User Settings
        // =========================================

        /* 整形機能のオン/オフ。false にすると該当 UI とロジックを丸ごとスキップ
           / Feature switches. Set to false to omit the UI and skip the logic */
        var FEATURE_STATUS = true;        // ステータス dropdown と検出 / Status dropdown + detection
        var FEATURE_SORT = true;          // ソートパネル + 並び順カスタマイズ / Sort panel + custom segment order
        var FEATURE_SEPARATOR = '-';      // 区切り記号統一: '-' / '_' で有効化＋既定値、false で無効 / '-' or '_' enables with that default; false disables
        var FEATURE_DOT_NORMALIZE = true; // "." を区切り記号にあわせて置換（要 FEATURE_SEPARATOR） / "." normalization with the chosen separator
        var FEATURE_NFC = true;           // 濁点・半濁点の NFC 結合 / Combine separated dakuten/handakuten (NFC)
        var FEATURE_CLEAN = true;         // クリーンなファイル名（OS 禁止文字 + 絵文字・機種依存文字の処理） / Clean filename (OS-invalid + emoji + platform-dependent)
        var FEATURE_TRANSLITERATE = true; // 法人略記・丸数字などを ASCII 相当に変換 / Transliterate corp abbrev / circled numbers / etc.
        var FEATURE_HALFWIDTH_KANA = true; // 半角カナ → 全角カナ変換（クリーンが '-' / '_' のときのみ有効） / Halfwidth-kana → fullwidth (active only when Clean is '-' or '_')
        var FEATURE_PAGE = true;          // 連番（pageNN）セグメント / Page-number segment (pageNN)

        /* ファイル名（拡張子込み）の UTF-8 バイト長の上限。超過時は確認ダイアログを出して続行可
           / Max UTF-8 byte length of the basename + extension; exceeding it triggers a confirm dialog */
        var FEATURE_MAX_FILENAME_BYTES = 240;

        /* rename モードで元ファイルを削除するときに、即削除ではなく ~/.Trash に移動
           / In rename mode, move the original to ~/.Trash instead of removing it outright */
        var FEATURE_USE_TRASH = true;

        /* 文字 → 置換文字列のマップ。法人略記、丸数字（白・黒・括弧）、ローマ数字、略記号、単位、ダッシュ類
           / Char → replacement map: corporate abbrev, circled (white/black/parenthesized), Roman numerals, abbrev symbols, units, dashes */
        var TRANSLITERATE_MAP = {
            // 法人略記
            '㈱': '株', '㈲': '有', '㈹': '代', '㈳': '社',
            '㈵': '特', '㈶': '財', '㈻': '学', '㍿': '株式会社',
            // 白丸数字 ①-⑳ (U+2460-U+2473)
            '①': '1', '②': '2', '③': '3', '④': '4', '⑤': '5',
            '⑥': '6', '⑦': '7', '⑧': '8', '⑨': '9', '⑩': '10',
            '⑪': '11', '⑫': '12', '⑬': '13', '⑭': '14', '⑮': '15',
            '⑯': '16', '⑰': '17', '⑱': '18', '⑲': '19', '⑳': '20',
            // 黒丸数字 ❶-❿ (U+2776-U+277F) + ⓫-⓴ (U+24EB-U+24F4)
            '❶': '1', '❷': '2', '❸': '3', '❹': '4', '❺': '5',
            '❻': '6', '❼': '7', '❽': '8', '❾': '9', '❿': '10',
            '⓫': '11', '⓬': '12', '⓭': '13', '⓮': '14', '⓯': '15',
            '⓰': '16', '⓱': '17', '⓲': '18', '⓳': '19', '⓴': '20',
            // 括弧数字 ⑴-⒇ (U+2474-U+2487)
            '⑴': '1', '⑵': '2', '⑶': '3', '⑷': '4', '⑸': '5',
            '⑹': '6', '⑺': '7', '⑻': '8', '⑼': '9', '⑽': '10',
            '⑾': '11', '⑿': '12', '⒀': '13', '⒁': '14', '⒂': '15',
            '⒃': '16', '⒄': '17', '⒅': '18', '⒆': '19', '⒇': '20',
            // ローマ数字 大文字 Ⅰ-Ⅻ (U+2160-U+216B)
            'Ⅰ': '1', 'Ⅱ': '2', 'Ⅲ': '3', 'Ⅳ': '4', 'Ⅴ': '5',
            'Ⅵ': '6', 'Ⅶ': '7', 'Ⅷ': '8', 'Ⅸ': '9', 'Ⅹ': '10',
            'Ⅺ': '11', 'Ⅻ': '12',
            // ローマ数字 小文字 ⅰ-ⅻ (U+2170-U+217B)
            'ⅰ': '1', 'ⅱ': '2', 'ⅲ': '3', 'ⅳ': '4', 'ⅴ': '5',
            'ⅵ': '6', 'ⅶ': '7', 'ⅷ': '8', 'ⅸ': '9', 'ⅹ': '10',
            'ⅺ': '11', 'ⅻ': '12',
            // 略記号
            '℡': 'TEL', '№': 'No',
            // 単位記号
            '㎜': 'mm', '㎝': 'cm', '㎞': 'km',
            '㎎': 'mg', '㎏': 'kg',
            '㎡': 'm2', '㎥': 'm3',
            // チルダ類
            '〜': '~', '～': '~',  // 〜 WAVE DASH / ～ FULLWIDTH TILDE
            // ハイフン・ダッシュ類
            '－': '-',  // － FULLWIDTH HYPHEN-MINUS
            '‐': '-',  // ‐ HYPHEN
            '‑': '-',  // ‑ NON-BREAKING HYPHEN
            '‒': '-',  // ‒ FIGURE DASH
            '–': '-',  // – EN DASH
            '—': '-',  // — EM DASH
            '―': '-',  // ― HORIZONTAL BAR
            '−': '-'   // − MINUS SIGN
        };

        /* 出力時のセグメント順序。base / title / status / timestamp / page / version。
           FEATURE_STATUS=false なら status を、FEATURE_PAGE=false なら page を除外
           / Output segment order; "status" / "page" are dropped when their FEATURE_* flags are false */
        var SEGMENT_ORDER = (function () {
            var order = ['base', 'title'];
            if (FEATURE_STATUS) order.push('status');
            order.push('timestamp');
            if (FEATURE_PAGE) order.push('page');
            order.push('version');
            return order;
        })();

        /* ステータス選択肢。value がファイル名に入り、ja / en が UI 表示。先頭は「なし」。
           ja が '---' の項目は dropdown 上の区切り線として表示（選択不可）
           / Status choices: `value` is what enters the filename; `ja` / `en` are UI labels.
           Items with `ja === '---'` render as an unselectable divider. */
        var STATUS_ITEMS = [
            { value: '', ja: 'なし', en: 'None' },
            { value: 'wip', ja: 'wip：作業中・仕掛かり中', en: 'wip: Work in progress' },
            { value: 'draft', ja: 'draft：下書き・ラフ・素案', en: 'draft: Draft / Rough' },
            { value: 'review', ja: 'review：レビュー待ち', en: 'review: Awaiting review' },
            { value: 'revised', ja: 'revised：改訂版・修正反映版', en: 'revised: Revised' },
            { value: 'updated', ja: 'updated：更新版', en: 'updated: Updated' },
            { value: 'fixed', ja: 'fixed：修正完了', en: 'fixed: Fix completed' },
            { value: 'approved', ja: 'approved：承認済み・確定', en: 'approved: Approved / Final' },
            { value: 'rejected', ja: 'rejected：ボツ・不採用案', en: 'rejected: Rejected' },
            { value: 'archived', ja: 'archived：保管用', en: 'archived: Archive' },
            { value: '', ja: '---', en: '---' },
            { value: 'flattened', ja: 'flattened：レイヤー結合済み（.psd）', en: 'flattened: Flattened (.psd)' },
            { value: 'outlined', ja: 'outlined：アウトライン済み（.ai）', en: 'outlined: Outlined (.ai)' }
        ];

        /**
         * ステータス表記の区切り文字かどうかを判定する
         * @param {object} item STATUS_ITEMS の要素
         * @returns {boolean} 区切り線なら true
         */
        function isStatusDivider(item) {
            return item && item.ja === '---';
        }

        var NEW_NAME_FIELD_WIDTH = 250;

        var DIALOG_OPACITY = 0.98;

        // =========================================
        // ローカライズ / Localization
        // =========================================

        // ローカライズ（再利用パーツ） / Localization (reusable)

        /**
         * UI の言語を返す（"ja" で始まるロケールは日本語、それ以外は英語）
         * @returns {string} "ja" または "en"
         */
        function getCurrentLang() {
            return (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en";
        }

        var uiLang = getCurrentLang();

        /**
         * LABELS から今の UI 言語の文言を取り出す。
         * @param {string|Object} labelRef - "dialog.title" のようなパス、または { ja, en }
         * @param {Object|Array} [placeholderValues] - { name: 値 } なら {name} を、[値, …] なら %1, %2 … を差し込む
         * @returns {string} 文言。パスが見つからなければパスの文字列、{ ja, en } が無ければ空文字
         */
        function getLabel(labelRef, placeholderValues) {
            var labelEntry = labelRef;
            if (typeof labelRef === "string") {
                var labelPathKeys = labelRef.split(".");
                labelEntry = LABELS;
                for (var i = 0; i < labelPathKeys.length && labelEntry != null; i++) {
                    labelEntry = labelEntry[labelPathKeys[i]];
                }
            }
            var labelString;
            if (typeof labelEntry === "string") labelString = labelEntry;
            else if (labelEntry != null && labelEntry[uiLang] != null) labelString = labelEntry[uiLang];
            else if (labelEntry != null && labelEntry.en != null) labelString = labelEntry.en;
            else return (typeof labelRef === "string") ? labelRef : "";
            return fillLabelPlaceholders(String(labelString), placeholderValues);
        }

        /**
         * 項目名の文言の末尾にコロンを付ける（日本語は半角スペース＋半角コロン「 :」、英語は「:」。Illustrator の線パネルなどの項目名に合わせる）
         * @param {string|Object} labelRef - getLabel と同じ
         * @param {Object|Array} [placeholderValues] - getLabel と同じ
         * @returns {string} コロン付きの文言
         */
        function labelText(labelRef, placeholderValues) {
            return getLabel(labelRef, placeholderValues) + (uiLang === "ja" ? " :" : ":");
        }

        /**
         * 「項目名 : 値」の1行を返す（日本語は「件数 : 5」、英語は「Count: 5」。どちらもコロンのあとに空白を入れる）
         * @param {string|Object} labelRef - getLabel と同じ
         * @param {string|number} value - コロンのあとに続ける値
         * @returns {string} 項目名と値をつないだ文字列
         */
        function labelValueText(labelRef, value) {
            return labelText(labelRef) + " " + value;
        }

        /**
         * 文言の {name} や %1 に値を差し込む
         * @param {string} labelString - 文言
         * @param {Object|Array} [placeholderValues] - { name: 値 } または [値, …]
         * @returns {string} 差し込んだ文言
         */
        function fillLabelPlaceholders(labelString, placeholderValues) {
            if (placeholderValues == null) return labelString;
            if (placeholderValues instanceof Array) {
                /* 大きい番号から置き換え、%1 が %10 の一部を置き換えないようにする / Replace from the highest index so %1 does not eat into %10 */
                for (var i = placeholderValues.length; i >= 1; i--) {
                    labelString = labelString.split("%" + i).join(String(placeholderValues[i - 1]));
                }
                return labelString;
            }
            for (var placeholderKey in placeholderValues) {
                if (!placeholderValues.hasOwnProperty(placeholderKey)) continue;
                labelString = labelString.split("{" + placeholderKey + "}").join(String(placeholderValues[placeholderKey]));
            }
            return labelString;
        }

        // ローカライズ（再利用パーツ）ここまで / End of the reusable localization

        // =========================================
        // UIレイアウトの共通設定 / Shared UI layout
        // =========================================

        // UIレイアウト（再利用パーツ） / UI layout (reusable)

        /* ウィンドウ・パネルの余白と間隔 / Window & panel margins and spacing */
        var WINDOW_MARGINS = 16;                 /* ウィンドウ外周の余白 / window margin */
        var WINDOW_SPACING = 12;                 /* ウィンドウ内の要素間隔 / window spacing */
        var PANEL_MARGINS  = [16, 20, 16, 12];   /* パネル余白 [左,上,右,下] / panel margins */
        var PANEL_SPACING  = 12;                 /* パネル内の要素間隔 / panel spacing */
        var COLUMN_SPACING = 12;                 /* 2カラムの間隔 / gap between columns */
        var TAB_MARGINS    = [15, 20, 5, 10];    /* タブ余白 [左,上,右,下] / tab margins */

        /**
         * ウィンドウの共通設定
         * @param {Window} targetWindow - 対象のウィンドウ
         * @param {number} [spacing] - 要素間隔（省略時は WINDOW_SPACING）
         * @returns {void}
         */
        function setupWindow(targetWindow, spacing) {
            targetWindow.orientation = "column";
            targetWindow.alignChildren = "fill";
            targetWindow.margins = WINDOW_MARGINS;
            targetWindow.spacing = (typeof spacing === "number") ? spacing : WINDOW_SPACING;
        }

        /**
         * パネルの共通設定（子は幅いっぱい。ボタンは alignment = "left" で広げない）
         * @param {Panel} targetPanel - 対象のパネル
         * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
         * @returns {void}
         */
        function setupPanel(targetPanel, spacing) {
            targetPanel.orientation = "column";
            targetPanel.alignChildren = ["fill", "top"];
            targetPanel.alignment = "fill";
            targetPanel.margins = PANEL_MARGINS;
            targetPanel.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
        }

        /**
         * タブの共通設定
         * @param {Tab} targetTab - 対象のタブ
         * @param {number} [spacing] - 要素間隔（省略時は変えない）
         * @returns {void}
         */
        function setupTab(targetTab, spacing) {
            targetTab.orientation = "column";
            targetTab.alignChildren = "fill";
            targetTab.margins = TAB_MARGINS;
            if (typeof spacing === "number") targetTab.spacing = spacing;
        }

        /**
         * 横並びの行グループの共通設定（ボタン列など）。
         * alignment と alignChildren を対で指定し、中のボタンが横に伸びたり天地がずれたりしないようにする
         * @param {Group} rowGroup - 対象のグループ
         * @param {string|string[]} [rowAlignment] - 横方向の alignment（省略時は "left"）。配列ならそのまま使う
         * @param {number} [spacing] - 要素間隔（省略時は PANEL_SPACING）
         * @returns {void}
         */
        function setupRow(rowGroup, rowAlignment, spacing) {
            rowGroup.orientation = "row";
            rowGroup.alignment = (rowAlignment instanceof Array) ? rowAlignment : [rowAlignment || "left", "center"];
            rowGroup.alignChildren = ["left", "center"];
            rowGroup.spacing = (typeof spacing === "number") ? spacing : PANEL_SPACING;
        }

        /**
         * ボタンの高さを指定した px だけ詰める（レイアウトが決まったあとに呼ぶ）
         * @param {Button} targetButton - 対象のボタン
         * @param {number} trimPixels - 詰める量（px）
         * @returns {void}
         */
        function trimButtonHeight(targetButton, trimPixels) {
            /* レイアウト前は size が無い / size is not set until the layout runs */
            if (!targetButton.size) return;
            targetButton.size = [targetButton.size.width, targetButton.size.height - trimPixels];
        }

        // UIレイアウト（再利用パーツ）ここまで / End of the reusable UI layout

        // ボタン行（再利用パーツ） / Button row (reusable)

        var BUTTON_ROW_TOP_MARGIN = 5; /* ボタン行の上の余白 / top margin of the button row */
        var BUTTON_ROW_BOTTOM_MARGIN = 14; /* ボタン行の下の余白。ダイアログの下余白と合わせて約30px（Illustrator 標準のダイアログに合わせる） / bottom margin; with the dialog margin about 30px, like Illustrator's own dialogs */
        var BUTTON_ROW_SPACING = 10;   /* ボタンどうしの間隔 / spacing between buttons */
        var BUTTON_ROW_CENTER_MAX_WIDTH = 240; /* 右のボタンだけの行を中央に置く、ダイアログの内側の最大幅（px、左右の余白を除く）。広いダイアログは右揃え / max inner dialog width (px, margins excluded) that centers a right-only row; wider dialogs keep it right-aligned */

        /**
         * ダイアログ下部のボタン行を作る。
         * 通常は「左のグループ・伸びるスペーサー・右のグループ」、centered なら行そのものを左右中央に置く
         * @param {Window|Group|Panel} parent - 行を足す先（ふつうはダイアログ）
         * @param {Object} [rowOptions] - { centered: true } で左右中央に並べる
         * @returns {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} 行と左右のグループ（centered のときは左右が null）
         */
        function addButtonRow(parent, rowOptions) {
            var isCentered = !!(rowOptions && rowOptions.centered);
            var btnRowGroup = parent.add("group");
            btnRowGroup.orientation = "row";
            btnRowGroup.margins = [0, BUTTON_ROW_TOP_MARGIN, 0, BUTTON_ROW_BOTTOM_MARGIN];
            btnRowGroup.spacing = BUTTON_ROW_SPACING;

            if (isCentered) {
                btnRowGroup.alignment = ["center", "bottom"];
                btnRowGroup.alignChildren = ["center", "center"];
                return { rowGroup: btnRowGroup, leftGroup: null, rightGroup: null };
            }

            btnRowGroup.alignment = ["fill", "bottom"];

            var btnLeftGroup = btnRowGroup.add("group");
            btnLeftGroup.alignChildren = ["left", "center"];
            btnLeftGroup.spacing = BUTTON_ROW_SPACING;

            /* 余りの幅を吸って、右のグループを右端に寄せる / Absorbs the extra width so the right group sits at the right edge */
            var spacer = btnRowGroup.add("group");
            spacer.alignment = ["fill", "fill"];
            spacer.minimumSize.width = 0;

            var btnRightGroup = btnRowGroup.add("group");
            btnRightGroup.alignChildren = ["right", "center"];
            btnRightGroup.spacing = BUTTON_ROW_SPACING;

            return { rowGroup: btnRowGroup, leftGroup: btnLeftGroup, rightGroup: btnRightGroup };
        }

        /**
         * 左のグループにボタンが無い（右のボタンだけの）行を、ダイアログの幅に合わせて揃える。
         * 内側の幅（左右の余白を除く）が BUTTON_ROW_CENTER_MAX_WIDTH 以下なら左右中央、それより広ければ右揃えのまま。
         * 幅はレイアウトが決まるまで分からないので、ダイアログを表示した時点（show イベント）で判定する。
         * ボタンをすべて足したあと、show() の前に呼ぶ。centered で作った行や、左にボタンがある行はそのまま
         * @param {{rowGroup: Group, leftGroup: Group|null, rightGroup: Group|null}} buttonRow - addButtonRow() の戻り値
         * @returns {void}
         */
        function alignRightOnlyButtonRow(buttonRow) {
            if (!buttonRow.leftGroup || buttonRow.leftGroup.children.length > 0) return;
            var dialogWindow = buttonRow.rowGroup.window;
            dialogWindow.addEventListener("show", function () {
                if (!buttonRow.leftGroup) return;
                var btnRowGroup = buttonRow.rowGroup;
                /* 行の幅＝ダイアログの内側の幅（左右の余白を除く）/ The row spans the dialog's inner width (margins excluded) */
                if (!btnRowGroup.size || btnRowGroup.size.width > BUTTON_ROW_CENTER_MAX_WIDTH) return;
                /* 左のグループとスペーサーを外し、右のグループだけを中央に置く / Drop the left group and the spacer so only the right group remains, centered */
                btnRowGroup.remove(buttonRow.leftGroup);
                btnRowGroup.remove(btnRowGroup.children[0]); /* 左のグループを外すと先頭はスペーサー / the spacer is first once the left group is gone */
                btnRowGroup.alignment = ["center", "bottom"];
                btnRowGroup.alignChildren = ["center", "center"];
                buttonRow.leftGroup = null;
                dialogWindow.layout.layout(true);
            });
        }

        // ボタン行（再利用パーツ）ここまで / End of the reusable button row

        // UI の明暗（再利用パーツ） / UI theme (reusable)

        /**
         * UI がダークテーマかどうかを判定する（Illustrator は uiBrightness、InDesign は uiBrightnessPreference）
         * @returns {boolean} ダークなら true。取得できない環境では false（明るいUI扱い）
         */
        function isDarkUI() {
            try {
                if (app.preferences && app.preferences.getRealPreference) {
                    return app.preferences.getRealPreference("uiBrightness") <= 0.5; /* Illustrator */
                }
                return app.generalPreferences.uiBrightnessPreference <= 0.5; /* InDesign */
            } catch (e) {
                return false;
            }
        }

        // UI の明暗（再利用パーツ）ここまで / End of the reusable UI theme

        // バージョン表示（再利用パーツ） / Version footer (reusable)

        var VERSION_FOOTER_TOP_MARGIN = 4;    /* バージョンの行の上に足す余白（px。ウィンドウの間隔に足す）/ extra space above the version row, added to the window spacing */
        var VERSION_FOOTER_BOTTOM_MARGIN = 8; /* バージョンの行の下の余白（px。ウィンドウの下余白をこの値にする）/ space below the version row (replaces the window's bottom margin) */
        var VERSION_FOOTER_PIXEL_SIZE = 1;    /* ドット1つの大きさ（px）/ size of one dot (px) */
        var VERSION_FOOTER_LETTER_GAP = 1;    /* 字の間（ドット）/ gap between glyphs (dots) */
        var VERSION_FOOTER_BRAND = "DTP Transit"; /* 右下に出す名前（字形にある文字だけ）/ name shown at the bottom right (glyph characters only) */
        var VERSION_FOOTER_COLOR = isDarkUI() ? [0.45, 0.45, 0.45, 1] : [0.62, 0.62, 0.62, 1]; /* 文字の色（ディム表示に近い灰色）/ text color, a gray close to the dimmed look */

        /* 字形：Sigi 7px Regular（Rasmus Andersson、CC0。https://github.com/rsms/sigi-pixel-font）の大文字・数字・「. - _ +」・空白を
           9 行のドット（# が点。上7行が大文字の高さ、下2行は小文字の下に出る部分）に写したもの。Sigi に小文字が無いので、a〜z は同じ大きさで描き足した。I は l と見分けるよう上下に横棒を足した
           / Glyphs: uppercase, digits, ". - _ +" and space from Sigi 7px Regular by Rasmus Andersson (CC0, https://github.com/rsms/sigi-pixel-font),
             nine rows each ("#" is a dot; seven rows of cap height plus two for descenders). Sigi has no lowercase, so a-z were drawn to match. I has top and bottom bars to tell it from l */
        var VERSION_FOOTER_GLYPH_HEIGHT = 9;  /* 字の高さ（ドット。下2行は g・j・p・q・y の下に出る部分）/ glyph height (dots), including two descender rows */
        var VERSION_FOOTER_GLYPHS = {
            "A": [".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
            "B": ["####.", "#...#", "#...#", "####.", "#...#", "#...#", "####.", ".....", "....."],
            "C": [".###.", "#...#", "#....", "#....", "#....", "#...#", ".###.", ".....", "....."],
            "D": ["####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####.", ".....", "....."],
            "E": ["#####", "#....", "#....", "####.", "#....", "#....", "#####", ".....", "....."],
            "F": ["#####", "#....", "#....", "####.", "#....", "#....", "#....", ".....", "....."],
            "G": [".###.", "#...#", "#....", "#..##", "#...#", "#...#", ".###.", ".....", "....."],
            "H": ["#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#", ".....", "....."],
            "I": ["###", ".#.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
            "J": ["....#", "....#", "....#", "....#", "....#", "#...#", ".###.", ".....", "....."],
            "K": ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#", ".....", "....."],
            "L": ["#...", "#...", "#...", "#...", "#...", "#...", "####", "....", "...."],
            "M": ["#...#", "##.##", "#.#.#", "#...#", "#...#", "#...#", "#...#", ".....", "....."],
            "N": ["#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#", ".....", "....."],
            "O": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
            "P": ["####.", "#...#", "#...#", "####.", "#....", "#....", "#....", ".....", "....."],
            "Q": [".###.", "#...#", "#...#", "#...#", "#...#", "#..##", ".####", ".....", "....."],
            "R": ["####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#", ".....", "....."],
            "S": [".###.", "#...#", "#....", ".###.", "....#", "#...#", ".###.", ".....", "....."],
            "T": ["#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
            "U": ["#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
            "V": ["#...#", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", "..#..", ".....", "....."],
            "W": ["#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", "#..#..#", ".##.##.", ".......", "......."],
            "X": ["#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#", ".....", "....."],
            "Y": ["#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#..", ".....", "....."],
            "Z": ["#####", "....#", "...#.", "..#..", ".#...", "#....", "#####", ".....", "....."],
            "a": ["....", "....", ".##.", "...#", ".###", "#..#", ".###", "....", "...."],
            "b": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "###.", "....", "...."],
            "c": ["....", "....", ".###", "#...", "#...", "#...", ".###", "....", "...."],
            "d": ["...#", "...#", ".###", "#..#", "#..#", "#..#", ".###", "....", "...."],
            "e": ["....", "....", ".##.", "#..#", "####", "#...", ".###", "....", "...."],
            "f": ["..#", ".#.", "###", ".#.", ".#.", ".#.", ".#.", "...", "..."],
            "g": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "###."],
            "h": ["#...", "#...", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
            "i": ["#", ".", "#", "#", "#", "#", "#", ".", "."],
            "j": [".#", "..", ".#", ".#", ".#", ".#", ".#", ".#", "#."],
            "k": ["#...", "#...", "#..#", "#.#.", "##..", "#.#.", "#..#", "....", "...."],
            "l": ["#.", "#.", "#.", "#.", "#.", "#.", ".#", "..", ".."],
            "m": [".....", ".....", "####.", "#.#.#", "#.#.#", "#.#.#", "#.#.#", ".....", "....."],
            "n": ["....", "....", "###.", "#..#", "#..#", "#..#", "#..#", "....", "...."],
            "o": ["....", "....", ".##.", "#..#", "#..#", "#..#", ".##.", "....", "...."],
            "p": ["....", "....", "###.", "#..#", "#..#", "#..#", "###.", "#...", "#..."],
            "q": ["....", "....", ".###", "#..#", "#..#", "#..#", ".###", "...#", "...#"],
            "r": ["...", "...", "#.#", "##.", "#..", "#..", "#..", "...", "..."],
            "s": ["....", "....", ".###", "#...", ".##.", "...#", "###.", "....", "...."],
            "t": ["...", ".#.", "###", ".#.", ".#.", ".#.", ".##", "...", "..."],
            "u": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "....", "...."],
            "v": [".....", ".....", "#...#", "#...#", ".#.#.", ".#.#.", "..#..", ".....", "....."],
            "w": [".....", ".....", "#...#", "#...#", "#.#.#", "#.#.#", ".#.#.", ".....", "....."],
            "x": ["....", "....", "#..#", "#..#", ".##.", "#..#", "#..#", "....", "...."],
            "y": ["....", "....", "#..#", "#..#", "#..#", "#..#", ".###", "...#", "###."],
            "z": ["....", "....", "####", "...#", ".##.", "#...", "####", "....", "...."],
            "0": [".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###.", ".....", "....."],
            "1": [".#.", "##.", ".#.", ".#.", ".#.", ".#.", "###", "...", "..."],
            "2": [".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####", ".....", "....."],
            "3": [".###.", "#...#", "....#", "..##.", "....#", "#...#", ".###.", ".....", "....."],
            "4": ["...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#.", ".....", "....."],
            "5": ["#####", "#....", "####.", "....#", "....#", "#...#", ".###.", ".....", "....."],
            "6": [".###.", "#...#", "#....", "####.", "#...#", "#...#", ".###.", ".....", "....."],
            "7": ["#####", "....#", "....#", "...#.", "...#.", "..#..", "..#..", ".....", "....."],
            "8": [".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###.", ".....", "....."],
            "9": [".###.", "#...#", "#...#", ".####", "....#", "#...#", ".###.", ".....", "....."],
            ".": [".", ".", ".", ".", ".", ".", "#", ".", "."],
            "-": ["...", "...", "...", "###", "...", "...", "...", "...", "..."],
            "_": ["....", "....", "....", "....", "....", "....", "####", "....", "...."],
            "+": [".....", "..#..", "..#..", "#####", "..#..", "..#..", ".....", ".....", "....."],
            " ": ["...", "...", "...", "...", "...", "...", "...", "...", "..."]
        };

        /**
         * ウィンドウの下端の左にスクリプト名とバージョン（SCRIPT_NAME・SCRIPT_VERSION）、右に VERSION_FOOTER_BRAND を小さく薄く入れる。部品をすべて足したあと、show() の直前に呼ぶ。
         * 直前の行（ボタン行など）の下余白を 0 にし、ウィンドウの下余白を VERSION_FOOTER_BOTTOM_MARGIN にする。
         * InDesign の ScriptUI は文字サイズの指定を無視するので、onDraw でドットを並べて描く（UITheme の isDarkUI() を使う）
         * @param {Window} targetWindow - ダイアログまたはパレット（縦並び）
         * @returns {Group|null} バージョンを描くグループ。すでに足してあれば null
         */
        function addVersionFooter(targetWindow) {
            if (targetWindow.versionFooter) return null;

            /* ボタン行の下余白（BUTTON_ROW_BOTTOM_MARGIN）は、この行が引き受ける / this row takes over the button row's bottom margin */
            var lastChild = targetWindow.children[targetWindow.children.length - 1];
            if (lastChild && lastChild.type === "group") {
                var rowMargins = lastChild.margins;
                lastChild.margins = [rowMargins[0], rowMargins[1], rowMargins[2], 0];
            }
            var windowMargins = targetWindow.margins;
            targetWindow.margins = [windowMargins[0], windowMargins[1], windowMargins[2], VERSION_FOOTER_BOTTOM_MARGIN];

            var footerGroup = targetWindow.add("group");
            footerGroup.orientation = "row";
            footerGroup.alignment = ["fill", "bottom"];
            footerGroup.alignChildren = ["left", "center"];
            footerGroup.margins = [0, VERSION_FOOTER_TOP_MARGIN, 0, 0];

            /* 左は「スクリプト名 バージョン」。字形に無い文字（日本語など）を含む名前や、幅が足りないときはバージョンだけ。
               左の欄は余りの幅まで伸ばし、ダイアログの幅はバージョンの分しか求めない（名前でダイアログを広げない）
               / Left: "script name version", or just the version when the name has characters without glyphs (e.g. Japanese)
                 or does not fit. The left area takes the extra width and only asks for the version's width, so the name never widens the dialog */
            var versionText = String(SCRIPT_VERSION);
            var leftCandidates = [versionText];
            if (typeof SCRIPT_NAME === "string" && hasVersionFooterGlyphs(SCRIPT_NAME)) leftCandidates.unshift(SCRIPT_NAME + " " + versionText);
            var versionCanvas = addVersionFooterCanvas(footerGroup, leftCandidates);
            versionCanvas.alignment = ["fill", "center"];
            bindVersionInfoClick(versionCanvas); /* クリックで「このスクリプトについて」を開く / click opens About This Script */
            var brandCanvas = addVersionFooterCanvas(footerGroup, [VERSION_FOOTER_BRAND]);
            brandCanvas.alignment = ["right", "center"];
            brandCanvas.maximumSize = brandCanvas.preferredSize;
            targetWindow.versionFooter = footerGroup;
            return versionCanvas;
        }

        /**
         * 文字列のすべての文字に字形があるかを返す
         * @param {string} dotText - 文字列
         * @returns {boolean} すべてあれば true
         */
        function hasVersionFooterGlyphs(dotText) {
            for (var i = 0; i < dotText.length; i++) {
                if (!VERSION_FOOTER_GLYPHS.hasOwnProperty(dotText.charAt(i))) return false;
            }
            return dotText.length > 0;
        }

        /**
         * ドットで文字列を描くグループを足す。候補のうち、欄の幅に収まる最初のものを描く
         * @param {Group} parentGroup - 足す先
         * @param {string[]} dotTexts - 描く文字列の候補（長い順。いちばん短いものの幅を欄の幅として求める）
         * @returns {Group} 描くグループ
         */
        function addVersionFooterCanvas(parentGroup, dotTexts) {
            var dotCanvas = parentGroup.add("group");
            var shortestText = dotTexts[dotTexts.length - 1];
            dotCanvas.preferredSize = [measureVersionFooterDots(shortestText) * VERSION_FOOTER_PIXEL_SIZE, VERSION_FOOTER_GLYPH_HEIGHT * VERSION_FOOTER_PIXEL_SIZE];
            dotCanvas.helpTip = dotTexts[0];
            dotCanvas.onDraw = function () {
                var availableWidth = this.size ? this.size.width : 0;
                var drawText = shortestText;
                for (var i = 0; i < dotTexts.length; i++) {
                    if (measureVersionFooterDots(dotTexts[i]) * VERSION_FOOTER_PIXEL_SIZE <= availableWidth) {
                        drawText = dotTexts[i];
                        break;
                    }
                }
                drawVersionFooterDots(this.graphics, drawText);
            };
            return dotCanvas;
        }

        /**
         * 文字列の幅をドットの数で返す（字形に無い文字は数えない）
         * @param {string} versionText - 文字列
         * @returns {number} 幅（ドット）
         */
        function measureVersionFooterDots(versionText) {
            var dotCount = 0;
            for (var i = 0; i < versionText.length; i++) {
                var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
                if (!glyphRows) continue;
                if (dotCount > 0) dotCount += VERSION_FOOTER_LETTER_GAP;
                dotCount += glyphRows[0].length;
            }
            return dotCount;
        }

        /**
         * 文字列をドットで描く。横に続くドットは1つの四角にまとめて塗る
         * @param {ScriptUIGraphics} canvasGraphics - 描く先の graphics
         * @param {string} versionText - 文字列
         * @returns {void}
         */
        function drawVersionFooterDots(canvasGraphics, versionText) {
            var footerBrush = canvasGraphics.newBrush(canvasGraphics.BrushType.SOLID_COLOR, VERSION_FOOTER_COLOR);
            var dotSize = VERSION_FOOTER_PIXEL_SIZE;
            var cursorDots = 0;
            canvasGraphics.newPath();
            for (var i = 0; i < versionText.length; i++) {
                var glyphRows = VERSION_FOOTER_GLYPHS[versionText.charAt(i)];
                if (!glyphRows) continue;
                if (cursorDots > 0) cursorDots += VERSION_FOOTER_LETTER_GAP;
                for (var row = 0; row < glyphRows.length; row++) {
                    var rowText = glyphRows[row];
                    var runStart = -1;
                    for (var col = 0; col <= rowText.length; col++) {
                        var isDot = col < rowText.length && rowText.charAt(col) === "#";
                        if (isDot && runStart < 0) runStart = col;
                        if (!isDot && runStart >= 0) {
                            canvasGraphics.rectPath((cursorDots + runStart) * dotSize, row * dotSize, (col - runStart) * dotSize, dotSize);
                            runStart = -1;
                        }
                    }
                }
                cursorDots += glyphRows[0].length;
            }
            canvasGraphics.fillPath(footerBrush);
        }

        // -----------------------------------------
        // このスクリプトについて / About this script
        // -----------------------------------------
        /* 左下のスクリプト名・バージョンをクリックすると開く。基本情報ブロックの SCRIPT_* を読み、
           この部品だけで動くよう、文言（VERSION_INFO_LABELS）とレイアウトの値も部品の中に持つ
           Opened by clicking the name and version at the bottom left. Reads the SCRIPT_* basic info,
           and keeps its own labels and layout values so the part works on its own */

        var VERSION_INFO_LANG = (String($.locale || "").indexOf("ja") === 0) ? "ja" : "en"; /* 文言の言語 / label language */
        var VERSION_INFO_IS_INDESIGN = (String(app.name).indexOf("InDesign") >= 0);         /* InDesign で動いているか / running in InDesign */
        /* 実行中のスクリプトのファイル。ボタンを押すころには $.fileName が別のものを指すことがあるので、読み込んだ時点で控える
           The running script file, captured at load time; $.fileName may point elsewhere by the time the button is clicked */
        var VERSION_INFO_SCRIPT_FILE = new File($.fileName);
        var VERSION_INFO_REVEAL_APP_PATH = "/Applications/RevealInFinder.app";   /* Finder で選択表示する補助アプリ / helper app that reveals a file in the Finder */
        var VERSION_INFO_REVEAL_PATH_FILE = "/tmp/illustrator_reveal_path.txt";  /* 補助アプリが読むパス（アプリの旧名のまま。変えると読めない）/ path the helper reads (keeps the app's old name) */

        var VERSION_INFO_WINDOW_MARGINS = 16;               /* ウィンドウの余白 / window margin */
        var VERSION_INFO_WINDOW_SPACING = 12;               /* ウィンドウ内の間隔 / window spacing */
        var VERSION_INFO_PANEL_MARGINS = [16, 20, 16, 12];  /* パネルの余白 [左,上,右,下] / panel margins */
        var VERSION_INFO_ROW_SPACING = 6;                   /* 項目名と値の間隔 / gap between a label and its value */
        var VERSION_INFO_BUTTON_SPACING = 10;               /* ボタンどうしの間隔 / gap between buttons */
        var VERSION_INFO_BUTTON_ROW_MARGINS = [0, 5, 0, 14]; /* ボタン行の余白（Illustrator 標準のダイアログに合わせる）/ button row margins */
        var VERSION_INFO_COPY_BUTTON_SIZE = 22;             /* コピーボタンの一辺 / copy button size */
        /* コピーボタンの配色。∧∨（ステップボタン）と同じく、背景に重ねる半透明 / Copy button colors, translucent overlays like the stepper */
        var VERSION_INFO_COPY_FILL_COLOR    = isDarkUI() ? [0, 0, 0, 0.10] : [1, 1, 1, 0.50]; /* 地 / background */
        var VERSION_INFO_COPY_FRAME_COLOR   = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.15]; /* 枠線 / frame */
        var VERSION_INFO_COPY_PRESSED_COLOR = isDarkUI() ? [1, 1, 1, 0.12] : [0, 0, 0, 0.13]; /* 押下中 / pressed */
        var VERSION_INFO_COPY_ICON_COLOR    = isDarkUI() ? [1, 1, 1, 0.85] : [0, 0, 0, 0.70]; /* アイコン / icon */

        var VERSION_INFO_LABELS = {
            dialog: {
                title: { ja: "このスクリプトについて", en: "About This Script" }
            },
            panel: {
                generalInfo: { ja: "基本情報", en: "General" },
                links: { ja: "リンク", en: "Links" }
            },
            fieldLabel: {
                scriptName: { ja: "スクリプト名", en: "Script Name" },
                scriptFeature: { ja: "機能", en: "Feature" },
                scriptVersion: { ja: "バージョン", en: "Version" }
            },
            button: {
                openReadme: { ja: "README", en: "README" },
                openSourceCode: { ja: "ソースコード", en: "Source Code" },
                openArticle: { ja: "記事（note）", en: "Article (note)" },
                revealInFinder: { ja: "Finder に表示", en: "Show in Finder" },
                revealInExplorer: { ja: "エクスプローラーに表示", en: "Show in Explorer" },
                close: { ja: "閉じる", en: "Close" }
            },
            tooltip: {
                versionInfo: { ja: "クリックで、このスクリプトについての情報を表示", en: "Click for info about this script" },
                copyScriptName: { ja: "スクリプト名をコピー", en: "Copy Script Name" }
            },
            alert: {
                copyFailed: { ja: "スクリプト名をコピーできませんでした。", en: "Could not copy the script name." }
            }
        };

        /**
         * VERSION_INFO_LABELS の文言を今の言語で返す
         * @param {Object} labelEntry - { ja, en }
         * @returns {string} 文言
         */
        function getVersionInfoLabel(labelEntry) {
            return labelEntry[VERSION_INFO_LANG] || labelEntry.en;
        }

        /**
         * 基本情報ブロックの値を返す（変数が無い・文字列でなければ空文字）。typeof で読むので、未定義でも例外にならない
         * @param {string} variableKey - "name" / "version" / "feature" / "readme" / "source" / "article"
         * @returns {string} 値
         */
        function getVersionInfoValue(variableKey) {
            var infoValue;
            if (variableKey === "name") infoValue = (typeof SCRIPT_NAME !== "undefined") ? SCRIPT_NAME : "";
            else if (variableKey === "version") infoValue = (typeof SCRIPT_VERSION !== "undefined") ? SCRIPT_VERSION : "";
            else if (variableKey === "feature") infoValue = (typeof SCRIPT_DESCRIPTION_JA !== "undefined") ? SCRIPT_DESCRIPTION_JA : "";
            else if (variableKey === "readme") {
                if (VERSION_INFO_LANG === "ja") infoValue = (typeof SCRIPT_README_JA !== "undefined") ? SCRIPT_README_JA : "";
                else infoValue = (typeof SCRIPT_README_EN !== "undefined") ? SCRIPT_README_EN : "";
            }
            else if (variableKey === "source") infoValue = (typeof SCRIPT_SOURCE_URL !== "undefined") ? SCRIPT_SOURCE_URL : "";
            else if (variableKey === "article") infoValue = (typeof SCRIPT_ARTICLE_URL !== "undefined") ? SCRIPT_ARTICLE_URL : "";
            return (infoValue === undefined || infoValue === null) ? "" : String(infoValue);
        }

        /**
         * 左下のスクリプト名・バージョンをクリックしたら、「このスクリプトについて」のダイアログを開くようにする
         * @param {Group} versionCanvas - addVersionFooterCanvas() で作った左の欄
         * @returns {void}
         */
        function bindVersionInfoClick(versionCanvas) {
            versionCanvas.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.versionInfo);
            /* mousedown で開くと、離したときのイベントが閉じたあとの欄に届くので mouseup で開く
               Open on mouseup so the release does not land on the footer after the dialog closes */
            versionCanvas.addEventListener("mouseup", function () {
                showVersionInfoDialog(versionCanvas.window.type === "palette");
            });
        }

        /**
         * 「このスクリプトについて」のダイアログを開く。スクリプト名（コピーボタン付き）・機能・バージョンの［基本情報］パネル、
         * README・ソースコード・記事を開く［リンク］パネル、［Finder に表示］［閉じる］を並べる
         * @param {boolean} isFromPalette - 常駐パレットから開いたなら true（Illustrator のコピーを BridgeTalk 経由にする）
         * @returns {void}
         */
        function showVersionInfoDialog(isFromPalette) {
            var infoDialog = new Window("dialog", getVersionInfoLabel(VERSION_INFO_LABELS.dialog.title));
            infoDialog.orientation = "column";
            infoDialog.alignChildren = "fill";
            infoDialog.margins = VERSION_INFO_WINDOW_MARGINS;
            infoDialog.spacing = VERSION_INFO_WINDOW_SPACING;

            var infoPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.generalInfo);
            /* コピーボタンはスクリプト名だけ / Only the script name gets a copy button */
            addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptName, getVersionInfoValue("name"), isFromPalette);
            /* 機能は README の見出しで日本語だけなので、日本語の画面だけに出す / The feature is the Japanese README title, shown only in the Japanese UI */
            if (VERSION_INFO_LANG === "ja" && getVersionInfoValue("feature") !== "") {
                addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptFeature, getVersionInfoValue("feature"), null);
            }
            addVersionInfoRow(infoPanel, VERSION_INFO_LABELS.fieldLabel.scriptVersion, getVersionInfoValue("version"), null);
            alignVersionInfoLabels(infoPanel);

            /* URL が無いボタンはディム表示にして、並びはスクリプトごとに変えない / Dim buttons without a URL; keep the same buttons everywhere */
            var linksPanel = addVersionInfoPanel(infoDialog, VERSION_INFO_LABELS.panel.links);
            var linkButtonRow = linksPanel.add("group");
            linkButtonRow.orientation = "row";
            linkButtonRow.alignment = ["left", "center"];
            linkButtonRow.alignChildren = ["left", "center"];
            linkButtonRow.spacing = VERSION_INFO_BUTTON_SPACING;
            addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openReadme, getVersionInfoValue("readme"));
            addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openSourceCode, getVersionInfoValue("source"));
            addVersionInfoLinkButton(infoDialog, linkButtonRow, VERSION_INFO_LABELS.button.openArticle, getVersionInfoValue("article"));

            /* ボタン行：左に［Finder に表示］、右に［閉じる］ / Button row: Show in Finder at the left, Close at the right */
            var buttonRow = infoDialog.add("group");
            buttonRow.orientation = "row";
            buttonRow.alignment = ["fill", "bottom"];
            buttonRow.alignChildren = ["left", "center"];
            buttonRow.margins = VERSION_INFO_BUTTON_ROW_MARGINS;
            buttonRow.spacing = VERSION_INFO_BUTTON_SPACING;
            var revealLabel = (File.fs === "Windows") ? VERSION_INFO_LABELS.button.revealInExplorer : VERSION_INFO_LABELS.button.revealInFinder;
            var revealButton = buttonRow.add("button", undefined, getVersionInfoLabel(revealLabel));
            if (VERSION_INFO_SCRIPT_FILE.exists) {
                revealButton.helpTip = VERSION_INFO_SCRIPT_FILE.fsName;
                revealButton.onClick = function () {
                    revealVersionInfoScriptFile(VERSION_INFO_SCRIPT_FILE);
                    infoDialog.close();
                };
            } else {
                revealButton.enabled = false;
            }
            /* 余りの幅を吸って、［閉じる］を右端に寄せる / Absorbs the extra width so Close sits at the right edge */
            var buttonSpacer = buttonRow.add("group");
            buttonSpacer.alignment = ["fill", "fill"];
            buttonSpacer.minimumSize.width = 0;
            var closeButton = buttonRow.add("button", undefined, getVersionInfoLabel(VERSION_INFO_LABELS.button.close), { name: "ok" });
            closeButton.alignment = ["right", "center"];
            /* return でも esc でも閉じる / Close with both Return and Esc */
            infoDialog.defaultElement = closeButton;
            infoDialog.cancelElement = closeButton;
            infoDialog.onShow = function () {
                pinVersionInfoCopyButton(infoPanel);
            };
            infoDialog.show();
        }

        /**
         * 「このスクリプトについて」のダイアログにパネルを足す
         * @param {Window} infoDialog - 足す先のダイアログ
         * @param {Object} titleEntry - パネル名の文言 { ja, en }
         * @returns {Panel} パネル
         */
        function addVersionInfoPanel(infoDialog, titleEntry) {
            var infoPanel = infoDialog.add("panel", undefined, getVersionInfoLabel(titleEntry));
            infoPanel.orientation = "column";
            infoPanel.alignChildren = ["fill", "top"];
            infoPanel.alignment = "fill";
            infoPanel.margins = VERSION_INFO_PANEL_MARGINS;
            infoPanel.spacing = VERSION_INFO_WINDOW_SPACING;
            return infoPanel;
        }

        /**
         * ［基本情報］パネルに「項目名 : 値」の1行を足す（値は見せるだけなので statictext）
         * @param {Panel} infoPanel - 足す先のパネル
         * @param {Object} labelEntry - 項目名の文言 { ja, en }
         * @param {string} valueText - 表示する値
         * @param {boolean|null} copyFromPalette - 値の右にコピーボタンを置くなら true / false（常駐パレットから開いたか）、置かないなら null
         * @returns {StaticText} 値の statictext
         */
        function addVersionInfoRow(infoPanel, labelEntry, valueText, copyFromPalette) {
            var infoRow = infoPanel.add("group");
            infoRow.orientation = "row";
            infoRow.alignment = ["fill", "center"];
            infoRow.alignChildren = ["left", "center"];
            infoRow.spacing = VERSION_INFO_ROW_SPACING;
            /* 項目名のコロンは日本語が「 :」、英語が「:」 / Colon: " :" in Japanese, ":" in English */
            var rowLabel = infoRow.add("statictext", undefined, getVersionInfoLabel(labelEntry) + (VERSION_INFO_LANG === "ja" ? " :" : ":"));
            rowLabel.justify = "right";
            var valueLabel = infoRow.add("statictext", undefined, valueText);
            if (copyFromPalette === null) return valueLabel;
            /* statictext の fill では伸びないことがあるので、伸びるスペーサーでコピーボタンをパネルの右端に寄せる
               A stretching spacer (statictext fill is unreliable) pushes the copy button to the panel's right edge */
            var copySpacer = infoRow.add("group");
            copySpacer.alignment = ["fill", "fill"];
            copySpacer.minimumSize.width = 0;
            infoRow.copyButton = addVersionInfoCopyButton(infoRow, valueLabel, copyFromPalette);
            return valueLabel;
        }

        /**
         * コピーボタンを［基本情報］パネルの右端に置き直す（表示時、レイアウトが決まったあとに呼ぶ）。
         * 行の fill・スペーサーだけでは、項目の値が短い行がパネルの幅まで伸びないことがあるので、行の幅とボタンの位置を直接入れる
         * @param {Panel} infoPanel - ［基本情報］パネル
         * @returns {void}
         */
        function pinVersionInfoCopyButton(infoPanel) {
            var innerWidth = infoPanel.size.width - VERSION_INFO_PANEL_MARGINS[0] - VERSION_INFO_PANEL_MARGINS[2];
            for (var i = 0; i < infoPanel.children.length; i++) {
                var infoRow = infoPanel.children[i];
                if (!infoRow.copyButton || !infoRow.size || infoRow.size.width >= innerWidth) continue;
                infoRow.size = [innerWidth, infoRow.size.height];
                infoRow.copyButton.location = [innerWidth - infoRow.copyButton.size.width, infoRow.copyButton.location[1]];
            }
        }

        /**
         * ［基本情報］パネルの項目名を、いちばん長いものの幅にそろえる
         * @param {Panel} infoPanel - 対象のパネル
         * @returns {void}
         */
        function alignVersionInfoLabels(infoPanel) {
            var rowLabels = [];
            var labelWidth = 0;
            for (var i = 0; i < infoPanel.children.length; i++) {
                var rowLabel = infoPanel.children[i].children[0]; /* 行の先頭は項目名 / each row starts with its label */
                rowLabels.push(rowLabel);
                labelWidth = Math.max(labelWidth, rowLabel.graphics.measureString(rowLabel.text)[0]);
            }
            for (var j = 0; j < rowLabels.length; j++) {
                rowLabels[j].preferredSize.width = Math.ceil(labelWidth) + 2;
            }
        }

        /**
         * URL を開くボタンを足す。URL が無ければディム表示にする。開いたらダイアログは閉じる
         * @param {Window} infoDialog - ボタンを置くダイアログ
         * @param {Group} buttonGroup - 足す先のグループ
         * @param {Object} labelEntry - ボタンの文言 { ja, en }
         * @param {string} targetUrl - 開く URL（空ならディム表示）
         * @returns {void}
         */
        function addVersionInfoLinkButton(infoDialog, buttonGroup, labelEntry, targetUrl) {
            var linkButton = buttonGroup.add("button", undefined, getVersionInfoLabel(labelEntry));
            if (!targetUrl) {
                linkButton.enabled = false;
                return;
            }
            linkButton.helpTip = targetUrl;
            linkButton.onClick = function () {
                openVersionInfoUrl(targetUrl);
                infoDialog.close();
            };
        }

        /**
         * 値をクリップボードへコピーするアイコンのボタンを足す。コピーしたらアイコンをチェックマークに変え、ポインタが外れたら戻す
         * @param {Group} infoRow - 足す先の行
         * @param {StaticText} valueLabel - コピーする値の statictext
         * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
         * @returns {Group} ボタンとして使う group
         */
        function addVersionInfoCopyButton(infoRow, valueLabel, isFromPalette) {
            var buttonSize = VERSION_INFO_COPY_BUTTON_SIZE;
            var copyButton = infoRow.add("group");
            copyButton.preferredSize = [buttonSize, buttonSize];
            copyButton.minimumSize = [buttonSize, buttonSize];
            copyButton.maximumSize = [buttonSize, buttonSize];
            copyButton.helpTip = getVersionInfoLabel(VERSION_INFO_LABELS.tooltip.copyScriptName);
            copyButton.isPressed = false;
            copyButton.isCopied = false;

            copyButton.onDraw = function () {
                var buttonGraphics = copyButton.graphics;
                var fillColor = copyButton.isPressed ? VERSION_INFO_COPY_PRESSED_COLOR : VERSION_INFO_COPY_FILL_COLOR;
                buttonGraphics.newPath();
                buttonGraphics.rectPath(0, 0, buttonSize, buttonSize);
                buttonGraphics.fillPath(buttonGraphics.newBrush(buttonGraphics.BrushType.SOLID_COLOR, fillColor));
                buttonGraphics.newPath();
                buttonGraphics.rectPath(0.5, 0.5, buttonSize - 1, buttonSize - 1);
                buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_FRAME_COLOR, 1));
                if (copyButton.isCopied) drawVersionInfoCheckIcon(buttonGraphics, buttonSize);
                else drawVersionInfoCopyIcon(buttonGraphics, buttonSize);
            };

            /**
             * 状態を変えて描き直す（group には notify() が無いので隠して再表示する）
             * @param {boolean} isPressed - 押下中なら true
             * @param {boolean} isCopied - コピー済みなら true
             * @returns {void}
             */
            function repaint(isPressed, isCopied) {
                if (copyButton.isPressed === isPressed && copyButton.isCopied === isCopied) return;
                copyButton.isPressed = isPressed;
                copyButton.isCopied = isCopied;
                copyButton.hide();
                copyButton.show();
            }
            copyButton.addEventListener("mousedown", function () { repaint(true, false); });
            copyButton.addEventListener("mouseup", function () {
                if (!copyButton.isPressed) return;
                var hasCopied = copyVersionInfoText(valueLabel.text, isFromPalette);
                repaint(false, hasCopied);
                if (!hasCopied) alert(getVersionInfoLabel(VERSION_INFO_LABELS.alert.copyFailed));
            });
            /* 押したまま外へ出たとき・コピーのあと離れたときは元の見た目に戻す / Reset when the pointer leaves */
            copyButton.addEventListener("mouseout", function () { repaint(false, false); });
            return copyButton;
        }

        /**
         * コピーのアイコン（後ろの四角に前の四角を重ねた形）を描く
         * @param {ScriptUIGraphics} buttonGraphics - 描画先
         * @param {number} buttonSize - ボタンの一辺
         * @returns {void}
         */
        function drawVersionInfoCopyIcon(buttonGraphics, buttonSize) {
            var iconPen = buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1);
            var sheetSize = 9;
            var offset = 3;
            var frontLeft = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
            var frontTop = Math.round((buttonSize - sheetSize - offset) / 2) + offset + 0.5;
            var backLeft = frontLeft - offset;
            var backTop = frontTop - offset;
            /* 後ろの四角は、前の四角に隠れる部分を描かない（上と左の辺だけ）/ Draw only the visible top and left of the back sheet */
            buttonGraphics.newPath();
            buttonGraphics.moveTo(frontLeft, backTop + sheetSize);
            buttonGraphics.lineTo(backLeft, backTop + sheetSize);
            buttonGraphics.lineTo(backLeft, backTop);
            buttonGraphics.lineTo(backLeft + sheetSize, backTop);
            buttonGraphics.lineTo(backLeft + sheetSize, frontTop);
            buttonGraphics.strokePath(iconPen);
            buttonGraphics.newPath();
            buttonGraphics.rectPath(frontLeft, frontTop, sheetSize, sheetSize);
            buttonGraphics.strokePath(iconPen);
        }

        /**
         * コピーしたあとのチェックマークを描く
         * @param {ScriptUIGraphics} buttonGraphics - 描画先
         * @param {number} buttonSize - ボタンの一辺
         * @returns {void}
         */
        function drawVersionInfoCheckIcon(buttonGraphics, buttonSize) {
            var center = buttonSize / 2;
            buttonGraphics.newPath();
            buttonGraphics.moveTo(center - 4.5, center);
            buttonGraphics.lineTo(center - 1.5, center + 3);
            buttonGraphics.lineTo(center + 4.5, center - 3.5);
            buttonGraphics.strokePath(buttonGraphics.newPen(buttonGraphics.PenType.SOLID_COLOR, VERSION_INFO_COPY_ICON_COLOR, 1.5));
        }

        /**
         * 文字列をクリップボードにコピーする。
         * InDesign は AppleScript（Windows は VBScript）の doScript で書き込む。
         * Illustrator は文字列を直接送る API が無いので、一時レイヤーのテキストフレームを選んでコピーする（プレーンテキストも入る）。
         * Illustrator の常駐パレットからは DOM に触れないので、同じ処理を BridgeTalk でメインエンジンに渡す
         * @param {string} copyText - コピーする文字列
         * @param {boolean} isFromPalette - 常駐パレットから開いたなら true
         * @returns {boolean} コピーの操作まで進めたら true
         */
        function copyVersionInfoText(copyText, isFromPalette) {
            try {
                if (VERSION_INFO_IS_INDESIGN) {
                    if (File.fs === "Windows") {
                        app.doScript('CreateObject("htmlfile").parentWindow.clipboardData.setData "text", "' + copyText.replace(/"/g, '""') + '"', ScriptLanguage.VISUAL_BASIC);
                    } else {
                        app.doScript('set the clipboard to "' + copyText.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"', ScriptLanguage.APPLESCRIPT_LANGUAGE);
                    }
                    return true;
                }
                var copyScript = buildVersionInfoCopyScript(copyText);
                if (!isFromPalette) return eval(copyScript) === true;
                var copyMessage = new BridgeTalk();
                copyMessage.target = BridgeTalk.appSpecifier; /* 複数バージョンを起動していても、今のバージョンに送る / the running version, even with several installed */
                copyMessage.body = copyScript;
                copyMessage.send();
                return true;
            } catch (e) {
                return false;
            }
        }

        /**
         * Illustrator でコピーする処理を文字列で組み立てる（BridgeTalk でも送れるよう、関数の toString() は使わない）。
         * 一時レイヤーにテキストフレームを作り、フレームを選んでメニューコマンドでコピーして、レイヤーごと消す。
         * 文字として選択（textRange.select()）してコピーすると「オブジェクトをコピーできません」の警告が出るので使わない。
         * 選択と作業レイヤーは元に戻す。ドキュメントが無ければ一時ドキュメントを作って閉じる
         * @param {string} copyText - コピーする文字列
         * @returns {string} 実行すると true / false を返すスクリプト
         */
        function buildVersionInfoCopyScript(copyText) {
            return [
                "(function (copyText) {",
                "    var usingTempDoc = (app.documents.length === 0);",
                "    var targetDoc = usingTempDoc ? app.documents.add() : app.activeDocument;",
                "    var savedSelection = (!usingTempDoc && targetDoc.selection instanceof Array) ? targetDoc.selection : [];",
                "    var savedActiveLayer = usingTempDoc ? null : targetDoc.activeLayer;",
                "    var tempLayer = null;",
                "    var hasCopied = false;",
                "    try {",
                "        tempLayer = targetDoc.layers.add();",
                "        var tempFrame = tempLayer.textFrames.add();",
                "        tempFrame.contents = copyText;",
                "        app.redraw();",
                "        app.executeMenuCommand('deselectall');",
                "        tempFrame.selected = true;",
                "        app.redraw();",
                "        app.executeMenuCommand('copy');",
                "        app.redraw();",
                "        hasCopied = true;",
                "    } catch (e) { }",
                "    if (tempLayer) { try { tempLayer.remove(); } catch (e) { } }",
                "    if (usingTempDoc) { targetDoc.close(SaveOptions.DONOTSAVECHANGES); return hasCopied; }",
                "    try { targetDoc.activeLayer = savedActiveLayer; } catch (e) { }",
                "    targetDoc.selection = null;",
                "    for (var i = 0; i < savedSelection.length; i++) { try { savedSelection[i].selected = true; } catch (e) { } }",
                "    app.redraw();",
                "    return hasCopied;",
                "})(" + quoteVersionInfoString(copyText) + ");"
            ].join(" "); /* 行コメントを含まないので1行につなぐ（BridgeTalk の転送で改行が化けない）/ joined on one line; there are no line comments */
        }

        /**
         * 文字列を、スクリプトに埋め込める二重引用符のリテラルにする
         * @param {string} sourceText - 文字列
         * @returns {string} "…" の形のリテラル
         */
        function quoteVersionInfoString(sourceText) {
            return '"' + String(sourceText).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n") + '"';
        }

        /**
         * ファイルを Finder で表示する。RevealInFinder.app があればファイルを選択した状態で表示し、無ければ入っているフォルダーを開く
         * @param {File} scriptFile - 表示するファイル
         * @returns {void}
         */
        function revealVersionInfoScriptFile(scriptFile) {
            /* .app は実体がフォルダーなので File.exists が false になる環境がある。Folder でも確かめる / An .app is a folder, so check with Folder too */
            var hasRevealApp = (File.fs === "Macintosh")
                && (new Folder(VERSION_INFO_REVEAL_APP_PATH).exists || new File(VERSION_INFO_REVEAL_APP_PATH).exists);
            /* アプリは一時ファイルからパスを読むので、書き出してから起動する / The app reads the path from a temp file */
            if (hasRevealApp && writeVersionInfoRevealPath(scriptFile.fsName) && new File(VERSION_INFO_REVEAL_APP_PATH).execute()) return;
            /* アプリが無い・起動できないときは、何も起きないままにせずフォルダーを開く / Otherwise open the enclosing folder */
            scriptFile.parent.execute();
        }

        /**
         * RevealInFinder.app に渡すパスを一時ファイルへ書き出す（UTF-8、改行なし）
         * @param {string} targetPath - 絶対パス
         * @returns {boolean} 書き出せたら true
         */
        function writeVersionInfoRevealPath(targetPath) {
            var pathFile = new File(VERSION_INFO_REVEAL_PATH_FILE);
            pathFile.encoding = "UTF-8";
            pathFile.lineFeed = "Unix";
            if (!pathFile.open("w")) return false;
            var hasWritten = pathFile.write(targetPath);
            pathFile.close();
            return hasWritten;
        }

        /**
         * URL を既定のブラウザーで開く（一時的なショートカットファイルを作って開く）
         * @param {string} targetUrl - 開く URL
         * @returns {void}
         */
        function openVersionInfoUrl(targetUrl) {
            var isMac = (File.fs === "Macintosh");
            var shortcutFile = new File(Folder.temp.fsName + "/VersionInfoLink" + (isMac ? ".webloc" : ".url"));
            shortcutFile.encoding = "UTF-8";
            shortcutFile.open("w");
            if (isMac) {
                var escapedUrl = targetUrl.replace(/&/g, "&amp;").replace(/</g, "&lt;");
                shortcutFile.write('<?xml version="1.0" encoding="UTF-8"?>\n'
                    + '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
                    + '<plist version="1.0"><dict><key>URL</key><string>' + escapedUrl + '</string></dict></plist>\n');
            } else {
                shortcutFile.write("[InternetShortcut]\r\nURL=" + targetUrl + "\r\n");
            }
            shortcutFile.close();
            shortcutFile.execute();
        }

        // バージョン表示（再利用パーツ）ここまで / End of the reusable version footer

        /* 日英ラベル定義 / Japanese-English label definitions */

        var LABELS = {
            dialog: {
                title: { ja: "ファイル名を変更して保存", en: "Rename and Save" }
            },
            panel: {
                mode: { ja: "動作", en: "Mode" },
                opMode: { ja: "モード", en: "Scope" },
                filename: { ja: "ファイル名プレビュー", en: "File Name Preview" },
                options: { ja: "ファイル名の設定", en: "Filename Settings" },
                sort: { ja: "構成要素の順序", en: "Segment Order" }
            },
            radio: {
                rename: { ja: "元ファイルをリネーム", en: "Rename Original" },
                saveAs: { ja: "別名で保存", en: "Save As" },
                saveCopy: { ja: "コピー（複製）を保存", en: "Save a Copy" },
                opVersionOnly: { ja: "バージョンのみ", en: "Version Only" },
                opFull: { ja: "全体", en: "Full" },
                noChange: { ja: "変更しない", en: "No Change" },
                titleNone: { ja: "なし", en: "None" },
                titleParent: { ja: "親フォルダー", en: "Parent Folder" },
                titleGrandparent: { ja: "2 階層上のフォルダー", en: "Grandparent Folder" },
                titleCustom: { ja: "指定", en: "Custom" },
                timestampNone: { ja: "なし", en: "None" },
                timestampDate: { ja: "YYYYMMDD", en: "YYYYMMDD" },
                timestampDateDash: { ja: "YYYY-MM-DD", en: "YYYY-MM-DD" },
                timestampWithTime: { ja: "時刻も付与", en: "Append HHMM" },
                versionNone: { ja: "なし", en: "None" },
                versionShort: { ja: "v1, v2…", en: "v1, v2…" },
                versionPadded: { ja: "v01, v02…", en: "v01, v02…" },
                versionPaddedWide: { ja: "v001, v002…", en: "v001, v002…" },
                changeToDash: { ja: "-に変更", en: "Change to -" },
                changeToUnderscore: { ja: "_に変更", en: "Change to _" },
                nfcCombine: { ja: "結合する", en: "Combine" },
                cleanRemove: { ja: "削除する", en: "Remove" },
                translitRemove: { ja: "削除する", en: "Remove" },
                translitConvert: { ja: "変換する", en: "Convert" },
                halfwidthKanaConvert: { ja: "半角カナ → 全角", en: "Half-width → Full-width Kana" },
                pageEnable: { ja: "連番を付与", en: "Append Sequence" },
                pagePad2: { ja: "01, 02…", en: "01, 02…" },
                pagePad3: { ja: "001, 002…", en: "001, 002…" },
                sortOff: { ja: "標準順", en: "Default" },
                sortCurrent: { ja: "現在のファイル名に準じる", en: "Match Current" },
                sortOn: { ja: "カスタム順", en: "Custom" }
            },
            label: {
                currentName: { ja: "現在", en: "Current" },
                finalName: { ja: "保存後の名前", en: "Saved Name" },
                base: { ja: "ベース", en: "Base" },
                title: { ja: "サブテキスト", en: "Project Name" },
                status: { ja: "ステータス", en: "Status" },
                timestamp: { ja: "タイムスタンプ", en: "Timestamp" },
                version: { ja: "バージョン番号", en: "Version" },
                page: { ja: "連番", en: "Sequence" },
                separator: { ja: "区切り記号", en: "Separator" },
                nfc: { ja: "濁点・半濁点の正規化", en: "NFC Normalization" },
                clean: { ja: "クリーンなファイル名", en: "Clean Filename" },
                translit: { ja: "丸数字や法人略記など", en: "Symbols" }
            },
            tip: {
                rename: {
                    ja: "新しい名前で保存したあと、元ファイルをゴミ箱に移します（実質的にリネーム）。元ファイルを参照している他のドキュメント（配置 .ai／InDesign のリンクなど）はリンク切れになります。",
                    en: "Saves with the new name, then moves the original to the Trash (effectively a rename). Documents that reference the original file (placed .ai or InDesign links) will lose the link."
                },
                nonNativeUnsupported: {
                    ja: "保存されるのは InDesign 形式（.indd）だけなので、.indd 以外の書類ではリネーム・コピーを使えません。「別名で保存」を使ってください。",
                    en: "Only InDesign (.indd) is written, so Rename and Save a Copy are unavailable for a non-.indd document. Use \"Save As\" instead."
                },
                saveAs: {
                    ja: "新しい名前で保存します。元ファイルは残り、作業中のドキュメントが新ファイルに切り替わります。",
                    en: "Saves with the new name. The original file is kept, and the active document switches to the new file."
                },
                saveCopy: {
                    ja: "元ファイルに上書き保存したうえで、別名のコピーを作成します。作業中のドキュメントは元ファイルのまま残ります。",
                    en: "Saves the original, then creates a copy with the new name. The active document remains the original file."
                },
                base: {
                    ja: "ファイル名の先頭部分。空欄にすると省略されます。",
                    en: "Leading part of the filename. Leave empty to omit."
                },
                title: {
                    ja: "ファイル名に追加する案件名・補足テキスト。「指定」で入力欄の文字列を使用します。",
                    en: "Choose how to set the project name in the filename. With \"Custom\", the entered text is used."
                },
                status: {
                    ja: "ファイル名に挿入する制作ステータスを選択します。「：」より前の文字列が入ります。",
                    en: "Choose a production status to insert. Only the text before \":\" is used in the filename."
                },
                timestamp: {
                    ja: "タイムスタンプの形式を選択。「なし」で元の日付があっても削除します。",
                    en: "Choose timestamp format. \"None\" removes any existing date."
                },
                timestampWithTime: {
                    ja: "タイムスタンプの末尾に時刻（HHMM）を付加します。1 日に複数版を出すときに便利。",
                    en: "Append the current time (HHMM) to the timestamp. Useful for multiple versions per day."
                },
                version: {
                    ja: "バージョン番号の形式。v1/v2 はパディング無し、v01/v02 は 2 桁、v001/v002 は 3 桁ゼロ埋め。既存の v 番号は +1、無い場合は v1/v01/v001 を付与。「なし」で削除。",
                    en: "Version format. v1/v2 has no padding, v01/v02 is 2-digit, v001/v002 is 3-digit zero-padded. An existing v-number is bumped by +1; otherwise v1/v01/v001 is added. \"None\" removes."
                },
                page: {
                    ja: "「page01」「page001」のような連番をファイル名に追加します。プレフィックス（page 等）と桁数（01 / 001）を選択。保存時に同フォルダ内の最大連番 +1 へ自動繰り上げ。",
                    en: "Append a sequence such as page01 / page001. Configure prefix (e.g. page) and width (01 / 001). On save, bumps to (max in folder) + 1 if collisions exist."
                },
                separator: {
                    ja: "ファイル名全体の区切り記号の扱いを選択します。「-」「_」「.」が対象。YYYY-MM-DD のタイムスタンプは保護されます。",
                    en: "Choose how separators in the filename are handled. Targets `-`, `_`, and `.`. YYYY-MM-DD timestamps are preserved."
                },
                sort: {
                    ja: "並び順を選択。「現在のファイル名に準じる」は検出された要素のみ、「カスタム順」は［編集］で並び替え。",
                    en: "Choose order. \"Match Current\" uses only detected segments; \"Custom\" enables [Edit]."
                },
                nfc: {
                    ja: "ファイル名に分離した濁点・半濁点が含まれる場合、結合済み文字（NFC）に正規化します。",
                    en: "Normalize separated dakuten/handakuten to combined characters (NFC)."
                },
                clean: {
                    ja: "OS で使えない文字（\\ / : * ? \" < > |）、絵文字・機種依存文字（㈱・①・㌔ など）、スペースの扱いをまとめて選択します。連続するスペースは 1 つにまとめてから処理。",
                    en: "How to handle OS-invalid characters (\\ / : * ? \" < > |), emoji, platform-dependent chars (㈱, ①, ㌔), and spaces. Consecutive spaces collapse to one before replacement."
                },
                translit: {
                    ja: "法人略記（㈱→株）、丸数字（①→1）、ローマ数字（Ⅰ→1）、TEL/No、単位記号（㎜→mm）、ダッシュ類を ASCII 相当に変換します。",
                    en: "Convert corporate abbreviations (㈱→株), circled numbers (①→1), Roman numerals, TEL/No, units (㎜→mm), and dashes to ASCII equivalents."
                },
                halfwidthKana: {
                    ja: "「-」または「_」を選んだとき、半角カタカナを全角カタカナに変換します（濁点・半濁点付きは結合）。",
                    en: "When `-` or `_` is selected, convert half-width katakana to full-width (voiced/semi-voiced marks are merged)."
                }
            },
            button: {
                cancel: { ja: "キャンセル", en: "Cancel" },
                ok: { ja: "OK", en: "OK" },
                sort: { ja: "編集", en: "Edit" }
            },
            sort: {
                title: { ja: "ファイル名の並び順", en: "Filename Order" },
                hint: { ja: "選択中の項目を ↑↓ で並び替え", en: "Select an item and use ↑↓ to reorder" }
            },
            message: {
                noDoc: { ja: "ドキュメントが開かれていません", en: "No document is open." },
                emptyName: { ja: "ファイル名が空です", en: "File name is empty." },
                chooseDestination: { ja: "保存先フォルダを指定", en: "Choose destination folder" },
                confirmOverwrite: {
                    ja: "同名ファイルが存在します。上書きしますか？",
                    en: "A file with the same name exists. Overwrite?"
                },
                confirmTooLong: {
                    ja: "ファイル名が長すぎる可能性があります（{bytes} バイト / 上限 {limit} バイト）。このまま続行しますか？",
                    en: "The filename may be too long ({bytes} bytes / limit {limit}). Continue anyway?"
                },
                saveFailed: { ja: "保存に失敗しました", en: "Failed to save" }
            }
        };

        // =========================================
        // ヘルパー / Helpers
        // =========================================

        var VERSION_TOKEN_RE = /^[vV]\d+$/;   // v123 / V123
        var VERSION_TOKEN_SOURCE = '[vV]';     // 採番パターンを組み立てるときの v 部分

        /**
         * 月日として妥当な組み合わせかを判定する
         * @param {string} monthStr 月（数値でも可）
         * @param {string} dayStr 日（数値でも可）
         * @returns {boolean} 月日として妥当なら true
         */
        function isValidMonthDay(monthStr, dayStr) {
            var m = parseInt(monthStr, 10);
            var d = parseInt(dayStr, 10);
            return m >= 1 && m <= 12 && d >= 1 && d <= 31;
        }

        /**
         * 日付セグメントとして解釈できる文字列かを判定する
         * @param {string} token 判定するトークン
         * @returns {boolean} 日付トークンなら true
         */
        function isDateToken(token) {
            var s = String(token);
            if (/^\d{8}$/.test(s)) return isValidMonthDay(s.substring(4, 6), s.substring(6, 8));
            if (/^\d{6}$/.test(s)) return isValidMonthDay(s.substring(2, 4), s.substring(4, 6));
            return false;
        }

        /**
         * バージョンセグメントとして解釈できる文字列かを判定する
         * @param {string} token 判定するトークン
         * @returns {boolean} バージョントークンなら true
         */
        function isVersionToken(token) {
            return VERSION_TOKEN_RE.test(String(token));
        }

        /**
         * ステータスセグメントとして解釈できるかを判定する
         * @param {string} token 判定するトークン
         * @returns {string} 一致したステータス値（無ければ空文字）
         */
        function matchStatusToken(token) {
            var s = String(token).toLowerCase();
            for (var i = 1; i < STATUS_ITEMS.length; i++) {
                if (isStatusDivider(STATUS_ITEMS[i])) continue;
                if (STATUS_ITEMS[i].value === s) return STATUS_ITEMS[i].value;
            }
            return '';
        }

        /**
         * ファイル名をセグメントの配列へ分解する
         * @param {string} name 拡張子を除いたファイル名
         * @returns {array} {kind, value, sep} を要素とするセグメント配列
         */
        function parseFileName(name) {
            var split = String(name).split(/([-_])/); // ["handout","-","Adobe","-","20260422"]
            var segments = [];
            var textBuffer = [];      // token と区切りを交互に蓄積（join('') で結合）
            var textLeadingSep = '';  // テキスト segment の直前に置く区切り
            var hasDate = false, hasVersion = false, hasStatus = false;
            var currentSep = '';

            /**
             * 読み取り中のテキストを 1 セグメントとして確定する
             * @returns {void}
             */
            function flushText() {
                if (!textBuffer.length) return;
                segments.push({
                    kind: 'text',
                    value: textBuffer.join(''),
                    sep: textLeadingSep
                });
                textBuffer = [];
                textLeadingSep = '';
            }

            var i = 0;
            while (i < split.length) {
                if (i % 2 === 1) {
                    currentSep = split[i];
                    i++;
                    continue;
                }
                var token = split[i];

                // YYYY-MM-DD / YYYY_MM_DD（3 トークン + 同じ区切り 2 つ）の日付パターン
                if (!hasDate && i > 0
                    && /^\d{4}$/.test(token)
                    && i + 4 < split.length
                    && (split[i + 1] === '-' || split[i + 1] === '_')
                    && /^\d{2}$/.test(split[i + 2])
                    && split[i + 3] === split[i + 1]
                    && /^\d{2}$/.test(split[i + 4])
                    && isValidMonthDay(split[i + 2], split[i + 4])) {
                    flushText();
                    var compositeDate = token + split[i + 1] + split[i + 2] + split[i + 3] + split[i + 4];
                    segments.push({ kind: 'date', value: compositeDate, sep: currentSep });
                    hasDate = true;
                    i += 5; // 3 tokens + 2 separators
                    continue;
                }

                if (i === 0) {
                    segments.push({ kind: 'base', value: token, sep: '' });
                } else if (!hasDate && isDateToken(token)) {
                    flushText();
                    segments.push({ kind: 'date', value: token, sep: currentSep });
                    hasDate = true;
                } else if (!hasVersion && isVersionToken(token)) {
                    flushText();
                    segments.push({ kind: 'version', value: token, sep: currentSep });
                    hasVersion = true;
                } else if (FEATURE_STATUS && !hasStatus && matchStatusToken(token)) {
                    flushText();
                    segments.push({ kind: 'status', value: matchStatusToken(token), sep: currentSep });
                    hasStatus = true;
                } else {
                    if (!textBuffer.length) {
                        textLeadingSep = currentSep;
                    } else {
                        textBuffer.push(currentSep);
                    }
                    textBuffer.push(token);
                }
                i++;
            }
            flushText();
            return segments;
        }

        /**
         * 分断されたテキストセグメントをつなぎ直す
         * @param {array} segments セグメント配列
         * @returns {array} text をまとめたセグメント配列
         */
        function mergeFragmentedText(segments) {
            var firstText = -1, lastText = -1;
            for (var i = 0; i < segments.length; i++) {
                if (segments[i].kind === 'text') {
                    if (firstText === -1) firstText = i;
                    lastText = i;
                }
            }
            if (firstText === -1 || firstText === lastText) return segments;
            var combined = segments[firstText].value;
            for (var j = firstText + 1; j <= lastText; j++) {
                combined += segments[j].sep + segments[j].value;
            }
            var merged = { kind: 'text', value: combined, sep: segments[firstText].sep };
            var result = segments.slice(0, firstText);
            result.push(merged);
            for (var k = lastText + 1; k < segments.length; k++) result.push(segments[k]);
            return result;
        }

        /**
         * 既存のファイル名からセグメントの並び順を推定する
         * @param {array} segments セグメント配列
         * @returns {array} 出現順の並び（SEGMENT_ORDER の kind）
         */
        function deriveOrderFromSegments(segments) {
            var kindToOrder = {
                base: 'base',
                text: 'title',
                status: 'status',
                date: 'timestamp',
                version: 'version'
            };
            var order = [];
            var seen = {};
            for (var i = 0; i < segments.length; i++) {
                var k = kindToOrder[segments[i].kind];
                if (!k || seen[k]) continue;
                if (k === 'status' && !FEATURE_STATUS) continue;
                order.push(k);
                seen[k] = true;
            }
            return order;
        }

        /**
         * 指定した種別の最初のセグメント値を取得する
         * @param {array} segments セグメント配列
         * @param {string} kind 取得する kind
         * @returns {string} 最初に見つかった値（無ければ空文字）
         */
        function getFirstSegmentValue(segments, kind) {
            for (var i = 0; i < segments.length; i++) {
                if (segments[i].kind === kind) return segments[i].value;
            }
            return '';
        }

        /**
         * 左側をゼロ埋めして桁を揃える
         * @param {string} str 対象の文字列
         * @param {number} width 必要な桁数
         * @returns {string} 0 で左詰めした文字列
         */
        function padLeft(str, width) {
            while (str.length < width) str = '0' + str;
            return str;
        }

        /**
         * 今日の日付からタイムスタンプ文字列を作る
         * @param {string} sep 年月日の間に挟む文字（省略可）
         * @param {boolean} withTime true なら末尾に "-HHMM" を付ける
         * @returns {string} 今日の日付文字列
         */
        function todayTimestamp(sep, withTime) {
            sep = sep || '';
            var d = new Date();
            var date = String(d.getFullYear()) + sep +
                padLeft(String(d.getMonth() + 1), 2) + sep +
                padLeft(String(d.getDate()), 2);
            if (!withTime) return date;
            return date + '-' + padLeft(String(d.getHours()), 2) + padLeft(String(d.getMinutes()), 2);
        }

        /**
         * バージョン番号を 1 つ繰り上げる
         * @param {string} currentBaseName 拡張子を除いた現在のファイル名
         * @returns {string} v 番号を 1 つ繰り上げたファイル名
         */
        function bumpVersionInPlace(currentBaseName) {
            var parts = extractNumberedParts(currentBaseName, VERSION_TOKEN_SOURCE);
            if (!parts) return currentBaseName + '-v2';
            var nextNum = parseInt(parts.digits, 10) + 1;
            var newDigits = padLeft(String(nextNum), parts.digits.length);
            return parts.prefix + parts.token + newDigits + parts.suffix;
        }

        /**
         * バージョン番号を指定の書式へ整形する
         * @param {string} originalVersion 元のバージョン文字列（無ければ空）
         * @param {string} mode 桁数モード（'padded' / 'paddedWide' / それ以外）
         * @returns {string} 繰り上げたバージョン文字列
         */
        function formatVersion(originalVersion, mode) {
            var match = String(originalVersion || '').match(/^([vV])(\d+)$/);
            var letter = match ? match[1] : 'v';
            var nextNum = match ? (parseInt(match[2], 10) + 1) : 1;
            if (mode === 'padded') {
                var width = match ? Math.max(match[2].length, 2) : 2;
                return letter + padLeft(String(nextNum), width);
            }
            if (mode === 'paddedWide') {
                var widthWide = match ? Math.max(match[2].length, 3) : 3;
                return letter + padLeft(String(nextNum), widthWide);
            }
            return letter + String(nextNum);
        }

        /* ダイアログ表示中はフォルダーの内容が変わらない前提で、ファイル名一覧を 1 度だけ列挙して使い回す。
           採番は 1 打鍵ごとに走るため、毎回 getFiles() すると数千ファイルのフォルダーで目に見えて重くなる */
        var folderFileNamesCache = {};

        /**
         * フォルダー内のファイル名一覧を返す（同じフォルダーの 2 回目以降はキャッシュを返す）
         * @param {Folder} folder 走査するフォルダー
         * @returns {array} % デコード済みのファイル名の配列
         */
        function getFolderFileNames(folder) {
            if (!folder) return [];
            var key = folder.fsName;
            if (folderFileNamesCache[key]) return folderFileNamesCache[key];
            var files;
            try { files = folder.getFiles(); } catch (e) { return []; }
            var names = [];
            for (var i = 0; i < files.length; i++) {
                if (!(files[i] instanceof File)) continue;
                names.push(decodePercentEncoded(files[i].name));
            }
            folderFileNamesCache[key] = names;
            return names;
        }

        /**
         * フォルダー列挙のキャッシュを破棄する。ダイアログを閉じたあと、実保存前に呼んで
         * 表示中に増えたファイルを採番に反映させる
         * @returns {void}
         */
        function resetFolderFileNamesCache() {
            folderFileNamesCache = {};
        }

        /**
         * baseName 内の最初の「{tokenSource}+数字」セグメントを抽出する。マッチしなければ null。
         * 区切り（- _ .）か文字列端に挟まれたものだけを対象にするため、"rev1-catalog-v02" では
         * "rev1" ではなく "v02" を拾う（部分文字列で拾うと無関係な語が繰り上がる）
         * @param {string} baseName 拡張子を除いたファイル名
         * @param {string} tokenSource 数字の直前に来るトークンの正規表現ソース（"[vV]" など）
         * @returns {object} {prefix, token, digits, suffix}（マッチしなければ null）
         */
        function extractNumberedParts(baseName, tokenSource) {
            var re = new RegExp('^(|.*?[-_.])(' + tokenSource + ')(\\d+)(?=$|[-_.])(.*)$', 'i');
            var m = String(baseName).match(re);
            if (!m) return null;
            return { prefix: m[1], token: m[2], digits: m[3], suffix: m[4] };
        }

        /**
         * 正規表現で特別な意味を持つ文字をエスケープする
         * @param {string} s エスケープする文字列
         * @returns {string} 正規表現で安全に使える文字列
         */
        function escapeRegExp(s) {
            return String(s).replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        }

        /**
         * baseName と同じ prefix / suffix を持つファイルを folder から探し、最大の番号を返す
         * @param {string} baseName 照合するベース名
         * @param {Folder} folder 走査するフォルダー
         * @param {string} ext 拡張子（".indd" など）
         * @param {string} tokenSource 数字の直前に来るトークンの正規表現ソース
         * @returns {number} 最大の番号（見つからなければ null）
         */
        function findMaxNumberedInFolder(baseName, folder, ext, tokenSource) {
            if (!folder) return null;
            var parts = extractNumberedParts(baseName, tokenSource);
            if (!parts) return null;
            var re = new RegExp(
                '^' + escapeRegExp(parts.prefix) + '(?:' + tokenSource + ')(\\d+)'
                + escapeRegExp(parts.suffix) + escapeRegExp(ext) + '$',
                'i'
            );
            var names = getFolderFileNames(folder);
            var maxNum = -1;
            for (var i = 0; i < names.length; i++) {
                var m = names[i].match(re);
                if (!m) continue;
                var num = parseInt(m[1], 10);
                if (num > maxNum) maxNum = num;
            }
            return maxNum >= 0 ? maxNum : null;
        }

        /**
         * baseName 内の番号を、親フォルダー内の同パターンの最大番号 +1 に置き換える。
         * 無い、または +1 が現在値以下のときは baseName のまま返す。桁数は維持
         * @param {string} baseName 拡張子を除いたファイル名
         * @param {Folder} folder 走査するフォルダー
         * @param {string} ext 拡張子
         * @param {string} tokenSource 数字の直前に来るトークンの正規表現ソース
         * @returns {string} 衝突しない番号に置き換えたファイル名
         */
        function nextAvailableNumberedName(baseName, folder, ext, tokenSource) {
            var maxNum = findMaxNumberedInFolder(baseName, folder, ext, tokenSource);
            if (maxNum === null) return baseName;
            var parts = extractNumberedParts(baseName, tokenSource);
            if (!parts) return baseName;
            var current = parseInt(parts.digits, 10);
            var target = maxNum + 1;
            if (target <= current) return baseName;
            var width = Math.max(parts.digits.length, String(target).length);
            return parts.prefix + parts.token + padLeft(String(target), width) + parts.suffix;
        }

        /**
         * v 番号を親フォルダー内の最大値 +1 に繰り上げる
         * @param {string} baseName 拡張子を除いたファイル名
         * @param {Folder} folder 走査するフォルダー
         * @param {string} ext 拡張子
         * @returns {string} 衝突しない v 番号に置き換えたファイル名
         */
        function nextAvailableVersionName(baseName, folder, ext) {
            return nextAvailableNumberedName(baseName, folder, ext, VERSION_TOKEN_SOURCE);
        }

        /**
         * 連番を親フォルダー内の最大値 +1 に繰り上げる
         * @param {string} baseName 拡張子を除いたファイル名
         * @param {Folder} folder 走査するフォルダー
         * @param {string} ext 拡張子
         * @param {string} prefix 連番のプレフィックス（空なら何もしない）
         * @returns {string} 衝突しない連番に置き換えたファイル名
         */
        function nextAvailablePageName(baseName, folder, ext, prefix) {
            var p = String(prefix || '');
            if (!p) return baseName;
            return nextAvailableNumberedName(baseName, folder, ext, escapeRegExp(p));
         }

        /* Windows 予約名（拡張子の有無を問わず使用不可）。一致したら末尾に "_" を足してエスケープ
           / Windows-reserved basenames (regardless of extension); append "_" to escape them */
        var WINDOWS_RESERVED_NAMES = {
            CON: 1, PRN: 1, AUX: 1, NUL: 1,
            COM1: 1, COM2: 1, COM3: 1, COM4: 1, COM5: 1,
            COM6: 1, COM7: 1, COM8: 1, COM9: 1,
            LPT1: 1, LPT2: 1, LPT3: 1, LPT4: 1, LPT5: 1,
            LPT6: 1, LPT7: 1, LPT8: 1, LPT9: 1
        };

        /**
         * Windows の予約語にあたる名前を安全な形へ変える
         * @param {string} baseName 拡張子を除いたファイル名
         * @returns {string} 予約名なら "_" を足した名前
         */
        function escapeWindowsReserved(baseName) {
            var key = String(baseName).toUpperCase();
            return (WINDOWS_RESERVED_NAMES[key] === 1) ? baseName + '_' : baseName;
        }

        /**
         * 連番プレフィックスにも本体と同じ整形を掛ける。ベース名は整形後の文字列で照合されるため、
         * 生の入力（"page " など）のままだとパターンが一致せず採番が空振りする。
         * 区切りの圧縮（collapseAndTrimSeparators）は末尾の区切りを落としてしまうので掛けない
         * @param {string} prefix 連番のプレフィックス
         * @param {object} uiState UI の状態
         * @returns {string} 整形後のプレフィックス
         */
        function transformPagePrefix(prefix, uiState) {
            var text = String(prefix || '');
            if (!text) return text;
            if (FEATURE_NFC && uiState.nfc === 'combine') text = normalizeNFC(text);
            if (FEATURE_HALFWIDTH_KANA && uiState.halfwidthKana === 'convert'
                && (uiState.clean === 'dash' || uiState.clean === 'underscore')) {
                text = convertHalfwidthKana(text);
            }
            if (FEATURE_TRANSLITERATE) text = transliterate(text, uiState.translit);
            if (FEATURE_CLEAN) text = cleanFilenameChars(text, uiState.clean);
            return text;
        }

        /**
         * ベース名に整形と採番をまとめて適用する。
         * プレビューと実保存の両方がこの 1 本を通ることで、ダイアログの表示と
         * 実際に書き出される名前がずれないようにしている
         * @param {string} baseName 整形前のベース名（拡張子なし）
         * @param {object} uiState UI の状態
         * @param {Folder} folder 採番で走査するフォルダー
         * @param {string} ext 拡張子（".indd"）
         * @returns {string} 整形・採番済みのベース名
         */
        function applyNameTransforms(baseName, uiState, folder, ext) {
            var name = baseName;
            if (FEATURE_NFC && uiState.nfc === 'combine') {
                name = normalizeNFC(name);
            }
            // 半角カナ → 全角カナ（clean が '-' / '_' のときだけ）。translit より先に行う
            if (FEATURE_HALFWIDTH_KANA && uiState.halfwidthKana === 'convert'
                && (uiState.clean === 'dash' || uiState.clean === 'underscore')) {
                name = convertHalfwidthKana(name);
            }
            // translit はクリーンより先に行う（㈱→株 などを残すため）
            if (FEATURE_TRANSLITERATE) {
                name = transliterate(name, uiState.translit);
            }
            if (FEATURE_CLEAN) {
                name = cleanFilenameChars(name, uiState.clean);
            }
            name = collapseAndTrimSeparators(name, uiState.separator);
            // 採番は整形後の名前で行う。フォルダー内の既存ファイル名は整形済みで保存されているため、
            // clean / translit / 区切り統一のあとに走らせないと prefix/suffix が一致せず最大値を取りこぼす
            if (uiState.version === 'short' || uiState.version === 'padded' || uiState.version === 'paddedWide') {
                name = nextAvailableVersionName(name, folder, ext);
            }
            if (uiState.pageEnable === 'yes') {
                name = nextAvailablePageName(name, folder, ext, transformPagePrefix(uiState.pagePrefix, uiState));
            }
            return escapeWindowsReserved(name);
        }

        /**
         * パーセントエンコードされた文字列を復号する
         * @param {string} str 対象の文字列
         * @returns {string} デコードした文字列（失敗時は元の文字列）
         */
        function decodePercentEncoded(str) {
            str = String(str);
            if (str.indexOf('%') === -1) return str;
            try {
                return decodeURIComponent(str);
            } catch (e) {
                return str;
            }
        }

        /**
         * ファイル名から拡張子を取り除く
         * @param {string} name 対象のファイル名
         * @returns {string} 拡張子を除いた名前
         */
        function stripExtension(name) {
            var dot = name.lastIndexOf('.');
            return (dot > 0) ? name.substring(0, dot) : name;
        }

        /**
         * パス比較用に畳んだキーを返す（% デコード + 濁点の NFC 結合 + 小文字化）。
         * macOS は大文字小文字を区別せず、ディスク上の日本語名は NFD で保持されるため、
         * 生の文字列比較では同じファイルを別ファイルと誤判定する
         * @param {string} path 対象のパス
         * @returns {string} 比較用に畳んだパス
         */
        function foldPathForCompare(path) {
            return normalizeNFC(decodePercentEncoded(String(path))).toLowerCase();
        }

        /**
         * 2 つのパスが同じファイルの綴り違い（大文字小文字 / 濁点の合成違い）かを判定する
         * @param {string} pathA 比較するパス
         * @param {string} pathB 比較するパス
         * @returns {boolean} 同じファイルを指していれば true
         */
        function isSamePathSpelling(pathA, pathB) {
            if (!pathA || !pathB) return false;
            if (pathA === pathB) return true;
            return foldPathForCompare(pathA) === foldPathForCompare(pathB);
        }

        /**
         * ファイルの更新日時をミリ秒で返す
         * @param {string} path 対象のパス
         * @returns {number} 更新日時（存在しない・読めない場合は null）
         */
        function fileModifiedTime(path) {
            if (!path) return null;
            var file = File(path);
            if (!file.exists) return null;
            try {
                return file.modified ? file.modified.getTime() : null;
            } catch (e) {
                return null;
            }
        }

        /**
         * 連続する区切り記号をまとめ、前後の区切りを取り除く
         * @param {string} str 対象の文字列
         * @param {string} sep 最終的な区切り文字（'-' / '_' / ''）
         * @returns {string} 整えた文字列
         */
        function collapseAndTrimSeparators(str, sep) {
            var s = String(str);
            if (sep === '-' || sep === '_') {
                // 異種の混在も含めて連続した区切りを sep 1 つに統一（YYYY-MM-DD 等は呼び出し前に通過済み想定）
                s = s.replace(/[-_.]{2,}/g, sep);
            } else {
                // 区切り未指定でも同種連続だけは圧縮（-- → -, __ → _, .. → .）
                s = s.replace(/--+/g, '-').replace(/__+/g, '_').replace(/\.\.+/g, '.');
            }
            // 先頭末尾の区切り・空白を除去
            s = s.replace(/^[-_.\s]+|[-_.\s]+$/g, '');
            return s;
        }

        /**
         * UTF-8 でのバイト数を数える
         * @param {string} str 対象の文字列
         * @returns {number} UTF-8 でのバイト長
         */
        function byteLengthUTF8(str) {
            var s = String(str);
            var n = 0;
            for (var i = 0; i < s.length; i++) {
                var code = s.charCodeAt(i);
                if (code < 0x80) n += 1;
                else if (code < 0x800) n += 2;
                else if (code >= 0xD800 && code <= 0xDBFF) { n += 4; i++; } // サロゲートペア（4 バイト）
                else n += 3;
            }
            return n;
        }

        /**
         * ファイル名に使えない文字を置き換える
         * @param {string} str 対象の文字列
         * @returns {string} ファイル名に使える文字列
         */
        function sanitizeFilename(str) {
            var trimmed = String(str).replace(/^\s+|\s+$/g, '');
            if (FEATURE_CLEAN) return trimmed;
            return trimmed.replace(/[\\\/:*?"<>|]/g, '');
        }

        /**
         * 文字列を NFC 正規化する
         * @param {string} str 対象の文字列
         * @returns {string} 濁点・半濁点を結合した文字列
         */
        function normalizeNFC(str) {
            return String(str).replace(/(.)([゙゚])/g, function (_, base, mark) {
                var voiced = (mark === '゙');
                if (voiced) {
                    if (base === 'う') return 'ゔ';
                    if (base === 'ウ') return 'ヴ';
                    if (base === 'ワ') return 'ヷ';
                    if (base === 'ヰ') return 'ヸ';
                    if (base === 'ヱ') return 'ヹ';
                    if (base === 'ヲ') return 'ヺ';
                }
                var code = base.charCodeAt(0);
                var isHiragana = code >= 0x3041 && code <= 0x3093;
                var isKatakana = code >= 0x30A1 && code <= 0x30F3;
                if (isHiragana || isKatakana) {
                    return String.fromCharCode(code + (voiced ? 1 : 2));
                }
                return base + mark;
            });
        }

        /**
         * ファイル名にそのまま使える文字かを判定する
         * @param {number} code 判定する文字コード
         * @returns {boolean} 標準的な文字なら true
         */
        function isStandardFilenameChar(code) {
            // OS 禁止文字: \ 5C / 2F : 3A * 2A ? 3F " 22 < 3C > 3E | 7C
            if (code === 0x5C || code === 0x2F || code === 0x3A || code === 0x2A
                || code === 0x3F || code === 0x22 || code === 0x3C
                || code === 0x3E || code === 0x7C) return false;
            // 半角・全角スペース
            if (code === 0x20 || code === 0x3000) return false;
            if (code >= 0x21 && code <= 0x7E) return true;     // ASCII printable（space を除く）
            if (code >= 0x3001 && code <= 0x303F) return true; // CJK 記号と句読点（、。「」など / 全角スペースを除く）
            if (code >= 0x3040 && code <= 0x309F) return true; // ひらがな
            if (code >= 0x30A0 && code <= 0x30FF) return true; // カタカナ
            if (code >= 0x3400 && code <= 0x4DBF) return true; // CJK 拡張 A
            if (code >= 0x4E00 && code <= 0x9FFF) return true; // CJK 基本
            if (code >= 0xAC00 && code <= 0xD7A3) return true; // ハングル音節
            if (code >= 0xFF00 && code <= 0xFF5E) return true; // 全角 ASCII
            if (code >= 0xFF61 && code <= 0xFF9F) return true; // 半角カタカナ
            return false;
        }

        /**
         * ファイル名に不向きな文字を置き換える
         * @param {string} str 対象の文字列
         * @param {string} mode 処理モード（'remove' / 'dash' / 'underscore'）
         * @returns {string} 整えた文字列
         */
        function cleanFilenameChars(str, mode) {
            var replacement = (mode === 'dash') ? '-' : (mode === 'underscore') ? '_' : '';
            // 連続する空白を 1 つにまとめてから per-char で置換（mode='dash' で "  " が "--" にならないように）
            var s = String(str).replace(/\s+/g, ' ');
            var result = '';
            var i = 0;
            while (i < s.length) {
                var code = s.charCodeAt(i);
                if (code >= 0xD800 && code <= 0xDBFF && i + 1 < s.length) {
                    // 高サロゲート + 低サロゲートは常に非標準（BMP 外の絵文字など）
                    result += replacement;
                    i += 2;
                    continue;
                }
                if (isStandardFilenameChar(code)) {
                    result += s.charAt(i);
                } else {
                    result += replacement;
                }
                i++;
            }
            return result;
        }

        /* 半角カタカナ → 全角カタカナのマップ（清音）/ Half-width → full-width katakana (unvoiced) */
        var HALFWIDTH_KANA_MAP = {
            'ｦ': 'ヲ', 'ｧ': 'ァ', 'ｨ': 'ィ', 'ｩ': 'ゥ', 'ｪ': 'ェ', 'ｫ': 'ォ',
            'ｬ': 'ャ', 'ｭ': 'ュ', 'ｮ': 'ョ', 'ｯ': 'ッ', 'ｰ': 'ー',
            'ｱ': 'ア', 'ｲ': 'イ', 'ｳ': 'ウ', 'ｴ': 'エ', 'ｵ': 'オ',
            'ｶ': 'カ', 'ｷ': 'キ', 'ｸ': 'ク', 'ｹ': 'ケ', 'ｺ': 'コ',
            'ｻ': 'サ', 'ｼ': 'シ', 'ｽ': 'ス', 'ｾ': 'セ', 'ｿ': 'ソ',
            'ﾀ': 'タ', 'ﾁ': 'チ', 'ﾂ': 'ツ', 'ﾃ': 'テ', 'ﾄ': 'ト',
            'ﾅ': 'ナ', 'ﾆ': 'ニ', 'ﾇ': 'ヌ', 'ﾈ': 'ネ', 'ﾉ': 'ノ',
            'ﾊ': 'ハ', 'ﾋ': 'ヒ', 'ﾌ': 'フ', 'ﾍ': 'ヘ', 'ﾎ': 'ホ',
            'ﾏ': 'マ', 'ﾐ': 'ミ', 'ﾑ': 'ム', 'ﾒ': 'メ', 'ﾓ': 'モ',
            'ﾔ': 'ヤ', 'ﾕ': 'ユ', 'ﾖ': 'ヨ',
            'ﾗ': 'ラ', 'ﾘ': 'リ', 'ﾙ': 'ル', 'ﾚ': 'レ', 'ﾛ': 'ロ',
            'ﾜ': 'ワ', 'ﾝ': 'ン'
        };

        /* 半角カナ + ﾞ の結合マップ（濁音）/ Half-width + dakuten → voiced full-width */
        var HALFWIDTH_KANA_VOICED = {
            'ｶ': 'ガ', 'ｷ': 'ギ', 'ｸ': 'グ', 'ｹ': 'ゲ', 'ｺ': 'ゴ',
            'ｻ': 'ザ', 'ｼ': 'ジ', 'ｽ': 'ズ', 'ｾ': 'ゼ', 'ｿ': 'ゾ',
            'ﾀ': 'ダ', 'ﾁ': 'ヂ', 'ﾂ': 'ヅ', 'ﾃ': 'デ', 'ﾄ': 'ド',
            'ﾊ': 'バ', 'ﾋ': 'ビ', 'ﾌ': 'ブ', 'ﾍ': 'ベ', 'ﾎ': 'ボ',
            'ｳ': 'ヴ'
        };

        /* 半角カナ + ﾟ の結合マップ（半濁音）/ Half-width + handakuten → semi-voiced full-width */
        var HALFWIDTH_KANA_SEMI_VOICED = {
            'ﾊ': 'パ', 'ﾋ': 'ピ', 'ﾌ': 'プ', 'ﾍ': 'ペ', 'ﾎ': 'ポ'
        };

        /**
         * 半角カナを全角カナへ変換する
         * @param {string} str 対象の文字列
         * @returns {string} 半角カナを全角にした文字列
         */
        function convertHalfwidthKana(str) {
            var s = String(str);
            var result = '';
            var i = 0;
            while (i < s.length) {
                var ch = s.charAt(i);
                var next = (i + 1 < s.length) ? s.charAt(i + 1) : '';
                if (next === 'ﾞ' && typeof HALFWIDTH_KANA_VOICED[ch] === 'string') {
                    result += HALFWIDTH_KANA_VOICED[ch];
                    i += 2;
                    continue;
                }
                if (next === 'ﾟ' && typeof HALFWIDTH_KANA_SEMI_VOICED[ch] === 'string') {
                    result += HALFWIDTH_KANA_SEMI_VOICED[ch];
                    i += 2;
                    continue;
                }
                var mapped = HALFWIDTH_KANA_MAP[ch];
                if (typeof mapped === 'string') {
                    result += mapped;
                } else if (ch === 'ﾞ') {
                    result += '゛';
                } else if (ch === 'ﾟ') {
                    result += '゜';
                } else {
                    result += ch;
                }
                i++;
            }
            return result;
        }

        /**
         * 丸数字や法人略記などを ASCII 表記へ置き換える
         * @param {string} str 対象の文字列
         * @param {string} mode 処理モード（'remove' / 'convert' / それ以外）
         * @returns {string} 変換後の文字列
         */
        function transliterate(str, mode) {
            if (mode === 'keep') return String(str);
            var s = String(str);
            var result = '';
            for (var i = 0; i < s.length; i++) {
                var ch = s.charAt(i);
                var mapped = TRANSLITERATE_MAP[ch];
                if (typeof mapped === 'string') {
                    result += (mode === 'remove') ? '' : mapped;
                } else {
                    result += ch;
                }
            }
            return result;
        }

        /**
         * 保存先フォルダをユーザーに選ばせる
         * @param {string} promptLabel ダイアログに表示する説明
         * @returns {File} 選択されたファイル（キャンセル時は null）
         */
        function pickInddDestination(promptLabel) {
            var chosen = File.saveDialog(promptLabel, '*.indd');
            if (!chosen) return null;
            var file = File(chosen.fsName);
            if (!/\.indd$/i.test(file.name)) {
                file = File(file.parent.fsName + '/' + stripExtension(file.name) + '.indd');
            }
            return file;
        }

        /**
         * 設定を保存するファイルを取得する
         * @returns {File} 設定ファイル
         */
        function getPrefsFile() {
            return File(Folder.userData.fsName + '/FileNameManager-prefs.txt');
        }

        /**
         * 保存しておいた設定を読み込む
         * @returns {object} 保存されていた設定（無ければ空オブジェクト）
         */
        function loadPrefs() {
            var file = getPrefsFile();
            if (!file.exists) return {};
            file.encoding = 'UTF-8';
            file.open('r');
            var raw = file.read();
            file.close();
            var prefs = {};
            var lines = String(raw).split('\n');
            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];
                var eq = line.indexOf('=');
                if (eq > 0) prefs[line.substring(0, eq)] = line.substring(eq + 1);
            }
            return prefs;
        }

        /**
         * 現在の設定を保存する
         * @param {object} prefs 保存する設定
         * @returns {void}
         */
        function savePrefs(prefs) {
            try {
                var file = getPrefsFile();
                file.encoding = 'UTF-8';
                file.open('w');
                var lines = [];
                for (var key in prefs) {
                    if (prefs.hasOwnProperty(key)) lines.push(key + '=' + prefs[key]);
                }
                file.write(lines.join('\n'));
                file.close();
            } catch (e) { /* 保存できなくても処理は止めない */ }
        }

        /**
         * アクティブドキュメントのファイル情報を集める
         * @param {Document} doc 対象のドキュメント
         * @returns {object} ファイル名・パス・親フォルダー名などの情報
         */
        function gatherDocumentInfo(doc) {
            var fullName = doc.fullName;
            var currentName = decodePercentEncoded(fullName ? fullName.name : doc.name);
            var parentFolderName = '';
            var grandparentFolderName = '';
            if (fullName && fullName.parent) {
                parentFolderName = decodePercentEncoded(fullName.parent.name);
                if (fullName.parent.parent) {
                    grandparentFolderName = decodePercentEncoded(fullName.parent.parent.name);
                }
            }
            return {
                currentName: currentName,
                baseName: stripExtension(currentName),
                fsPath: fullName ? fullName.fsName : null,
                folder: fullName ? fullName.parent : null,
                parentFolderName: parentFolderName,
                grandparentFolderName: grandparentFolderName
            };
        }

        /**
         * 保存先フォルダを確定する（未保存なら選択させる）
         * @param {Folder} folder 既に判明しているフォルダー（無ければ null）
         * @returns {Folder} 保存先フォルダー（キャンセル時は null）
         */
        function ensureTargetFolder(folder) {
            if (folder) return folder;
            var picked = pickInddDestination(getLabel('message.chooseDestination'));
            return picked ? picked.parent : null;
        }

        /**
         * 書類が InDesign ネイティブ（.indd）かどうかを判定する。
         * 保存されるのは常に .indd なので、.indd 以外の書類でリネームすると形式変換したうえで
         * 原本を失う。コピーも元ファイルのバイトコピーなので中身と拡張子が食い違う。
         * 未保存なら失う原本が無いので許可する
         * @param {object} documentInfo gatherDocumentInfo が返すファイル情報
         * @returns {boolean} .indd（または未保存）なら true
         */
        function isNativeDocument(documentInfo) {
            if (!documentInfo.fsPath) return true;
            return /\.indd$/i.test(documentInfo.currentName);
        }

        /**
         * 同名ファイルがある場合に上書きの可否を確認する
         * @param {File} destFile 保存先のファイル
         * @param {string} originalFsPath 元ファイルのパス
         * @returns {boolean} 続行してよければ true
         */
        function confirmOverwriteIfExists(destFile, originalFsPath) {
            if (!destFile.exists) return true;
            // 大文字小文字・濁点の合成違いだけのリネームは自分自身への上書きなので確認しない
            if (isSamePathSpelling(destFile.fsName, originalFsPath)) return true;
            return confirm(getLabel('message.confirmOverwrite') + '\n\n' + destFile.fsName, true);
        }

        /**
         * ファイルをゴミ箱へ移動する
         * @param {File} file 移動するファイル
         * @returns {boolean} 移動できたら true
         */
        function moveToTrash(file) {
            if (!file || !file.exists) return false;
            var trash = Folder("~/.Trash");
            if (!trash.exists) return false;
            var origName = file.name;
            var dot = origName.lastIndexOf('.');
            var stem = (dot > 0) ? origName.substring(0, dot) : origName;
            var ext = (dot > 0) ? origName.substring(dot) : '';
            var dest = File(trash.fsName + '/' + origName);
            var counter = 1;
            while (dest.exists) {
                dest = File(trash.fsName + '/' + stem + ' ' + counter + ext);
                counter++;
                if (counter > 9999) return false; // 暴走防止
            }
            try {
                if (!file.copy(dest)) return false;
                return file.remove();
            } catch (e) {
                return false;
            }
        }

        /**
         * リネーム時に元ファイルを削除する
         * @param {string} originalFsPath 元ファイルのパス
         * @param {string} destFsPath 保存先のパス
         * @param {number} modifiedBeforeSave 保存前の元ファイルの更新日時（ミリ秒、無ければ null）
         * @returns {void}
         */
        function removeOriginalFile(originalFsPath, destFsPath, modifiedBeforeSave) {
            if (!originalFsPath || isSamePathSpelling(originalFsPath, destFsPath)) return;
            var file = File(originalFsPath);
            if (!file.exists) return;
            // 綴り違いを取りこぼしても保存したてのファイルを消さないための最終防衛線。
            // 直前の保存は保存先しか触らないので、元ファイルの更新日時が動いていたら
            // それは保存先と同一実体（大文字小文字・NFD/NFC 違いのパス）である
            var modifiedNow = fileModifiedTime(originalFsPath);
            if (modifiedBeforeSave !== null && modifiedNow !== null && modifiedNow !== modifiedBeforeSave) return;
            if (FEATURE_USE_TRASH && moveToTrash(file)) return;
            try { file.remove(); } catch (e) { /* 削除できない場合は黙って継続 */ }
        }

        /**
         * 選択したモードでリネーム・別名保存・コピー保存を実行する
         * @param {Document} doc 対象のドキュメント
         * @param {File} destFile 保存先のファイル
         * @param {string} mode 動作モード（'rename' / 'saveAs' / 'copy'）
         * @param {string} originalFsPath 元ファイルのパス（未保存なら null）
         * @returns {void}
         */
        function executeOutput(doc, destFile, mode, originalFsPath) {
            if (mode === 'copy' && originalFsPath) {
                // 現在の変更を元ファイルへ保存してから、物理ファイルとしてコピー
                if (!doc.saved) doc.save();
                var originalFile = File(originalFsPath);
                if (!originalFile.exists) {
                    throw new Error(getLabel('message.saveFailed') + '\n' + destFile.fsName);
                }
                // File.copy() は既存ファイルを上書きしない。上書きは確認済みなので先に取り除く
                if (destFile.exists && !destFile.remove()) {
                    throw new Error(getLabel('message.saveFailed') + '\n' + destFile.fsName);
                }
                if (!originalFile.copy(destFile)) {
                    throw new Error(getLabel('message.saveFailed') + '\n' + destFile.fsName);
                }
                return;
            }
            // rename / saveAs / 未保存ドキュメントの copy: 新名で保存
            var modifiedBeforeSave = fileModifiedTime(originalFsPath);
            doc.save(destFile);
            if (mode === 'rename') {
                removeOriginalFile(originalFsPath, destFile.fsName, modifiedBeforeSave);
            }
        }

        /**
         * UI の状態とセグメントから最終的なファイル名を組み立てる
         * @param {array} segments セグメント配列
         * @param {object} uiState UI の状態
         * @returns {string} 拡張子を除いた最終ファイル名
         */
        function buildFinalName(segments, uiState) {
            // 区切り記号: 明示選択があればそれを、無ければ元のファイル名で優勢な区切りを使う
            var defaultSep;
            if (uiState.separator === '-' || uiState.separator === '_') {
                defaultSep = uiState.separator;
            } else {
                defaultSep = dominantSeparator(segments);
            }

            /**
             * セグメント種別ごとに出力する値を決める
             * @param {string} kind セグメントの kind
             * @returns {string} その kind の値（空文字なら出力しない）
             */
            function valueForKind(kind) {
                if (kind === 'base') {
                    return sanitizeFilename(uiState.baseText || '');
                }
                if (kind === 'title') {
                    if (uiState.titleMode === 'none') return '';
                    if (uiState.titleMode === 'parent') return sanitizeFilename(uiState.parentFolderName);
                    if (uiState.titleMode === 'grandparent') return sanitizeFilename(uiState.grandparentFolderName);
                    return sanitizeFilename(uiState.titleText);
                }
                if (kind === 'status') {
                    return uiState.status || '';
                }
                if (kind === 'timestamp') {
                    var withTime = (uiState.timestampTime === 'hhmm');
                    if (uiState.timestamp === 'date') return todayTimestamp('', withTime);
                    if (uiState.timestamp === 'dateDash') return todayTimestamp('-', withTime);
                    return '';
                }
                if (kind === 'version') {
                    if (uiState.version === 'none') return '';
                    return formatVersion(getFirstSegmentValue(segments, 'version'), uiState.version);
                }
                if (kind === 'page') {
                    if (uiState.pageEnable !== 'yes') return '';
                    var pageWidth = (uiState.pagePad === '3') ? 3 : 2;
                    return (uiState.pagePrefix || '') + padLeft('1', pageWidth);
                }
                return '';
            }

            // ピースごとに区切り統一（YYYY-MM-DD のタイムスタンプだけは内部 "-" を保護）
            var order = (uiState.segmentOrder && uiState.segmentOrder.length) ? uiState.segmentOrder : SEGMENT_ORDER;
            var pieces = [];
            for (var i = 0; i < order.length; i++) {
                var kind = order[i];
                var value = valueForKind(kind);
                if (!value) continue;
                // YYYY-MM-DD（および YYYY-MM-DD-HHMM、YYYYMMDD-HHMM）は内部の "-" を保護
                var isProtectedDate = (kind === 'timestamp')
                    && (uiState.timestamp === 'dateDash' || uiState.timestampTime === 'hhmm');
                if (!isProtectedDate && FEATURE_SEPARATOR) {
                    // 区切り記号統一。FEATURE_DOT_NORMALIZE が true なら "." も対象
                    if (uiState.separator === '-') {
                        value = FEATURE_DOT_NORMALIZE ? value.replace(/[_.]/g, '-') : value.replace(/_/g, '-');
                    } else if (uiState.separator === '_') {
                        value = FEATURE_DOT_NORMALIZE ? value.replace(/[-.]/g, '_') : value.replace(/-/g, '_');
                    }
                }
                pieces.push(value);
            }
            var result = pieces.join(defaultSep);
            // スペース（半角・全角・タブ・改行）の処理は後段の cleanFilenameChars に集約
            return result;
        }

        /**
         * ファイル名で最も多く使われている区切り記号を求める
         * @param {array} segments セグメント配列
         * @returns {string} 優勢な区切り文字
         */
        function dominantSeparator(segments) {
            var dashes = 0, underscores = 0;
            for (var i = 0; i < segments.length; i++) {
                if (segments[i].sep === '-') dashes++;
                else if (segments[i].sep === '_') underscores++;
            }
            return (underscores > dashes) ? '_' : '-';
        }

        // =========================================
        // ダイアログビルダー / Dialog builders
        // =========================================

        /**
         * セグメントの並び替えパネルを組み立てる
         * @param {Group} parent 追加先のコンテナ
         * @param {boolean} currentOrderAvailable 「現在のファイル名に準じる」を選べるか
         * @returns {object} パネル内のコントロール
         */
        function buildSortPanel(parent, currentOrderAvailable) {
            var panel = parent.add('panel', undefined, getLabel('panel.sort'));
            setupPanel(panel, 6);
            var sortOffRadio = panel.add('radiobutton', undefined, getLabel('radio.sortOff'));
            sortOffRadio.helpTip = getLabel('tip.sort');
            var sortCurrentRadio = panel.add('radiobutton', undefined, getLabel('radio.sortCurrent'));
            sortCurrentRadio.helpTip = getLabel('tip.sort');
            if (!currentOrderAvailable) sortCurrentRadio.enabled = false;
            // 「カスタム順」ラジオと「編集」ボタンを同じ行に並べる
            var customRow = panel.add('group');
            setupRow(customRow, ['fill', 'top'], 8);
            var sortOnRadio = customRow.add('radiobutton', undefined, getLabel('radio.sortOn'));
            sortOnRadio.helpTip = getLabel('tip.sort');
            var sortButton = customRow.add('button', undefined, getLabel('button.sort'));
            // 並び順の初期値は prefs を見ず、常に「現在のファイル名に準じる」（不可なら「標準順」）に固定
            var initialSort = currentOrderAvailable ? 'current' : 'off';
            /**
             * 3 つのラジオのうち 1 つだけを選択状態にする。
             * 「カスタム順」だけが customRow の中にいるため、ScriptUI の自動排他
             * （同じ親コンテナ内でのみ働く）が 3 つ揃っては効かない
             * @param {string} mode 選択する並び順（'off' / 'current' / 'on'）
             * @returns {void}
             */
            function selectSortMode(mode) {
                sortOffRadio.value = (mode === 'off');
                sortCurrentRadio.value = (mode === 'current');
                sortOnRadio.value = (mode === 'on');
                sortButton.enabled = (mode === 'on');
            }
            selectSortMode(initialSort);
            // onClick は呼び出し側で wire（refreshPreviews と組み合わせるため）
            return {
                panel: panel,
                sortOffRadio: sortOffRadio,
                sortCurrentRadio: sortCurrentRadio,
                sortOnRadio: sortOnRadio,
                sortButton: sortButton,
                /* 'off' / 'current' / 'on' */
                getSortMode: function () {
                    if (sortOnRadio.value) return 'on';
                    if (sortCurrentRadio.value) return 'current';
                    return 'off';
                },
                isSortOn: function () { return sortOnRadio.value; },
                selectSortMode: selectSortMode
            };
        }

        /**
         * 動作モード（リネーム／別名保存／コピー）のパネルを組み立てる
         * @param {Group} parent 追加先のコンテナ
         * @returns {object} パネル内のコントロール
         */
        function buildOpModePanel(parent) {
            var panel = parent.add('panel', undefined, getLabel('panel.opMode'));
            setupPanel(panel, 6);
            var versionOnlyRadio = panel.add('radiobutton', undefined, getLabel('radio.opVersionOnly'));
            var fullRadio = panel.add('radiobutton', undefined, getLabel('radio.opFull'));
            versionOnlyRadio.value = false;
            fullRadio.value = true;
            return {
                panel: panel,
                versionOnlyRadio: versionOnlyRadio,
                fullRadio: fullRadio,
                isVersionOnly: function () { return versionOnlyRadio.value; },
                getOpMode: function () { return versionOnlyRadio.value ? 'versionOnly' : 'full'; }
            };
        }

        /**
         * 動作モードのパネルを組み立てる
         * @param {Group} parent 追加先のコンテナ
         * @param {boolean} isNative 書類が .indd ネイティブか
         * @returns {object} パネル内のコントロール
         */
        function buildModePanel(parent, isNative) {
            var panel = parent.add('panel', undefined, getLabel('panel.mode'));
            setupPanel(panel, 6);
            var renameRadio = panel.add('radiobutton', undefined, getLabel('radio.rename'));
            // .indd 以外の書類は保存が形式変換になるため、元ファイルを消すリネームは選ばせない
            renameRadio.enabled = !!isNative;
            renameRadio.helpTip = isNative ? getLabel('tip.rename') : getLabel('tip.nonNativeUnsupported');
            var saveAsRadio = panel.add('radiobutton', undefined, getLabel('radio.saveAs'));
            saveAsRadio.helpTip = getLabel('tip.saveAs');
            var saveCopyRadio = panel.add('radiobutton', undefined, getLabel('radio.saveCopy'));
            // コピーは元ファイルのバイトコピーなので、.indd 以外だと中身と拡張子が食い違う
            saveCopyRadio.enabled = !!isNative;
            saveCopyRadio.helpTip = isNative ? getLabel('tip.saveCopy') : getLabel('tip.nonNativeUnsupported');
            // 初期選択は常に「別名で保存」
            renameRadio.value = false;
            saveAsRadio.value = true;
            saveCopyRadio.value = false;
            return {
                panel: panel,
                renameRadio: renameRadio,
                saveAsRadio: saveAsRadio,
                saveCopyRadio: saveCopyRadio,
                /* 現在選択中のモード（'rename' / 'saveAs' / 'copy'） / Currently selected mode */
                getMode: function () {
                    if (renameRadio.value) return 'rename';
                    if (saveCopyRadio.value) return 'copy';
                    return 'saveAs';
                }
            };
        }

        /**
         * ファイル名のパネルを組み立てる
         * @param {Group} parent 追加先のコンテナ
         * @param {string} currentName 現在のファイル名（拡張子込み）
         * @returns {object} パネル内のコントロールとラベル参照
         */
        function buildFilenamePanel(parent, currentName) {
            var panel = parent.add('panel', undefined, getLabel('panel.filename'));
            setupPanel(panel);

            var currentNameRow = panel.add('group');
            setupRow(currentNameRow);
            var currentNameLabel = currentNameRow.add('statictext', undefined, labelText('label.currentName'), { justify: 'right' });
            currentNameRow.add('statictext', undefined, currentName);

            var finalNameRow = panel.add('group');
            setupRow(finalNameRow);
            var finalNameLabel = finalNameRow.add('statictext', undefined, labelText('label.finalName'), { justify: 'right' });
            // 「変更後：」は statictext のためレイアウト後にサイズ固定。
            // 現在のファイル名と「入力フィールド + 余白」の大きい方を確保しておく
            var finalNameValue = finalNameRow.add('statictext', undefined, currentName);
            var currentNameWidth = panel.graphics.measureString(currentName).width;
            finalNameValue.preferredSize.width = Math.max(currentNameWidth + 20, 340);

            // 個別整列はせず、ラベル参照を呼び出し側に返し、後段で全パネル統一整列する
            return {
                panel: panel,
                finalNameValue: finalNameValue,
                labels: [currentNameLabel, finalNameLabel],
                labelTexts: [labelText('label.currentName'), labelText('label.finalName')]
            };
        }

        /**
         * セグメントごとのオプションパネルを組み立てる
         * @param {Group} parent 追加先のコンテナ
         * @param {array} segments セグメント配列
         * @param {object} prefs 保存しておいた設定
         * @param {string} parentFolderName 親フォルダー名
         * @param {string} grandparentFolderName 2 階層上のフォルダー名
         * @returns {object} パネル内のコントロールと取得関数
         */
        function buildOptionsPanel(parent, segments, prefs, parentFolderName, grandparentFolderName) {
            var panel = parent.add('panel', undefined, getLabel('panel.options'));
            setupPanel(panel);

            // ベース: 検出値を初期表示する入力欄。空欄可、prefs には保存しない
            var detectedBase = getFirstSegmentValue(segments, 'base');
            var baseRow = panel.add('group');
            setupRow(baseRow);
            var baseLabel = baseRow.add('statictext', undefined, labelText('label.base'));
            baseLabel.helpTip = getLabel('tip.base');
            var baseField = baseRow.add('edittext', undefined, detectedBase);
            baseField.preferredSize.width = NEW_NAME_FIELD_WIDTH;
            baseField.helpTip = getLabel('tip.base');

            // 元ファイル名のテキスト部（base / status / date / version 以外）をサブテキストとして検出
            var detectedTitle = getFirstSegmentValue(segments, 'text');

            // サブテキスト: 1 行目 = ラベル + 3 ラジオ、2 行目 = 「指定」用の入力欄
            var titleSection = panel.add('group');
            titleSection.orientation = 'column';
            titleSection.alignChildren = ['fill', 'top'];
            titleSection.spacing = 4;

            var titleRow = addRadioRow(titleSection, 'label.title', 'tip.title', [
                { key: 'none', text: getLabel('radio.titleNone') },
                { key: 'custom', text: getLabel('radio.titleCustom') },
                { key: 'parent', text: getLabel('radio.titleParent') },
                { key: 'grandparent', text: getLabel('radio.titleGrandparent') }
            ]);
            titleRow.group.alignment = ['left', 'top'];
            // 親/2 階層上のフォルダー名がある場合は helpTip にフォルダ名を追記、無ければ無効化
            if (parentFolderName) titleRow.radios.parent.helpTip = getLabel('tip.title') + ' (' + parentFolderName + ')';
            else titleRow.radios.parent.enabled = false;
            if (grandparentFolderName) titleRow.radios.grandparent.helpTip = getLabel('tip.title') + ' (' + grandparentFolderName + ')';
            else titleRow.radios.grandparent.enabled = false;

            // 「指定」用の入力欄は次の行（ラベル列幅だけ左に余白を入れて radios に揃える）
            var titleFieldRow = titleSection.add('group');
            setupRow(titleFieldRow, ['left', 'top']);
            var titleFieldSpacer = titleFieldRow.add('statictext', undefined, '');
            var titleField = titleFieldRow.add('edittext', undefined, detectedTitle);
            titleField.preferredSize.width = NEW_NAME_FIELD_WIDTH;
            titleField.helpTip = getLabel('tip.title');

            // 初期モード: 元ファイル名にサブテキストが無ければ「なし」を強制。
            // 検出できた場合は prefs.titleMode を優先、無ければ 'custom'（parent/grandparent は対応フォルダ名必須）
            var initialTitleMode = !detectedTitle ? 'none' :
                pickPref(prefs, 'titleMode', ['none', 'parent', 'grandparent', 'custom'], 'custom');
            if (initialTitleMode === 'parent' && !parentFolderName) {
                initialTitleMode = detectedTitle ? 'custom' : 'none';
            }
            if (initialTitleMode === 'grandparent' && !grandparentFolderName) {
                initialTitleMode = detectedTitle ? 'custom' : 'none';
            }
            titleRow.radios.none.value = (initialTitleMode === 'none');
            titleRow.radios.parent.value = (initialTitleMode === 'parent');
            titleRow.radios.grandparent.value = (initialTitleMode === 'grandparent');
            titleRow.radios.custom.value = (initialTitleMode === 'custom');
            titleField.enabled = (initialTitleMode === 'custom');

            /**
             * タイトルの指定方法に応じて入力欄の有効／無効を切り替える
             * @returns {void}
             */
            function syncTitleFieldEnabled() {
                titleField.enabled = titleRow.radios.custom.value;
            }

            // ステータス（dropdown。先頭は「なし」）
            var statusLabel = null, statusDropdown = null;
            if (FEATURE_STATUS) {
                var statusRow = panel.add('group');
                setupRow(statusRow);
                statusLabel = statusRow.add('statictext', undefined, labelText('label.status'));
                statusLabel.helpTip = getLabel('tip.status');
                statusDropdown = statusRow.add('dropdownlist', undefined, undefined);
                statusDropdown.helpTip = getLabel('tip.status');
                var parsedStatus = getFirstSegmentValue(segments, 'status');
                var initialStatus = parsedStatus || ((prefs && prefs.status) ? prefs.status : '');
                var initialStatusIdx = -1;
                for (var siItem = 0; siItem < STATUS_ITEMS.length; siItem++) {
                    var sItem = STATUS_ITEMS[siItem];
                    var ddItem = statusDropdown.add('item', (uiLang === 'ja' ? sItem.ja : sItem.en));
                    if (isStatusDivider(sItem)) {
                        ddItem.enabled = false;
                        continue;
                    }
                    if (initialStatusIdx === -1 && sItem.value === initialStatus) {
                        initialStatusIdx = siItem;
                    }
                }
                if (initialStatusIdx === -1) initialStatusIdx = 0;
                statusDropdown.selection = initialStatusIdx;
            }

            // タイムスタンプ（なし / YYYYMMDD / YYYY-MM-DD。デフォルト YYYYMMDD）
            // 末尾に「時刻も付与」(HHMM) チェックボックスを同居
            var timestampRow = addRadioRow(panel, 'label.timestamp', 'tip.timestamp', [
                { key: 'none', text: getLabel('radio.timestampNone') },
                { key: 'date', text: getLabel('radio.timestampDate') },
                { key: 'dateDash', text: getLabel('radio.timestampDateDash') }
            ]);
            var initialTimestamp = pickPref(prefs, 'timestamp', ['none', 'date', 'dateDash'], 'date');
            timestampRow.radios.none.value = (initialTimestamp === 'none');
            timestampRow.radios.date.value = (initialTimestamp === 'date');
            timestampRow.radios.dateDash.value = (initialTimestamp === 'dateDash');

            var timestampHHMMCheckbox = timestampRow.group.add('checkbox', undefined, getLabel('radio.timestampWithTime'));
            timestampHHMMCheckbox.helpTip = getLabel('tip.timestampWithTime');
            timestampHHMMCheckbox.value = pickPref(prefs, 'timestampTime', ['no', 'hhmm'], 'no') === 'hhmm';

            /**
             * 「時刻も付与」が ON なのにタイムスタンプが「なし」だと時刻はファイル名に出ない。
             * ON にした時点で YYYYMMDD を選び直す（明示的に「なし」へ戻すのは妨げない）
             * @returns {void}
             */
            function coerceTimestampForHHMM() {
                if (!timestampHHMMCheckbox.value) return;
                if (!timestampRow.radios.none.value) return;
                timestampRow.radios.none.value = false;
                timestampRow.radios.date.value = true;
            }
            coerceTimestampForHHMM();

            // 連番（チェックボックス + プレフィックス入力 + 桁数ラジオ）。デフォルト OFF / "page" / 2 桁
            // SEGMENT_ORDER 内では timestamp の後・version の前に配置
            var pageRow = null;
            var pageCheckbox = null;
            var pagePrefixField = null;
            var pagePadRadio2 = null;
            var pagePadRadio3 = null;
            if (FEATURE_PAGE) {
                pageRow = panel.add('group');
                setupRow(pageRow);
                var pageLabelCtrl = pageRow.add('statictext', undefined, labelText('label.page'));
                pageLabelCtrl.helpTip = getLabel('tip.page');
                pageCheckbox = pageRow.add('checkbox', undefined, getLabel('radio.pageEnable'));
                pageCheckbox.helpTip = getLabel('tip.page');
                pageCheckbox.value = pickPref(prefs, 'pageEnable', ['no', 'yes'], 'no') === 'yes';
                pagePrefixField = pageRow.add('edittext', undefined, '');
                pagePrefixField.preferredSize.width = 60;
                pagePrefixField.helpTip = getLabel('tip.page');
                pagePrefixField.text = (prefs && typeof prefs.pagePrefix === 'string') ? prefs.pagePrefix : 'page';
                pagePadRadio2 = pageRow.add('radiobutton', undefined, getLabel('radio.pagePad2'));
                pagePadRadio2.helpTip = getLabel('tip.page');
                pagePadRadio3 = pageRow.add('radiobutton', undefined, getLabel('radio.pagePad3'));
                pagePadRadio3.helpTip = getLabel('tip.page');
                var initialPagePad = pickPref(prefs, 'pagePad', ['2', '3'], '2');
                pagePadRadio2.value = (initialPagePad === '2');
                pagePadRadio3.value = (initialPagePad === '3');
                pageRow.label = pageLabelCtrl; // setLabelWidthsFromMeasuredText 用に統一形にしておく
            }

            /**
             * 連番の ON/OFF に応じて関連項目を切り替える
             * @returns {void}
             */
            function syncPageControlsEnabled() {
                if (!pageCheckbox) return;
                var enabled = pageCheckbox.value;
                if (pagePrefixField) pagePrefixField.enabled = enabled;
                if (pagePadRadio2) pagePadRadio2.enabled = enabled;
                if (pagePadRadio3) pagePadRadio3.enabled = enabled;
            }
            syncPageControlsEnabled();

            // バージョン番号（なし / v1, v2… / v01, v02… / v001, v002…。デフォルト v1, v2…）
            // ES3 で 'short' は予約語のため、ラジオキーは short_ にする（pref 値 'short' とは別物）
            var versionRow = addRadioRow(panel, 'label.version', 'tip.version', [
                { key: 'none', text: getLabel('radio.versionNone') },
                { key: 'short_', text: getLabel('radio.versionShort') },
                { key: 'padded', text: getLabel('radio.versionPadded') },
                { key: 'paddedWide', text: getLabel('radio.versionPaddedWide') }
            ]);
            // デフォルトは「なし」。元ファイルに v 番号がある場合は prefs を優先（無ければ「なし」）
            var hasOriginalVersion = !!getFirstSegmentValue(segments, 'version');
            var initialVersion = hasOriginalVersion
                ? pickPref(prefs, 'version', ['none', 'short', 'padded', 'paddedWide'], 'none')
                : 'none';
            versionRow.radios.none.value = (initialVersion === 'none');
            versionRow.radios.short_.value = (initialVersion === 'short');
            versionRow.radios.padded.value = (initialVersion === 'padded');
            versionRow.radios.paddedWide.value = (initialVersion === 'paddedWide');

            // 区切り記号（変更しない / - / _ 横並び。デフォルト "-"）
            var separatorRow = null;
            if (FEATURE_SEPARATOR) {
                separatorRow = addRadioRow(panel, 'label.separator', 'tip.separator', [
                    { key: 'noChange', text: getLabel('radio.noChange') },
                    { key: 'dash', text: '-' },
                    { key: 'underscore', text: '_' }
                ]);
                // prefs があればそれを優先、無ければ FEATURE_SEPARATOR の指定文字（'-' or '_'）を初期値に
                var defaultSeparator = (FEATURE_SEPARATOR === '_') ? '_' : '-';
                var initialSeparator = pickPref(prefs, 'separator', ['', '-', '_'], defaultSeparator);
                separatorRow.radios.noChange.value = (initialSeparator === '');
                separatorRow.radios.dash.value = (initialSeparator === '-');
                separatorRow.radios.underscore.value = (initialSeparator === '_');
            }

            // 濁点処理（変更しない / 結合する。デフォルト "結合する"）
            var nfcRow = null;
            if (FEATURE_NFC) {
                nfcRow = addRadioRow(panel, 'label.nfc', 'tip.nfc', [
                    { key: 'keep', text: getLabel('radio.noChange') },
                    { key: 'combine', text: getLabel('radio.nfcCombine') }
                ]);
                var initialNfc = pickPref(prefs, 'nfc', ['keep', 'combine'], 'combine');
                nfcRow.radios.keep.value = (initialNfc === 'keep');
                nfcRow.radios.combine.value = (initialNfc === 'combine');
            }

            // クリーンなファイル名（削除する / -に変更 / _に変更。デフォルト "-に変更"）
            // OS 禁止文字（\/:*?"<>|）と絵文字・機種依存文字をまとめて処理。
            // 末尾に「半角カナ → 全角」チェックボックスを同居（'-' / '_' のときだけ有効）
            var cleanRow = null;
            var halfwidthKanaCheckbox = null;
            if (FEATURE_CLEAN) {
                cleanRow = addRadioRow(panel, 'label.clean', 'tip.clean', [
                    { key: 'remove', text: getLabel('radio.cleanRemove') },
                    { key: 'dash', text: getLabel('radio.changeToDash') },
                    { key: 'underscore', text: getLabel('radio.changeToUnderscore') }
                ]);
                var initialClean = pickPref(prefs, 'clean', ['remove', 'dash', 'underscore'], 'dash');
                cleanRow.radios.remove.value = (initialClean === 'remove');
                cleanRow.radios.dash.value = (initialClean === 'dash');
                cleanRow.radios.underscore.value = (initialClean === 'underscore');

                if (FEATURE_HALFWIDTH_KANA) {
                    halfwidthKanaCheckbox = cleanRow.group.add('checkbox', undefined, getLabel('radio.halfwidthKanaConvert'));
                    halfwidthKanaCheckbox.helpTip = getLabel('tip.halfwidthKana');
                    halfwidthKanaCheckbox.value = pickPref(prefs, 'halfwidthKana', ['keep', 'convert'], 'convert') === 'convert';
                }
            }

            // 法人略記・丸数字（変更しない / 削除する / 変換する。デフォルト "変換する"）
            var translitRow = null;
            if (FEATURE_TRANSLITERATE) {
                translitRow = addRadioRow(panel, 'label.translit', 'tip.translit', [
                    { key: 'keep', text: getLabel('radio.noChange') },
                    { key: 'remove', text: getLabel('radio.translitRemove') },
                    { key: 'convert', text: getLabel('radio.translitConvert') }
                ]);
                var initialTranslit = pickPref(prefs, 'translit', ['keep', 'remove', 'convert'], 'convert');
                translitRow.radios.keep.value = (initialTranslit === 'keep');
                translitRow.radios.remove.value = (initialTranslit === 'remove');
                translitRow.radios.convert.value = (initialTranslit === 'convert');
            }

            // クリーンが '-' / '_' のときだけ「半角カナ → 全角」を有効化
            /**
             * 半角カナ変換の ON/OFF に応じて関連項目を切り替える
             * @returns {void}
             */
            function syncHalfwidthKanaEnabled() {
                if (!halfwidthKanaCheckbox || !cleanRow) return;
                halfwidthKanaCheckbox.enabled = (cleanRow.radios.dash.value || cleanRow.radios.underscore.value);
            }
            syncHalfwidthKanaEnabled();

            // ラベル幅を統一（FEATURE で UI 非表示の行は除外）
            var labelTexts = [labelText('label.base'), labelText('label.title')];
            var labelControls = [baseLabel, titleRow.label];
            if (FEATURE_STATUS) { labelTexts.push(labelText('label.status')); labelControls.push(statusLabel); }
            labelTexts.push(labelText('label.timestamp')); labelControls.push(timestampRow.label);
            if (FEATURE_PAGE) { labelTexts.push(labelText('label.page')); labelControls.push(pageRow.label); }
            labelTexts.push(labelText('label.version')); labelControls.push(versionRow.label);
            if (FEATURE_SEPARATOR) { labelTexts.push(labelText('label.separator')); labelControls.push(separatorRow.label); }
            if (FEATURE_NFC) { labelTexts.push(labelText('label.nfc')); labelControls.push(nfcRow.label); }
            if (FEATURE_CLEAN) { labelTexts.push(labelText('label.clean')); labelControls.push(cleanRow.label); }
            if (FEATURE_TRANSLITERATE) { labelTexts.push(labelText('label.translit')); labelControls.push(translitRow.label); }
            // 個別整列はせず、呼び出し側に渡してファイル名パネルと統一整列する
            // titleFieldSpacer の幅は createDialog 側で整列後に設定する

            return {
                panel: panel,
                baseField: baseField,
                titleRow: titleRow,
                titleField: titleField,
                titleFieldSpacer: titleFieldSpacer,
                syncTitleFieldEnabled: syncTitleFieldEnabled,
                labels: labelControls,
                labelTexts: labelTexts,
                statusDropdown: statusDropdown,
                timestampRow: timestampRow,
                timestampHHMMCheckbox: timestampHHMMCheckbox,
                coerceTimestampForHHMM: coerceTimestampForHHMM,
                pageCheckbox: pageCheckbox,
                pagePrefixField: pagePrefixField,
                pagePadRadio2: pagePadRadio2,
                pagePadRadio3: pagePadRadio3,
                syncPageControlsEnabled: syncPageControlsEnabled,
                versionRow: versionRow,
                separatorRow: separatorRow,
                nfcRow: nfcRow,
                cleanRow: cleanRow,
                halfwidthKanaCheckbox: halfwidthKanaCheckbox,
                translitRow: translitRow,
                syncHalfwidthKanaEnabled: syncHalfwidthKanaEnabled,
                /* '' = 変更しない、'-' / '_' = 統一。FEATURE_SEPARATOR=false なら常に '' */
                getSeparator: function () {
                    if (!separatorRow) return '';
                    if (separatorRow.radios.noChange.value) return '';
                    if (separatorRow.radios.dash.value) return '-';
                    return '_';
                },
                /* 'keep' = そのまま、'combine' = 濁点・半濁点を NFC 結合。FEATURE_NFC=false なら常に 'keep' */
                getNfc: function () {
                    if (!nfcRow) return 'keep';
                    return nfcRow.radios.keep.value ? 'keep' : 'combine';
                },
                /* 'remove' / 'dash' / 'underscore'。FEATURE_CLEAN=false なら常に '' を返す（無処理） */
                getClean: function () {
                    if (!cleanRow) return '';
                    if (cleanRow.radios.dash.value) return 'dash';
                    if (cleanRow.radios.underscore.value) return 'underscore';
                    return 'remove';
                },
                /* 'keep' = そのまま、'remove' = 削除、'convert' = TRANSLITERATE_MAP で変換。FEATURE_TRANSLITERATE=false なら常に 'keep' */
                getTranslit: function () {
                    if (!translitRow) return 'keep';
                    if (translitRow.radios.convert.value) return 'convert';
                    if (translitRow.radios.remove.value) return 'remove';
                    return 'keep';
                },
                /* 'keep' = そのまま、'convert' = 半角カナを全角カナに。FEATURE_HALFWIDTH_KANA=false なら常に 'keep' */
                getHalfwidthKana: function () {
                    if (!halfwidthKanaCheckbox) return 'keep';
                    return halfwidthKanaCheckbox.value ? 'convert' : 'keep';
                },
                /* 'none' / 'date' / 'dateDash' */
                getTimestamp: function () {
                    if (timestampRow.radios.none.value) return 'none';
                    if (timestampRow.radios.dateDash.value) return 'dateDash';
                    return 'date';
                },
                /* 'no' / 'hhmm'（時刻 HHMM をタイムスタンプ末尾に付与するか）*/
                getTimestampTime: function () {
                    return timestampHHMMCheckbox.value ? 'hhmm' : 'no';
                },
                /* 'no' / 'yes'（ページ番号セグメントを付与するか）。FEATURE_PAGE=false なら常に 'no' */
                getPageEnable: function () {
                    if (!pageCheckbox) return 'no';
                    return pageCheckbox.value ? 'yes' : 'no';
                },
                /* '2' / '3'（連番のゼロ埋め桁数）。FEATURE_PAGE=false なら '2' */
                getPagePad: function () {
                    if (!pagePadRadio3) return '2';
                    return pagePadRadio3.value ? '3' : '2';
                },
                /* 連番のプレフィックス（例: "page"）。FEATURE_PAGE=false なら '' */
                getPagePrefix: function () {
                    if (!pagePrefixField) return '';
                    return pagePrefixField.text;
                },
                /* STATUS_ITEMS の value（'' = なし）。FEATURE_STATUS=false なら常に '' */
                getStatus: function () {
                    if (!FEATURE_STATUS || !statusDropdown) return '';
                    var idx = statusDropdown.selection ? statusDropdown.selection.index : 0;
                    var item = STATUS_ITEMS[idx];
                    if (!item || isStatusDivider(item)) return '';
                    return item.value;
                },
                /* 'none' / 'short' / 'padded' / 'paddedWide' */
                getVersion: function () {
                    if (versionRow.radios.none.value) return 'none';
                    if (versionRow.radios.short_.value) return 'short';
                    if (versionRow.radios.padded.value) return 'padded';
                    return 'paddedWide';
                },
                /* 'none' / 'parent' / 'grandparent' / 'custom' */
                getTitleMode: function () {
                    if (titleRow.radios.none.value) return 'none';
                    if (titleRow.radios.parent.value) return 'parent';
                    if (titleRow.radios.grandparent.value) return 'grandparent';
                    return 'custom';
                },
                /* ベース入力欄の現在値 / Current value of the base input */
                getBase: function () {
                    return baseField.text;
                }
            };
        }

        /**
         * セグメントの並び替えダイアログを開く
         * @param {array} initialOrder 編集前の並び
         * @returns {array} 編集後の並び（キャンセル時は null）
         */
        function openSortDialog(initialOrder) {
            var dlg = new Window('dialog', getLabel('sort.title'));
            dlg.opacity = DIALOG_OPACITY;
            setupWindow(dlg, 10);

            var hint = dlg.add('statictext', undefined, getLabel('sort.hint'));
            hint.alignment = 'left';

            var body = dlg.add('group');
            setupRow(body, ['fill', 'fill']);
            body.alignChildren = ['fill', 'fill'];

            var order = initialOrder.slice();
            var list = body.add('listbox', undefined, []);
            list.preferredSize = [200, 140];
            for (var i = 0; i < order.length; i++) {
                list.add('item', getLabel('label.' + order[i]));
            }
            list.selection = 0;

            var btnCol = body.add('group');
            btnCol.orientation = 'column';
            btnCol.alignChildren = 'fill';
            var upBtn = btnCol.add('button', undefined, '↑');
            upBtn.preferredSize = [36, 24];
            var downBtn = btnCol.add('button', undefined, '↓');
            downBtn.preferredSize = [36, 24];

            /**
             * 並び替えダイアログのリスト表示を更新する
             * @param {number} newIdx 選択し直す位置
             * @returns {void}
             */
            function refreshList(newIdx) {
                for (var i = 0; i < order.length; i++) {
                    list.items[i].text = getLabel('label.' + order[i]);
                }
                list.selection = newIdx;
            }
            upBtn.onClick = function () {
                var idx = list.selection ? list.selection.index : -1;
                if (idx <= 0) return;
                var tmp = order[idx - 1];
                order[idx - 1] = order[idx];
                order[idx] = tmp;
                refreshList(idx - 1);
            };
            downBtn.onClick = function () {
                var idx = list.selection ? list.selection.index : -1;
                if (idx < 0 || idx >= order.length - 1) return;
                var tmp = order[idx + 1];
                order[idx + 1] = order[idx];
                order[idx] = tmp;
                refreshList(idx + 1);
            };

            var buttonRow = addButtonRow(dlg);
            var btnCancel = buttonRow.rightGroup.add('button', undefined, getLabel('button.cancel'), { name: 'cancel' });
            var btnOK = buttonRow.rightGroup.add('button', undefined, getLabel('button.ok'), { name: 'ok' });
            alignRightOnlyButtonRow(buttonRow);

            if (dlg.show() !== 1) return null;
            return order;
        }

        /**
         * 配列に値が含まれるかを判定する
         * @param {array} arr 探す配列
         * @param {string} val 探す値
         * @returns {boolean} 含まれていれば true
         */
        function arrayContains(arr, val) {
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] === val) return true;
            }
            return false;
        }

        /**
         * 保存された設定から値を取り出す（無ければ既定値）
         * @param {object} prefs 保存しておいた設定
         * @param {string} key 取り出すキー
         * @param {array} validValues 許可する値の一覧
         * @param {string} fallback 一覧に無いときの既定値
         * @returns {string} 採用する値
         */
        function pickPref(prefs, key, validValues, fallback) {
            var v = prefs && prefs[key];
            return arrayContains(validValues, v) ? v : fallback;
        }

        /**
         * 保存されたセグメント順の設定を配列へ変換する
         * @param {string} value カンマ区切りの並び順文字列
         * @returns {array} 並び順の配列（不正なら null）
         */
        function parseSegmentOrderPref(value) {
            if (!value) return null;
            var parts = String(value).split(',');
            if (parts.length !== SEGMENT_ORDER.length) return null;
            var seen = {};
            for (var i = 0; i < parts.length; i++) {
                var kind = parts[i];
                if (!arrayContains(SEGMENT_ORDER, kind) || seen[kind]) return null;
                seen[kind] = true;
            }
            return parts;
        }

        /**
         * ラベル文字列を measureString で測り、最も長い幅（＋余白）をすべてのコントロールに当てる
         * @param {Panel} panel 幅の計測に使うパネル
         * @param {array} labelTexts ラベル文字列の配列
         * @param {array} controls 幅を揃えるコントロールの配列
         * @returns {void}
         */
        function setLabelWidthsFromMeasuredText(panel, labelTexts, controls) {
            var graphics = panel.graphics;
            var maxWidth = 0;
            for (var i = 0; i < labelTexts.length; i++) {
                var width = graphics.measureString(labelTexts[i]).width;
                if (width > maxWidth) maxWidth = width;
            }
            maxWidth += 12;
            var needsIndicator = false;
            for (var k = 0; k < controls.length; k++) {
                if (controls[k].type === 'checkbox' || controls[k].type === 'radiobutton') {
                    needsIndicator = true;
                    break;
                }
            }
            if (needsIndicator) maxWidth += 20;
            for (var j = 0; j < controls.length; j++) {
                controls[j].preferredSize = [maxWidth, controls[j].preferredSize.height || 20];
            }
        }

        /**
         * ラベル付きのラジオボタン行を追加する
         * @param {Panel} panel 追加先のパネル
         * @param {string} labelKey ラベルのキー
         * @param {string} tipKey ヘルプチップのキー
         * @param {array} radioDefs {key, text} を要素とするラジオ定義
         * @returns {object} {group, label, radios}
         */
        function addRadioRow(panel, labelKey, tipKey, radioDefs) {
            var row = panel.add('group');
            setupRow(row);
            var tip = getLabel(tipKey);
            var label = row.add('statictext', undefined, labelText(labelKey));
            label.helpTip = tip;
            var radios = {};
            for (var i = 0; i < radioDefs.length; i++) {
                var def = radioDefs[i];
                var r = row.add('radiobutton', undefined, def.text);
                r.helpTip = tip;
                radios[def.key] = r;
            }
            return { group: row, label: label, radios: radios };
        }

        /**
         * コントロールの変更時にプレビューを更新するよう結び付ける
         * @param {function} callback 変更時に呼ぶコールバック
         * @param {array} controls 対象のコントロール配列（null は読み飛ばす）
         * @returns {void}
         */
        function wireRefresh(callback, controls) {
            for (var i = 0; i < controls.length; i++) {
                var c = controls[i];
                if (!c) continue;
                var t = c.type;
                if (t === 'radiobutton' || t === 'checkbox') c.onClick = callback;
                else if (t === 'edittext') c.onChanging = callback;
                else if (t === 'dropdownlist') c.onChange = callback;
            }
        }

        /**
         * ファイル名変更のダイアログを組み立てる
         * @param {array} segments セグメント配列
         * @param {string} currentName 現在のファイル名
         * @param {object} prefs 保存しておいた設定
         * @param {string} parentFolderName 親フォルダー名
         * @param {string} grandparentFolderName 2 階層上のフォルダー名
         * @param {Folder} folder 保存先フォルダー
         * @param {boolean} isNative 書類が .indd ネイティブか
         * @returns {object} {dialog, getUIState, getMode}
         */
        function createDialog(segments, currentName, prefs, parentFolderName, grandparentFolderName, folder, isNative) {
            var dialog = new Window('dialog', getLabel('dialog.title'));
            dialog.opacity = DIALOG_OPACITY;
            setupWindow(dialog, 10);

            // 上部: 動作パネル + モードパネル + ソートパネル（FEATURE_SORT=false ならソートパネル無し）
            var topRow = dialog.add('group');
            setupRow(topRow, ['fill', 'top'], COLUMN_SPACING);
            topRow.alignChildren = ['fill', 'top'];
            var mode = buildModePanel(topRow, isNative);
            var opMode = buildOpModePanel(topRow);
            // 現在のファイル名から検出した並び順（要素ゼロなら「現在に準じる」は無効化）
            var currentOrder = FEATURE_SORT ? deriveOrderFromSegments(segments) : [];
            var sort = FEATURE_SORT ? buildSortPanel(topRow, currentOrder.length > 0) : null;

            // 並び順カスタム値（prefs に保存されたものを採用、不正・未保存ならデフォルト）
            var customOrder = FEATURE_SORT
                ? (parseSegmentOrderPref(prefs && prefs.segmentOrder) || SEGMENT_ORDER.slice())
                : SEGMENT_ORDER.slice();

            var filename = buildFilenamePanel(dialog, currentName);
            var options = buildOptionsPanel(dialog, segments, prefs, parentFolderName, grandparentFolderName);

            // 2 つのパネルのラベル幅を統一整列（測定基準は options.panel）
            var combinedTexts = filename.labelTexts.concat(options.labelTexts);
            var combinedLabels = filename.labels.concat(options.labels);
            setLabelWidthsFromMeasuredText(options.panel, combinedTexts, combinedLabels);
            // サブテキスト 2 行目「指定」入力欄の左余白を統一後のラベル列幅に合わせる
            options.titleFieldSpacer.preferredSize = [options.titleRow.label.preferredSize.width, 1];

            // ---- ライブプレビュー ----
            /**
             * ダイアログの現在の状態を取得する
             * @returns {object} 現在の UI 状態
             */
            function currentUIState() {
                var sortMode = (FEATURE_SORT && sort) ? sort.getSortMode() : 'off';
                var segmentOrder;
                if (sortMode === 'on') segmentOrder = customOrder;
                else if (sortMode === 'current') segmentOrder = currentOrder;
                else segmentOrder = SEGMENT_ORDER;
                return {
                    opMode: opMode.getOpMode(),
                    baseText: options.getBase(),
                    titleMode: options.getTitleMode(),
                    titleText: options.titleField.text,
                    parentFolderName: parentFolderName,
                    grandparentFolderName: grandparentFolderName,
                    status: options.getStatus(),
                    timestamp: options.getTimestamp(),
                    timestampTime: options.getTimestampTime(),
                    pageEnable: options.getPageEnable(),
                    pagePad: options.getPagePad(),
                    pagePrefix: options.getPagePrefix(),
                    version: options.getVersion(),
                    separator: options.getSeparator(),
                    nfc: options.getNfc(),
                    translit: options.getTranslit(),
                    clean: options.getClean(),
                    halfwidthKana: options.getHalfwidthKana(),
                    sort: sortMode,
                    customSegmentOrder: customOrder.slice(),
                    segmentOrder: segmentOrder
                };
            }

            // 「バージョン番号のみ」モード時に隠す UI（ソート + ファイル名の設定）
            /**
             * 動作モードに応じて関連コントロールの表示を切り替える
             * @returns {void}
             */
            function syncOpModeVisibility() {
                var versionOnly = opMode.isVersionOnly();
                if (sort) sort.panel.visible = !versionOnly;
                options.panel.visible = !versionOnly;
                dialog.layout.layout(true);
                dialog.layout.resize();
            }

            /**
             * 現在の入力内容でファイル名のプレビューを更新する
             * @returns {void}
             */
            function refreshPreviews() {
                options.syncTitleFieldEnabled();
                options.syncHalfwidthKanaEnabled();
                options.syncPageControlsEnabled();
                // 「バージョンのみ」モードでは UI 整形を一切かけず、元ファイル名の v 番号だけ更新
                if (opMode.isVersionOnly()) {
                    var versionOnlyBase = bumpVersionInPlace(stripExtension(currentName));
                    versionOnlyBase = nextAvailableVersionName(versionOnlyBase, folder, '.indd');
                    filename.finalNameValue.text = versionOnlyBase + '.indd';
                    return;
                }
                var st = currentUIState();
                var finalBase = applyNameTransforms(buildFinalName(segments, st), st, folder, '.indd');
                filename.finalNameValue.text = finalBase ? (finalBase + '.indd') : getLabel('message.emptyName');
            }

            opMode.versionOnlyRadio.onClick = function () {
                syncOpModeVisibility();
                refreshPreviews();
            };
            opMode.fullRadio.onClick = function () {
                syncOpModeVisibility();
                refreshPreviews();
            };

            // ファイル名設定パネル内のすべての入力（無効化中の FEATURE は row が null で来るので skip される）
            var tr = options.titleRow, ts = options.timestampRow, vr = options.versionRow;
            var sr = options.separatorRow, nr = options.nfcRow, cr = options.cleanRow, lr = options.translitRow;

            // 構成要素（ベース／サブテキスト／ステータス／タイムスタンプ／バージョン）を変更したら、
            // 「現在のファイル名に準じる」は前提が崩れるので「標準順」に降格させる
            /**
             * 並び順の指定を既定へ戻す
             * @returns {void}
             */
            function demoteSortToDefault() {
                if (!sort) return;
                if (!sort.sortCurrentRadio.value) return;
                sort.selectSortMode('off');
            }
            /**
             * プレビューを更新し、必要なら並び順を既定へ戻す
             * @returns {void}
             */
            function refreshAndDemoteSort() {
                demoteSortToDefault();
                refreshPreviews();
            }

            // 構成要素を変える操作（「現在のファイル名に準じる」は解除）
            wireRefresh(refreshAndDemoteSort, [
                tr.radios.none, tr.radios.parent, tr.radios.grandparent, tr.radios.custom,
                options.baseField, options.titleField,
                options.statusDropdown,
                ts.radios.none, ts.radios.date, ts.radios.dateDash,
                options.pageCheckbox, options.pagePrefixField, options.pagePadRadio2, options.pagePadRadio3,
                vr.radios.none, vr.radios.short_, vr.radios.padded, vr.radios.paddedWide
            ]);
            // 「時刻も付与」だけは、ON にしたときタイムスタンプを YYYYMMDD に引き上げてから更新する
            options.timestampHHMMCheckbox.onClick = function () {
                options.coerceTimestampForHHMM();
                refreshAndDemoteSort();
            };

            // 整形のみ変える操作（並び順には影響しないので「現在のファイル名に準じる」を維持）
            wireRefresh(refreshPreviews, [
                sr && sr.radios.noChange, sr && sr.radios.dash, sr && sr.radios.underscore,
                nr && nr.radios.keep, nr && nr.radios.combine,
                cr && cr.radios.remove, cr && cr.radios.dash, cr && cr.radios.underscore,
                options.halfwidthKanaCheckbox,
                lr && lr.radios.keep, lr && lr.radios.remove, lr && lr.radios.convert
            ]);

            // ソートパネルの ON/OFF とサブダイアログ起動（FEATURE_SORT のとき）
            if (FEATURE_SORT && sort) {
                var onSortToggle = function (mode) {
                    return function () {
                        sort.selectSortMode(mode);
                        refreshPreviews();
                    };
                };
                sort.sortOffRadio.onClick = onSortToggle('off');
                sort.sortCurrentRadio.onClick = onSortToggle('current');
                sort.sortOnRadio.onClick = onSortToggle('on');
                sort.sortButton.onClick = function () {
                    var newOrder = openSortDialog(customOrder);
                    if (newOrder) {
                        customOrder = newOrder;
                        refreshPreviews();
                    }
                };
            }

            refreshPreviews();

            // ---- ボタン（キャンセル / OK） ----
            var buttonRow = addButtonRow(dialog);
            var btnCancel = buttonRow.rightGroup.add('button', undefined, getLabel('button.cancel'), { name: 'cancel' });
            var btnOK = buttonRow.rightGroup.add('button', undefined, getLabel('button.ok'), { name: 'ok' });
            alignRightOnlyButtonRow(buttonRow);

            return {
                dialog: dialog,
                getUIState: currentUIState,
                getMode: mode.getMode
            };
        }

        // =========================================
        // メイン / Main
        // =========================================

        /**
         * ドキュメントを検証し、ダイアログの指定に従って出力する
         * @returns {void}
         */
        function main() {
            if (app.documents.length === 0) {
                alert(getLabel('message.noDoc'));
                return;
            }

            var doc = app.activeDocument;
            var info = gatherDocumentInfo(doc);
            var segments = mergeFragmentedText(parseFileName(info.baseName));
            var prefs = loadPrefs();

            // 保存先はダイアログ表示前に確定する。未保存ドキュメントはここで保存先フォルダーを選択。
            // 同じフォルダーをプレビュー（連番/バージョンの繰り上げ）と実処理の両方で使い、両者を一致させる
            var targetFolder = ensureTargetFolder(info.folder);
            if (!targetFolder) return; // キャンセル

            var ui = createDialog(segments, info.currentName, prefs, info.parentFolderName, info.grandparentFolderName, targetFolder, isNativeDocument(info));
            addVersionFooter(ui.dialog);
            if (ui.dialog.show() !== 1) return; // キャンセル

            // プレビュー中はフォルダー列挙をキャッシュしている。実保存の採番は取り直した一覧で行う
            resetFolderFileNamesCache();

            var uiState = ui.getUIState();
            var newBaseName = (uiState.opMode === 'versionOnly')
                ? bumpVersionInPlace(info.baseName)
                : buildFinalName(segments, uiState);

            if (uiState.opMode === 'versionOnly') {
                // 「バージョンのみ」モードでは UI 整形をスキップして元ファイル名をそのまま尊重
                newBaseName = nextAvailableVersionName(newBaseName, targetFolder, '.indd');
            } else {
                newBaseName = applyNameTransforms(newBaseName, uiState, targetFolder, '.indd');
            }

            // 整形前だけでなく整形後も判定する。記号だけ・絵文字だけの名前は
            // clean / collapse を通ると空になり、そのままでは「.indd」という不可視ファイルになる
            if (!newBaseName) {
                alert(getLabel('message.emptyName'));
                return;
            }

            var destFile = File(targetFolder.fsName + '/' + newBaseName + '.indd');

            // 長さチェック（拡張子込み）: 上限超過なら確認ダイアログを出して続行可
            var fullByteLength = byteLengthUTF8(newBaseName + '.indd');
            if (fullByteLength > FEATURE_MAX_FILENAME_BYTES) {
                var msg = getLabel('message.confirmTooLong')
                    .replace('{bytes}', String(fullByteLength))
                    .replace('{limit}', String(FEATURE_MAX_FILENAME_BYTES));
                if (!confirm(msg + '\n\n' + newBaseName + '.indd')) return;
            }

            if (!confirmOverwriteIfExists(destFile, info.fsPath)) return;

            try {
                executeOutput(doc, destFile, ui.getMode(), info.fsPath);
                // 成功したら今回の選択をプリセットとして保存（versionOnly モードでは保存しない）
                if (uiState.opMode !== 'versionOnly') {
                    var prefsToSave = {
                        titleMode: uiState.titleMode,
                        timestamp: uiState.timestamp,
                        timestampTime: uiState.timestampTime,
                        version: uiState.version
                    };
                    if (FEATURE_PAGE) {
                        prefsToSave.pageEnable = uiState.pageEnable;
                        prefsToSave.pagePad = uiState.pagePad;
                        prefsToSave.pagePrefix = uiState.pagePrefix;
                    }
                    if (FEATURE_STATUS) prefsToSave.status = uiState.status;
                    if (FEATURE_SEPARATOR) prefsToSave.separator = uiState.separator;
                    if (FEATURE_NFC) prefsToSave.nfc = uiState.nfc;
                    if (FEATURE_CLEAN) prefsToSave.clean = uiState.clean;
                    if (FEATURE_HALFWIDTH_KANA && FEATURE_CLEAN) prefsToSave.halfwidthKana = uiState.halfwidthKana;
                    if (FEATURE_TRANSLITERATE) prefsToSave.translit = uiState.translit;
                    if (FEATURE_SORT) {
                        // sort モード自体は復元しない（毎回「現在のファイル名に準じる」を初期値）
                        prefsToSave.segmentOrder = uiState.customSegmentOrder.join(',');
                    }
                    savePrefs(prefsToSave);
                }
            } catch (e) {
                alert(getLabel('message.saveFailed') + '\n' + e);
            }
        }

        main();

    })();